"""
Builds admin.html and chat.html — runs AFTER dashboard.html is built.
Uses string concatenation to avoid Python f-string vs JSX brace conflicts.
"""
import pathlib

ROOT   = pathlib.Path(__file__).parent
ICONS  = (ROOT / "Icons.jsx").read_text()
BADGES = (ROOT / "Badges.jsx").read_text()
CSS    = (ROOT / "colors_and_type.css").read_text()

SHARED_TOP = (
    "<!DOCTYPE html>\n<html lang=\"en\" data-theme=\"dark\">\n<head>\n"
    "<meta charset=\"UTF-8\"/>\n"
    "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\"/>\n"
    "<link href=\"https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700"
    "&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap\" rel=\"stylesheet\"/>\n"
    "<script src=\"https://unpkg.com/react@18.3.1/umd/react.development.js\" crossorigin></script>\n"
    "<script src=\"https://unpkg.com/react-dom@18.3.1/umd/react-dom.development.js\" crossorigin></script>\n"
    "<script src=\"https://unpkg.com/@babel/standalone@7.29.0/babel.min.js\" crossorigin></script>\n"
    "<style>\n"
)

SHARED_STYLE_EXTRA = """
:root{--font-sans:'IBM Plex Sans','Segoe UI',sans-serif;--font-mono:'IBM Plex Mono',ui-monospace,monospace}
*{box-sizing:border-box;margin:0;padding:0}html,body,#root{height:100%;overflow:hidden}
body{background:var(--bg-app);font-family:var(--font-sans);font-size:13px;color:var(--fg-1)}
@keyframes pulse-dot{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.3;transform:scale(1.7)}}
@keyframes slide-up{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes bounce3{0%,80%,100%{opacity:.15}40%{opacity:1}}
.anim-up{animation:slide-up .2s ease both}
::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--gray-700);border-radius:3px}
.label{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--fg-3)}
.mono{font-family:var(--font-mono)}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
"""

SHARED_SCRIPT_OPEN = (
    "</style></head>\n<body><div id=\"root\"></div>\n"
    "<script type=\"text/babel\">\n"
)

SHARED_SCRIPT_CLOSE = (
    "\nReactDOM.createRoot(document.getElementById('root')).render(<App/>);\n"
    "</script></body></html>"
)

ADMIN_JSX = r"""
const {useState,useEffect,useRef} = React;
const API='http://localhost:8000/api', WS_URL='ws://localhost:8000/ws';
const ago=ts=>{if(!ts)return'—';const s=(Date.now()-new Date(ts))/1000;if(s<5)return'just now';if(s<60)return Math.round(s)+'s ago';if(s<3600)return Math.round(s/60)+'m ago';return Math.round(s/3600)+'h ago';};
const Dot=({color,size})=>{const c=color||'var(--success-500)',sz=size||7;return(<span style={{position:'relative',display:'inline-flex',width:sz,height:sz,flexShrink:0}}><span style={{position:'absolute',inset:0,borderRadius:'50%',background:c,animation:'pulse-dot 2s infinite'}}/><span style={{position:'relative',width:sz,height:sz,borderRadius:'50%',background:c}}/></span>);};
const Spin=({size})=>{const sz=size||13;return(<svg width={sz} height={sz} viewBox="0 0 24 24" fill="none" stroke="var(--accent-400)" strokeWidth="2.5" strokeLinecap="round" style={{animation:'spin .8s linear infinite',flexShrink:0}}><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>);};

const stCol={active:'var(--accent-400)',ok:'var(--success-500)',ready:'var(--info-400)',idle:'var(--fg-4)',err:'var(--critical-400)'};
const msgTypeColor={kpi_data:'var(--accent-400)',threshold_breach:'var(--warning-400)',correlation:'oklch(.72 .12 290)',remediation:'var(--success-500)',remediation_plan:'var(--success-500)',llm_response:'var(--critical-400)',engineer_query:'var(--fg-2)',ack:'var(--fg-3)'};

const agentDefs=[
  {id:'agent1',label:'KPI Collector',    icon:'Activity', out:'kpi_data',          color:'var(--accent-400)'},
  {id:'agent2',label:'Threshold Analyzer',icon:'Gauge',   out:'threshold_breach',  color:'var(--warning-400)'},
  {id:'agent3',label:'Syslog Correlator', icon:'Terminal',out:'correlation',        color:'oklch(.72 .12 290)'},
  {id:'agent4',label:'Remediation Engine',icon:'Book',    out:'remediation',        color:'var(--success-500)'},
  {id:'agent5',label:'ChatBot Notifier',  icon:'Bot',     out:'→ L2 Engineers',    color:'var(--critical-400)'},
];

function App() {
  const [agents,setAgents]   = useState({});
  const [msgs,setMsgs]       = useState([]);
  const [running,setRunning] = useState(false);
  const [lastRun,setLastRun] = useState(null);
  const [cycles,setCycles]   = useState(0);
  const [conn,setConn]       = useState(false);
  const [status,setStatus]   = useState({});
  const [tab,setTab]         = useState('pipeline');
  const [autoScroll,setAuto] = useState(true);
  const msgRef = useRef(null);
  const wsRef  = useRef(null);

  useEffect(()=>{fetch(`${API}/status`).then(r=>r.json()).then(setStatus).catch(()=>{});},[]);

  useEffect(()=>{
    const connect=()=>{
      const ws=new WebSocket(WS_URL); wsRef.current=ws;
      ws.onopen=()=>{setConn(true); const hb=setInterval(()=>{if(ws.readyState===1)ws.send(JSON.stringify({action:'ping'}));},20000); ws._hb=hb;};
      ws.onmessage=e=>{
        const {type,data}=JSON.parse(e.data);
        if(type==='init'){setAgents(data.agent_statuses||{});setMsgs(data.mcp_messages||[]);setRunning(data.pipeline_running||false);}
        if(type==='agent_status')setAgents(p=>({...p,[data.agent]:data.status}));
        if(type==='mcp_message')setMsgs(p=>[...p.slice(-500),{...data,time:new Date().toLocaleTimeString()}]);
        if(type==='pipeline_status'){setRunning(data.running);if(!data.running&&data.last_run_at){setLastRun(data.last_run_at);setCycles(data.cycle||0);}}
        if(type==='init'){setStatus(prev=>({...prev,...(data.status||{})}));}
      };
      ws.onclose=()=>{setConn(false);clearInterval(ws._hb);setTimeout(connect,3000);};
      ws.onerror=()=>ws.close();
    };
    connect(); return()=>wsRef.current?.close();
  },[]);

  useEffect(()=>{if(autoScroll&&msgRef.current)msgRef.current.scrollTo({top:1e9,behavior:'smooth'});},[msgs,autoScroll]);

  const run=()=>{
    if(wsRef.current?.readyState===1)wsRef.current.send(JSON.stringify({action:'run_pipeline'}));
    else fetch(`${API}/pipeline/run`,{method:'POST'}).catch(()=>{});
  };

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100vh'}}>
      <div style={{height:48,display:'flex',alignItems:'center',gap:12,padding:'0 16px',background:'var(--surface-0)',borderBottom:'1px solid var(--border)',flexShrink:0}}>
        <img src="/assets/logo-mark.svg" width="24" height="24" alt=""/>
        <span style={{fontFamily:'var(--font-mono)',fontSize:14,fontWeight:700}}>VINGC Admin</span>
        <span style={{fontFamily:'var(--font-mono)',fontSize:11,color:'var(--fg-4)'}}>pipeline & mcp inspector</span>
        <div style={{flex:1}}/>
        <Dot color={conn?'var(--success-500)':'var(--critical-500)'} size={7}/>
        <span style={{fontFamily:'var(--font-mono)',fontSize:11,color:'var(--fg-3)'}}>{conn?'live':'offline'}</span>
      </div>

      <div style={{display:'flex',borderBottom:'1px solid var(--border)',background:'var(--surface-0)',flexShrink:0}}>
        {[['pipeline','Pipeline'],['mcp','MCP Bus']].map(([id,lbl])=>(
          <button key={id} onClick={()=>setTab(id)} style={{all:'unset',cursor:'pointer',padding:'10px 18px',fontSize:13,fontWeight:tab===id?600:500,color:tab===id?'var(--fg-1)':'var(--fg-3)',borderBottom:tab===id?'2px solid var(--accent-500)':'2px solid transparent',marginBottom:-1}}>
            {lbl}
          </button>
        ))}
      </div>

      <div style={{flex:1,overflow:'auto',padding:16}}>
        {tab==='pipeline' && (
          <div style={{display:'flex',flexDirection:'column',gap:14}}>
            <div style={{display:'flex',alignItems:'center',gap:12}}>
              <h2 style={{fontSize:16,fontWeight:700}}>Agent Pipeline Status</h2>
              <div style={{flex:1}}/>
              <span style={{fontFamily:'var(--font-mono)',fontSize:11,color:'var(--fg-3)'}}>cycle #{cycles} · {lastRun?ago(lastRun):'never'}</span>
              <button onClick={run} disabled={running} style={{all:'unset',cursor:running?'wait':'pointer',display:'inline-flex',alignItems:'center',gap:6,padding:'7px 14px',fontSize:12,fontWeight:700,borderRadius:'var(--r-sm)',background:running?'var(--surface-2)':'var(--accent-500)',color:running?'var(--fg-4)':'var(--fg-on-accent)'}}>
                {running?<><Spin size={12}/> Running…</>:<><Icons.Play size={12}/> Trigger Pipeline</>}
              </button>
            </div>

            <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:10}}>
              {agentDefs.map((a,i)=>{
                const I=Icons[a.icon]; const st=agents[a.id]||'ready'; const col=stCol[st]||'var(--fg-3)';
                return (
                  <div key={a.id} className="anim-up" style={{animationDelay:`${i*.05}s`,background:'var(--surface-1)',border:`1px solid ${st==='active'?a.color:'var(--border)'}`,borderRadius:'var(--r-md)',padding:16,boxShadow:st==='active'?`0 0 12px -4px ${a.color}44`:'none'}}>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
                      <I size={18} color={st==='active'?a.color:col}/><Dot color={col} size={7}/>
                    </div>
                    <div style={{fontFamily:'var(--font-mono)',fontSize:10,color:'var(--fg-4)',marginBottom:2}}>{a.id}</div>
                    <div style={{fontWeight:700,fontSize:14,color:'var(--fg-1)',marginBottom:6}}>{a.label}</div>
                    <div style={{fontFamily:'var(--font-mono)',fontSize:10,color:col,padding:'2px 6px',background:`color-mix(in oklch,${col},transparent 88%)`,border:`1px solid color-mix(in oklch,${col},transparent 70%)`,borderRadius:2,display:'inline-block',marginBottom:10}}>{st}</div>
                    <div style={{fontSize:11,color:'var(--fg-3)'}}>out: <span style={{color:'var(--fg-2)',fontFamily:'var(--font-mono)'}}>{a.out}</span></div>
                    {i<4 && <div style={{marginTop:12,textAlign:'center',color:'var(--fg-4)',fontSize:11,fontFamily:'var(--font-mono)'}}>↓ MCP bus ↓</div>}
                  </div>
                );
              })}
            </div>

            <div style={{background:'var(--surface-1)',border:'1px solid var(--border)',borderRadius:'var(--r-md)',padding:16}}>
              <div className="label" style={{marginBottom:12}}>System Status</div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:14}}>
                {[['Pipeline Running',running?'YES':'NO',running?'var(--accent-400)':'var(--success-500)'],
                  ['Active Incidents',status.active_incidents||0,'var(--fg-1)'],
                  ['Open Incidents',status.open_incidents||0,status.open_incidents>0?'var(--critical-400)':'var(--success-500)'],
                  ['MCP Messages',status.mcp_message_count||0,'var(--fg-1)'],
                  ['Claude API',status.anthropic_key_set?'KEY SET ✓':'NOT SET',status.anthropic_key_set?'var(--success-500)':'var(--warning-400)'],
                  ['Pipeline Cycles',cycles,'var(--accent-400)'],
                ].map(([l,v,c])=>(
                  <div key={l}>
                    <div className="label" style={{marginBottom:5}}>{l}</div>
                    <div style={{fontFamily:'var(--font-mono)',fontSize:16,fontWeight:700,color:c}}>{String(v)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab==='mcp' && (
          <div style={{display:'flex',flexDirection:'column',gap:12,height:'calc(100vh - 120px)'}}>
            <div style={{display:'flex',alignItems:'center',gap:10,flexShrink:0}}>
              <h2 style={{fontSize:16,fontWeight:700}}>MCP Bus — Live Message Stream</h2>
              <Badge variant="neutral">{msgs.length} messages</Badge>
              <div style={{flex:1}}/>
              <label style={{display:'flex',alignItems:'center',gap:6,fontSize:12,color:'var(--fg-2)',cursor:'pointer'}}>
                <input type="checkbox" checked={autoScroll} onChange={e=>setAuto(e.target.checked)} style={{accentColor:'var(--accent-500)'}}/>
                Auto-scroll
              </label>
              <button onClick={()=>setMsgs([])} style={{all:'unset',cursor:'pointer',padding:'5px 10px',fontSize:11,fontWeight:600,border:'1px solid var(--border)',borderRadius:'var(--r-sm)',color:'var(--fg-3)'}}>Clear</button>
            </div>

            <div ref={msgRef} style={{flex:1,overflow:'auto',fontFamily:'var(--font-mono)',fontSize:12,background:'var(--surface-0)',border:'1px solid var(--border)',borderRadius:'var(--r-md)',padding:10}}>
              {msgs.length===0&&<div style={{padding:20,color:'var(--fg-4)',textAlign:'center'}}>Waiting for pipeline messages…<br/>Click "Trigger Pipeline" on the Pipeline tab.</div>}
              {msgs.map((m,i)=>{
                const col=msgTypeColor[m.type]||'var(--fg-3)';
                return (
                  <div key={i} style={{display:'flex',gap:10,padding:'5px 8px',borderBottom:'1px solid var(--border)',alignItems:'flex-start',background:i%2?'transparent':'rgba(255,255,255,.015)'}}>
                    <span style={{color:'var(--fg-4)',flexShrink:0,width:75,fontSize:11}}>{m.time||'—'}</span>
                    <span style={{color:'var(--fg-4)',flexShrink:0,width:56,fontSize:11}}>#{(m.id||'').slice(0,6)}</span>
                    <span style={{color:'var(--accent-400)',fontWeight:600,flexShrink:0,width:70}}>{m.sender||'—'}</span>
                    <span style={{color:'var(--fg-4)',flexShrink:0}}>→</span>
                    <span style={{color:'var(--fg-2)',flexShrink:0,width:70}}>{m.receiver||'—'}</span>
                    <span style={{color:col,fontWeight:600,flexShrink:0,width:120,padding:'1px 5px',background:`color-mix(in oklch,${col},transparent 88%)`,borderRadius:2,border:`1px solid color-mix(in oklch,${col},transparent 70%)`}}>{m.type}</span>
                    <span style={{color:'var(--fg-3)',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{m.preview||''}</span>
                  </div>
                );
              })}
            </div>

            <div style={{display:'flex',gap:6,flexWrap:'wrap',flexShrink:0}}>
              {Object.entries(msgTypeColor).map(([t,c])=>(
                <span key={t} style={{fontFamily:'var(--font-mono)',fontSize:10,padding:'2px 7px',background:`color-mix(in oklch,${c},transparent 88%)`,color:c,border:`1px solid color-mix(in oklch,${c},transparent 70%)`,borderRadius:2}}>{t}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
"""

CHAT_JSX = r"""
const {useState,useEffect,useRef} = React;
const API='http://localhost:8000/api', WS_URL='ws://localhost:8000/ws';
const ago=ts=>{if(!ts)return'—';const s=(Date.now()-new Date(ts))/1000;if(s<5)return'just now';if(s<60)return Math.round(s)+'s ago';if(s<3600)return Math.round(s/60)+'m ago';return Math.round(s/3600)+'h ago';};
const Dot=({color,size})=>{const c=color||'var(--success-500)',sz=size||7;return(<span style={{position:'relative',display:'inline-flex',width:sz,height:sz,flexShrink:0}}><span style={{position:'absolute',inset:0,borderRadius:'50%',background:c,animation:'pulse-dot 2s infinite'}}/><span style={{position:'relative',width:sz,height:sz,borderRadius:'50%',background:c}}/></span>);};
const stCol={active:'var(--accent-400)',ok:'var(--success-500)',ready:'var(--info-400)',idle:'var(--fg-4)'};
const msgTypeColor={kpi_data:'var(--accent-400)',threshold_breach:'var(--warning-400)',correlation:'oklch(.72 .12 290)',remediation:'var(--success-500)',engineer_query:'var(--fg-2)',llm_response:'var(--critical-400)',ack:'var(--fg-4)'};
const agentDefs=[{id:'agent1',icon:'Activity'},{id:'agent2',icon:'Gauge'},{id:'agent3',icon:'Terminal'},{id:'agent4',icon:'Book'},{id:'agent5',icon:'Bot'}];
const suggestions=["What is the root cause?","Show oc commands to run","Which UPF is affected?","Is the UDR incident related?","How long to resolve?"];

function App() {
  const incId = new URLSearchParams(window.location.search).get('incident');
  const [incidents,setIncidents] = useState([]);
  const [selId,setSelId]         = useState(incId||null);
  const [msgs,setMsgs]           = useState([]);
  const [input,setInput]         = useState('');
  const [typing,setTyping]       = useState(false);
  const [acked,setAcked]         = useState(false);
  const [mcpMsgs,setMcpMsgs]    = useState([]);
  const [agents,setAgents]       = useState({});
  const [conn,setConn]           = useState(false);
  const scrollRef = useRef(null);
  const wsRef     = useRef(null);

  const selInc = incidents.find(i=>i.id===selId)||null;

  useEffect(()=>{
    fetch(`${API}/incidents`).then(r=>r.json()).then(d=>{
      const incs=d.incidents||[]; setIncidents(incs);
      if(!selId&&incs.length) setSelId(incs[0].id);
    }).catch(()=>{});
  },[]);

  useEffect(()=>{
    const connect=()=>{
      const ws=new WebSocket(WS_URL); wsRef.current=ws;
      ws.onopen=()=>{setConn(true);};
      ws.onmessage=e=>{
        const {type,data}=JSON.parse(e.data);
        if(type==='init'){setMcpMsgs(data.mcp_messages||[]);setAgents(data.agent_statuses||{});
          if(data.incidents?.length){setIncidents(data.incidents);if(!selId)setSelId(data.incidents[0]?.id);}}
        if(type==='new_incident')setIncidents(p=>{const e=p.find(i=>i.id===data.id);return e?p.map(i=>i.id===data.id?data:i):[data,...p];});
        if(type==='incident_acked'&&data.incident_id===selId)setAcked(true);
        if(type==='mcp_message')setMcpMsgs(p=>[...p.slice(-199),{...data,time:new Date().toLocaleTimeString()}]);
        if(type==='agent_status')setAgents(p=>({...p,[data.agent]:data.status}));
      };
      ws.onclose=()=>{setConn(false);setTimeout(connect,3000);};
      ws.onerror=()=>ws.close();
    };
    connect(); return()=>wsRef.current?.close();
  },[]);

  useEffect(()=>{if(selInc)setAcked(selInc.acked||false);},[selInc]);
  useEffect(()=>{scrollRef.current?.scrollTo({top:1e9,behavior:'smooth'});},[msgs,typing]);

  const ack=async()=>{
    if(!selInc||acked)return;
    await fetch(`${API}/incidents/${selInc.id}/ack`,{method:'POST'}).catch(()=>{});
    setAcked(true); setMsgs(m=>[...m,{role:'system',text:'Incident acknowledged — L2 assistant unlocked'}]);
  };

  const send=async()=>{
    if(!input.trim()||!acked||!selInc)return;
    const q=input.trim(); setInput('');
    setMsgs(m=>[...m,{role:'user',text:q,time:new Date().toLocaleTimeString()}]);
    setTyping(true);
    try{
      const r=await fetch(`${API}/chat`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({incident_id:selInc.id,message:q})});
      const d=await r.json();
      setMsgs(m=>[...m,{role:'assistant',text:d.reply,model:d.model,time:new Date().toLocaleTimeString()}]);
    }catch{setMsgs(m=>[...m,{role:'assistant',text:'API error — is the server running on port 8000?'}]);}
    finally{setTyping(false);}
  };

  return (
    <div style={{display:'flex',height:'100vh',overflow:'hidden'}}>
      {/* Left: channel list + MCP mini */}
      <div style={{width:250,minWidth:250,display:'flex',flexDirection:'column',background:'var(--surface-0)',borderRight:'1px solid var(--border)'}}>
        <div style={{height:48,display:'flex',alignItems:'center',gap:10,padding:'0 12px',borderBottom:'1px solid var(--border)'}}>
          <img src="/assets/logo-mark.svg" width="22" height="22" alt=""/>
          <span style={{fontFamily:'var(--font-mono)',fontSize:13,fontWeight:700}}>L2 Chat</span>
          <div style={{flex:1}}/><Dot color={conn?'var(--success-500)':'var(--critical-500)'} size={6}/>
        </div>
        <div style={{flex:1,overflowY:'auto',padding:'6px 8px'}}>
          <div className="label" style={{padding:'6px 8px 4px'}}>Incidents</div>
          {incidents.length===0&&<div style={{padding:'10px 10px',fontSize:12,color:'var(--fg-3)'}}>No incidents yet. Go to the dashboard and click Run Now.</div>}
          {incidents.map(inc=>(
            <div key={inc.id} onClick={()=>setSelId(inc.id)} style={{cursor:'pointer',padding:'9px 10px',borderRadius:'var(--r-sm)',marginBottom:3,background:selId===inc.id?'color-mix(in oklch,var(--accent-500),transparent 88%)':'transparent',border:selId===inc.id?'1px solid color-mix(in oklch,var(--accent-500),transparent 70%)':'1px solid transparent'}}>
              <div style={{display:'flex',gap:4,marginBottom:3,alignItems:'center'}}>
                <PriorityBadge priority={inc.priority}/>
                {!inc.acked&&<Dot color="var(--critical-400)" size={5}/>}
              </div>
              <div className="mono" style={{fontSize:9,color:'var(--accent-400)',marginBottom:2}}>{inc.id}</div>
              <div style={{fontSize:11,fontWeight:600,color:'var(--fg-1)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{inc.title}</div>
            </div>
          ))}
        </div>
        {/* Agent dots */}
        <div style={{borderTop:'1px solid var(--border)',padding:'8px 12px'}}>
          <div className="label" style={{marginBottom:6}}>Agents</div>
          <div style={{display:'flex',gap:8}}>
            {agentDefs.map(a=>{const I=Icons[a.icon];const st=agents[a.id]||'ready';const col=stCol[st]||'var(--fg-3)';return(<div key={a.id} title={`${a.id}: ${st}`} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:3}}><I size={13} color={col}/><Dot color={col} size={4}/></div>);
            })}
          </div>
        </div>
        {/* Live MCP last 5 */}
        <div style={{borderTop:'1px solid var(--border)',padding:'6px 8px',display:'flex',flexDirection:'column',gap:3,maxHeight:160,overflowY:'auto'}}>
          <div className="label" style={{padding:'0 4px 4px'}}>MCP Recent</div>
          {[...mcpMsgs].reverse().slice(0,8).map((m,i)=>{
            const col=msgTypeColor[m.type]||'var(--fg-3)';
            return(<div key={i} style={{padding:'3px 6px',background:'var(--surface-1)',border:'1px solid var(--border)',borderRadius:'var(--r-sm)'}}>
              <div style={{display:'flex',gap:4,alignItems:'center'}}>
                <span className="mono" style={{fontSize:9,color:'var(--accent-400)'}}>{m.sender}</span>
                <span style={{fontSize:9,color:'var(--fg-4)'}}>→</span>
                <span className="mono" style={{fontSize:9,color:'var(--fg-3)'}}>{m.receiver}</span>
                <span style={{marginLeft:'auto',fontSize:9,padding:'1px 4px',background:`color-mix(in oklch,${col},transparent 85%)`,color:col,borderRadius:2}}>{m.type}</span>
              </div>
            </div>);
          })}
        </div>
      </div>

      {/* Right: chat */}
      <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
        {/* Header */}
        {selInc ? (
          <div style={{height:48,display:'flex',alignItems:'center',gap:10,padding:'0 16px',background:'var(--surface-0)',borderBottom:'1px solid var(--border)',flexShrink:0}}>
            <Icons.AlertOct size={15} color={selInc.priority==='P1'?'var(--critical-400)':'var(--warning-400)'}/>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontWeight:600,fontSize:13,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{selInc.title}</div>
              <div className="mono" style={{fontSize:9,color:'var(--fg-3)'}}>{selInc.id} · {selInc.priority} · {(selInc.nfs||[]).join(', ')}</div>
            </div>
            <PriorityBadge priority={selInc.priority}/>
            {acked ? <Badge variant="success">ACKED</Badge> : (
              <button onClick={ack} style={{all:'unset',cursor:'pointer',padding:'5px 12px',fontSize:11,fontWeight:700,borderRadius:'var(--r-sm)',background:'var(--accent-500)',color:'var(--fg-on-accent)',display:'inline-flex',alignItems:'center',gap:5}}>
                <Icons.Check size={11}/> Acknowledge
              </button>
            )}
            <a href="/admin" target="_blank" title="Open Admin" style={{all:'unset',cursor:'pointer',color:'var(--fg-3)',display:'flex',alignItems:'center',padding:4}}><Icons.ExternalLink size={13}/></a>
          </div>
        ) : (
          <div style={{height:48,display:'flex',alignItems:'center',padding:'0 16px',background:'var(--surface-0)',borderBottom:'1px solid var(--border)',color:'var(--fg-3)',fontSize:13}}>
            Select an incident from the left panel
          </div>
        )}

        {/* Messages */}
        <div ref={scrollRef} style={{flex:1,overflowY:'auto',padding:'14px 20px',display:'flex',flexDirection:'column',gap:10}}>
          {selInc&&!acked&&(
            <div style={{padding:'10px 14px',background:'color-mix(in oklch,var(--warning-500),transparent 88%)',border:'1px solid color-mix(in oklch,var(--warning-500),transparent 60%)',borderRadius:'var(--r-md)',fontSize:12,display:'flex',alignItems:'center',gap:8}}>
              <Icons.AlertTri size={13} color="var(--warning-400)"/>
              Acknowledge the incident above to unlock the L2 assistant and start chatting.
            </div>
          )}
          {msgs.map((m,i)=>{
            if(m.role==='system')return(<div key={i} style={{textAlign:'center',fontSize:11,color:'var(--fg-3)',fontFamily:'var(--font-mono)',padding:'4px 0',borderTop:'1px solid var(--border)',borderBottom:'1px solid var(--border)'}}>{m.text}</div>);
            const isUser=m.role==='user';
            return(
              <div key={i} style={{display:'flex',gap:8,flexDirection:isUser?'row-reverse':'row'}}>
                <div style={{width:26,height:26,borderRadius:'50%',flexShrink:0,background:isUser?'var(--surface-2)':'color-mix(in oklch,var(--accent-500),transparent 80%)',border:'1px solid var(--border)',display:'grid',placeItems:'center',fontFamily:'var(--font-mono)',fontSize:10,fontWeight:700,color:isUser?'var(--fg-2)':'var(--accent-400)'}}>
                  {isUser?'KM':<Icons.Bot size={13}/>}
                </div>
                <div style={{maxWidth:'72%',display:'flex',flexDirection:'column',gap:3,alignItems:isUser?'flex-end':'flex-start'}}>
                  <div style={{fontSize:10,color:'var(--fg-3)',fontFamily:'var(--font-mono)',display:'flex',gap:8}}>
                    <span style={{color:isUser?'var(--fg-2)':'var(--accent-400)',fontWeight:700}}>{isUser?'k.mishra':'l2_assistant'}</span>
                    {m.time&&<span>{m.time}</span>}
                    {m.model&&<span style={{color:'var(--fg-4)'}}>{m.model}</span>}
                  </div>
                  <div style={{padding:'9px 12px',lineHeight:1.55,fontSize:13,background:isUser?'color-mix(in oklch,var(--accent-500),transparent 88%)':'var(--surface-1)',border:isUser?'1px solid color-mix(in oklch,var(--accent-500),transparent 70%)':'1px solid var(--border)',borderRadius:'var(--r-md)',color:'var(--fg-1)',whiteSpace:'pre-wrap',wordBreak:'break-word'}}>
                    {m.text}
                  </div>
                </div>
              </div>
            );
          })}
          {typing&&<div style={{display:'flex',gap:8}}>
            <div style={{width:26,height:26,borderRadius:'50%',background:'color-mix(in oklch,var(--accent-500),transparent 80%)',border:'1px solid var(--border)',display:'grid',placeItems:'center',color:'var(--accent-400)'}}><Icons.Bot size={13}/></div>
            <div style={{padding:'10px 14px',background:'var(--surface-1)',border:'1px solid var(--border)',borderRadius:'var(--r-md)'}}>
              <div style={{display:'flex',gap:3}}>
                {[0,1,2].map(j=><span key={j} style={{width:5,height:5,borderRadius:'50%',background:'var(--fg-3)',animation:`bounce3 1.2s ${j*.15}s infinite ease-in-out`,display:'block'}}/>)}
              </div>
            </div>
          </div>}
        </div>

        {/* Composer */}
        <div style={{padding:'10px 14px',borderTop:'1px solid var(--border)',background:'var(--surface-0)',flexShrink:0}}>
          <div style={{display:'flex',flexWrap:'wrap',gap:5,marginBottom:8}}>
            {suggestions.map(s=><button key={s} onClick={()=>setInput(s)} disabled={!acked} style={{all:'unset',cursor:acked?'pointer':'not-allowed',padding:'3px 8px',fontSize:11,background:'var(--surface-1)',border:'1px solid var(--border)',color:acked?'var(--fg-2)':'var(--fg-4)',borderRadius:'var(--r-sm)',opacity:acked?1:.5}}>{s}</button>)}
          </div>
          <div style={{display:'flex',gap:8,padding:'7px 10px',background:'var(--surface-1)',border:'1px solid var(--border)',borderRadius:'var(--r-md)'}}>
            <textarea value={input} rows={1} disabled={!acked}
              onChange={e=>{setInput(e.target.value);e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,120)+'px';}}
              onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}}}
              placeholder={acked?"Ask about this incident…":"Acknowledge first to chat…"}
              style={{all:'unset',flex:1,fontSize:13,fontFamily:'var(--font-sans)',color:'var(--fg-1)',lineHeight:1.5,resize:'none',minHeight:20,opacity:acked?1:.5}}/>
            <button onClick={send} disabled={!input.trim()||!acked} style={{all:'unset',cursor:input.trim()&&acked?'pointer':'not-allowed',display:'grid',placeItems:'center',width:30,height:26,borderRadius:'var(--r-sm)',background:input.trim()&&acked?'var(--accent-500)':'var(--surface-2)',color:input.trim()&&acked?'var(--fg-on-accent)':'var(--fg-4)'}}>
              <Icons.Send size={13}/>
            </button>
          </div>
          <div style={{display:'flex',justifyContent:'space-between',marginTop:5,fontFamily:'var(--font-mono)',fontSize:10,color:'var(--fg-4)'}}>
            <span>model: claude-sonnet-4 · incident + kb context</span>
            <span>Enter to send · Shift+Enter newline</span>
          </div>
        </div>
      </div>
    </div>
  );
}
"""

def build(title, jsx_body, out_name):
    html = (
        SHARED_TOP.replace("{title}", title) +
        CSS +
        SHARED_STYLE_EXTRA +
        "</style>\n" +
        SHARED_SCRIPT_OPEN +
        ICONS + "\n" +
        BADGES + "\n" +
        jsx_body +
        SHARED_SCRIPT_CLOSE
    )
    path = ROOT / out_name
    path.write_text(html, encoding='utf-8')
    print(f"  {out_name}  {path.stat().st_size//1024} KB")

print("Building pages...")
build("VINGC Admin — Pipeline & MCP Inspector", ADMIN_JSX, "admin.html")
build("VINGC L2 Chat — Incident Assistant",      CHAT_JSX,  "chat.html")

# Add bounce3 to admin.html too
for fn in ["admin.html", "chat.html"]:
    p = ROOT / fn
    t = p.read_text()
    if "@keyframes bounce3" not in t:
        t = t.replace("@keyframes spin{to{transform:rotate(360deg)}}", 
                      "@keyframes spin{to{transform:rotate(360deg)}}\n@keyframes bounce3{0%,80%,100%{opacity:.15}40%{opacity:1}}")
        p.write_text(t)

print("Done.")
