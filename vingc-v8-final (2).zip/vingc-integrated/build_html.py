"""
Reads Icons.jsx, Badges.jsx, colors_and_type.css and inlines them into
dashboard.html and chat.html so the browser gets a single-file app with
zero external dependencies (except React from unpkg CDN).
"""
import re, pathlib

ROOT = pathlib.Path(__file__).parent

icons_js  = (ROOT / "Icons.jsx").read_text()
badges_js = (ROOT / "Badges.jsx").read_text()
css_full  = (ROOT / "colors_and_type.css").read_text()

def build(src_name, dst_name):
    src = (ROOT / src_name).read_text()

    # Remove the external script tags that load Icons/Badges
    src = re.sub(r'<script[^>]+src="Icons\.jsx"[^>]*></script>', "", src)
    src = re.sub(r'<script[^>]+src="Badges\.jsx"[^>]*></script>', "", src)
    src = re.sub(r'<script[^>]+src="\.\./ops_console/Icons\.jsx"[^>]*></script>', "", src)
    src = re.sub(r'<script[^>]+src="\.\./ops_console/Badges\.jsx"[^>]*></script>', "", src)

    # Remove the external CSS link
    src = re.sub(r'<link[^>]+colors_and_type\.css[^>]*/>', "", src)

    # Inject everything just before </head>
    injection = f"""
<style>
{css_full}

/* Layout overrides */
html,body,#root{{height:100%;margin:0}}
body{{background:var(--bg-app);overflow:hidden}}
*{{box-sizing:border-box}}
@keyframes vingc-pulse{{0%,100%{{opacity:1;transform:scale(1)}}50%{{opacity:.35;transform:scale(1.6)}}}}
@keyframes vingc-slide-in{{from{{opacity:0;transform:translateY(6px)}}to{{opacity:1;transform:translateY(0)}}}}
@keyframes vingc-bounce{{0%,80%,100%{{opacity:.2}}40%{{opacity:1}}}}
.appear{{animation:vingc-slide-in .22s ease-out}}
.msg-enter{{animation:vingc-slide-in .18s ease-out}}
.dot-bounce{{display:inline-flex;gap:3px}}
.dot-bounce span{{width:5px;height:5px;border-radius:50%;background:var(--fg-3);animation:vingc-bounce 1.2s infinite ease-in-out}}
.dot-bounce span:nth-child(2){{animation-delay:.15s}}
.dot-bounce span:nth-child(3){{animation-delay:.30s}}
::-webkit-scrollbar{{width:8px;height:8px}}
::-webkit-scrollbar-track{{background:transparent}}
::-webkit-scrollbar-thumb{{background:var(--gray-700);border-radius:4px;border:2px solid var(--bg-app)}}
::-webkit-scrollbar-thumb:hover{{background:var(--gray-600)}}
</style>
<script type="text/babel">
// ── Icons ─────────────────────────────────────────────────────────────────
{icons_js}
// ── Badges ────────────────────────────────────────────────────────────────
{badges_js}
</script>
"""
    src = src.replace("</head>", injection + "</head>")

    # Fix asset paths — api_server serves /assets/ route
    src = src.replace('src="assets/', 'src="/assets/')
    src = src.replace("src='assets/", "src='/assets/")

    (ROOT / dst_name).write_text(src)
    size = (ROOT / dst_name).stat().st_size // 1024
    print(f"  Built {dst_name}  ({size} KB)")

print("Building self-contained HTML files...")
build("dashboard.html", "dashboard.html")
build("chat.html",      "chat.html")
print("Done.")
