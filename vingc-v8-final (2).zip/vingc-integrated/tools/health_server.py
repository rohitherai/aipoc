"""
VINGC Health & Metrics Server
Exposes /health/live, /health/ready on port 8081
and /metrics (Prometheus format) on port 8080.
Runs as a background asyncio task alongside the agent pipeline.
"""

import asyncio
import json
import logging
import time
from datetime import datetime
from typing import Dict, Any

from aiohttp import web
from prometheus_client import (
    Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST,
    CollectorRegistry,
)

log = logging.getLogger("health_server")

# ── Prometheus metrics ──────────────────────────────────────────────────────
REGISTRY = CollectorRegistry()

PIPELINE_RUNS_TOTAL = Counter(
    "vingc_pipeline_runs_total",
    "Total number of complete agent pipeline executions",
    registry=REGISTRY,
)
PIPELINE_DURATION = Histogram(
    "vingc_pipeline_duration_seconds",
    "End-to-end pipeline latency in seconds",
    buckets=[0.5, 1, 2, 5, 10, 30],
    registry=REGISTRY,
)
AGENT_ERRORS = Counter(
    "vingc_agent_errors_total",
    "Agent errors by agent ID",
    ["agent_id"],
    registry=REGISTRY,
)
KPI_BREACHES = Counter(
    "vingc_kpi_breaches_total",
    "KPI threshold breaches detected",
    ["network_function", "severity"],
    registry=REGISTRY,
)
ACTIVE_INCIDENTS = Gauge(
    "vingc_active_incidents",
    "Number of currently active incidents",
    registry=REGISTRY,
)
KB_LOOKUPS = Counter(
    "vingc_kb_lookups_total",
    "Knowledge base lookup results",
    ["result"],   # "hit" | "miss"
    registry=REGISTRY,
)
LLM_CALLS = Counter(
    "vingc_llm_calls_total",
    "LLM fallback calls",
    ["status"],   # "success" | "error"
    registry=REGISTRY,
)
NOTIFICATIONS_SENT = Counter(
    "vingc_notifications_sent_total",
    "Notifications dispatched by channel",
    ["channel"],  # "slack" | "teams" | "websocket"
    registry=REGISTRY,
)

# Shared state accessed by health endpoints and updated by agents
_state: Dict[str, Any] = {
    "started_at":        datetime.utcnow().isoformat(),
    "last_poll_at":      None,
    "last_pipeline_at":  None,
    "active_incidents":  0,
    "agents_ok":         True,
    "agent_status": {
        "agent1": "initializing",
        "agent2": "initializing",
        "agent3": "initializing",
        "agent4": "initializing",
        "agent5": "initializing",
    },
    "pipeline_run_count": 0,
}


def update_state(**kwargs):
    """Thread-safe state updater called by agents."""
    _state.update(kwargs)
    if "active_incidents" in kwargs:
        ACTIVE_INCIDENTS.set(kwargs["active_incidents"])


# ── HTTP handlers ───────────────────────────────────────────────────────────

async def liveness(request: web.Request) -> web.Response:
    """Kubernetes liveness probe — always 200 if process is alive."""
    return web.json_response({"status": "alive", "timestamp": datetime.utcnow().isoformat()})


async def readiness(request: web.Request) -> web.Response:
    """Kubernetes readiness probe — 503 if agents are not yet initialised."""
    all_ready = all(
        s in ("ready", "running")
        for s in _state["agent_status"].values()
    )
    status = 200 if all_ready else 503
    return web.json_response(
        {
            "status": "ready" if all_ready else "not_ready",
            "agents": _state["agent_status"],
            "last_poll_at": _state["last_poll_at"],
        },
        status=status,
    )


async def metrics_handler(request: web.Request) -> web.Response:
    """Prometheus /metrics endpoint."""
    data = generate_latest(REGISTRY)
    return web.Response(body=data, content_type=CONTENT_TYPE_LATEST)


async def status_handler(request: web.Request) -> web.Response:
    """Human-readable /status JSON endpoint."""
    return web.json_response({
        **_state,
        "uptime_seconds": round(
            (datetime.utcnow() -
             datetime.fromisoformat(_state["started_at"])).total_seconds()
        ),
    })


async def pipeline_history_handler(request: web.Request) -> web.Response:
    """Returns recent MCP message history — useful for debugging."""
    from mcp.mcp_server import bus
    limit = int(request.query.get("limit", 50))
    history = [
        {
            "id":           m.id[:8],
            "sender":       m.sender,
            "receiver":     m.receiver,
            "message_type": m.message_type,
            "timestamp":    m.timestamp,
            "correlation":  (m.correlation_id or "")[:8],
        }
        for m in bus.get_history()[-limit:]
    ]
    return web.json_response({"count": len(history), "messages": history})


# ── Server lifecycle ────────────────────────────────────────────────────────

async def start_health_server(health_port: int = 8081, metrics_port: int = 8080):
    """Start both HTTP servers as background asyncio tasks."""

    health_app = web.Application()
    health_app.router.add_get("/health/live",  liveness)
    health_app.router.add_get("/health/ready", readiness)
    health_app.router.add_get("/status",       status_handler)
    health_app.router.add_get("/pipeline/history", pipeline_history_handler)

    metrics_app = web.Application()
    metrics_app.router.add_get("/metrics", metrics_handler)

    async def _run(app: web.Application, port: int, name: str):
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", port)
        await site.start()
        log.info("%s server listening on port %d", name, port)
        # Keep running until cancelled
        try:
            while True:
                await asyncio.sleep(3600)
        finally:
            await runner.cleanup()

    asyncio.create_task(_run(health_app,   health_port,   "Health"))
    asyncio.create_task(_run(metrics_app,  metrics_port,  "Metrics"))
