@echo off
echo Installing VINGC v3 dependencies...
pip install fastapi
pip install uvicorn
pip install aiohttp
pip install pydantic
pip install prometheus-client
pip install python-multipart
pip install websockets
pip install spacy
echo.
echo Done. Run: python api_server.py
pause
