@echo off
title VINGC Agentic AI
color 0A

echo.
echo  =========================================
echo   VINGC Agentic AI - Local Launcher
echo  =========================================
echo.

:: Check Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ERROR: Python not found.
    echo  Download from: https://python.org/downloads
    echo  Tick "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)

echo  Python found:
python --version
echo.

echo  [1/3] Installing dependencies...
echo.

pip install fastapi --quiet
pip install uvicorn --quiet
pip install aiohttp --quiet
pip install pydantic --quiet
pip install prometheus-client --quiet
pip install python-multipart --quiet
pip install websockets --quiet

echo.
echo  [2/3] Dependencies ready.
echo.

if defined ANTHROPIC_API_KEY (
    echo  [3/3] ANTHROPIC_API_KEY detected - Claude responses REAL.
) else (
    echo  [3/3] No ANTHROPIC_API_KEY - LLM responses SIMULATED.
    echo        To enable real Claude, set the variable before running:
    echo        set ANTHROPIC_API_KEY=sk-ant-api03-your-key-here
)

echo.
echo  =========================================
echo   http://localhost:8000/           Dashboard
echo   http://localhost:8000/chat       Chatbot
echo   http://localhost:8000/docs       API docs
echo  =========================================
echo.
echo  Press Ctrl+C to stop.
echo.

start "" cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:8000"

python api_server.py

echo.
echo  Server stopped.
pause
