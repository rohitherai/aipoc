// Badges for severity, priority, source, status

const badgeBase = {
  display: "inline-flex",
  alignItems: "center",
  gap: "4px",
  fontFamily: "var(--font-mono)",
  fontSize: "10px",
  fontWeight: 700,
  letterSpacing: "0.08em",
  textTransform: "uppercase",
  padding: "2px 6px",
  borderRadius: "2px",
  border: "1px solid",
  lineHeight: 1.2,
  whiteSpace: "nowrap",
};

const variants = {
  critical: { color: "var(--critical-400)", background: "color-mix(in oklch, var(--critical-500), transparent 88%)", borderColor: "color-mix(in oklch, var(--critical-500), transparent 70%)" },
  warning:  { color: "var(--warning-400)",  background: "color-mix(in oklch, var(--warning-500), transparent 88%)",  borderColor: "color-mix(in oklch, var(--warning-500), transparent 70%)" },
  success:  { color: "var(--success-500)",  background: "color-mix(in oklch, var(--success-500), transparent 88%)",  borderColor: "color-mix(in oklch, var(--success-500), transparent 70%)" },
  info:     { color: "var(--info-500)",     background: "color-mix(in oklch, var(--info-500), transparent 88%)",     borderColor: "color-mix(in oklch, var(--info-500), transparent 70%)" },
  neutral:  { color: "var(--fg-2)",         background: "var(--surface-2)", borderColor: "var(--border)" },
  accent:   { color: "var(--accent-400)",   background: "color-mix(in oklch, var(--accent-500), transparent 88%)",   borderColor: "color-mix(in oklch, var(--accent-500), transparent 70%)" },
};

const Badge = ({ variant = "neutral", children, dot = false, style, ...rest }) => (
  <span style={{ ...badgeBase, ...variants[variant], ...style }} {...rest}>
    {dot && <span style={{ width: 6, height: 6, borderRadius: "50%", background: "currentColor" }} />}
    {children}
  </span>
);

const SeverityBadge = ({ severity }) => {
  const map = { CRITICAL: "critical", WARNING: "warning", INFO: "info", HEALTHY: "success" };
  return <Badge variant={map[severity] || "neutral"} dot>{severity}</Badge>;
};

const PriorityBadge = ({ priority }) => {
  const map = { P1: "critical", P2: "warning", P3: "info", P4: "neutral" };
  return <Badge variant={map[priority] || "neutral"}>{priority}</Badge>;
};

const SourceBadge = ({ source }) => {
  if (source === "knowledge_base") return <Badge variant="info">KB</Badge>;
  if (source === "llm_generated")  return <Badge variant="accent">LLM</Badge>;
  return <Badge>{source}</Badge>;
};

const LiveDot = ({ color = "var(--accent-500)", size = 8 }) => (
  <span style={{ position: "relative", display: "inline-flex", width: size, height: size }}>
    <span style={{
      position: "absolute", inset: 0, borderRadius: "50%", background: color,
      animation: "vingc-pulse 2s ease-in-out infinite",
    }}/>
    <span style={{ position: "relative", width: size, height: size, borderRadius: "50%", background: color }}/>
  </span>
);

window.Badge = Badge;
window.SeverityBadge = SeverityBadge;
window.PriorityBadge = PriorityBadge;
window.SourceBadge = SourceBadge;
window.LiveDot = LiveDot;
