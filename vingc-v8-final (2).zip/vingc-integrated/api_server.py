"""
VINGC API Server v3 — api_server.py
=====================================
New in v3:
  ✓ Agent 6: Auto-resolver (5-min KPI watch → auto-resolve or escalate)
  ✓ Agent 7: Remediation Orchestrator (confidence-based, L2 approval flow)
  ✓ 5 extra KPIs per NF (21 SMF + 13 UDR = new total)
  ✓ Status: OPEN | IN_PROGRESS | PENDING_APPROVAL | PENDING_L2 | PENDING | RESOLVED
  ✓ SLA definitions with breach alerting (P1/P2/P3)
  ✓ Kafka-like streaming simulator (EventBus with topics)
  ✓ Network topology: Site A (Paris) + Site B (Frankfurt) + 4G nodes
  ✓ GET /api/topology - heatmap data with node health
  ✓ GET /api/sla      - SLA breach predictions
  ✓ GET /api/replay   - time-travel KPI replay
  ✓ POST /api/incidents/{id}/approve  - L2 Lead approves Agent7 plan
  ✓ POST /api/incidents/{id}/pending  - L2 sets ticket to PENDING
  ✓ WS pushes sla_breach_warning to L2 Lead
"""

import asyncio, json, logging, os, random, sys, uuid
from collections import deque
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

from mcp.mcp_server import MCPBus, MCPMessage
from agents.agent2_threshold_analyzer import ThresholdAnalyzerAgent
from agents.agent3_syslog_correlator  import SyslogCorrelatorAgent
from agents.agent4_remediation_engine import RemediationEngine
from agents.agent5_chatbot_notifier   import ChatBotNotifierAgent
from agents.agent6_auto_resolver      import AutoResolverAgent
from agents.agent7_remediation_orchestrator import RemediationOrchestratorAgent

try:
    import spacy
    _nlp = spacy.blank("en")
    SPACY_OK = True
except Exception:
    _nlp = None; SPACY_OK = False

logging.basicConfig(level=logging.INFO,
    format="%(asctime)s  [%(name)-20s]  %(levelname)-8s  %(message)s")
log = logging.getLogger("api_server")

# ─────────────────────────────────────────────────────────────────────────────
# SLA DEFINITIONS
# ─────────────────────────────────────────────────────────────────────────────
SLA = {
    "P1": {"ack_min": 15,  "resolve_hr": 4,  "label": "Critical"},
    "P2": {"ack_min": 60,  "resolve_hr": 24, "label": "High"},
    "P3": {"ack_min": 240, "resolve_hr": 72, "label": "Warning/Minor"},
}

# ─────────────────────────────────────────────────────────────────────────────
# NETWORK TOPOLOGY  (Site A = Paris, Site B = Frankfurt)
# ─────────────────────────────────────────────────────────────────────────────
SITES = {
    "site_a": {
        "name": "Site A — Paris (FR)",
        "lat": 48.8566, "lon": 2.3522,
        "country": "France",
        "nodes": {
            "SMF-A":  {"type":"5GC","lat":48.860,"lon":2.355,"nf":"SMF"},
            "UDR-A":  {"type":"5GC","lat":48.855,"lon":2.348,"nf":"UDR"},
            "AMF-A":  {"type":"5GC","lat":48.862,"lon":2.360,"nf":"AMF"},
            "UPF-A1": {"type":"5GC","lat":48.850,"lon":2.340,"nf":"UPF"},
            "UPF-A2": {"type":"5GC","lat":48.858,"lon":2.345,"nf":"UPF"},
            "eNB-A1": {"type":"4G", "lat":48.870,"lon":2.370,"nf":"eNodeB"},
            "eNB-A2": {"type":"4G", "lat":48.845,"lon":2.335,"nf":"eNodeB"},
            "SGW-A":  {"type":"4G", "lat":48.852,"lon":2.362,"nf":"SGW"},
            "PGW-A":  {"type":"4G", "lat":48.864,"lon":2.342,"nf":"PGW"},
        }
    },
    "site_b": {
        "name": "Site B — Frankfurt (DE)",
        "lat": 50.1109, "lon": 8.6821,
        "country": "Germany",
        "nodes": {
            "SMF-B":  {"type":"5GC","lat":50.115,"lon":8.685,"nf":"SMF"},
            "UDR-B":  {"type":"5GC","lat":50.108,"lon":8.678,"nf":"UDR"},
            "AMF-B":  {"type":"5GC","lat":50.113,"lon":8.692,"nf":"AMF"},
            "UPF-B1": {"type":"5GC","lat":50.105,"lon":8.670,"nf":"UPF"},
            "UPF-B2": {"type":"5GC","lat":50.118,"lon":8.674,"nf":"UPF"},
            "eNB-B1": {"type":"4G", "lat":50.122,"lon":8.698,"nf":"eNodeB"},
            "eNB-B2": {"type":"4G", "lat":50.100,"lon":8.665,"nf":"eNodeB"},
            "SGW-B":  {"type":"4G", "lat":50.110,"lon":8.690,"nf":"SGW"},
            "PGW-B":  {"type":"4G", "lat":50.120,"lon":8.675,"nf":"PGW"},
        }
    }
}

# 4G/5G network edges (links between nodes)
NETWORK_EDGES = [
    # Site A internal
    ("eNB-A1","SGW-A"),("eNB-A2","SGW-A"),("SGW-A","PGW-A"),
    ("PGW-A","UPF-A1"),("PGW-A","UPF-A2"),("UPF-A1","SMF-A"),("UPF-A2","SMF-A"),
    ("SMF-A","AMF-A"),("SMF-A","UDR-A"),
    # Site B internal
    ("eNB-B1","SGW-B"),("eNB-B2","SGW-B"),("SGW-B","PGW-B"),
    ("PGW-B","UPF-B1"),("PGW-B","UPF-B2"),("UPF-B1","SMF-B"),("UPF-B2","SMF-B"),
    ("SMF-B","AMF-B"),("SMF-B","UDR-B"),
    # Inter-site (active-active backbone)
    ("SMF-A","SMF-B"),("UDR-A","UDR-B"),("AMF-A","AMF-B"),
    ("PGW-A","PGW-B"),("SGW-A","SGW-B"),
]

# ─────────────────────────────────────────────────────────────────────────────
# EXTENDED KPI SCENARIOS (21 SMF + 13 UDR KPIs each)
# ─────────────────────────────────────────────────────────────────────────────

SMF_EXTRA_KPIS_NORMAL = [
    {"metric":"smf_handover_success_rate_pct",   "value":99.2, "unit":"%",     "threshold":95},
    {"metric":"smf_paging_success_rate_pct",      "value":98.8, "unit":"%",     "threshold":95},
    {"metric":"smf_registration_success_rate_pct","value":99.5, "unit":"%",     "threshold":97},
    {"metric":"smf_bearer_setup_time_ms",         "value":45.0, "unit":"ms",    "threshold":100},
    {"metric":"smf_upf_selection_latency_ms",     "value":12.0, "unit":"ms",    "threshold":30},
]
SMF_EXTRA_KPIS_CRITICAL = [
    {"metric":"smf_handover_success_rate_pct",   "value":72.0, "unit":"%",     "threshold":95},
    {"metric":"smf_paging_success_rate_pct",      "value":68.0, "unit":"%",     "threshold":95},
    {"metric":"smf_registration_success_rate_pct","value":81.0, "unit":"%",     "threshold":97},
    {"metric":"smf_bearer_setup_time_ms",         "value":320.0,"unit":"ms",    "threshold":100},
    {"metric":"smf_upf_selection_latency_ms",     "value":88.0, "unit":"ms",    "threshold":30},
]
UDR_EXTRA_KPIS_NORMAL = [
    {"metric":"udr_replication_lag_ms",           "value":5.0,  "unit":"ms",    "threshold":50},
    {"metric":"udr_cache_hit_ratio_pct",          "value":94.5, "unit":"%",     "threshold":80},
    {"metric":"udr_query_p99_latency_ms",         "value":18.0, "unit":"ms",    "threshold":50},
    {"metric":"udr_active_subscribers",           "value":180000,"unit":"count","threshold":250000},
    {"metric":"udr_notification_success_rate_pct","value":99.1, "unit":"%",     "threshold":98},
]
UDR_EXTRA_KPIS_CRITICAL = [
    {"metric":"udr_replication_lag_ms",           "value":480.0,"unit":"ms",    "threshold":50},
    {"metric":"udr_cache_hit_ratio_pct",          "value":52.0, "unit":"%",     "threshold":80},
    {"metric":"udr_query_p99_latency_ms",         "value":220.0,"unit":"ms",    "threshold":50},
    {"metric":"udr_active_subscribers",           "value":248000,"unit":"count","threshold":250000},
    {"metric":"udr_notification_success_rate_pct","value":84.0, "unit":"%",     "threshold":98},
]

SCENARIOS = [
    {
        "priority": "P1", "site": "site_a",
        "smf_kpis": [
            {"metric":"smf_n4_message_latency_ms",       "value":87.0,"unit":"ms",    "threshold":50},
            {"metric":"smf_session_establishment_rate",   "value":420.0,"unit":"sess/s","threshold":1000},
            {"metric":"smf_cpu_utilization_pct",          "value":91.0,"unit":"%",     "threshold":80},
            {"metric":"smf_transaction_failure_rate_pct", "value":2.8,"unit":"%",      "threshold":1.0},
            {"metric":"smf_memory_utilization_pct",       "value":79.0,"unit":"%",     "threshold":75},
            {"metric":"smf_active_sessions",              "value":48000,"unit":"count","threshold":50000},
            {"metric":"smf_session_release_rate",         "value":180.0,"unit":"sess/s","threshold":500},
            {"metric":"smf_session_modification_rate",    "value":210.0,"unit":"sess/s","threshold":800},
        ] + SMF_EXTRA_KPIS_CRITICAL,
        "udr_kpis": [
            {"metric":"udr_db_connection_pool_usage_pct","value":97.0,"unit":"%",    "threshold":85},
            {"metric":"udr_response_latency_p95_ms",     "value":55.0,"unit":"ms",   "threshold":30},
            {"metric":"udr_error_rate_pct",              "value":1.2,"unit":"%",     "threshold":0.5},
            {"metric":"udr_subscription_read_rate",      "value":3200.0,"unit":"req/s","threshold":5000},
            {"metric":"udr_subscription_write_rate",     "value":1100.0,"unit":"req/s","threshold":2000},
            {"metric":"udr_cpu_utilization_pct",         "value":85.0,"unit":"%",    "threshold":80},
            {"metric":"udr_memory_utilization_pct",      "value":78.0,"unit":"%",    "threshold":75},
            {"metric":"udr_throughput_mbps",             "value":820.0,"unit":"Mbps","threshold":1000},
        ] + UDR_EXTRA_KPIS_CRITICAL,
        "logs": [
            "2026-04-26T14:00:01Z smf-pod-1 ERROR N4 association failed for UPF 10.0.0.3 after 3 retries",
            "2026-04-26T14:00:02Z smf-pod-2 ERROR N4 association failed for UPF 10.0.0.4 after 3 retries",
            "2026-04-26T14:00:03Z smf-pod-1 ERROR PDU session establishment failed IMSI-001122334455",
            "2026-04-26T14:00:04Z smf-pod-2 WARN  PFCP heartbeat timeout UPF 10.0.0.3 unresponsive",
            "2026-04-26T14:00:05Z udr-pod-1 CRIT  database connection pool exhausted 97/100",
            "2026-04-26T14:00:06Z smf-pod-1 ERROR N11 message timeout AMF-01 not responding",
            "2026-04-26T14:00:07Z kubelet    WARN  OOMKilled smf-worker in pod smf-pod-3",
        ],
    },
    {
        "priority": "P2", "site": "site_b",
        "smf_kpis": [
            {"metric":"smf_n4_message_latency_ms",       "value":38.0,"unit":"ms",    "threshold":50},
            {"metric":"smf_session_establishment_rate",   "value":870.0,"unit":"sess/s","threshold":1000},
            {"metric":"smf_cpu_utilization_pct",          "value":84.0,"unit":"%",     "threshold":80},
            {"metric":"smf_transaction_failure_rate_pct", "value":0.4,"unit":"%",      "threshold":1.0},
            {"metric":"smf_memory_utilization_pct",       "value":71.0,"unit":"%",     "threshold":75},
            {"metric":"smf_active_sessions",              "value":38000,"unit":"count","threshold":50000},
            {"metric":"smf_session_release_rate",         "value":380.0,"unit":"sess/s","threshold":500},
            {"metric":"smf_session_modification_rate",    "value":620.0,"unit":"sess/s","threshold":800},
        ] + SMF_EXTRA_KPIS_NORMAL,
        "udr_kpis": [
            {"metric":"udr_db_connection_pool_usage_pct","value":88.0,"unit":"%",    "threshold":85},
            {"metric":"udr_response_latency_p95_ms",     "value":25.0,"unit":"ms",   "threshold":30},
            {"metric":"udr_error_rate_pct",              "value":0.2,"unit":"%",     "threshold":0.5},
            {"metric":"udr_subscription_read_rate",      "value":4100.0,"unit":"req/s","threshold":5000},
            {"metric":"udr_subscription_write_rate",     "value":1600.0,"unit":"req/s","threshold":2000},
            {"metric":"udr_cpu_utilization_pct",         "value":60.0,"unit":"%",    "threshold":80},
            {"metric":"udr_memory_utilization_pct",      "value":65.0,"unit":"%",    "threshold":75},
            {"metric":"udr_throughput_mbps",             "value":650.0,"unit":"Mbps","threshold":1000},
        ] + UDR_EXTRA_KPIS_NORMAL,
        "logs": [
            "2026-04-26T14:00:01Z smf-pod-1 WARN  CPU throttling detected",
            "2026-04-26T14:00:05Z udr-pod-1 WARN  database connection pool at 88%",
            "2026-04-26T14:00:07Z udr-pod-2 WARN  Nudr response timeout subscriber 0049123",
        ],
    },
    {
        "priority": "P3", "site": "site_a",
        "smf_kpis": [
            {"metric":"smf_n4_message_latency_ms",       "value":22.0,"unit":"ms",    "threshold":50},
            {"metric":"smf_session_establishment_rate",   "value":950.0,"unit":"sess/s","threshold":1000},
            {"metric":"smf_cpu_utilization_pct",          "value":55.0,"unit":"%",     "threshold":80},
            {"metric":"smf_transaction_failure_rate_pct", "value":0.1,"unit":"%",      "threshold":1.0},
            {"metric":"smf_memory_utilization_pct",       "value":60.0,"unit":"%",     "threshold":75},
            {"metric":"smf_active_sessions",              "value":25000,"unit":"count","threshold":50000},
            {"metric":"smf_session_release_rate",         "value":430.0,"unit":"sess/s","threshold":500},
            {"metric":"smf_session_modification_rate",    "value":720.0,"unit":"sess/s","threshold":800},
        ] + SMF_EXTRA_KPIS_NORMAL,
        "udr_kpis": [
            {"metric":"udr_db_connection_pool_usage_pct","value":70.0,"unit":"%",    "threshold":85},
            {"metric":"udr_response_latency_p95_ms",     "value":18.0,"unit":"ms",   "threshold":30},
            {"metric":"udr_error_rate_pct",              "value":0.05,"unit":"%",    "threshold":0.5},
            {"metric":"udr_subscription_read_rate",      "value":4800.0,"unit":"req/s","threshold":5000},
            {"metric":"udr_subscription_write_rate",     "value":1900.0,"unit":"req/s","threshold":2000},
            {"metric":"udr_cpu_utilization_pct",         "value":45.0,"unit":"%",    "threshold":80},
            {"metric":"udr_memory_utilization_pct",      "value":55.0,"unit":"%",    "threshold":75},
            {"metric":"udr_throughput_mbps",             "value":1020.0,"unit":"Mbps","threshold":1000},
        ] + UDR_EXTRA_KPIS_NORMAL,
        "logs": [
            "2026-04-26T14:00:01Z udr-pod-1 INFO  Subscription data retrieved in 18ms",
            "2026-04-26T14:00:02Z udr-pod-2 WARN  throughput slightly above threshold",
        ],
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# KAFKA-LIKE EVENT STREAMING SIMULATOR
# ─────────────────────────────────────────────────────────────────────────────

class KafkaSimulator:
    """
    Mimics Kafka topic-based event streaming using asyncio queues.
    Topics: kpi_stream, incident_stream, alert_stream, sla_stream
    """
    def __init__(self):
        self.topics: Dict[str, asyncio.Queue] = {
            "kpi_stream":      asyncio.Queue(maxsize=1000),
            "incident_stream": asyncio.Queue(maxsize=500),
            "alert_stream":    asyncio.Queue(maxsize=500),
            "sla_stream":      asyncio.Queue(maxsize=200),
        }
        self.consumers: Dict[str, List] = {t: [] for t in self.topics}
        self.message_count = 0
        self.running = False

    async def produce(self, topic: str, key: str, value: Dict):
        msg = {
            "topic":     topic,
            "key":       key,
            "value":     value,
            "offset":    self.message_count,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "partition": hash(key) % 3,
        }
        self.message_count += 1
        if not self.topics[topic].full():
            await self.topics[topic].put(msg)
        # Notify consumers
        for cb in self.consumers.get(topic, []):
            asyncio.create_task(cb(msg))
        return msg

    def subscribe(self, topic: str, callback):
        if topic in self.consumers:
            self.consumers[topic].append(callback)

    async def start_kpi_stream(self, get_kpis_fn, broadcast_fn):
        """Continuously emit KPI events every 5 seconds (Kafka-like stream)."""
        self.running = True
        while self.running:
            await asyncio.sleep(5)
            kpis = get_kpis_fn()
            for kpi in kpis:
                if kpi.get("severity") != "HEALTHY":
                    msg = await self.produce("kpi_stream", kpi["metric"], kpi)
                    await broadcast_fn("kafka_event", {
                        "topic":  "kpi_stream",
                        "key":    kpi["metric"],
                        "value":  kpi["severity"],
                        "offset": msg["offset"],
                        "partition": msg["partition"],
                    })

kafka = KafkaSimulator()

# ─────────────────────────────────────────────────────────────────────────────
# spaCy RCA
# ─────────────────────────────────────────────────────────────────────────────

FAULT_KEYWORDS = {
    "N4 association": "N4 interface failure between SMF and UPF — PFCP session establishment blocked",
    "PFCP heartbeat": "PFCP heartbeat timeout — UPF unreachable on N4 interface",
    "PDU session":    "PDU session establishment failure — subscribers unable to connect",
    "N11 timeout":    "N11 interface timeout — AMF-SMF communication degraded",
    "DB pool":        "Database connection pool exhausted — UDR unable to serve subscription requests",
    "OOMKilled":      "Container OOM kill — pod memory limit exceeded",
    "Nudr timeout":   "Nudr API timeout — UDR service degraded",
    "CPU throttling": "CPU resource contention — pod needs scaling",
    "replication lag":"Database replication lag — read replicas falling behind",
    "handover":       "Handover failure — inter-cell mobility degraded",
    "paging":         "Paging failure — UE reachability impacted",
    "bearer setup":   "Bearer setup latency spike — QoS impacted",
}

def nlp_rca(logs: List[str], faults: List[Dict]) -> str:
    if not _nlp or not logs:
        return faults[0].get("fault","Root cause under investigation") if faults else "Under investigation"
    combined = " ".join(logs)
    doc = _nlp(combined)
    tokens_lower = {t.text.lower() for t in doc}
    for pattern, rca_text in FAULT_KEYWORDS.items():
        words = pattern.lower().split()
        if all(any(w in t for t in tokens_lower) for w in words):
            return rca_text
    freq = {}
    stop = {"the","a","an","for","in","to","of","and","or","on","at","from","with","is","was","not"}
    for t in doc:
        if t.text.lower() not in stop and len(t.text) > 3:
            freq[t.text] = freq.get(t.text,0)+1
    if freq:
        top = max(freq, key=freq.get)
        return f"NLP (spaCy): most frequent fault indicator — '{top}'"
    return "Root cause under analysis"

# ─────────────────────────────────────────────────────────────────────────────
# APPLICATION STATE
# ─────────────────────────────────────────────────────────────────────────────

class L2Agent:
    def __init__(self, ws, name):
        self.ws=ws; self.name=name
        self.id=str(uuid.uuid4())[:8]
        self.joined=datetime.now(timezone.utc).isoformat()
        self.status="available"

class AppState:
    def __init__(self):
        self.bus = MCPBus()
        self.incidents:   Dict[str, Dict]    = {}
        self.kpi_snapshot: Dict              = {}
        self.kpi_history:  Dict[str, deque]  = {}
        self.kpi_replay:   Dict[str, List]   = {}   # for time-travel
        self.mcp_messages: List[Dict]        = []
        self.pipeline_running: bool          = False
        self.last_run_at: Optional[str]      = None
        self.cycle_count: int                = 0
        self.scenario_index: int             = 0
        self.ws_clients: Dict[WebSocket, Optional[L2Agent]] = {}
        self.agent_statuses: Dict[str,str]   = {f"agent{i}":"ready" for i in range(1,8)}
        self.node_health: Dict[str, str]     = {}   # node_id → CRITICAL|WARNING|HEALTHY
        # Agents wired in startup
        self.agent2=self.agent3=self.agent4=self.agent5=None
        self.agent6=self.agent7=None

    @property
    def online_l2_agents(self):
        return [a for a in self.ws_clients.values() if a is not None]

    def record_kpi(self, metric, value, ts):
        if metric not in self.kpi_history:
            self.kpi_history[metric] = deque(maxlen=60)
        self.kpi_history[metric].append({"ts":ts,"v":value})
        # Also keep replay buffer (longer)
        if metric not in self.kpi_replay:
            self.kpi_replay[metric] = []
        self.kpi_replay[metric].append({"ts":ts,"v":value})
        if len(self.kpi_replay[metric]) > 360:   # 3 hours
            self.kpi_replay[metric] = self.kpi_replay[metric][-360:]

    def next_scenario(self):
        s = SCENARIOS[self.scenario_index % len(SCENARIOS)]
        self.scenario_index += 1
        return s

state = AppState()

# ─────────────────────────────────────────────────────────────────────────────
# FASTAPI
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(title="VINGC API v3", version="3.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/assets", StaticFiles(directory="assets"), name="assets")

# ─────────────────────────────────────────────────────────────────────────────
# BROADCAST
# ─────────────────────────────────────────────────────────────────────────────

async def broadcast(event_type: str, data: Any):
    if not state.ws_clients: return
    payload = json.dumps({"type":event_type,"data":data,
                          "ts":datetime.now(timezone.utc).isoformat()})
    dead = []
    for ws in list(state.ws_clients.keys()):
        try:
            await ws.send_text(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        state.ws_clients.pop(ws, None)

# ─────────────────────────────────────────────────────────────────────────────
# MCP INSTRUMENTATION
# ─────────────────────────────────────────────────────────────────────────────

def instrument_bus():
    orig = state.bus.publish
    async def tracked(msg: MCPMessage):
        entry = {"id":msg.id[:8],"sender":msg.sender,"receiver":msg.receiver,
                 "type":msg.message_type,"corr":(msg.correlation_id or "")[:8],
                 "ts":msg.timestamp,"time":datetime.now(timezone.utc).strftime("%H:%M:%S"),
                 "preview":_preview(msg)}
        state.mcp_messages.append(entry)
        if len(state.mcp_messages) > 500: state.mcp_messages = state.mcp_messages[-500:]
        await broadcast("mcp_message", entry)
        if msg.sender in state.agent_statuses:
            state.agent_statuses[msg.sender] = "active"
            await broadcast("agent_status", {"agent":msg.sender,"status":"active"})
        result = await orig(msg)
        async def cool(aid):
            await asyncio.sleep(1.5)
            if state.agent_statuses.get(aid) == "active":
                state.agent_statuses[aid] = "ok"
                await broadcast("agent_status", {"agent":aid,"status":"ok"})
        if msg.sender in state.agent_statuses:
            asyncio.create_task(cool(msg.sender))
        return result
    state.bus.publish = tracked

def _preview(msg: MCPMessage) -> str:
    p = msg.payload
    if msg.message_type == "kpi_data":
        nfs = list(p.get("network_functions",{}).keys())
        total = sum(len(v.get("kpis",[])) for v in p.get("network_functions",{}).values())
        return f"{total} KPIs · {', '.join(nfs)}"
    if msg.message_type == "threshold_breach":
        b=p.get("breaches",[]); s=p.get("summary",{})
        return f"{len(b)} breach(es) · {s.get('critical_count',0)} CRIT · {s.get('warning_count',0)} WARN"
    if msg.message_type == "correlation":
        return f"{p.get('incident_id','?')} · {p.get('fault_count',0)} fault(s) · {p.get('recommended_priority','?')}"
    if msg.message_type == "remediation":
        return f"{p.get('remediation_count',0)} remediation(s) · {p.get('priority','?')}"
    return msg.message_type

# ─────────────────────────────────────────────────────────────────────────────
# NODE HEALTH UPDATER
# ─────────────────────────────────────────────────────────────────────────────

def update_node_health(scenario: Dict):
    """Compute health per network node based on scenario severity."""
    priority = scenario.get("priority","P3")
    site     = scenario.get("site","site_a")

    for s_id, site_data in SITES.items():
        for node_id, node_info in site_data["nodes"].items():
            nf = node_info["nf"]
            if s_id == site and priority == "P1":
                if nf in ("SMF","UDR","UPF"):
                    state.node_health[node_id] = random.choice(["CRITICAL","CRITICAL","WARNING"])
                elif nf in ("AMF","PGW"):
                    state.node_health[node_id] = "WARNING"
                else:
                    state.node_health[node_id] = random.choice(["HEALTHY","WARNING"])
            elif s_id == site and priority == "P2":
                if nf in ("SMF","UDR"):
                    state.node_health[node_id] = "WARNING"
                else:
                    state.node_health[node_id] = "HEALTHY"
            else:
                state.node_health[node_id] = "HEALTHY"

# ─────────────────────────────────────────────────────────────────────────────
# SNAPSHOT BUILDER
# ─────────────────────────────────────────────────────────────────────────────

ENGINEERS = ["K.Mishra","R.Patel","A.Singh","S.Kumar","D.Nair"]
_eng_idx = 0

def next_engineer():
    global _eng_idx
    e = ENGINEERS[_eng_idx % len(ENGINEERS)]; _eng_idx+=1; return e

def build_snapshot(scenario: Dict) -> Dict:
    now = datetime.now(timezone.utc).isoformat()
    def jitter(v): return round(v*(1+random.uniform(-0.03,0.04)),2)
    snap = {"collected_at":now,"network_functions":{
        "SMF":{"kpis":[dict(k,value=jitter(k["value"]),timestamp=now) for k in scenario["smf_kpis"]]},
        "UDR":{"kpis":[dict(k,value=jitter(k["value"]),timestamp=now) for k in scenario["udr_kpis"]]},
    }}
    for nf_data in snap["network_functions"].values():
        for kpi in nf_data["kpis"]:
            state.record_kpi(kpi["metric"], kpi["value"], now)
    return snap

def kpis_flat() -> List[Dict]:
    out = []
    for nf, nfd in state.kpi_snapshot.get("network_functions",{}).items():
        for kpi in nfd.get("kpis",[]):
            r = kpi["value"]/kpi["threshold"] if kpi["threshold"] else 0
            sev = "CRITICAL" if r>=1.5 else "WARNING" if r>=1.0 else "HEALTHY"
            hist = list(state.kpi_history.get(kpi["metric"],[]))
            out.append({**kpi,"nf":nf,"severity":sev,"history":hist})
    return out

def sev_of(v,t):
    r=t and v/t or 0
    return "CRITICAL" if r>=1.5 else "WARNING" if r>=1.0 else "HEALTHY"

def plan_to_incident(plan, scenario):
    remeds = plan.get("remediations",[])
    nfs    = plan.get("nfs_affected",[])
    priority = scenario["priority"]
    severity = "CRITICAL" if priority=="P1" else "WARNING" if priority=="P2" else "INFO"
    now    = datetime.now(timezone.utc).isoformat()
    rca    = nlp_rca(scenario.get("logs",[]), remeds)
    b      = plan.get("breach_summary",{})
    return {
        "id":           plan.get("incident_id","INC-UNKNOWN"),
        "priority":     priority,
        "severity":     severity,
        "nfs":          nfs,
        "site":         scenario.get("site","site_a"),
        "title":        remeds[0]["title"] if remeds else "Network fault detected",
        "fault":        remeds[0].get("fault","Unknown") if remeds else "Unknown",
        "source":       remeds[0].get("source","knowledge_base") if remeds else "knowledge_base",
        "kb_id":        remeds[0].get("kb_id","—") if remeds else "—",
        "ci_name":      "5GC-"+("+".join(nfs))+"-PROD-OCP4",
        "category":     "5G Core / Network Function Fault",
        "assigned_to":  next_engineer(),
        "created_at":   now,
        "updated_at":   now,
        "resolved_at":  None,
        "status":       "OPEN",
        "acked":        False,
        "notes":        [],
        "breach_summary": b,
        "remediations": remeds,
        "root_cause":   rca,
        "issue_description": (
            f"{b.get('critical_count',0)} CRITICAL + {b.get('warning_count',0)} WARNING "
            f"KPI breach(es) on {', '.join(nfs)}. Correlated with "
            f"{plan.get('remediation_count',0)} syslog fault event(s). spaCy NLP active."
        ),
        "resolution":   "—",
        "sla":          SLA[priority]["label"] + f" — {SLA[priority]['ack_min']}min ack / {SLA[priority]['resolve_hr']}hr resolve",
        "sla_ack_deadline":  (datetime.now(timezone.utc)+timedelta(minutes=SLA[priority]["ack_min"])).isoformat(),
        "sla_res_deadline":  (datetime.now(timezone.utc)+timedelta(hours=SLA[priority]["resolve_hr"])).isoformat(),
        "generated_at": now,
        "pending_reason": None,
        "agent7_plan":  None,
        "auto_resolved": False,
        "escalated_to_agent7": False,
    }

# ─────────────────────────────────────────────────────────────────────────────
# SLA BREACH MONITOR
# ─────────────────────────────────────────────────────────────────────────────

async def sla_monitor_loop():
    """Check every 60s for SLA breaches; alert L2 Lead."""
    while True:
        await asyncio.sleep(60)
        now = datetime.now(timezone.utc)
        for inc_id, inc in state.incidents.items():
            if inc["status"] in ("RESOLVED","CANCELLED"):
                continue
            priority = inc.get("priority","P3")
            sla_def  = SLA.get(priority, SLA["P3"])

            ack_dl  = inc.get("sla_ack_deadline")
            res_dl  = inc.get("sla_res_deadline")

            warnings = []
            if ack_dl and not inc.get("acked"):
                dl = datetime.fromisoformat(ack_dl)
                mins_left = (dl - now).total_seconds() / 60
                if mins_left < 10:
                    warnings.append(f"ACK deadline in {max(0,int(mins_left))} min!")
            if res_dl:
                dl = datetime.fromisoformat(res_dl)
                hrs_left = (dl - now).total_seconds() / 3600
                if hrs_left < 1:
                    warnings.append(f"RESOLUTION deadline in {max(0,int(hrs_left*60))} min!")

            if warnings:
                await broadcast("sla_breach_warning", {
                    "incident_id": inc_id,
                    "priority":    priority,
                    "title":       inc.get("title","—"),
                    "warnings":    warnings,
                    "sla_label":   sla_def["label"],
                })
                await kafka.produce("sla_stream", inc_id, {
                    "incident_id": inc_id, "warnings": warnings
                })

# ─────────────────────────────────────────────────────────────────────────────
# STARTUP
# ─────────────────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    api_key = os.getenv("ANTHROPIC_API_KEY","")
    instrument_bus()

    state.agent2 = ThresholdAnalyzerAgent(bus=state.bus)
    state.agent3 = SyslogCorrelatorAgent(bus=state.bus, loki_url="http://mock-loki:3100")
    state.agent3._session = AsyncMock()

    state.agent4 = RemediationEngine(bus=state.bus, anthropic_api_key=api_key or "mock-key")
    if not api_key:
        state.agent4._session = AsyncMock()
        state.agent4._llm_fallback = AsyncMock(return_value={
            "steps":["oc get pods -n 5gc-smf","oc describe pod smf-0 -n 5gc-smf",
                     "oc logs smf-0 --tail=200","oc rollout restart deployment/smf -n 5gc-smf"],
            "rationale":"LLM simulation — set ANTHROPIC_API_KEY for real Claude."
        })
    else:
        import aiohttp
        state.agent4._session = aiohttp.ClientSession()

    state.agent5 = ChatBotNotifierAgent(bus=state.bus,
        anthropic_api_key=api_key or "mock-key",
        slack_webhook_url=None, teams_webhook_url=None, websocket_broadcast_url=None)
    state.agent5._session = AsyncMock()

    # Agent 7 first (Agent 6 needs ref to Agent 7)
    state.agent7 = RemediationOrchestratorAgent(
        bus=state.bus, state_ref=state.incidents, broadcast_fn=broadcast)

    state.agent6 = AutoResolverAgent(
        bus=state.bus, state_ref=state.incidents,
        broadcast_fn=broadcast, agent7=state.agent7)

    # ── Correct pipeline flow: 1→2→3→4→6→7→L2(agent5) ────────────────
    # Agent4 produces remediation payload → we intercept here
    # NO popup fires at incident creation — popup only fires when Agent7
    # requests L2 approval (confidence ≥95%) or assigns to L2 (confidence <95%)
    orig_handler = state.agent5._handle_remediation
    async def patched(msg: MCPMessage):
        # Call original Agent5 (Slack/Teams etc — all mocked)
        await orig_handler(msg)
        plan     = msg.payload
        scenario = SCENARIOS[(state.scenario_index-1) % len(SCENARIOS)]
        state.agent3._query_loki = AsyncMock(return_value=scenario.get("logs",[]))
        incident = plan_to_incident(plan, scenario)
        state.incidents[incident["id"]] = incident
        # Broadcast new incident to UI (dashboard table updates, no popup yet)
        await broadcast("new_incident", incident)
        await broadcast("mcp_message", {
            "id": incident["id"][:8], "sender": "agent4", "receiver": "agent6",
            "type": "handoff_to_agent6", "time": datetime.now(timezone.utc).strftime("%H:%M:%S"),
            "preview": f"Incident {incident['id']} [{incident['priority']}] → Agent6 5-min watch"
        })
        # Extract breach list for Agent6 watch
        breaches = plan.get("breaches", [])
        if not isinstance(breaches, list):
            # Build from breach_summary if raw breaches not available
            bs = plan.get("breach_summary", {})
            breaches = [{"metric": f"{inc_nf}_breach_{i}", "severity": "CRITICAL"}
                        for i, inc_nf in enumerate(incident["nfs"])]
        # Hand to Agent6 — it will auto-resolve OR escalate to Agent7
        state.agent6.watch(incident["id"], breaches, kpi_snapshot=state.kpi_snapshot)
        await kafka.produce("incident_stream", incident["id"], {
            "id": incident["id"], "priority": incident["priority"], "status": "OPEN"
        })
        log.info("Incident %s [%s] → Agent6 watching (no L2 popup yet)",
                 incident["id"], incident["priority"])
    state.bus._handlers.setdefault("agent5", {})["remediation"] = patched

    log.info("All agents wired (1-7). spaCy: %s. API key: %s",
             "ok" if SPACY_OK else "blank", "SET" if api_key else "NOT SET")

    # Initial seed
    asyncio.create_task(_seed())
    asyncio.create_task(sla_monitor_loop())
    asyncio.create_task(kafka.start_kpi_stream(kpis_flat, broadcast))

async def _seed():
    await asyncio.sleep(1.5)
    await _run_cycle()

# ─────────────────────────────────────────────────────────────────────────────
# PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

async def _run_cycle():
    if state.pipeline_running: return
    state.pipeline_running = True
    state.last_run_at = datetime.now(timezone.utc).isoformat()
    state.cycle_count += 1

    scenario = state.next_scenario()
    snap     = build_snapshot(scenario)
    state.kpi_snapshot = snap
    update_node_health(scenario)

    if state.agent3:
        state.agent3._query_loki = AsyncMock(return_value=scenario.get("logs",[]))

    await broadcast("kpi_update", snap)
    await broadcast("pipeline_status", {"running":True,"cycle":state.cycle_count,
                                         "started_at":state.last_run_at})
    await broadcast("topology_update", get_topology_data())
    await broadcast("kpi_history_update", {k:list(v) for k,v in state.kpi_history.items()})
    await kafka.produce("kpi_stream", "pipeline_cycle",
        {"cycle":state.cycle_count,"scenario":scenario["priority"]})

    corr = str(uuid.uuid4())
    msg  = MCPMessage(sender="agent1",receiver="agent2",message_type="kpi_data",
                      payload=snap,correlation_id=corr)
    await state.bus.publish(msg)

    await asyncio.sleep(0.5)
    state.pipeline_running = False
    await broadcast("pipeline_status",{
        "running":False,"cycle":state.cycle_count,
        "last_run_at":state.last_run_at,
        "agent_statuses":state.agent_statuses,
    })

# ─────────────────────────────────────────────────────────────────────────────
# TOPOLOGY DATA
# ─────────────────────────────────────────────────────────────────────────────

def get_topology_data():
    nodes = []
    for site_id, site in SITES.items():
        for node_id, info in site["nodes"].items():
            health = state.node_health.get(node_id, "HEALTHY")
            nodes.append({
                "id":      node_id,
                "site":    site_id,
                "site_name": site["name"],
                "lat":     info["lat"],
                "lon":     info["lon"],
                "nf":      info["nf"],
                "type":    info["type"],
                "health":  health,
                "blinking": health == "CRITICAL",
            })

    # Compute edge congestion based on node health
    edges = []
    for src, dst in NETWORK_EDGES:
        sh = state.node_health.get(src, "HEALTHY")
        dh = state.node_health.get(dst, "HEALTHY")
        if sh == "CRITICAL" or dh == "CRITICAL":
            congestion = "CRITICAL"
        elif sh == "WARNING" or dh == "WARNING":
            congestion = "WARNING"
        else:
            congestion = "HEALTHY"
        edges.append({"src":src,"dst":dst,"congestion":congestion})

    return {"nodes":nodes,"edges":edges,
            "sites":{k:{"name":v["name"],"lat":v["lat"],"lon":v["lon"]}
                     for k,v in SITES.items()}}

# ─────────────────────────────────────────────────────────────────────────────
# REST ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/status")
async def get_status():
    return {
        "pipeline_running":  state.pipeline_running,
        "last_run_at":       state.last_run_at,
        "cycle_count":       state.cycle_count,
        "agent_statuses":    state.agent_statuses,
        "active_incidents":  len(state.incidents),
        "open_incidents":    len([i for i in state.incidents.values() if i["status"] not in ("RESOLVED",)]),
        "pending_approval":  len([i for i in state.incidents.values() if i["status"]=="PENDING_APPROVAL"]),
        "mcp_message_count": len(state.mcp_messages),
        "anthropic_key_set": bool(os.getenv("ANTHROPIC_API_KEY")),
        "spacy_loaded":      SPACY_OK,
        "l2_agents_online":  len(state.online_l2_agents),
        "kafka_messages":    kafka.message_count,
    }

@app.get("/api/kpis")
async def get_kpis():
    return {"collected_at":state.kpi_snapshot.get("collected_at"),"kpis":kpis_flat()}

@app.get("/api/kpis/history/{metric}")
async def get_kpi_history(metric: str):
    hist = list(state.kpi_history.get(metric,[]))
    return {"metric":metric,"history":hist,"points":len(hist)}

@app.get("/api/incidents")
async def get_incidents():
    return {"incidents":list(state.incidents.values())}

@app.get("/api/incidents/{incident_id}")
async def get_incident(incident_id: str):
    inc = state.incidents.get(incident_id)
    if not inc: raise HTTPException(404,"Incident not found")
    return inc

@app.post("/api/incidents/{incident_id}/ack")
async def ack_incident(incident_id: str):
    inc = state.incidents.get(incident_id)
    if not inc: raise HTTPException(404,"Not found")
    inc["status"]="IN_PROGRESS"; inc["acked"]=True
    inc["updated_at"]=datetime.now(timezone.utc).isoformat()
    await broadcast("incident_updated", inc)
    return {"status":"ok","new_status":"IN_PROGRESS"}

class StatusUpdate(BaseModel):
    status: str
    resolution: str = ""

@app.post("/api/incidents/{incident_id}/status")
async def update_status(incident_id: str, body: StatusUpdate):
    inc = state.incidents.get(incident_id)
    if not inc: raise HTTPException(404,"Not found")
    valid = {"IN_PROGRESS","RESOLVED","PENDING_APPROVAL","PENDING_L2","PENDING"}
    if body.status not in valid: raise HTTPException(400,f"Invalid status. Must be one of {valid}")
    inc["status"]=body.status; inc["acked"]=body.status!="OPEN"
    inc["updated_at"]=datetime.now(timezone.utc).isoformat()
    if body.status=="RESOLVED":
        inc["resolved_at"]=inc["updated_at"]
        if body.resolution: inc["resolution"]=body.resolution
    await broadcast("incident_updated", inc)
    return {"status":"ok","incident":inc}

class NoteRequest(BaseModel):
    engineer: str
    text: str

@app.post("/api/incidents/{incident_id}/note")
async def add_note(incident_id: str, body: NoteRequest):
    inc = state.incidents.get(incident_id)
    if not inc: raise HTTPException(404,"Not found")
    note={"id":str(uuid.uuid4())[:8],"ts":datetime.now(timezone.utc).isoformat(),
          "engineer":body.engineer,"text":body.text}
    inc["notes"].append(note); inc["updated_at"]=note["ts"]
    await broadcast("incident_note",{"incident_id":incident_id,"note":note})
    await broadcast("incident_updated",inc)
    return {"status":"ok","note":note}

class PendingRequest(BaseModel):
    reason: str = "Pending L2 investigation"

@app.post("/api/incidents/{incident_id}/pending")
async def set_pending(incident_id: str, body: PendingRequest):
    inc = state.incidents.get(incident_id)
    if not inc: raise HTTPException(404,"Not found")
    inc["status"]="PENDING"; inc["pending_reason"]=body.reason
    inc["updated_at"]=datetime.now(timezone.utc).isoformat()
    await broadcast("incident_updated",inc)
    return {"status":"ok","incident_id":incident_id}

class ApprovalRequest(BaseModel):
    approver: str

@app.post("/api/incidents/{incident_id}/approve")
async def approve_incident(incident_id: str, body: ApprovalRequest):
    inc = state.incidents.get(incident_id)
    if not inc: raise HTTPException(404,"Not found")
    if inc["status"] != "PENDING_APPROVAL":
        raise HTTPException(400,"Incident is not in PENDING_APPROVAL state")
    result = await state.agent7.execute_approved(incident_id, body.approver)
    return {"status":"ok","execution":result}

@app.post("/api/pipeline/run")
async def trigger_pipeline():
    asyncio.create_task(_run_cycle())
    return {"status":"triggered","at":datetime.now(timezone.utc).isoformat()}

@app.get("/api/mcp/messages")
async def get_mcp(limit:int=100):
    return {"messages":state.mcp_messages[-limit:]}

@app.get("/api/agents/online")
async def get_online_agents():
    return {"count":len(state.online_l2_agents),
            "agents":[{"id":a.id,"name":a.name,"status":a.status,"joined":a.joined}
                      for a in state.online_l2_agents]}

@app.get("/api/topology")
async def get_topology():
    return get_topology_data()

@app.get("/api/sla")
async def get_sla():
    """SLA status for all open incidents."""
    now = datetime.now(timezone.utc)
    result = []
    for inc in state.incidents.values():
        if inc["status"] == "RESOLVED": continue
        p  = inc.get("priority","P3")
        dl = SLA.get(p, SLA["P3"])
        ack_dl = inc.get("sla_ack_deadline")
        res_dl = inc.get("sla_res_deadline")
        ack_mins_left = None
        res_hrs_left  = None
        if ack_dl:
            ack_mins_left = max(0, (datetime.fromisoformat(ack_dl)-now).total_seconds()/60)
        if res_dl:
            res_hrs_left  = max(0, (datetime.fromisoformat(res_dl)-now).total_seconds()/3600)
        result.append({
            "incident_id":    inc["id"],
            "priority":       p,
            "title":          inc.get("title","—"),
            "status":         inc["status"],
            "ack_deadline":   ack_dl,
            "res_deadline":   res_dl,
            "ack_mins_left":  round(ack_mins_left,1) if ack_mins_left is not None else None,
            "res_hrs_left":   round(res_hrs_left,2) if res_hrs_left is not None else None,
            "ack_breached":   ack_mins_left==0 if ack_mins_left is not None else False,
            "res_breached":   res_hrs_left==0  if res_hrs_left  is not None else False,
            "sla_label":      dl["label"],
        })
    return result

@app.get("/api/replay")
async def replay_kpis(t: int = 0):
    """Time-travel: return KPI snapshot at offset t seconds ago."""
    result = {}
    now = datetime.now(timezone.utc)
    for metric, pts in state.kpi_replay.items():
        target = now - timedelta(seconds=t)
        # Find closest point
        closest = min(pts, key=lambda p: abs(
            datetime.fromisoformat(p["ts"]).replace(tzinfo=timezone.utc) - target
        ), default=None)
        if closest:
            result[metric] = closest
    return result

class ChatRequest(BaseModel):
    incident_id: str
    message: str

@app.post("/api/chat")
async def chat(req: ChatRequest):
    inc     = state.incidents.get(req.incident_id)
    api_key = os.getenv("ANTHROPIC_API_KEY","")
    if state.agent5 and req.incident_id not in state.agent5._active_incidents:
        if inc: state.agent5._active_incidents[req.incident_id] = inc
    if api_key:
        import aiohttp
        if not state.agent5._session or isinstance(state.agent5._session, AsyncMock):
            state.agent5._session = aiohttp.ClientSession()
        reply = await state.agent5.handle_engineer_query(req.incident_id, req.message)
        model = "claude-sonnet-4"
    else:
        reply = _canned_reply(req.message, inc)
        model = "simulated"
    return {"reply":reply,"incident_id":req.incident_id,"model":model}

def _canned_reply(q, inc):
    q2 = q.lower(); rc = inc.get("root_cause","—") if inc else "—"
    remeds = inc.get("remediations",[]) if inc else []
    plan   = inc.get("agent7_plan",{}) if inc else {}
    if any(w in q2 for w in ["root","cause","why","reason"]):
        return f"**Root Cause (spaCy NLP):**\n{rc}\n\nAgent7 plan confidence: {plan.get('overall_confidence','N/A')}%"
    if any(w in q2 for w in ["oc ","command","step","fix","run"]):
        steps = remeds[0].get("steps",[]) if remeds else []
        return "**Remediation commands:**\n```\n"+"\n".join(steps[:5])+"\n```" if steps else "Run: `oc get pods -n 5gc-smf`"
    if any(w in q2 for w in ["approve","approval","agent7"]):
        return f"The incident is **{inc.get('status','?') if inc else '?'}**. If status is PENDING_APPROVAL, use the Approve button in the L2 Approval tab."
    if any(w in q2 for w in ["sla","time","deadline","breach"]):
        return f"SLA: **{inc.get('sla','—') if inc else '—'}**\nACK deadline: {inc.get('sla_ack_deadline','—') if inc else '—'}"
    return (f"I have full context for this incident.\n\nAsk me:\n"
            f"- *What is the root cause?*\n- *Show oc commands*\n"
            f"- *What is the SLA?*\n- *Agent7 approval status?*\n\n"
            f"Set `ANTHROPIC_API_KEY` for live Claude responses.")

# ─────────────────────────────────────────────────────────────────────────────
# STATIC PAGES
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/")
async def serve_dash():    return FileResponse("dashboard.html")
@app.get("/chat")
async def serve_chat():    return FileResponse("chat.html")
@app.get("/admin")
async def serve_admin():   return FileResponse("admin.html")
@app.get("/topology")
async def serve_topology(): return FileResponse("topology.html")

# ─────────────────────────────────────────────────────────────────────────────
# WEBSOCKET
# ─────────────────────────────────────────────────────────────────────────────

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    state.ws_clients[ws] = None
    log.info("WS connected (%d total)", len(state.ws_clients))

    await ws.send_text(json.dumps({"type":"init","data":{
        "kpis":           kpis_flat(),
        "incidents":      list(state.incidents.values()),
        "mcp_messages":   state.mcp_messages[-50:],
        "agent_statuses": state.agent_statuses,
        "pipeline_running": state.pipeline_running,
        "kpi_history":    {k:list(v) for k,v in state.kpi_history.items()},
        "l2_agents_online": [{"id":a.id,"name":a.name,"status":a.status}
                              for a in state.online_l2_agents],
        "topology":       get_topology_data(),
        "kafka_stats":    {"message_count":kafka.message_count},
    }}))

    try:
        while True:
            try:
                raw = await asyncio.wait_for(ws.receive_text(), timeout=30)
            except asyncio.TimeoutError:
                try: await ws.send_text(json.dumps({"type":"pong"}))
                except: break
                continue
            try: data = json.loads(raw)
            except: continue

            action = data.get("action","")
            if action == "ping":
                try: await ws.send_text(json.dumps({"type":"pong"}))
                except: break
            elif action == "run_pipeline":
                asyncio.create_task(_run_cycle())
                try: await ws.send_text(json.dumps({"type":"ack","action":"run_pipeline"}))
                except: break
            elif action == "register":
                name  = data.get("name","Anonymous")
                agent = L2Agent(ws, name)
                state.ws_clients[ws] = agent
                log.info("L2 registered: %s", name)
                await broadcast("l2_agent_joined",{
                    "id":agent.id,"name":name,"status":"available",
                    "total_online":len(state.online_l2_agents)
                })
    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.warning("WS error: %s", e)
    finally:
        agent = state.ws_clients.pop(ws, None)
        if agent:
            await broadcast("l2_agent_left",{"id":agent.id,"name":agent.name,
                "total_online":len(state.online_l2_agents)})
        log.info("WS disconnected (%d remaining)", len(state.ws_clients))

# Auto-refresh every 60s
@app.on_event("startup")
async def auto_refresh():
    async def loop():
        while True:
            await asyncio.sleep(60)
            await _run_cycle()
    asyncio.create_task(loop())

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api_server:app", host="0.0.0.0", port=8000, reload=False)
