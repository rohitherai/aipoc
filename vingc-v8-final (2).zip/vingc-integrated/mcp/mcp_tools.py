"""
VINGC MCP Tool Definitions
Formal tool schemas following the Model Context Protocol specification.
These are registered on the MCP bus and can be called by any agent or
by an external orchestrator (e.g. Claude via tool_use).

Each tool definition includes:
  - name, description
  - JSON Schema input_schema
  - The async handler function
"""

from typing import Any, Dict, List
from dataclasses import dataclass


@dataclass
class MCPTool:
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: Any  # async callable


# ── Tool registry ────────────────────────────────────────────────────────────

MCP_TOOLS: List[MCPTool] = [

    MCPTool(
        name="collect_nf_kpis",
        description=(
            "Collect real-time KPI metrics for one or all 5G network functions "
            "(SMF, UDR) from Prometheus. Returns a timestamped snapshot of all "
            "configured metrics with their current values and thresholds."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "network_function": {
                    "type": "string",
                    "enum": ["SMF", "UDR", "ALL"],
                    "description": "Which NF to collect KPIs for. Use 'ALL' for both.",
                    "default": "ALL",
                },
                "time_range_minutes": {
                    "type": "integer",
                    "description": "Look-back window for rate/histogram queries (default: 5).",
                    "default": 5,
                    "minimum": 1,
                    "maximum": 60,
                },
            },
            "required": [],
        },
        handler=None,  # set at runtime: agent1._fetch_all_kpis
    ),

    MCPTool(
        name="analyze_thresholds",
        description=(
            "Evaluate a KPI snapshot against configured thresholds. "
            "Returns a list of breaches sorted by excess percentage, "
            "with CRITICAL (≥150% of threshold) and WARNING (≥100%) severity bands."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "kpi_snapshot": {
                    "type": "object",
                    "description": "KPI snapshot as returned by collect_nf_kpis.",
                },
                "include_ok": {
                    "type": "boolean",
                    "description": "Include metrics within threshold in the response.",
                    "default": False,
                },
            },
            "required": ["kpi_snapshot"],
        },
        handler=None,  # set at runtime: agent2._analyze
    ),

    MCPTool(
        name="query_syslogs",
        description=(
            "Query the centralized logging server (Loki/EFK) for log entries "
            "matching a network function and optional fault pattern. "
            "Returns matching log lines with fault classification."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "network_function": {
                    "type": "string",
                    "enum": ["SMF", "UDR", "SYSTEM", "ALL"],
                    "description": "NF namespace to scope the log query.",
                },
                "pattern": {
                    "type": "string",
                    "description": "Optional regex pattern to filter log lines.",
                },
                "lookback_minutes": {
                    "type": "integer",
                    "description": "How many minutes back to search (default: 15).",
                    "default": 15,
                    "minimum": 1,
                    "maximum": 1440,
                },
                "max_lines": {
                    "type": "integer",
                    "description": "Maximum log lines to return (default: 200).",
                    "default": 200,
                    "maximum": 1000,
                },
            },
            "required": ["network_function"],
        },
        handler=None,  # set at runtime: agent3._query_loki
    ),

    MCPTool(
        name="correlate_incident",
        description=(
            "Correlate KPI threshold breaches with syslog events to produce "
            "a structured incident record. Matches breach timestamps against "
            "log fault patterns and returns root cause hints."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "breaches": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Breach list from analyze_thresholds.",
                },
            },
            "required": ["breaches"],
        },
        handler=None,
    ),

    MCPTool(
        name="lookup_knowledge_base",
        description=(
            "Search the VINGC knowledge base for remediation runbooks matching "
            "a fault description and network function. Returns matching KB entries "
            "with step-by-step resolution procedures and runbook URLs."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "fault_description": {
                    "type": "string",
                    "description": "Natural language description of the fault to look up.",
                },
                "network_function": {
                    "type": "string",
                    "enum": ["SMF", "UDR", "SYSTEM"],
                    "description": "NF context for scoping the search.",
                },
            },
            "required": ["fault_description", "network_function"],
        },
        handler=None,  # set at runtime: agent4._lookup_kb
    ),

    MCPTool(
        name="generate_llm_remediation",
        description=(
            "Call the Claude LLM to generate remediation steps for a fault that "
            "has no matching knowledge base entry. Returns structured steps and "
            "a brief rationale. Flag output as LLM-generated before applying."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "fault":              {"type": "string", "description": "Fault name or description."},
                "network_function":   {"type": "string", "description": "Affected NF (SMF, UDR, SYSTEM)."},
                "severity":           {"type": "string", "enum": ["CRITICAL", "WARNING", "INFO"]},
                "sample_logs":        {"type": "array",  "items": {"type": "string"}, "description": "Up to 3 sample log lines."},
                "correlated_metric":  {"type": "string", "description": "KPI metric name linked to this fault."},
            },
            "required": ["fault", "network_function", "severity"],
        },
        handler=None,  # set at runtime: agent4._llm_fallback
    ),

    MCPTool(
        name="notify_l2_engineers",
        description=(
            "Send a real-time pop-up alert with remediation plan to L2 engineers "
            "via Slack, Microsoft Teams, and/or the internal WebSocket chatbot. "
            "Returns delivery status per channel."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "incident_id": {"type": "string"},
                "priority":    {"type": "string", "enum": ["P1", "P2", "P3"]},
                "remediation_plan": {
                    "type": "object",
                    "description": "Full remediation plan as produced by Agent 4.",
                },
                "channels": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["slack", "teams", "websocket"]},
                    "description": "Which channels to notify (default: all configured).",
                    "default": ["slack", "teams", "websocket"],
                },
            },
            "required": ["incident_id", "priority", "remediation_plan"],
        },
        handler=None,  # set at runtime: agent5
    ),

    MCPTool(
        name="get_pipeline_status",
        description=(
            "Return the current status of all 5 agents, the last pipeline run "
            "timestamp, active incident count, and Prometheus metrics summary."
        ),
        input_schema={
            "type": "object",
            "properties": {},
            "required": [],
        },
        handler=None,  # set at runtime: health_server._state
    ),

    MCPTool(
        name="trigger_manual_collection",
        description=(
            "Manually trigger an immediate KPI collection cycle, bypassing the "
            "scheduled poll interval. Useful for on-demand incident investigation."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Optional reason for the manual trigger (logged for audit).",
                },
            },
            "required": [],
        },
        handler=None,
    ),
]


def get_tool_by_name(name: str) -> MCPTool:
    for tool in MCP_TOOLS:
        if tool.name == name:
            return tool
    raise KeyError(f"MCP tool '{name}' not found")


def tools_as_anthropic_spec() -> list:
    """
    Return tool definitions in Anthropic tool_use format.
    Pass this to the Claude API `tools` parameter to let Claude
    call VINGC agent capabilities directly.
    """
    return [
        {
            "name":         t.name,
            "description":  t.description,
            "input_schema": t.input_schema,
        }
        for t in MCP_TOOLS
    ]
