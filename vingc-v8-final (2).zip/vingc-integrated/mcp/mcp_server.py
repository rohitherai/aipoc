"""
VINGC MCP Protocol Server
Acts as the central message bus coordinating all 5 agents.
Implements the Model Context Protocol (MCP) for agent-to-agent communication.
"""

import asyncio
import json
import logging
from typing import Any, Dict, Optional, Callable
from datetime import datetime
from dataclasses import dataclass, asdict, field
import uuid

logging.basicConfig(level=logging.INFO, format="%(asctime)s [MCP] %(message)s")
log = logging.getLogger("mcp_server")


@dataclass
class MCPMessage:
    """Standardized MCP message envelope used by all agents."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    sender: str = ""
    receiver: str = ""
    message_type: str = ""      # "kpi_data" | "threshold_breach" | "correlation" | "remediation" | "alert"
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    correlation_id: Optional[str] = None   # links messages in a pipeline run

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, data: str) -> "MCPMessage":
        return cls(**json.loads(data))


class MCPBus:
    """
    Central MCP protocol bus.
    Agents register handlers; bus routes messages by (receiver, message_type).
    """

    def __init__(self):
        self._handlers: Dict[str, Dict[str, Callable]] = {}   # {agent_id: {msg_type: handler}}
        self._history: list[MCPMessage] = []
        self._running = True

    def register(self, agent_id: str, message_type: str, handler: Callable):
        """Register an agent handler for a specific message type."""
        self._handlers.setdefault(agent_id, {})[message_type] = handler
        log.info("Registered handler: agent=%s type=%s", agent_id, message_type)

    async def publish(self, msg: MCPMessage) -> Optional[MCPMessage]:
        """Publish a message; returns response if handler produces one."""
        self._history.append(msg)
        log.info("MSG [%s] %s → %s [%s]", msg.id[:8], msg.sender, msg.receiver, msg.message_type)

        agent_handlers = self._handlers.get(msg.receiver, {})
        handler = agent_handlers.get(msg.message_type) or agent_handlers.get("*")

        if not handler:
            log.warning("No handler for receiver=%s type=%s", msg.receiver, msg.message_type)
            return None

        return await handler(msg)

    def get_history(self, correlation_id: str = None) -> list:
        if correlation_id:
            return [m for m in self._history if m.correlation_id == correlation_id]
        return list(self._history)


# Singleton bus used by all agents
bus = MCPBus()
