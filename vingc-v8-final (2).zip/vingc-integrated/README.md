# VINGC Agentic AI — Integrated UI + Agent System

## What's included

```
vingc-integrated/
├── api_server.py          ← Python backend: FastAPI + WebSocket + all 5 agents
├── dashboard.html         ← L2 Ops Dashboard UI (KPIs, incidents, pipeline strip)
├── chat.html              ← L2 Chatbot UI (alert card, Q&A, MCP inspector)
├── Icons.jsx              ← Icon library (from design system)
├── Badges.jsx             ← Badge components (from design system)
├── colors_and_type.css    ← Full design token system (dark theme)
├── assets/                ← Logo and SVG assets
├── agents/                ← Python agents 1-5
├── mcp/                   ← MCP bus + tool definitions
├── tools/                 ← Health server + Prometheus metrics
├── config/                ← config.json
├── requirements.txt       ← Python dependencies
├── start.bat              ← Windows one-click launcher
└── start.sh               ← macOS/Linux launcher
```

---

## Run on Windows (your machine)

### Step 1 — Install Python 3.10+
Download from https://python.org/downloads — tick "Add Python to PATH" during install.

### Step 2 — Unzip the project
```
Unzip vingc-integrated.zip → you get a vingc-integrated\ folder
```

### Step 3 — Double-click start.bat
The script:
- Installs all Python dependencies automatically (first run only)
- Starts the API server on http://localhost:8000
- Opens your browser automatically

### Step 4 — Use the UI
| URL | Purpose |
|-----|---------|
| http://localhost:8000/ | L2 Operations Dashboard |
| http://localhost:8000/chat | L2 Chatbot (click an incident first) |
| http://localhost:8000/docs | FastAPI auto-generated API docs |

---

## Run manually (command line)

```cmd
cd vingc-integrated

:: Install once
pip install fastapi "uvicorn[standard]" aiohttp pydantic prometheus-client python-multipart

:: Start server
python api_server.py
```

Then open http://localhost:8000 in your browser.

---

## Enable real Claude API (optional)

Without a key, Agent 4 LLM fallback is mocked and chatbot gives canned answers.
With the key, both use real Claude claude-sonnet-4.

```cmd
:: Windows Command Prompt
set ANTHROPIC_API_KEY=sk-ant-api03-your-key-here
python api_server.py

:: Windows PowerShell
$env:ANTHROPIC_API_KEY="sk-ant-api03-your-key-here"
python api_server.py
```

---

## How the integration works

```
Browser UI (dashboard.html / chat.html)
        │  HTTP REST + WebSocket
        ▼
   api_server.py  (FastAPI on port 8000)
        │  MCP bus.publish()
        ▼
   Agent 2 → Agent 3 → Agent 4 → Agent 5
        │
        ▼ (Agent 5 pushes to WS instead of Slack)
   WebSocket broadcast → Browser UI
        (live KPI updates, new incident popup, MCP message stream)
```

**Key design:**
- The browser connects over WebSocket on startup and receives all live events
- Clicking "Run pipeline" sends an action over the WebSocket
- Agent 5's Slack/Teams notification is replaced by a WebSocket broadcast so the
  browser receives the same rich card that would go to Slack
- The chatbot Q&A calls `POST /api/chat` which routes to Agent 5's
  `handle_engineer_query()` — the same function that would answer Slack DMs

---

## API endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/status | Pipeline + agent health |
| GET | /api/kpis | Latest 16 KPI values |
| GET | /api/incidents | All incidents |
| GET | /api/incidents/{id} | Single incident detail |
| POST | /api/incidents/{id}/ack | Acknowledge an incident |
| POST | /api/pipeline/run | Trigger manual pipeline cycle |
| POST | /api/chat | Chatbot message → Claude response |
| GET | /api/mcp/messages | Recent MCP bus message log |
| WS | /ws | Live event stream |

---

## Troubleshooting

**"Module not found" error**
→ Run `pip install fastapi "uvicorn[standard]" aiohttp pydantic prometheus-client python-multipart`

**Browser shows "API disconnected"**
→ Make sure `python api_server.py` is running and check http://localhost:8000/api/status

**No incidents appearing**
→ Click "Run" in the Pipeline Strip — incidents appear after the first pipeline cycle (~2 seconds)

**Chatbot not responding**
→ You must click "Acknowledge" on the alert card before the chat unlocks

**Want real Claude answers?**
→ Set ANTHROPIC_API_KEY environment variable before starting the server
