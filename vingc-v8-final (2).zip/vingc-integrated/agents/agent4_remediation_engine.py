"""
Agent 4 — Remediation Engine
Receives correlated incident from Agent 3.
1. Looks up the knowledge base (runbooks / SOPs).
2. If no match found, calls Claude/LLM for a remediation recommendation.
3. Passes the full remediation plan to Agent 5 (ChatBot Notifier).
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional
import aiohttp

from mcp.mcp_server import MCPBus, MCPMessage

log = logging.getLogger("agent4.remediation_engine")


# ─────────────────────────────────────────────────────────────────────────────
#  Embedded Knowledge Base  (production: replace with vector DB / Confluence)
# ─────────────────────────────────────────────────────────────────────────────
KNOWLEDGE_BASE: List[Dict] = [
    {
        "id": "KB-SMF-001",
        "title": "SMF N4 Association Failure",
        "fault_keywords": ["N4 association failure", "PFCP heartbeat timeout"],
        "nf": "SMF",
        "steps": [
            "1. Verify UPF pods are running: `oc get pods -n 5gc-upf`",
            "2. Check N4 interface connectivity: `oc exec -n 5gc-smf <pod> -- ping <upf-n4-ip>`",
            "3. Inspect SMF N4 config: `oc get configmap smf-config -n 5gc-smf -o yaml | grep n4`",
            "4. Restart SMF N4 controller: `oc rollout restart deployment/smf-n4-ctrl -n 5gc-smf`",
            "5. Monitor PFCP association metrics in Grafana dashboard 'SMF-N4-Health'",
        ],
        "runbook_url": "https://wiki.vingc.internal/runbooks/smf-n4-failure",
        "priority": "P1",
    },
    {
        "id": "KB-SMF-002",
        "title": "SMF High Session Establishment Latency",
        "fault_keywords": ["smf_n4_message_latency", "PDU session establishment fail"],
        "nf": "SMF",
        "steps": [
            "1. Check SMF pod resource limits: `oc describe pod <smf-pod> -n 5gc-smf`",
            "2. Scale up SMF replicas: `oc scale deployment/smf --replicas=<n> -n 5gc-smf`",
            "3. Review N4 queue depth: check metric `smf_n4_queue_depth`",
            "4. Inspect UPF selection algorithm configuration",
            "5. Enable SMF session caching if not already active",
        ],
        "runbook_url": "https://wiki.vingc.internal/runbooks/smf-high-latency",
        "priority": "P2",
    },
    {
        "id": "KB-UDR-001",
        "title": "UDR Database Connection Pool Exhaustion",
        "fault_keywords": ["DB pool exhaustion", "database connection pool exhausted", "udr_db_connection_pool"],
        "nf": "UDR",
        "steps": [
            "1. Check current pool usage: query metric `udr_db_pool_used/udr_db_pool_total`",
            "2. Increase max pool size in UDR config: `oc edit configmap udr-db-config -n 5gc-udr`",
            "3. Identify long-running queries: `oc exec -n 5gc-udr <db-pod> -- psql -c 'SELECT * FROM pg_stat_activity WHERE state=active'`",
            "4. Terminate idle connections older than 5 min",
            "5. Consider read-replica routing for subscription reads",
        ],
        "runbook_url": "https://wiki.vingc.internal/runbooks/udr-db-pool-exhaustion",
        "priority": "P1",
    },
    {
        "id": "KB-UDR-002",
        "title": "UDR High Response Latency",
        "fault_keywords": ["Nudr interface timeout", "udr_response_latency", "subscription data not found"],
        "nf": "UDR",
        "steps": [
            "1. Enable UDR subscription cache: `oc set env deployment/udr CACHE_ENABLED=true -n 5gc-udr`",
            "2. Verify DB replication status: check `udr_db_replication_lag`",
            "3. Scale UDR replicas horizontally: `oc scale deployment/udr --replicas=<n>`",
            "4. Review Nudr API rate limiting config",
            "5. Check Persistent Volume performance: `oc get pvc -n 5gc-udr`",
        ],
        "runbook_url": "https://wiki.vingc.internal/runbooks/udr-high-latency",
        "priority": "P2",
    },
    {
        "id": "KB-OCP-001",
        "title": "OpenShift Pod OOM / CrashLoop",
        "fault_keywords": ["Container OOM kill", "Pod crash loop", "CrashLoopBackOff", "OOMKilled"],
        "nf": "SYSTEM",
        "steps": [
            "1. Get pod events: `oc describe pod <pod> -n <ns>`",
            "2. Increase memory limits in deployment: `oc set resources deployment/<name> --limits=memory=4Gi`",
            "3. Review application heap settings (JVM: -Xmx, Go: GOMEMLIMIT)",
            "4. Check for memory leaks using pprof or JFR profiling",
            "5. Enable VPA for automatic right-sizing",
        ],
        "runbook_url": "https://wiki.vingc.internal/runbooks/ocp-oom-crashloop",
        "priority": "P1",
    },
]


class RemediationEngine:
    """
    Agent 4 — KB lookup with LLM fallback.
    """

    AGENT_ID = "agent4"

    def __init__(self, bus: MCPBus, anthropic_api_key: str, llm_model: str = "claude-sonnet-4-20250514"):
        self.bus = bus
        self.api_key = anthropic_api_key
        self.llm_model = llm_model
        self._session: Optional[aiohttp.ClientSession] = None
        bus.register(self.AGENT_ID, "correlation", self._handle_correlation)

    async def _handle_correlation(self, msg: MCPMessage) -> None:
        if not self._session:
            self._session = aiohttp.ClientSession()

        incident = msg.payload
        log.info("Processing incident %s — %d correlated events",
                 incident.get("incident_id"), incident.get("fault_count", 0))

        remediation_items = await self._build_remediations(incident)
        plan = {
            "incident_id":       incident["incident_id"],
            "remediation_count": len(remediation_items),
            "remediations":      remediation_items,
            "generated_at":      datetime.utcnow().isoformat(),
            "priority":          incident.get("recommended_priority", "P2"),
            "nfs_affected":      incident.get("nfs_affected", []),
            "breach_summary":    incident.get("breach_summary", {}),
        }

        out = MCPMessage(
            sender=self.AGENT_ID,
            receiver="agent5",
            message_type="remediation",
            payload=plan,
            correlation_id=msg.correlation_id,
        )
        await self.bus.publish(out)

    async def _build_remediations(self, incident: Dict) -> List[Dict]:
        items = []
        for event in incident.get("correlated_events", []):
            kb_match = self._lookup_kb(event)
            if kb_match:
                log.info("KB hit: %s for fault '%s'", kb_match["id"], event["fault"])
                items.append({
                    "fault":       event["fault"],
                    "nf":          event["correlated_nf"],
                    "source":      "knowledge_base",
                    "kb_id":       kb_match["id"],
                    "title":       kb_match["title"],
                    "steps":       kb_match["steps"],
                    "runbook_url": kb_match.get("runbook_url"),
                    "priority":    kb_match["priority"],
                    "severity":    event["severity"],
                })
            else:
                log.info("No KB match for fault '%s' — calling LLM", event["fault"])
                llm_rec = await self._llm_fallback(event, incident)
                items.append({
                    "fault":    event["fault"],
                    "nf":       event["correlated_nf"],
                    "source":   "llm_generated",
                    "title":    f"LLM Recommendation: {event['fault']}",
                    "steps":    llm_rec.get("steps", []),
                    "rationale": llm_rec.get("rationale", ""),
                    "priority": "P2",
                    "severity": event["severity"],
                    "warning":  "LLM-generated — validate before applying",
                })
        return items

    def _lookup_kb(self, event: Dict) -> Optional[Dict]:
        """Simple keyword match against knowledge base entries."""
        fault_lower = event["fault"].lower()
        nf = event["correlated_nf"]
        for entry in KNOWLEDGE_BASE:
            if entry["nf"] not in (nf, "SYSTEM"):
                continue
            for kw in entry["fault_keywords"]:
                if kw.lower() in fault_lower or fault_lower in kw.lower():
                    return entry
        return None

    async def _llm_fallback(self, event: Dict, incident: Dict) -> Dict:
        """Call Claude to generate remediation steps for unknown faults."""
        system_prompt = (
            "You are a senior 5G core network reliability engineer specializing in "
            "OpenShift-deployed network functions (SMF, UDR, AMF, UPF). "
            "Provide concise, actionable remediation steps using OpenShift CLI (oc) commands "
            "and 3GPP-aware diagnostics. Format: JSON with keys 'steps' (list of strings) "
            "and 'rationale' (one sentence). Never include markdown fences."
        )
        user_prompt = (
            f"Incident ID: {incident.get('incident_id')}\n"
            f"Network Function: {event['correlated_nf']}\n"
            f"Fault: {event['fault']}\n"
            f"Severity: {event['severity']}\n"
            f"Sample logs: {json.dumps(event.get('sample_logs', [])[:2])}\n"
            f"Correlated KPI metric: {event.get('correlated_metric', 'unknown')}\n\n"
            "Provide remediation steps and rationale."
        )
        try:
            async with self._session.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.llm_model,
                    "max_tokens": 600,
                    "system": system_prompt,
                    "messages": [{"role": "user", "content": user_prompt}],
                },
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    text = data["content"][0]["text"]
                    return json.loads(text)
                log.error("LLM API error: HTTP %d", resp.status)
        except Exception as exc:
            log.error("LLM fallback failed: %s", exc)
        return {"steps": ["Manual investigation required."], "rationale": "LLM call failed."}
