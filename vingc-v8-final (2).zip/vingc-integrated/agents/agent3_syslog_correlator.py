"""
Agent 3 — Syslog Correlator
Queries the centralized logging server (EFK/Loki), correlates syslog
events with the KPI breaches reported by Agent 2, and passes the
enriched incident to Agent 4.
"""

import asyncio
import logging
import re
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
import aiohttp

from mcp.mcp_server import MCPBus, MCPMessage

log = logging.getLogger("agent3.syslog_correlator")


# Syslog patterns that indicate known fault conditions per NF
FAULT_PATTERNS: Dict[str, List[Dict]] = {
    "SMF": [
        {"pattern": r"N4\s+association\s+failed",              "fault": "N4 association failure",         "severity": "CRITICAL"},
        {"pattern": r"PDU\s+session\s+establishment\s+failed", "fault": "PDU session establishment fail", "severity": "CRITICAL"},
        {"pattern": r"PFCP\s+heartbeat\s+timeout",             "fault": "PFCP heartbeat timeout",         "severity": "WARNING"},
        {"pattern": r"UPF\s+selection\s+failed",               "fault": "UPF selection failure",          "severity": "WARNING"},
        {"pattern": r"QoS\s+flow\s+creation\s+failed",         "fault": "QoS flow creation failure",      "severity": "WARNING"},
        {"pattern": r"N11\s+message\s+timeout",                "fault": "N11 (AMF) timeout",              "severity": "WARNING"},
        {"pattern": r"DNN\s+not\s+found",                      "fault": "DNN resolution failure",         "severity": "INFO"},
    ],
    "UDR": [
        {"pattern": r"database\s+connection\s+pool\s+exhausted", "fault": "DB pool exhaustion",           "severity": "CRITICAL"},
        {"pattern": r"subscription\s+data\s+not\s+found",        "fault": "Subscription lookup miss",     "severity": "WARNING"},
        {"pattern": r"Nudr.*timeout",                            "fault": "Nudr interface timeout",       "severity": "WARNING"},
        {"pattern": r"replication\s+lag\s+exceeded",             "fault": "DB replication lag",           "severity": "CRITICAL"},
        {"pattern": r"5xx\s+error\s+rate\s+spike",               "fault": "HTTP 5xx spike",               "severity": "WARNING"},
    ],
    "SYSTEM": [
        {"pattern": r"OOMKilled",                               "fault": "Container OOM kill",             "severity": "CRITICAL"},
        {"pattern": r"CrashLoopBackOff",                        "fault": "Pod crash loop",                 "severity": "CRITICAL"},
        {"pattern": r"node.*not\s+ready",                       "fault": "OpenShift node not ready",       "severity": "CRITICAL"},
        {"pattern": r"PersistentVolumeClaim.*pending",          "fault": "PVC pending",                    "severity": "WARNING"},
        {"pattern": r"etcd.*leader\s+election",                 "fault": "etcd leader election",          "severity": "WARNING"},
    ],
}

# Map KPI metrics to correlated log patterns
KPI_TO_LOG_PATTERN: Dict[str, str] = {
    "smf_n4_message_latency_ms":        "PFCP",
    "smf_session_establishment_rate":   "PDU session",
    "smf_transaction_failure_rate_pct": "N4|N11|PFCP",
    "udr_db_connection_pool_usage_pct": "database|connection pool",
    "udr_response_latency_p95_ms":      "Nudr|timeout",
    "udr_error_rate_pct":               "5xx|error",
}


class SyslogCorrelatorAgent:
    """
    Agent 3 — queries EFK/Loki for logs matching the breach window,
    correlates by NF, fault pattern, and time proximity,
    then sends an enriched incident to Agent 4.
    """

    AGENT_ID = "agent3"

    def __init__(self, bus: MCPBus, loki_url: str, elastic_url: str = None):
        self.bus = bus
        self.loki_url = loki_url.rstrip("/")
        self.elastic_url = elastic_url
        self._session: Optional[aiohttp.ClientSession] = None
        bus.register(self.AGENT_ID, "threshold_breach", self._handle_breach)

    async def _handle_breach(self, msg: MCPMessage) -> None:
        if not self._session:
            self._session = aiohttp.ClientSession()

        breaches: List[Dict] = msg.payload.get("breaches", [])
        if not breaches:
            log.info("No breaches to correlate.")
            return

        log.info("Correlating syslogs for %d breach(es)…", len(breaches))
        correlated_events = await self._correlate(breaches)

        incident = self._build_incident(msg.payload, correlated_events)

        out = MCPMessage(
            sender=self.AGENT_ID,
            receiver="agent4",
            message_type="correlation",
            payload=incident,
            correlation_id=msg.correlation_id,
        )
        await self.bus.publish(out)

    async def _correlate(self, breaches: List[Dict]) -> List[Dict]:
        """For each breach, query Loki and match against fault patterns."""
        events: List[Dict] = []
        time_window_min = 15  # look back 15 minutes

        for breach in breaches:
            nf = breach["network_function"]
            metric = breach["metric"]
            breach_time = datetime.fromisoformat(breach["timestamp"])
            start_time = (breach_time - timedelta(minutes=time_window_min)).isoformat() + "Z"

            # Build Loki LogQL query scoped to the NF namespace
            log_query = self._build_logql(nf, metric)
            raw_logs = await self._query_loki(log_query, start_time)

            matched = self._match_patterns(raw_logs, nf)
            for m in matched:
                m["correlated_metric"] = metric
                m["correlated_nf"] = nf
                m["breach_excess_pct"] = breach["excess_pct"]
                events.append(m)

        # De-duplicate by fault type
        seen = set()
        unique_events = []
        for ev in events:
            key = (ev["correlated_nf"], ev["fault"])
            if key not in seen:
                seen.add(key)
                unique_events.append(ev)

        log.info("Correlation complete — %d unique fault event(s)", len(unique_events))
        return unique_events

    def _build_logql(self, nf: str, metric: str) -> str:
        """Construct a Loki LogQL query for the NF namespace."""
        ns_label = nf.lower()
        keyword = KPI_TO_LOG_PATTERN.get(metric, "error|fail|timeout|critical")
        return f'{{namespace=~"5gc-{ns_label}|vingc"}} |~ "(?i)({keyword})"'

    async def _query_loki(self, query: str, start: str) -> List[str]:
        """Query Loki and return a flat list of log lines."""
        url = f"{self.loki_url}/loki/api/v1/query_range"
        params = {"query": query, "start": start, "limit": 500, "direction": "backward"}
        try:
            async with self._session.get(url, params=params,
                                          timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    log.warning("Loki HTTP %d for query: %s", resp.status, query)
                    return []
                data = await resp.json()
                lines = []
                for stream in data.get("data", {}).get("result", []):
                    for _, line in stream.get("values", []):
                        lines.append(line)
                return lines
        except Exception as exc:
            log.error("Loki query error: %s", exc)
            return []

    def _match_patterns(self, log_lines: List[str], nf: str) -> List[Dict]:
        """Regex-match log lines against NF and SYSTEM fault patterns."""
        matched = []
        pattern_sets = [
            (nf, FAULT_PATTERNS.get(nf, [])),
            ("SYSTEM", FAULT_PATTERNS["SYSTEM"]),
        ]
        for _, patterns in pattern_sets:
            for fp in patterns:
                regex = re.compile(fp["pattern"], re.IGNORECASE)
                hits = [l for l in log_lines if regex.search(l)]
                if hits:
                    matched.append({
                        "fault":       fp["fault"],
                        "severity":    fp["severity"],
                        "hit_count":   len(hits),
                        "sample_logs": hits[:3],
                    })
        return matched

    def _build_incident(self, breach_payload: Dict, correlated_events: List[Dict]) -> Dict:
        """Assemble the full incident record for Agent 4."""
        critical_faults = [e for e in correlated_events if e["severity"] == "CRITICAL"]
        return {
            "incident_id":       f"INC-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            "created_at":        datetime.utcnow().isoformat(),
            "breach_summary":    breach_payload.get("summary", {}),
            "breaches":          breach_payload.get("breaches", []),
            "correlated_events": correlated_events,
            "fault_count":       len(correlated_events),
            "critical_faults":   critical_faults,
            "root_cause_hints":  self._extract_root_cause_hints(correlated_events),
            "nfs_affected":      list({e["correlated_nf"] for e in correlated_events}),
            "recommended_priority": "P1" if critical_faults else "P2",
        }

    def _extract_root_cause_hints(self, events: List[Dict]) -> List[str]:
        hints = []
        for ev in events:
            if ev["severity"] == "CRITICAL":
                hints.append(f"[{ev['correlated_nf']}] {ev['fault']} — {ev['hit_count']} log hits")
        return hints[:5]
