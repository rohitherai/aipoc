"""
Agent 2 — Threshold Analyzer
Receives KPI data from Agent 1, evaluates every metric against
configured thresholds, and forwards breach details to Agent 3.
"""

import logging
from typing import Any, Dict, List
from datetime import datetime

from mcp.mcp_server import MCPBus, MCPMessage

log = logging.getLogger("agent2.threshold_analyzer")


# Severity bands
SEVERITY_CRITICAL = "CRITICAL"
SEVERITY_WARNING  = "WARNING"
SEVERITY_INFO     = "INFO"


def _severity(value: float, threshold: float) -> str:
    ratio = value / threshold if threshold else 0
    if ratio >= 1.5:
        return SEVERITY_CRITICAL
    if ratio >= 1.0:
        return SEVERITY_WARNING
    return SEVERITY_INFO


class ThresholdAnalyzerAgent:
    """
    Agent 2 — detects KPI threshold breaches and packages them
    for syslog correlation by Agent 3.
    """

    AGENT_ID = "agent2"

    def __init__(self, bus: MCPBus):
        self.bus = bus
        bus.register(self.AGENT_ID, "kpi_data", self._handle_kpi_data)

    async def _handle_kpi_data(self, msg: MCPMessage) -> MCPMessage:
        snapshot = msg.payload
        breaches = self._analyze(snapshot)
        log.info("Analysis complete — %d breach(es) detected", len(breaches))

        out = MCPMessage(
            sender=self.AGENT_ID,
            receiver="agent3",
            message_type="threshold_breach",
            payload={
                "analysis_timestamp": datetime.utcnow().isoformat(),
                "total_kpis_checked": self._count_kpis(snapshot),
                "breaches": breaches,
                "summary": self._build_summary(breaches),
            },
            correlation_id=msg.correlation_id,
        )
        await self.bus.publish(out)
        # Return ack to Agent 1
        return MCPMessage(
            sender=self.AGENT_ID,
            receiver=msg.sender,
            message_type="ack",
            payload={"status": "analyzed", "breach_count": len(breaches)},
            correlation_id=msg.correlation_id,
        )

    def _analyze(self, snapshot: Dict[str, Any]) -> List[Dict]:
        """Walk every NF → KPI and flag those exceeding threshold."""
        breaches: List[Dict] = []
        for nf_name, nf_data in snapshot.get("network_functions", {}).items():
            for kpi in nf_data.get("kpis", []):
                value     = kpi.get("value", 0)
                threshold = kpi.get("threshold", 0)
                if value < 0:           # sentinel for query error
                    continue
                sev = _severity(value, threshold)
                if sev in (SEVERITY_WARNING, SEVERITY_CRITICAL):
                    excess_pct = round((value / threshold - 1) * 100, 2) if threshold else 0
                    breaches.append({
                        "network_function": nf_name,
                        "metric":           kpi["metric"],
                        "value":            value,
                        "unit":             kpi["unit"],
                        "threshold":        threshold,
                        "excess_pct":       excess_pct,
                        "severity":         sev,
                        "timestamp":        kpi.get("timestamp", datetime.utcnow().isoformat()),
                    })
                    log.warning("[%s] %s/%s = %.2f %s (threshold %.2f) — %s",
                                sev, nf_name, kpi["metric"], value, kpi["unit"], threshold, f"+{excess_pct}%")
        return sorted(breaches, key=lambda b: b["excess_pct"], reverse=True)

    def _count_kpis(self, snapshot: Dict) -> int:
        return sum(len(nf["kpis"]) for nf in snapshot.get("network_functions", {}).values())

    def _build_summary(self, breaches: List[Dict]) -> Dict:
        critical = [b for b in breaches if b["severity"] == SEVERITY_CRITICAL]
        warning  = [b for b in breaches if b["severity"] == SEVERITY_WARNING]
        nfs_affected = list({b["network_function"] for b in breaches})
        return {
            "critical_count": len(critical),
            "warning_count":  len(warning),
            "nfs_affected":   nfs_affected,
            "top_breach":     breaches[0] if breaches else None,
        }
