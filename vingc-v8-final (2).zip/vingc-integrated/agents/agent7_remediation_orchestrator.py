"""
agent7_remediation_orchestrator.py
Correct routing:
  - 90% of tickets: confidence-based routing
      >= 95%  -> PENDING_APPROVAL + popup to L2 Lead
      < 95%   -> PENDING_L2 + bottom notification to L2
  - 10% of tickets: always escalated directly to L2 regardless of confidence
"""
import asyncio, logging, random, uuid
from datetime import datetime, timezone
from typing import Dict, List

log = logging.getLogger("agent7")

KB = {
    "N4 association failure":        {"steps":["oc get pods -n 5gc-upf | grep -v Running","oc exec -n 5gc-smf smf-0 -- pfcp-client ping 10.0.0.3","oc rollout restart deployment/upf -n 5gc-upf","oc rollout status deployment/upf -n 5gc-upf --timeout=120s"],"base_confidence":97,"runbook":"RB-SMF-N4-001","ttm_min":8},
    "DB pool exhaustion":            {"steps":["oc exec -n 5gc-udr udr-0 -- psql -c \"SELECT count(*) FROM pg_stat_activity\"","oc set env deployment/udr -n 5gc-udr DB_POOL_SIZE=150","oc rollout restart deployment/udr -n 5gc-udr"],"base_confidence":94,"runbook":"RB-UDR-POOL-001","ttm_min":5},
    "PDU session establishment fail":{"steps":["oc logs -n 5gc-smf smf-0 --since=10m | grep -i PDU","oc rollout restart deployment/smf -n 5gc-smf"],"base_confidence":91,"runbook":"RB-SMF-PDU-002","ttm_min":6},
    "CPU throttling":                {"steps":["oc top pods -n 5gc-smf","oc patch hpa smf-hpa -n 5gc-smf -p '{\"spec\":{\"maxReplicas\":8}}'","oc scale deployment/smf --replicas=4 -n 5gc-smf"],"base_confidence":96,"runbook":"RB-OCP-CPU-003","ttm_min":4},
    "Container OOM kill":            {"steps":["oc describe node | grep -A10 Allocatable","oc set resources deployment/smf -n 5gc-smf --limits=memory=4Gi","oc rollout restart deployment/smf -n 5gc-smf"],"base_confidence":93,"runbook":"RB-OCP-OOM-004","ttm_min":7},
    "Nudr interface timeout":        {"steps":["oc exec -n 5gc-smf smf-0 -- curl -k https://udr.5gc-udr.svc.cluster.local/nudr-dr/v2/health","oc rollout restart deployment/udr -n 5gc-udr"],"base_confidence":92,"runbook":"RB-UDR-NUDR-005","ttm_min":5},
    "PFCP heartbeat timeout":        {"steps":["oc exec -n 5gc-upf upf-0 -- pfcpd status","oc rollout restart deployment/upf -n 5gc-upf","oc exec -n 5gc-smf smf-0 -- pfcp-client check-association"],"base_confidence":95,"runbook":"RB-SMF-PFCP-006","ttm_min":6},
    "throughput breach":             {"steps":["oc top pods -n 5gc-upf","oc scale deployment/upf --replicas=3 -n 5gc-upf"],"base_confidence":88,"runbook":"RB-UPF-TPUT-007","ttm_min":10},
    "replication lag":               {"steps":["oc exec -n 5gc-udr udr-0 -- psql -c \"SELECT * FROM pg_stat_replication\"","oc rollout restart deployment/udr-replica -n 5gc-udr"],"base_confidence":89,"runbook":"RB-UDR-REPL-008","ttm_min":8},
    "paging failure":                {"steps":["oc logs -n 5gc-amf amf-0 --since=15m | grep -i paging","oc rollout restart deployment/amf -n 5gc-amf"],"base_confidence":82,"runbook":"RB-AMF-PAGE-009","ttm_min":9},
    "handover failure":              {"steps":["oc logs -n 5gc-amf amf-0 --since=15m | grep -i handover","oc exec -n 5gc-amf amf-0 -- amf-cli show handover-stats"],"base_confidence":78,"runbook":"RB-AMF-HO-010","ttm_min":12},
    "bearer setup":                  {"steps":["oc logs -n 5gc-smf smf-0 --since=10m | grep -i bearer","oc set env deployment/smf -n 5gc-smf BEARER_TIMEOUT=15000"],"base_confidence":84,"runbook":"RB-SMF-BEAR-011","ttm_min":7},
    "N11 timeout":                   {"steps":["oc exec -n 5gc-smf smf-0 -- curl https://amf.5gc-amf.svc.cluster.local/namf-comm/v1/health","oc rollout restart deployment/amf -n 5gc-amf"],"base_confidence":86,"runbook":"RB-AMF-N11-012","ttm_min":8},
}

# Counters for 10% forced-L2 rule
_analyze_count = 0

class RemediationOrchestratorAgent:
    def __init__(self, bus, state_ref, broadcast_fn):
        self.bus       = bus
        self.state     = state_ref
        self.broadcast = broadcast_fn
        self._pending: Dict[str, Dict] = {}

    async def analyze(self, incident_id: str, breaches: List):
        global _analyze_count
        inc = self.state.get(incident_id)
        if not inc:
            return
        _analyze_count += 1
        log.info("Agent7: analyzing %s [#%d]", incident_id, _analyze_count)
        await asyncio.sleep(3)   # simulate analysis

        plan       = self._build_plan(inc, breaches)
        confidence = plan["overall_confidence"]

        # Rule: every 10th ticket (10%) always goes to L2 regardless of confidence
        force_l2 = (_analyze_count % 10 == 0)
        if force_l2:
            log.info("Agent7: %s force-escalated to L2 (10%% rule, ticket #%d)",
                     incident_id, _analyze_count)

        note = {
            "id":       str(uuid.uuid4())[:8],
            "ts":       datetime.now(timezone.utc).isoformat(),
            "engineer": "agent7_orchestrator",
            "text":     (
                f"🔍 Agent7 RCA complete. Confidence: **{confidence:.1f}%** "
                f"({'force-escalated to L2 — 10% rule' if force_l2 else '≥95% → L2 Approval' if confidence >= 95 else '<95% → L2 Assignment'}). "
                f"Matched {len(plan['remediations'])} KB entry(s). "
                f"Estimated TTM: {plan['estimated_ttm_min']} min."
            )
        }
        inc["notes"].append(note)
        inc["agent7_plan"] = plan
        await self.broadcast("incident_note", {"incident_id": incident_id, "note": note})

        if force_l2:
            await self._route_l2(incident_id, inc, plan,
                                  reason=f"Force-escalated to L2 (every 10th ticket rule). "
                                         f"Confidence was {confidence:.1f}%.")
        elif confidence >= 95.0:
            await self._route_approval(incident_id, inc, plan)
        else:
            await self._route_l2(incident_id, inc, plan)

        await self.broadcast("incident_updated", inc)

    def _build_plan(self, inc: Dict, breaches: List) -> Dict:
        remediations = []
        ttm_total    = 0
        seen         = set()
        priority     = inc.get("priority", "P2")
        # Confidence bias: P1 tends higher (better KB coverage), P3 lower
        bias = {"P1": 4, "P2": 0, "P3": -10}.get(priority, 0)

        for r in inc.get("remediations", []):
            fault = r.get("fault", "") or r.get("title", "")
            kb = self._match_kb(fault)
            if kb and fault not in seen:
                seen.add(fault)
                conf = max(60.0, min(99.0, kb["base_confidence"] + bias + random.uniform(-5, 5)))
                remediations.append({"fault": fault, "steps": kb["steps"],
                                     "runbook": kb["runbook"], "confidence": round(conf, 1),
                                     "ttm_min": kb["ttm_min"], "status": "planned"})
                ttm_total += kb["ttm_min"]

        for b in (breaches or [])[:5]:
            metric = str(b.get("metric", ""))
            hints  = []
            if "latency" in metric or "n4" in metric.lower():   hints.append("N4 association failure")
            if "pool"    in metric or "db"  in metric.lower():  hints.append("DB pool exhaustion")
            if "cpu"     in metric:                              hints.append("CPU throttling")
            if "repl"    in metric:                              hints.append("replication lag")
            if "throughput" in metric:                           hints.append("throughput breach")
            if "paging"  in metric:                              hints.append("paging failure")
            if "handover" in metric:                             hints.append("handover failure")
            if "bearer"  in metric:                              hints.append("bearer setup")
            for hint in hints:
                if hint not in seen:
                    kb = self._match_kb(hint)
                    if kb:
                        seen.add(hint)
                        conf = max(60.0, min(99.0, kb["base_confidence"] + bias + random.uniform(-5, 5)))
                        remediations.append({"fault": hint, "steps": kb["steps"],
                                             "runbook": kb["runbook"], "confidence": round(conf, 1),
                                             "ttm_min": kb["ttm_min"], "status": "planned"})
                        ttm_total += kb["ttm_min"]

        if not remediations:
            conf = max(60.0, min(99.0, 72 + bias + random.uniform(-8, 8)))
            remediations.append({"fault": "Unknown fault pattern",
                                  "steps": ["oc get pods -A --field-selector status.phase!=Running",
                                            "oc describe pod <failing-pod>",
                                            "Review Prometheus dashboard"],
                                  "runbook": "RB-GENERIC-000",
                                  "confidence": round(conf, 1),
                                  "ttm_min": 20, "status": "planned"})
            ttm_total = 20

        overall = sum(r["confidence"] for r in remediations) / len(remediations)
        return {"remediations": remediations,
                "overall_confidence": round(overall, 1),
                "estimated_ttm_min":  ttm_total,
                "created_at":         datetime.now(timezone.utc).isoformat()}

    def _match_kb(self, fault: str):
        fl = fault.lower()
        for key, val in KB.items():
            if any(w in fl for w in key.lower().split()):
                return val
        return None

    async def _route_approval(self, incident_id: str, inc: Dict, plan: Dict):
        """confidence >= 95%: popup to L2 Lead + PENDING_APPROVAL."""
        inc["status"] = "PENDING_APPROVAL"
        inc["pending_reason"] = (
            f"Agent7 plan ready — {plan['overall_confidence']:.1f}% confidence (≥95%). "
            f"L2 Lead approval required before autonomous execution.")
        self._pending[incident_id] = plan
        inc["notes"].append({
            "id":       str(uuid.uuid4())[:8],
            "ts":       datetime.now(timezone.utc).isoformat(),
            "engineer": "agent7_orchestrator",
            "text":     (f"📋 PENDING L2 APPROVAL: {plan['overall_confidence']:.1f}% ≥ 95%. "
                         f"{len(plan['remediations'])} step(s), ~{plan['estimated_ttm_min']} min. "
                         f"L2 Lead popup sent.")
        })
        # Blocking popup → L2 Lead must approve
        await self.broadcast("popup_alert", {
            "incident_id":     incident_id,
            "priority":        inc.get("priority"),
            "title":           inc.get("title"),
            "nfs":             inc.get("nfs", []),
            "severity":        inc.get("severity"),
            "root_cause":      inc.get("root_cause"),
            "confidence":      plan["overall_confidence"],
            "action_required": "L2_APPROVAL",
            "plan":            plan,
        })
        await self.broadcast("l2_approval_required", {
            "incident_id": incident_id,
            "priority":    inc.get("priority"),
            "confidence":  plan["overall_confidence"],
            "plan":        plan,
            "title":       inc.get("title"),
        })
        log.info("Agent7: PENDING_APPROVAL %s (%.1f%%) — popup fired", incident_id, plan["overall_confidence"])

    async def _route_l2(self, incident_id: str, inc: Dict, plan: Dict, reason: str = ""):
        """confidence < 95% or force-escalated: PENDING_L2 + bottom-screen notification."""
        inc["status"] = "PENDING_L2"
        inc["pending_reason"] = (
            reason or
            f"Agent7 confidence {plan['overall_confidence']:.1f}% < 95%. "
            f"Cannot auto-remediate. L2 manual investigation required.")
        inc["notes"].append({
            "id":       str(uuid.uuid4())[:8],
            "ts":       datetime.now(timezone.utc).isoformat(),
            "engineer": "agent7_orchestrator",
            "text":     (f"⚠️ ASSIGNED TO L2: {reason or 'Confidence ' + str(plan['overall_confidence']) + '% < 95%'}. "
                         f"Best runbook: {plan['remediations'][0].get('runbook','—')}. "
                         f"L2 engineer: review Agent7 findings in notes and investigate manually.")
        })
        # Bottom-screen notification — non-blocking
        await self.broadcast("l2_notification", {
            "incident_id": incident_id,
            "priority":    inc.get("priority"),
            "title":       inc.get("title"),
            "nfs":         inc.get("nfs", []),
            "severity":    inc.get("severity"),
            "confidence":  plan["overall_confidence"],
            "assigned_to": inc.get("assigned_to"),
            "runbook":     plan["remediations"][0].get("runbook", "—"),
            "message":     (reason or
                            f"Confidence {plan['overall_confidence']:.1f}% below 95%. "
                            f"Assigned to L2 for manual investigation."),
        })
        log.info("Agent7: PENDING_L2 %s (%.1f%%) — bottom notification sent",
                 incident_id, plan["overall_confidence"])

    async def execute_approved(self, incident_id: str, approver: str) -> Dict:
        inc  = self.state.get(incident_id)
        if not inc:
            return {"error": "not found"}
        plan = self._pending.get(incident_id) or inc.get("agent7_plan", {})
        inc["notes"].append({
            "id":       str(uuid.uuid4())[:8],
            "ts":       datetime.now(timezone.utc).isoformat(),
            "engineer": "agent7_orchestrator",
            "text":     (f"✅ APPROVED by {approver}. Agent7 executing plan. "
                         f"~{plan.get('estimated_ttm_min',10)} min to complete.")
        })
        inc["status"]      = "IN_PROGRESS"
        inc["approved_by"] = approver
        await self.broadcast("incident_updated", inc)
        asyncio.create_task(self._execute(incident_id, plan, approver))
        return {"status": "executing", "ttm_min": plan.get("estimated_ttm_min", 10)}

    async def _execute(self, incident_id: str, plan: Dict, approver: str):
        await asyncio.sleep(min(plan.get("estimated_ttm_min", 8) * 8, 60))
        inc = self.state.get(incident_id)
        if not inc:
            return
        now = datetime.now(timezone.utc).isoformat()
        inc["notes"].append({
            "id": str(uuid.uuid4())[:8], "ts": now,
            "engineer": "agent7_orchestrator",
            "text": (f"🎯 REMEDIATION COMPLETE. All steps executed successfully. "
                     f"Approved by: {approver} | Confidence: {plan.get('overall_confidence','?')}%.")
        })
        inc["status"]      = "RESOLVED"
        inc["resolved_at"] = now
        inc["resolution"]  = (f"Agent7 autonomous execution after L2 approval by {approver}. "
                               f"Confidence: {plan.get('overall_confidence','?')}%.")
        inc["acked"] = True
        self._pending.pop(incident_id, None)
        await self.broadcast("incident_updated", inc)
        await self.broadcast("agent_event", {
            "agent": "agent7", "event": "remediation_complete",
            "incident_id": incident_id,
            "message": "Autonomous remediation complete — ticket resolved"
        })
        log.info("Agent7: RESOLVED %s after approved execution", incident_id)
