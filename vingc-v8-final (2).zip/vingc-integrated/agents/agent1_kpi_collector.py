"""
Agent 1 — KPI Collector
Connects to Prometheus and Grafana to collect KPI metrics
for SMF and UDR network functions deployed on OpenShift.
Publishes collected data to Agent 2 via MCP bus.
"""

import asyncio
import logging
from typing import Any, Dict, List
import aiohttp
from datetime import datetime
import uuid

from mcp.mcp_server import MCPBus, MCPMessage

log = logging.getLogger("agent1.kpi_collector")


# KPI definitions per NF — thresholds are also checked here
NETWORK_FUNCTION_KPIS = {
    "SMF": [
        {"metric": "smf_session_establishment_rate",    "query": "rate(smf_session_setup_total[5m])",           "unit": "sessions/s",  "threshold": 1000},
        {"metric": "smf_session_modification_rate",    "query": "rate(smf_session_modify_total[5m])",           "unit": "sessions/s",  "threshold": 800},
        {"metric": "smf_session_release_rate",         "query": "rate(smf_session_release_total[5m])",          "unit": "sessions/s",  "threshold": 500},
        {"metric": "smf_n4_message_latency_ms",        "query": "histogram_quantile(0.95,smf_n4_latency_bucket)", "unit": "ms",        "threshold": 50},
        {"metric": "smf_cpu_utilization_pct",          "query": "avg(rate(container_cpu_usage_seconds_total{pod=~'smf-.*'}[5m]))*100", "unit": "%", "threshold": 80},
        {"metric": "smf_memory_utilization_pct",       "query": "avg(container_memory_usage_bytes{pod=~'smf-.*'}) / avg(container_spec_memory_limit_bytes{pod=~'smf-.*'})*100", "unit": "%", "threshold": 75},
        {"metric": "smf_active_sessions",              "query": "smf_active_pdu_sessions",                      "unit": "count",       "threshold": 50000},
        {"metric": "smf_transaction_failure_rate_pct", "query": "rate(smf_transaction_failure_total[5m]) / rate(smf_transaction_total[5m])*100", "unit": "%", "threshold": 1.0},
    ],
    "UDR": [
        {"metric": "udr_subscription_read_rate",       "query": "rate(udr_nudr_read_total[5m])",                "unit": "req/s",       "threshold": 5000},
        {"metric": "udr_subscription_write_rate",      "query": "rate(udr_nudr_write_total[5m])",               "unit": "req/s",       "threshold": 2000},
        {"metric": "udr_response_latency_p95_ms",      "query": "histogram_quantile(0.95,udr_response_duration_bucket)", "unit": "ms","threshold": 30},
        {"metric": "udr_db_connection_pool_usage_pct", "query": "udr_db_pool_used/udr_db_pool_total*100",       "unit": "%",           "threshold": 85},
        {"metric": "udr_cpu_utilization_pct",          "query": "avg(rate(container_cpu_usage_seconds_total{pod=~'udr-.*'}[5m]))*100", "unit": "%", "threshold": 80},
        {"metric": "udr_memory_utilization_pct",       "query": "avg(container_memory_usage_bytes{pod=~'udr-.*'}) / avg(container_spec_memory_limit_bytes{pod=~'udr-.*'})*100", "unit": "%", "threshold": 75},
        {"metric": "udr_error_rate_pct",               "query": "rate(udr_http_5xx_total[5m])/rate(udr_http_requests_total[5m])*100", "unit": "%", "threshold": 0.5},
        {"metric": "udr_throughput_mbps",              "query": "rate(udr_bytes_total[5m])/1048576",            "unit": "Mbps",        "threshold": 1000},
    ],
}


class KPICollectorAgent:
    """
    Agent 1 — polls Prometheus for NF KPIs, fetches Grafana panels,
    assembles a KPI snapshot, and forwards it to Agent 2 via MCP.
    """

    AGENT_ID = "agent1"

    def __init__(self, bus: MCPBus, prometheus_url: str, grafana_url: str, grafana_token: str):
        self.bus = bus
        self.prometheus_url = prometheus_url.rstrip("/")
        self.grafana_url = grafana_url.rstrip("/")
        self.grafana_token = grafana_token
        self._session: aiohttp.ClientSession = None
        bus.register(self.AGENT_ID, "collect_kpis", self._handle_collect)

    async def start(self, poll_interval_sec: int = 60):
        """Start continuous KPI polling loop."""
        self._session = aiohttp.ClientSession()
        log.info("Agent 1 started — poll interval %ds", poll_interval_sec)
        try:
            while True:
                correlation_id = str(uuid.uuid4())
                await self._collect_and_forward(correlation_id)
                await asyncio.sleep(poll_interval_sec)
        finally:
            await self._session.close()

    async def _handle_collect(self, msg: MCPMessage) -> MCPMessage:
        """MCP handler: explicit trigger from orchestrator."""
        kpi_snapshot = await self._fetch_all_kpis()
        return self._build_mcp_message(kpi_snapshot, msg.id)

    async def _collect_and_forward(self, correlation_id: str):
        kpi_snapshot = await self._fetch_all_kpis()
        msg = self._build_mcp_message(kpi_snapshot, correlation_id)
        response = await self.bus.publish(msg)
        if response:
            log.info("Agent 2 acknowledged: %s", response.message_type)

    def _build_mcp_message(self, kpi_snapshot: Dict, correlation_id: str) -> MCPMessage:
        return MCPMessage(
            sender=self.AGENT_ID,
            receiver="agent2",
            message_type="kpi_data",
            payload=kpi_snapshot,
            correlation_id=correlation_id,
        )

    async def _fetch_all_kpis(self) -> Dict[str, Any]:
        """Query Prometheus for every NF KPI and return a timestamped snapshot."""
        snapshot = {
            "collected_at": datetime.utcnow().isoformat(),
            "network_functions": {},
        }
        for nf, kpis in NETWORK_FUNCTION_KPIS.items():
            nf_data = {"kpis": []}
            for kpi_def in kpis:
                value = await self._query_prometheus(kpi_def["query"])
                nf_data["kpis"].append({
                    "metric":    kpi_def["metric"],
                    "value":     value,
                    "unit":      kpi_def["unit"],
                    "threshold": kpi_def["threshold"],
                    "query":     kpi_def["query"],
                    "timestamp": datetime.utcnow().isoformat(),
                })
            snapshot["network_functions"][nf] = nf_data
            log.info("Collected %d KPIs for %s", len(kpis), nf)

        snapshot["grafana_annotations"] = await self._fetch_grafana_annotations()
        return snapshot

    async def _query_prometheus(self, query: str) -> float:
        """Execute an instant PromQL query."""
        url = f"{self.prometheus_url}/api/v1/query"
        try:
            async with self._session.get(url, params={"query": query}, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    log.warning("Prometheus HTTP %d for query: %s", resp.status, query)
                    return -1.0
                data = await resp.json()
                results = data.get("data", {}).get("result", [])
                if results:
                    return float(results[0]["value"][1])
                return 0.0
        except Exception as exc:
            log.error("Prometheus query error: %s — %s", query, exc)
            return -1.0

    async def _fetch_grafana_annotations(self) -> List[Dict]:
        """Fetch recent Grafana annotations for event correlation."""
        url = f"{self.grafana_url}/api/annotations"
        headers = {"Authorization": f"Bearer {self.grafana_token}"}
        try:
            async with self._session.get(url, headers=headers, params={"limit": 50},
                                          timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    return await resp.json()
        except Exception as exc:
            log.warning("Grafana annotations fetch failed: %s", exc)
        return []
