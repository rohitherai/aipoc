"""
Agent 5 — ChatBot Notifier
Receives the remediation plan from Agent 4 and:
  • Sends a pop-up notification to the L2 engineer chatbot interface
  • Broadcasts to configured channels (Slack, Teams, or internal WebSocket)
  • Maintains a stateful conversation for L2 follow-up questions (via Claude)
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional
import aiohttp

from mcp.mcp_server import MCPBus, MCPMessage

log = logging.getLogger("agent5.chatbot_notifier")


POPUP_TEMPLATE = """
🚨 *VINGC NETWORK ALERT* 🚨
────────────────────────────
Incident:  {incident_id}
Priority:  {priority}
NFs:       {nfs}
Faults:    {fault_count}
Time:      {timestamp}
────────────────────────────
{top_remediations}
────────────────────────────
Reply with the incident ID to get full remediation details.
"""


class ChatBotNotifierAgent:
    """
    Agent 5 — final pipeline stage.
    Sends pop-up alerts to L2 engineers and handles follow-up Q&A via LLM.
    """

    AGENT_ID = "agent5"

    def __init__(
        self,
        bus: MCPBus,
        anthropic_api_key: str,
        slack_webhook_url: str = None,
        teams_webhook_url: str = None,
        websocket_broadcast_url: str = None,
    ):
        self.bus = bus
        self.api_key = anthropic_api_key
        self.slack_webhook = slack_webhook_url
        self.teams_webhook = teams_webhook_url
        self.ws_url = websocket_broadcast_url
        self._session: Optional[aiohttp.ClientSession] = None
        # Store active incidents for follow-up conversation
        self._active_incidents: Dict[str, Dict] = {}
        bus.register(self.AGENT_ID, "remediation", self._handle_remediation)

    async def _handle_remediation(self, msg: MCPMessage) -> None:
        if not self._session:
            self._session = aiohttp.ClientSession()

        plan = msg.payload
        incident_id = plan.get("incident_id", "UNKNOWN")
        self._active_incidents[incident_id] = plan

        log.info("Preparing notifications for incident %s [%s]", incident_id, plan.get("priority"))

        popup_text = self._format_popup(plan)
        rich_payload = self._build_rich_card(plan)

        results = await asyncio.gather(
            self._send_slack(popup_text, rich_payload),
            self._send_teams(rich_payload),
            self._broadcast_websocket(rich_payload),
            return_exceptions=True,
        )
        for i, r in enumerate(results):
            if isinstance(r, Exception):
                log.warning("Notification channel %d failed: %s", i, r)

        log.info("Notifications dispatched for %s", incident_id)

    # ── Formatters ────────────────────────────────────────────────────────────

    def _format_popup(self, plan: Dict) -> str:
        top = plan.get("remediations", [])[:2]
        top_text = "\n".join(
            f"• [{r['nf']}] {r['title']}" for r in top
        ) or "No remediations found."
        return POPUP_TEMPLATE.format(
            incident_id=plan["incident_id"],
            priority=plan.get("priority", "P2"),
            nfs=", ".join(plan.get("nfs_affected", [])),
            fault_count=plan.get("remediation_count", 0),
            timestamp=plan.get("generated_at", datetime.utcnow().isoformat()),
            top_remediations=top_text,
        )

    def _build_rich_card(self, plan: Dict) -> Dict:
        """Build a rich card payload compatible with Slack Block Kit / Teams Adaptive Card."""
        priority_emoji = "🔴" if plan.get("priority") == "P1" else "🟠"
        remediations = plan.get("remediations", [])
        summary_fields = [
            {"label": "Incident",  "value": plan["incident_id"]},
            {"label": "Priority",  "value": f"{priority_emoji} {plan.get('priority','P2')}"},
            {"label": "NFs",       "value": ", ".join(plan.get("nfs_affected", []))},
            {"label": "Faults",    "value": str(plan.get("remediation_count", 0))},
            {"label": "Generated", "value": plan.get("generated_at", "")[:19]},
        ]
        actions = [
            {
                "label": f"[{r['nf']}] {r['title']} ({r.get('priority','P2')})",
                "source": r.get("source", "knowledge_base"),
                "steps": r.get("steps", []),
                "runbook_url": r.get("runbook_url", ""),
                "severity": r.get("severity", "WARNING"),
            }
            for r in remediations
        ]
        return {
            "type":      "vingc_alert",
            "incident":  plan["incident_id"],
            "priority":  plan.get("priority"),
            "summary":   summary_fields,
            "actions":   actions,
            "full_plan": plan,
        }

    # ── Notification channels ─────────────────────────────────────────────────

    async def _send_slack(self, text: str, card: Dict) -> None:
        if not self.slack_webhook:
            return
        blocks = [
            {"type": "section", "text": {"type": "mrkdwn", "text": text}},
            {"type": "divider"},
        ]
        for action in card.get("actions", [])[:3]:
            blocks.append({
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"*{action['label']}*"},
                "accessory": {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "View Steps"},
                    "value": json.dumps({"incident": card["incident"], "title": action["label"]}),
                    "action_id": "view_remediation",
                },
            })
        payload = {"text": f"VINGC Alert: {card['incident']}", "blocks": blocks}
        async with self._session.post(self.slack_webhook, json=payload,
                                      timeout=aiohttp.ClientTimeout(total=10)) as resp:
            log.info("Slack notification: HTTP %d", resp.status)

    async def _send_teams(self, card: Dict) -> None:
        if not self.teams_webhook:
            return
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "FF0000" if card["priority"] == "P1" else "FF8C00",
            "summary": f"VINGC Alert: {card['incident']}",
            "title": f"🚨 VINGC Network Alert — {card['incident']}",
            "sections": [
                {
                    "facts": [
                        {"name": f["label"], "value": f["value"]}
                        for f in card.get("summary", [])
                    ]
                }
            ],
            "potentialAction": [
                {
                    "@type": "ActionCard",
                    "name": f"View {a['label']}",
                    "actions": [{"@type": "HttpPOST", "name": "Acknowledge", "target": "https://vingc.internal/ack"}]
                }
                for a in card.get("actions", [])[:2]
            ],
        }
        async with self._session.post(self.teams_webhook, json=payload,
                                      timeout=aiohttp.ClientTimeout(total=10)) as resp:
            log.info("Teams notification: HTTP %d", resp.status)

    async def _broadcast_websocket(self, card: Dict) -> None:
        if not self.ws_url:
            return
        try:
            async with self._session.post(
                f"{self.ws_url}/broadcast",
                json={"channel": "l2_engineers", "type": "vingc_alert", "data": card},
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                log.info("WebSocket broadcast: HTTP %d", resp.status)
        except Exception as exc:
            log.warning("WebSocket broadcast failed: %s", exc)

    # ── Conversational follow-up ──────────────────────────────────────────────

    async def handle_engineer_query(self, incident_id: str, question: str) -> str:
        """
        Called by the L2 chatbot UI when an engineer asks a follow-up question.
        Uses Claude with the full incident context.
        """
        plan = self._active_incidents.get(incident_id)
        context = json.dumps(plan, indent=2) if plan else "No incident data found."
        system = (
            "You are a VINGC Network Operations AI assistant. "
            "Answer L2 engineer questions concisely using the provided incident data. "
            "Always refer to specific remediation steps and OpenShift commands."
        )
        messages = [
            {"role": "user", "content": f"Incident context:\n{context}\n\nEngineer question: {question}"}
        ]
        try:
            async with self._session.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": self.api_key, "anthropic-version": "2023-06-01",
                         "Content-Type": "application/json"},
                json={"model": "claude-sonnet-4-20250514", "max_tokens": 400,
                      "system": system, "messages": messages},
                timeout=aiohttp.ClientTimeout(total=20),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data["content"][0]["text"]
        except Exception as exc:
            log.error("Chatbot LLM call failed: %s", exc)
        return "Unable to retrieve response. Please consult the runbook directly."
