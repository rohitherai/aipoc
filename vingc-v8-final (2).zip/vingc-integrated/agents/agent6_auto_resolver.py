"""
agent6_auto_resolver.py - Corrected with deterministic simulation
"""
import asyncio, logging, random, uuid
from datetime import datetime, timezone
from typing import Dict, List

log = logging.getLogger("agent6")

class AutoResolverAgent:
    def __init__(self, bus, state_ref, broadcast_fn, agent7=None):
        self.bus = bus
        self.state = state_ref
        self.broadcast = broadcast_fn
        self.agent7 = agent7
        self._watches: Dict[str, asyncio.Task] = {}
        self._ticket_fate: Dict[str, str] = {}  # pre-decided: 'auto' or 'escalate'

    def watch(self, incident_id: str, initial_breaches: List, kpi_snapshot: Dict = None):
        if incident_id in self._watches:
            return
        inc = self.state.get(incident_id)
        priority = (inc or {}).get("priority", "P3")
        # Deterministic fate:
        # P1 → 30% auto-resolve, 70% escalate to Agent7
        # P2 → 55% auto-resolve, 45% escalate
        # P3 → 85% auto-resolve, 15% escalate
        fate_probs = {"P1": 0.30, "P2": 0.55, "P3": 0.85}
        auto_prob = fate_probs.get(priority, 0.5)
        fate = "auto" if random.random() < auto_prob else "escalate"
        self._ticket_fate[incident_id] = fate
        log.info("Agent6: watching %s [%s] — fate=%s", incident_id, priority, fate)
        task = asyncio.create_task(self._monitor(incident_id, initial_breaches))
        self._watches[incident_id] = task

    async def _monitor(self, incident_id: str, initial_breaches: List):
        CHECK_INTERVAL = 30   # seconds (simulated — in real prod this is 30s)
        MAX_WAIT = 300        # 5 minutes total
        elapsed = 0
        fate = self._ticket_fate.get(incident_id, "escalate")

        while elapsed < MAX_WAIT:
            await asyncio.sleep(CHECK_INTERVAL)
            elapsed += CHECK_INTERVAL
            inc = self.state.get(incident_id)
            if not inc or inc.get("status") == "RESOLVED":
                self._cleanup(incident_id)
                return

            # For auto-fate tickets: recover at 60% through window
            # For escalate-fate tickets: never recover (always still breached)
            still_breached = True
            if fate == "auto":
                recovery_at = int(MAX_WAIT * 0.6)  # recover at ~3 min
                still_breached = elapsed < recovery_at

            remaining = MAX_WAIT - elapsed
            if not still_breached:
                await self._auto_resolve(incident_id, elapsed, initial_breaches)
                self._cleanup(incident_id)
                return
            else:
                note = {
                    "id": str(uuid.uuid4())[:8],
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "engineer": "agent6_auto_resolver",
                    "text": (f"⏱ Agent6 check at +{elapsed}s: KPIs still breached. "
                             f"{remaining}s remaining before Agent7 escalation.")
                }
                inc["notes"].append(note)
                await self.broadcast("incident_note", {"incident_id": incident_id, "note": note})

        # 5-min window expired
        inc = self.state.get(incident_id)
        if inc and inc.get("status") not in ("RESOLVED",):
            esc_note = {
                "id": str(uuid.uuid4())[:8],
                "ts": datetime.now(timezone.utc).isoformat(),
                "engineer": "agent6_auto_resolver",
                "text": ("⚠️ KPIs NOT restored after 5 minutes. "
                         "Escalating to Agent7 (Remediation Orchestrator) for deep RCA.")
            }
            inc["notes"].append(esc_note)
            inc["escalated_to_agent7"] = True
            await self.broadcast("incident_note", {"incident_id": incident_id, "note": esc_note})
            await self.broadcast("incident_updated", inc)
            await self.broadcast("mcp_message", {
                "id": str(uuid.uuid4())[:8], "sender": "agent6", "receiver": "agent7",
                "type": "escalate_to_agent7",
                "time": datetime.now(timezone.utc).strftime("%H:%M:%S"),
                "preview": f"{incident_id} — 5-min watch expired, escalating for RCA"
            })
            if self.agent7:
                asyncio.create_task(self.agent7.analyze(incident_id, initial_breaches))
        self._cleanup(incident_id)

    async def _auto_resolve(self, incident_id: str, elapsed: int, breaches: List):
        inc = self.state.get(incident_id)
        if not inc:
            return
        now = datetime.now(timezone.utc).isoformat()
        note = {
            "id": str(uuid.uuid4())[:8],
            "ts": now,
            "engineer": "agent6_auto_resolver",
            "text": (f"✅ AUTO-RESOLVED by Agent6: KPIs returned to normal within {elapsed}s "
                     f"({datetime.now(timezone.utc).strftime('%H:%M:%S UTC')}). "
                     f"No L2 intervention required.")
        }
        inc["notes"].append(note)
        inc["status"] = "RESOLVED"
        inc["acked"] = True
        inc["resolved_at"] = now
        inc["resolution"] = f"Agent6 AUTO-RESOLVED: KPIs self-healed within {elapsed}s."
        inc["auto_resolved"] = True
        await self.broadcast("incident_updated", inc)
        await self.broadcast("agent_event", {
            "agent": "agent6", "event": "auto_resolved",
            "incident_id": incident_id,
            "message": f"KPIs restored in {elapsed}s — auto-resolved"
        })
        log.info("Agent6: AUTO-RESOLVED %s in %ds", incident_id, elapsed)

    def _cleanup(self, incident_id):
        self._watches.pop(incident_id, None)
        self._ticket_fate.pop(incident_id, None)
