@echo off
echo VINGC NOC v3
echo.
echo  http://localhost:8000/         Dashboard (all views)
echo  http://localhost:8000/admin    Pipeline + MCP admin (new window)
echo  http://localhost:8000/topology Network heatmap (new window)
echo  http://localhost:8000/chat     L2 Chat standalone
echo.
start http://localhost:8000
python api_server.py
pause
