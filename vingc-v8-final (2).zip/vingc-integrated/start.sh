#!/bin/bash
echo ""
echo " ========================================="
echo "  VINGC Agentic AI — Local Launcher"
echo " ========================================="
echo ""

# Install deps if needed
python3 -c "import fastapi" 2>/dev/null || pip3 install fastapi uvicorn[standard] aiohttp pydantic prometheus-client python-multipart

echo " Dashboard : http://localhost:8000/"
echo " Chat      : http://localhost:8000/chat"
echo " API docs  : http://localhost:8000/docs"
echo ""

# Open browser (mac)
(sleep 2 && open http://localhost:8000 2>/dev/null || xdg-open http://localhost:8000 2>/dev/null) &
python3 api_server.py
