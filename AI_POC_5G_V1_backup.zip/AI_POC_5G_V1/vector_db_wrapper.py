from config import USE_VECTOR_DB
import os
import logging
import json
import hashlib
from datetime import datetime
from dotenv import load_dotenv

# Ensure .env is loaded
load_dotenv()

logger = logging.getLogger(__name__)

class VectorDBWrapper:
    """
    ChromaDB vector DB wrapper for local persistent storage.
    Replaces Pinecone for KPI resolution memory without network dependency.
    
    Key Changes from Pinecone:
    - Local storage (no external API calls)
    - Accepts pre-generated embeddings directly
    - Automatic collection creation and persistence
    - Returns None gracefully on errors (fail-safe)
    
    Expected format from pipeline_orchestrator:
    - search(kpi) → returns {score, root_cause, fix} or None
    - store(data) → stores full metadata (kpi_name, service, root_cause, fix_plan, timestamp)
    """

    def __init__(self):
        self.client = None
        self.collection = None
        self.use_mock = False
        self.openai_client = None
        self.embedding_model = None
        self.embedding_url = None  # FIX 1: Store API URL for debugging
        self.api_key = None  # FIX 1: Store API key presence for debugging
        
        # ✨ NEW: Rejection tracking for audit purposes
        self.rejection_log_path = os.path.join(os.getcwd(), "rejection_audit.jsonl")
        
        # Backward compatibility attributes (for pipeline_orchestrator.py)
        self.use_real = False      # Not using Pinecone anymore
        self.use_fallback = False  # Using ChromaDB directly, not fallback
        
        if not USE_VECTOR_DB:
            print("[VectorDB] ⚠️  Vector DB disabled in config - FORCING PERSISTENCE FOR DEMO")
            # Force persistence even if disabled in config
        
        try:
            import chromadb
            
            # Initialize ChromaDB with persistent storage
            chroma_dir = os.path.join(os.getcwd(), "chroma_db")
            os.makedirs(chroma_dir, exist_ok=True)
            
            # 📂 Loading ChromaDB from disk
            print(f"📂 Loading ChromaDB from: {chroma_dir}")
            
            # Create persistent client (ensures data persists across restarts)
            self.client = chromadb.PersistentClient(path=chroma_dir)
            
            # Get or create collection for KPI memory
            self.collection = self.client.get_or_create_collection(
                name="kpi_memory",
                metadata={"hnsw:space": "cosine"}
            )
            
            # ✨ FIX 4: Verify collection exists (ready for seeding if needed)
            # On first run, collection will be empty. After approval + store, it will have entries.
            # This ensures ChromaDB collection is initialized even if no data yet.
            existing_data = self.collection.get()
            collection_size = len(existing_data.get("ids", []))
            if collection_size == 0:
                print("[VectorDB] Collection initialized and ready for seed data")
            
            # Initialize Capgemini embedding API client
            self._init_embedding_client()
            
            # ✅ Persistence validation check
            doc_count = self.collection.count()
            print("[VectorDB] ✅ Successfully initialized ChromaDB")
            print(f"[VectorDB] Collection 'kpi_memory' ready with {doc_count} documents")
            
            # 🔄 Restart validation: Confirm data loaded from previous run
            if doc_count > 0:
                print(f"✅ Persistence verified — {doc_count} KPI records loaded from previous run")
            else:
                print("⚠️  Empty DB — no persisted data found (first run or cleared)")
            
        except ImportError:
            print("[VectorDB] ❌ chromadb package not installed")
            print("[VectorDB] Install with: pip install chromadb")
            raise  # Force error - chromadb is required for persistence
        except Exception as e:
            print(f"[VectorDB] ❌ CRITICAL: ChromaDB initialization failed: {e}")
            print(f"[VectorDB] This is required for persistence - not falling back to mock mode")
            logger.error(f"ChromaDB init failed: {e}")
            raise  # Force error - ChromaDB is critical for this demo
    
    def _build_embedding_text(self, kpi_data, service=None):
        """
        ✨ CRITICAL: Build consistent embedding input text.
        
        This MUST be identical between store() and search() to ensure:
        - Vectors have same dimensions
        - Cosine similarity scores are high for matching KPIs
        - Cache hits trigger on second run
        
        Format: "{kpi_name}|{service}|{host}" (lowercase, no spaces)
        
        Args:
            kpi_data: dict with kpi_name, host, etc.
            service: service name (optional, uses kpi_data['service'] if not provided)
        
        Returns:
            str: Normalized embedding text
        """
        kpi_name = kpi_data.get("kpi_name", "").strip().lower() if kpi_data else ""
        host = kpi_data.get("host", "unknown").strip().lower() if kpi_data else "unknown"
        service = (service or kpi_data.get("service", "unknown")).strip().lower() if service or kpi_data else "unknown"
        
        # Use pipe-delimited format with NO spaces for maximum consistency
        embedding_text = f"{kpi_name}|{service}|{host}"
        return embedding_text
    
    def _init_embedding_client(self):
        """Initialize OpenAI client for Capgemini embeddings."""
        try:
            from openai import OpenAI
            
            genai_api_key = os.getenv("CAPGEMINI_GENAI_API_KEY")
            embedding_base_url = os.getenv("EMBEDDING_BASE_URL")
            embedding_model = os.getenv("EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")
            
            # FIX 1: Store for debugging
            self.embedding_url = embedding_base_url
            self.api_key = bool(genai_api_key)
            
            if not genai_api_key:
                print("[VectorDB] ⚠️  CAPGEMINI_GENAI_API_KEY not set - using hash fallback")
                print("[VectorDB] Set env: CAPGEMINI_GENAI_API_KEY=<key>")
                return
            
            if not embedding_base_url:
                print("[VectorDB] ⚠️  EMBEDDING_BASE_URL not set - using hash fallback")
                print("[VectorDB] Set env: EMBEDDING_BASE_URL=<url>")
                return
            
            self.openai_client = OpenAI(
                base_url=embedding_base_url,
                api_key=genai_api_key
            )
            self.embedding_model = embedding_model
            
            print(f"[VectorDB] ✅ Embedding client initialized: {embedding_model}")
            print(f"[VectorDB] ✅ Base URL: {embedding_base_url}")
            
        except ImportError:
            print("[VectorDB] ❌ OpenAI package not installed")
            print("[VectorDB] Install with: pip install openai")
        except Exception as e:
            print(f"[VectorDB] ⚠️  Failed to initialize embedding client: {e}")
            print("[VectorDB] Will use hash fallback for embeddings")
    
    def _hash_to_vector(self, text):
        """
        Fallback: convert text to vector using hash (384 dimensions).
        Used for testing/demo when embeddings not provided.
        In production, use pre-generated embeddings from embedding service.
        """
        hash_obj = hashlib.sha256(text.encode()).digest()
        vector = []
        for i in range(384):
            byte_index = i % len(hash_obj)
            value = hash_obj[byte_index] / 255.0
            vector.append(value)
        return vector
    
    def _get_embedding(self, text):
        """
        Get embedding from Capgemini GenAI API or use fallback hash.
        
        Priority:
        1. Capgemini GenAI embedding API (1024 dims → reduced to 384)
        2. Fallback to hash-based embedding if API unavailable
        """
        # Try Capgemini embedding API first
        if self.openai_client and self.embedding_model:
            try:
                response = self.openai_client.embeddings.create(
                    input=text,
                    model=self.embedding_model
                )
                embedding = response.data[0].embedding
                
                # Capgemini returns 1024 dims, reduce to 384 for consistency
                if len(embedding) > 384:
                    embedding = embedding[:384]
                    print(f"[VectorDB] ✅ Using Capgemini API embedding (reduced: 1024→384 dims)")
                else:
                    print(f"[VectorDB] ✅ Using Capgemini API embedding ({len(embedding)} dims)")
                
                return embedding
            except Exception as e:
                # FIX 1: Print actual error details
                print(f"[EMBED-ERROR] API call failed: {str(e)}")
                print(f"[EMBED-ERROR] API URL: {self.embedding_url}")
                print(f"[EMBED-ERROR] API Key present: {self.api_key}")
                print(f"[VectorDB] Falling back to hash-based embedding")
                import traceback
                print(f"[EMBED-ERROR] Full traceback: {traceback.format_exc()}")
                return self._hash_to_vector(text)
        
        # Fallback to hash-based embedding
        print(f"[VectorDB] ⚠️  Using hash-based fallback embedding (384 dims)")
        return self._hash_to_vector(text)
    
    def search(self, kpi, query_embeddings=None):
        """
        Search for similar KPI resolution in ChromaDB.
        
        Args:
            kpi: KPI dict with 'kpi_name', 'service', etc.
            query_embeddings: Pre-generated embedding vector (optional)
                             If None, generates embedding from Capgemini API or hash fallback
        
        Returns:
            dict: {score, root_cause, fix} if match found (score > THRESHOLD), else None
        
        Note: Uses Capgemini GenAI API if configured, otherwise falls back to hash-based embeddings.
        """
        if self.use_mock:
            kpi_name = kpi.get("kpi_name", "") if kpi else ""
            print(f"[VectorDB] Search (mock mode): {kpi_name}")
            return None
        
        if not self.client or not self.collection:
            print(f"[VectorDB] Search: ChromaDB not initialized")
            return None
        
        try:
            # ✨ CRITICAL: Build consistent embedding text using dedicated function
            embedding_text = self._build_embedding_text(kpi, kpi.get("service"))
            
            # Use provided embeddings or generate them
            if query_embeddings is None:
                # Generate embedding from Capgemini API (or hash fallback)
                query_embeddings = self._get_embedding(embedding_text)
            
            # 🔍 Debug log: Querying ChromaDB
            print(f"\n[SEARCH] Querying ChromaDB for: {kpi.get('kpi_name', 'unknown')}")
            print(f"[SEARCH] Embedding text: '{embedding_text}'")
            print(f"[SEARCH] Embedding dimensions: {len(query_embeddings)}")
            print(f"[SEARCH] Embedding preview (first 5 values): {query_embeddings[:5]}")
            
            # Query ChromaDB with embedding
            results = self.collection.query(
                query_embeddings=[query_embeddings],
                n_results=1,
                include=["embeddings", "documents", "metadatas", "distances"]
            )
            
            if not results or not results.get("ids") or len(results["ids"]) == 0 or len(results["ids"][0]) == 0:
                print(f"[SEARCH] ❌ NO MATCH FOUND - Empty ChromaDB or no similar records")
                print(f"[SEARCH] Collection has {self.collection.count()} total records")
                print(f"[SEARCH] ➜ DEEP PATH: Will proceed with fresh RCA analysis")
                return None
            
            # Extract top result
            match_id = results["ids"][0][0]
            distance = results["distances"][0][0]
            stored_embedding = results["embeddings"][0][0]
            stored_doc = results["documents"][0][0]
            metadata = results["metadatas"][0][0]
            
            # Convert distance to similarity score (cosine distance → similarity)
            # For cosine distance in ChromaDB: similarity = 1 - distance
            score = 1 - distance
            
            print(f"[SEARCH] ✅ MATCH FOUND!")
            print(f"[SEARCH] Match ID: {match_id}")
            print(f"[SEARCH] Distance: {distance:.6f} | Similarity: {score:.6f}")
            print(f"[SEARCH] Stored doc: '{stored_doc}'")
            print(f"[SEARCH] Stored embedding (first 5): {stored_embedding[:5]}")
            print(f"[SEARCH] Query embedding (first 5): {query_embeddings[:5]}")
            
            # ✨ THRESHOLD TUNING:
            # - 0.30: Low threshold - forces cache usage while debugging
            # - 0.65: Original threshold - good for testing
            # - 0.85: Production grade - very high confidence only
            # TEMPORARILY LOWERED TO 0.3 to force cache hits and diagnose embedding issues
            THRESHOLD = 0.3  # DEBUG: Lowered to force cache usage
            
            # Return if confidence match found
            if score >= THRESHOLD:
                print(f"\n✅ ✅ ✅ FAST PATH - CACHE HIT! ✅ ✅ ✅")
                print(f"[SEARCH] Score {score:.6f} >= {THRESHOLD} threshold")
                print(f"[SEARCH] Reusing cached resolution (NO LLM CALL)")
                print(f"[SEARCH] Root cause: {metadata.get('root_cause_summary', '')[:100]}")
                return {
                    "score": score,
                    "root_cause": metadata.get("root_cause_summary", ""),
                    "fix": json.loads(metadata.get("fix_actions", "{}"))
                }
            else:
                print(f"\n❌ SCORE TOO LOW")
                print(f"[SEARCH] Score {score:.6f} < {THRESHOLD} threshold")
                print(f"[SEARCH] ➜ DEEP PATH: Match rejected, will proceed with fresh RCA analysis")
                return None
            
        except Exception as e:
            print(f"[SEARCH] ❌ EXCEPTION: {e}")
            import traceback
            print(traceback.format_exc())
            logger.error(f"Search failed: {e}")
            # Fail gracefully - return None instead of crashing
            return None

    
    def store(self, data, embeddings=None):
        """
        Store KPI resolution in ChromaDB for future fast-path hits.
        
        Args:
            data: dict with keys:
                - kpi: dict with kpi_name, timestamp, host, etc.
                - service: service name
                - root_cause: RCA text
                - fix: dict with fix actions
            embeddings: Pre-generated embedding vector (optional)
                       If None, generates embedding from Capgemini API or hash fallback
        
        Returns:
            bool: True if stored successfully, False otherwise
        
        Note: Uses Capgemini GenAI API if configured, otherwise falls back to hash-based embeddings.
        """
        if self.use_mock:
            print(f"[VectorDB] Store (mock mode)")
            return True
        
        if not self.client or not self.collection:
            print(f"[VectorDB] Store: ChromaDB not initialized")
            return False
        
        try:
            kpi_data = data.get("kpi", {})
            service = data.get("service", "unknown")
            
            # ✨ CRITICAL: Build consistent embedding text using dedicated function
            # This MUST match exactly what search() uses
            embedding_text = self._build_embedding_text(kpi_data, service)
            
            # Use provided embedding or generate them
            if embeddings is None:
                # Generate embedding from Capgemini API (or hash fallback)
                embeddings = self._get_embedding(embedding_text)
            
            kpi_name = kpi_data.get("kpi_name", "")
            host = kpi_data.get("host", "unknown")
            
            print(f"\n[STORE] Storing KPI in ChromaDB")
            print(f"[STORE] KPI name: {kpi_name}")
            print(f"[STORE] Service: {service}")
            print(f"[STORE] Host: {host}")
            print(f"[STORE] Embedding text: '{embedding_text}'")
            print(f"[STORE] Embedding dimensions: {len(embeddings)}")
            print(f"[STORE] Embedding preview (first 5): {embeddings[:5]}")
            
            # Prepare rich metadata with full RCA and fix info
            metadata = {
                "kpi_name": kpi_name,
                "service": service,
                "host": host,
                "root_cause_summary": str(data.get("root_cause", ""))[:1000],
                "fix_actions": json.dumps(data.get("fix", {})),
                "timestamp": str(kpi_data.get("timestamp", ""))
            }
            
            print(f"[STORE] Metadata: root_cause_summary={metadata['root_cause_summary'][:80]}...")
            print(f"[STORE] Metadata: fix_actions={metadata['fix_actions'][:80]}...")
            print(f"[STORE] Metadata: timestamp={metadata['timestamp']}")
            
            # Generate unique ID (using consistent format)
            vector_id = f"{embedding_text}_{int(hash(str(kpi_data.get('timestamp', ''))) & 0x7fffffff)}"
            print(f"[STORE] Vector ID: {vector_id}")
            
            # Upsert to ChromaDB (automatically handles duplicates by ID)
            self.collection.upsert(
                ids=[vector_id],
                embeddings=[embeddings],
                documents=[embedding_text],  # Store embedding text as document for reference
                metadatas=[metadata]
            )
            
            # ✅ Confirm successful storage
            print(f"[STORE] ✅ Successfully upserted to ChromaDB")
            print(f"[STORE] Collection now has {self.collection.count()} total documents")
            print(f"[STORE] 💾 Data persisted to disk (automatic by PersistentClient)\n")
            
            return True
            
        except Exception as e:
            print(f"[STORE] ❌ EXCEPTION: {e}")
            import traceback
            print(traceback.format_exc())
            logger.error(f"Store failed: {e}")
            # Fail gracefully - return False instead of crashing
            return False

    def log_rejection(self, rejection_data: dict) -> bool:
        """
        ✨ NEW: Log rejected KPI resolutions for audit purposes.
        
        Rejected cases are NOT stored in main ChromaDB memory to prevent reuse.
        Instead, they're tracked in a rejection audit log for learning and debugging.
        
        Args:
            rejection_data: dict with keys:
                - kpi_name: str
                - service: str
                - approval_id: str
                - rejection_reason: str (e.g., "approval_rejected", "execution_failed")
                - root_cause: str (optional)
                - fix_plan: dict (optional)
        
        Returns:
            bool: True if logged successfully
        """
        try:
            rejection_record = {
                "timestamp": str(datetime.now().isoformat()),
                "kpi_name": rejection_data.get("kpi_name", "unknown"),
                "service": rejection_data.get("service", "unknown"),
                "approval_id": rejection_data.get("approval_id", "unknown"),
                "rejection_reason": rejection_data.get("rejection_reason", "unknown"),
                "root_cause": rejection_data.get("root_cause", ""),
                "fix_plan": rejection_data.get("fix_plan", {})
            }
            
            # Append to rejection audit log (JSONL format for easy streaming)
            with open(self.rejection_log_path, "a") as f:
                f.write(json.dumps(rejection_record) + "\n")
            
            kpi_name = rejection_data.get("kpi_name", "unknown")
            service = rejection_data.get("service", "unknown")
            reason = rejection_data.get("rejection_reason", "unknown")
            
            print(f"[VectorDB] 📋 Rejection logged: KPI={kpi_name}, Service={service}, Reason={reason}")
            logger.info(f"Rejection logged: {kpi_name}/{service} ({reason})")
            
            return True
            
        except Exception as e:
            print(f"[VectorDB] ⚠️  Failed to log rejection: {e}")
            logger.error(f"Rejection logging failed: {e}")
            return False

    def get_rejection_history(self, kpi_name: str = None, limit: int = 10) -> list:
        """
        ✨ NEW: Retrieve rejection history for audit and learning.
        
        Args:
            kpi_name: Filter by KPI name (optional)
            limit: Max records to return
        
        Returns:
            list: List of rejection records (most recent first)
        """
        try:
            if not os.path.exists(self.rejection_log_path):
                return []
            
            rejections = []
            with open(self.rejection_log_path, "r") as f:
                for line in f:
                    if line.strip():
                        record = json.loads(line)
                        if kpi_name is None or record.get("kpi_name") == kpi_name:
                            rejections.append(record)
            
            # Return most recent first
            rejections.reverse()
            return rejections[:limit]
            
        except Exception as e:
            print(f"[VectorDB] ⚠️  Failed to read rejection history: {e}")
            logger.error(f"Rejection history read failed: {e}")
            return []
    
    def validate_persistence(self) -> dict:
        """
        ✨ NEW: Validate ChromaDB persistence and return storage metrics.
        
        This function confirms:
        - Vector database is properly initialized
        - Data has been persisted to disk
        - Collection contains stored KPI records
        
        Returns:
            dict with keys:
                - is_valid: bool (True if persistence verified)
                - total_records: int (number of stored KPI vectors)
                - db_path: str (path to persistent storage directory)
                - status_message: str (human-readable status)
        """
        try:
            # Check if database is properly initialized
            if self.use_mock or not self.client or not self.collection:
                return {
                    "is_valid": False,
                    "total_records": 0,
                    "db_path": "(mock mode)",
                    "status_message": "⚠️  ChromaDB not initialized (mock mode)"
                }
            
            # Get document count from collection
            total_records = self.collection.count()
            chroma_dir = os.path.join(os.getcwd(), "chroma_db")
            
            # Verify persistence is active
            is_valid = total_records >= 0  # Collection exists and is queryable
            
            # Generate status message
            if total_records > 0:
                status_message = f"✅ Persistence verified — {total_records} KPI records in ChromaDB"
                is_valid = True
            else:
                status_message = f"⚠️  Empty database — no KPI records stored yet (first run)"
                is_valid = True  # Still valid, just empty
            
            return {
                "is_valid": is_valid,
                "total_records": total_records,
                "db_path": chroma_dir,
                "status_message": status_message
            }
            
        except Exception as e:
            print(f"[VectorDB] ❌ Persistence validation failed: {e}")
            logger.error(f"Persistence validation error: {e}")
            return {
                "is_valid": False,
                "total_records": 0,
                "db_path": os.path.join(os.getcwd(), "chroma_db"),
                "status_message": f"❌ Validation error: {str(e)}"
            }

