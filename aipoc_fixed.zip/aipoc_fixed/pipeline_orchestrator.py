import logging
import time
import uuid
from typing import Dict, List, Any, Optional
from datetime import datetime

from grafana_agent import get_kpi_data
from kpi_data_manager import get_kpi_data_with_fallback
from service_identifier_agent import ServiceIdentifierAgent
from log_agent import LogAgent
from rca_agent import RootCauseAgent
from fixer_agent import FixerAgent
from approval_agent import ApprovalAgent
from approval_executor_agent import ApprovalExecutorAgent
from kb_writer_agent import KBWriterAgent
from history_agent import HistoryAgent
from notification_agent import NotificationAgent
from vector_db_wrapper import VectorDBWrapper
from config import USE_VECTOR_DB

logger = logging.getLogger("pipeline_orchestrator")
CONFIDENCE_THRESHOLD = 0.75  # Minimum confidence to proceed (else force deep path)


class PipelineOrchestrator:
    def __init__(self):
        self.service_agent = ServiceIdentifierAgent()
        self.log_agent = LogAgent()
        self.rca_agent = RootCauseAgent()
        self.fixer_agent = FixerAgent()
        self.approval_agent = ApprovalAgent()
        self.approval_executor_agent = ApprovalExecutorAgent()
        self.kb_writer_agent = KBWriterAgent()
        self.history_agent = HistoryAgent()
        self.notification_agent = NotificationAgent()  # ✨ NEW: Notification support
        
        self.pipeline_stats = {
            "total_runs": 0,
            "kpis_processed": 0,
            "fast_path_hits": 0,
            "deep_path_hits": 0,
            "kb_hits": 0,
            "llm_calls": 0,
            "fixes_proposed": 0,
            "approvals_granted": 0,  # ✨ NEW: Track approvals
            "approvals_rejected": 0,  # ✨ NEW: Track rejections
            "executions_successful": 0,  # ✨ NEW: Track successful executions
            "executions_failed": 0,  # ✨ NEW: Track failed executions
            "avg_processing_time": 0.0
        }

    def run_pipeline(self) -> Dict[str, Any]:
        start_time = time.time()
        self.pipeline_stats["total_runs"] += 1
        progress_logs = []  # Track execution progress

        try:
            progress_logs.append("[START] Pipeline execution initiated")
            print("\n" + "="*70)
            print("🚀 AIOPS PIPELINE STARTED")
            print("="*70)
            print("📊 PIPELINE PROGRESS LOG")
            print("=" * 70)
            
            progress_logs.append("[STEP] Fetching KPI data from Grafana")
            print("🔄 Fetching KPI data...")
            kpis = get_kpi_data_with_fallback()  # Uses custom → Grafana → dummy priority
            if not kpis:
                progress_logs.append("[ERROR] No KPI data available")
                return self._create_result([], start_time, error="No KPI data", progress_logs=progress_logs)
            progress_logs.append(f"[OK] Retrieved {len(kpis)} KPIs")
            print(f"✅ Retrieved {len(kpis)} KPIs")

            vector_db = VectorDBWrapper()
            # Log vector DB connection status
            if vector_db.use_mock:
                print("⚠️  VectorDB: MOCK (data not persisted)")
                progress_logs.append("[WARN] VectorDB: Mock mode (no persistence)")
            else:
                print("✅ VectorDB: CHROMADB (local persistent storage)")
                progress_logs.append("[OK] VectorDB: ChromaDB initialized")
                
                # ✨ NEW: Show persistence status at start
                persistence = vector_db.validate_persistence()
                if persistence["total_records"] > 0:
                    print(f"💾 Persistence: {persistence['status_message']}")
                    progress_logs.append(f"[OK] {persistence['status_message']}")

            self.pipeline_stats["kpis_processed"] += len(kpis)

            progress_logs.append("[STEP] Identifying services for each KPI")
            print("🔍 Identifying services...")
            identified_kpis = []
            for kpi in kpis:
                service_result = self.service_agent.run({
                    "kpi_name": kpi.get("kpi_name", ""),
                    "labels": kpi.get("labels"),
                    "instance": kpi.get("instance")
                })
                identified_kpis.append({**kpi, **service_result})
            progress_logs.append(f"[OK] Service identification complete")
            print("✅ Service identification complete")

            progress_logs.append("[STEP] Checking ChromaDB memory for cached resolutions")
            print("\n💾 FAST PATH CHECK: Searching ChromaDB memory for cached resolutions...")
            fast_path_kpis = []
            deep_path_kpis = []

            for kpi in identified_kpis:
                kpi_name = kpi["kpi_name"]
                service = kpi["service"]

                # ═══ RUNTIME MEMORY: ChromaDB Search ═══
                print(f"\n📍 KPI: {kpi_name} | Service: {service}")
                print("🔎 Searching ChromaDB for cached resolution...")

                # Check if Vector DB is enabled
                if not USE_VECTOR_DB:
                    print("⚠️  ChromaDB disabled (config: USE_VECTOR_DB=False)")
                    progress_logs.append(f"[SKIP] ChromaDB search for {kpi_name} (disabled)")
                    deep_path_kpis.append({**kpi, "path": "deep"})
                    self.pipeline_stats["deep_path_hits"] += 1
                    continue

                # Search ChromaDB
                print(f"[DEBUG] VectorDB status - ChromaDB initialized (mock={vector_db.use_mock})")
                vector_result = vector_db.search(kpi)
                
                # ✨ NEW: Confidence-based decision logic
                confidence_score = 0.0
                decision_reason = "No cache match"
                
                if vector_result and isinstance(vector_result, dict) and vector_result.get("score", 0) > 0.85:
                    # High-confidence match
                    confidence_score = min(1.0, vector_result.get("score", 0))
                    decision_reason = f"High similarity match (score: {confidence_score:.2f})"
                    
                    print("✅ Fast path: High-score match found in ChromaDB memory")
                    progress_logs.append(f"[FAST-PATH] {kpi_name} - cached resolution found (score: {confidence_score:.2f})")
                    logger.info("✅ Fast-path (cached): %s/%s (score: %.2f)", 
                               kpi_name, service, confidence_score)
                    
                    # FAST PATH: Use cached resolution
                    fast_path_kpis.append({
                        "kpi_name": kpi_name,
                        "service": service,
                        "path": "fast",
                        "confidence_score": confidence_score,
                        "decision_reason": decision_reason,
                        "root_cause": vector_result.get("root_cause", "Cached analysis"),
                        "fix_plan": vector_result.get("fix", {}),
                        "received_kpi": kpi,
                    })
                    self.pipeline_stats["fast_path_hits"] += 1
                elif vector_result and isinstance(vector_result, dict) and 0.70 <= vector_result.get("score", 0) <= 0.85:
                    # Medium confidence - still use but log as borderline
                    confidence_score = vector_result.get("score", 0)
                    decision_reason = f"Medium confidence match (score: {confidence_score:.2f}) - forcing deep analysis"
                    print(f"⚠️  Borderline match found (score {confidence_score:.2f}) - forcing deep analysis")
                    progress_logs.append(f"[MEDIUM-CONFIDENCE] {kpi_name} - match score {confidence_score:.2f}, forcing deep path")
                    deep_path_kpis.append({**kpi, "path": "deep"})
                    self.pipeline_stats["deep_path_hits"] += 1
                else:
                    print("❌ No cached match - routing to deep path")
                    progress_logs.append(f"[DEEP-PATH] {kpi_name} - no cached match, routing to full analysis")
                    logger.info("🔍 Deep-path: %s/%s (no ChromaDB match)", kpi_name, service)
                    
                    # DEEP PATH: Full analysis required
                    deep_path_kpis.append({**kpi, "path": "deep"})
                    self.pipeline_stats["deep_path_hits"] += 1

            deep_results = []
            if deep_path_kpis:
                progress_logs.append(f"[STEP] Running deep analysis for {len(deep_path_kpis)} KPI(s)")
                print(f"\n🔬 Running deep analysis for {len(deep_path_kpis)} KPI(s)...")
                for kpi in deep_path_kpis:
                    result = self._process_deep_path(kpi, vector_db, progress_logs)
                    deep_results.append(result)
                self.pipeline_stats["fixes_proposed"] += len(deep_results)
                progress_logs.append(f"[OK] Deep analysis complete for {len(deep_path_kpis)} KPI(s)")
            else:
                progress_logs.append("[OK] All KPIs resolved via fast path")

            processing_time = time.time() - start_time
            self.pipeline_stats["avg_processing_time"] = (
                (self.pipeline_stats["avg_processing_time"] * (self.pipeline_stats["total_runs"] - 1)) +
                processing_time
            ) / self.pipeline_stats["total_runs"]

            all_results = []
            
            # Process fast-path KPIs (from ChromaDB cache)
            for fp_kpi in fast_path_kpis:
                kpi_name = fp_kpi.get("kpi_name", "unknown")
                service = fp_kpi.get("service", "unknown")
                incident_id = str(uuid.uuid4())[:8].upper()  # ✨ NEW: Unique incident ID
                confidence_score = fp_kpi.get("confidence_score", 0.9)
                decision_reason = fp_kpi.get("decision_reason", "Cache hit with high similarity")
                
                print(f"\n⚡ Fast-path (CACHED RESOLUTION) for {kpi_name} [Incident: {incident_id}]")
                print(f"✅ Resolution retrieved from ChromaDB memory")
                print(f"   Confidence Score: {confidence_score:.2f}")
                print(f"   Root Cause: {fp_kpi.get('root_cause', 'Cached analysis')[:80]}...")
                print(f"   Fix Plan: {len(fp_kpi.get('fix_plan', {}).get('actions', []))} actions")
                progress_logs.append(f"[FAST-PATH] ✅ Using cached resolution for {kpi_name} (Incident: {incident_id})")
                progress_logs.append(f"[FAST-PATH] Confidence: {confidence_score:.2f} | Source: ChromaDB cache")
                
                # ✨ NEW: Send RCA notification for fast-path too
                self.notification_agent.notify_rca_complete_awaiting_approval({
                    "kpi_name": kpi_name,
                    "service": service,
                    "root_cause": fp_kpi.get("root_cause", "Cached analysis"),
                    "proposed_fix": fp_kpi.get("fix_plan", {}),
                    "approval_id": f"fp_{incident_id}",
                    "confidence_score": confidence_score,
                    "decision_reason": f"Fast-path: {decision_reason}"
                })
                
                # Still need approval even for fast-path
                approval_result = self.approval_agent.run({
                    "fix_proposal": {
                        "kpi": fp_kpi["received_kpi"],
                        "service": service,
                        "fix_plan": fp_kpi.get("fix_plan", {})
                    }
                })
                approval_status = approval_result.get("status", "pending_approval")
                approval_id = approval_result.get("approval_id", "")
                
                # ✨ NEW: Send approval notification
                self.notification_agent.notify_approval_decision({
                    "approval_id": approval_id,
                    "kpi_name": kpi_name,
                    "service": service,
                    "decision": approval_status,
                    "decision_reason": "Using cached resolution"
                })
                
                # ✨ NEW: Generate incident report for fast-path
                incident_report = {
                    "incident_id": incident_id,
                    "kpi_name": kpi_name,
                    "service": service,
                    "root_cause": fp_kpi.get("root_cause", "Cached analysis"),
                    "fix_plan": fp_kpi.get("fix_plan", {}),
                    "approval_id": approval_id,
                    "approval_status": approval_status,
                    "execution_status": "not_required" if approval_status == "approved" else "skipped",
                    "confidence_score": confidence_score,
                    "decision_reason": decision_reason,
                    "path": "fast",
                    "rca_source": "cache",
                    "stored_in_memory": True,  # Already stored from previous run
                    "processing_time_seconds": 0.0
                }
                
                # Format result for consistency with deep-path
                all_results.append({
                    "incident_id": incident_id,  # ✨ NEW
                    "kpi_name": kpi_name,
                    "service": service,
                    "path": "fast",
                    "root_cause": fp_kpi.get("root_cause", "Cached analysis"),
                    "fix_plan": fp_kpi.get("fix_plan", {}),
                    "approval_id": approval_id,
                    "approval_status": approval_status,  # "pending_approval" from approval_agent
                    "execution_status": "not_required" if approval_status == "approved" else "skipped",
                    "confidence_score": confidence_score,  # ✨ NEW
                    "decision_reason": decision_reason,  # ✨ NEW
                    "memory_hit": True,
                    "stored_in_memory": True,  # Already stored from previous run
                    "received_kpi": fp_kpi.get("received_kpi", {}),  # Include for consistency
                    "incident_report": incident_report,  # ✨ NEW
                })
            
            # Add deep-path results
            all_results.extend(deep_results)
            
            # ✨ NEW: Summary logging
            processing_time = time.time() - start_time
            fast_count = len(fast_path_kpis)
            deep_count = len(deep_path_kpis)
            
            print(f"\n" + "="*70)
            print("📊 PIPELINE SUMMARY")
            print("="*70)
            print(f"⚡ Fast Path (Cache Hit): {fast_count}")
            print(f"🔬 Deep Path (Full Analysis): {deep_count}")
            print(f"⏱️  Total Processing Time: {processing_time:.2f}s")
            print(f"💾 Data Persisted in ChromaDB: Ready for next run")
            print("="*70)
            
            progress_logs.append(f"[COMPLETE] Pipeline finished in {processing_time:.2f}s")
            progress_logs.append(f"[SUMMARY] Fast paths: {fast_count}, Deep paths: {deep_count}")
            print(f"\n✅ Pipeline complete!")
            return self._create_result(all_results, start_time, progress_logs=progress_logs)

        except Exception as e:
            logger.error("Pipeline failed: %s", str(e))
            progress_logs.append(f"[ERROR] {str(e)}")
            return self._create_result([], start_time, error=str(e), progress_logs=progress_logs)

    def _process_deep_path(self, kpi: Dict[str, Any], vector_db: VectorDBWrapper, progress_logs: List[str]) -> Dict[str, Any]:
        """
        AIOps-compliant deep path: RCA → Fix → Approval → Execution → CONDITIONAL Storage
        
        ✨ KEY CHANGE: Storage now happens ONLY after BOTH approval AND execution success
        This ensures we only learn from validated resolutions.
        """
        kpi_name = kpi.get("kpi_name", "unknown")
        service = kpi.get("service", "unknown")
        incident_id = str(uuid.uuid4())[:8].upper()  # ✨ NEW: Unique incident ID
        start_time = time.time()
        
        print(f"\n🔍 Running deep path analysis for {kpi_name} [Incident: {incident_id}]")
        progress_logs.append(f"[ANALYSIS] Starting deep path for {kpi_name} (Incident: {incident_id})")
        
        # ═══ STEP 1: FETCH LOGS ═══
        print("📋 Step 1: Collecting logs...")
        progress_logs.append(f"[STEP 1] Collecting logs for {kpi_name}")
        logs_result = self.log_agent.run({"kpis": [kpi]})
        logs = logs_result.get("logs", {}).get(kpi_name, [])
        progress_logs.append(f"[OK] Retrieved {len(logs)} log entries")
        
        # ═══ STEP 2: ROOT CAUSE ANALYSIS ═══
        print("🔬 Step 2: Running RCA (KB + LLM)...")
        progress_logs.append(f"[STEP 2] Running Root Cause Analysis")
        rca_result = self.rca_agent.run({"kpi": kpi, "logs": logs, "progress_logs": progress_logs})
        root_cause = rca_result.get("root_cause", "Unknown cause")
        analysis_source = rca_result.get("analysis_source", "unknown")
        progress_logs.append(f"[OK] RCA complete (source: {analysis_source})")
        logger.info("📊 RCA analysis source: %s", analysis_source)
        
        # ═══ STEP 3: GENERATE FIX PLAN ═══
        print("🔧 Step 3: Generating fix plan...")
        progress_logs.append(f"[STEP 3] Generating fix plan")
        fix_result = self.fixer_agent.run({"rca_result": rca_result, "kpi": kpi})
        fix_plan = fix_result.get("fix_plan", {})
        progress_logs.append(f"[OK] Fix plan generated")
        
        # ✨ NEW: Calculate confidence score for RCA result
        # In production, this could be based on KB match quality, LLM certainty, etc.
        confidence_score = 0.8 if analysis_source == "kb_matched" else 0.75
        decision_reason = f"RCA from {analysis_source} with confidence {confidence_score:.2f}"
        
        # ═══ STEP 4: REQUEST APPROVAL (BEFORE EXECUTION) ═══
        print("🔐 Step 4: Requesting approval...")
        progress_logs.append(f"[STEP 4] Waiting for approval")
        approval_result = self.approval_agent.run({"fix_proposal": fix_result})
        approval_status = approval_result.get("status", "pending")
        approval_id = approval_result.get("approval_id", "")
        print(f"⏳ Approval Status: {approval_status.upper()}")
        progress_logs.append(f"[APPROVAL] Status: {approval_status}")
        
        # ✨ NEW: Send RCA + Fix notification (for operator awareness)
        print(f"📢 Step 4.5: Sending approval notification...")
        progress_logs.append(f"[NOTIFY] Sending RCA completion notification")
        self.notification_agent.notify_rca_complete_awaiting_approval({
            "kpi_name": kpi_name,
            "service": service,
            "root_cause": root_cause,
            "proposed_fix": fix_plan,
            "approval_id": approval_id,
            "confidence_score": confidence_score,
            "decision_reason": decision_reason
        })
        progress_logs.append(f"[OK] Notification sent")
        
        # ═══ STEP 5: EXECUTE ONLY IF APPROVED ═══
        execution_status = "pending"
        execution_output = ""
        
        if approval_status == "approved":
            print("✅ Approval granted - executing fix...")
            progress_logs.append(f"[STEP 5] Approval granted - executing fix")
            print(f"⚙️  EXECUTION STARTED")
            
            executor_result = self.approval_executor_agent.run({
                "approval_id": approval_id,
                "approval_status": approval_status,
                "fix_plan": fix_plan,
            })
            execution_status = executor_result.get("execution_status", "pending")
            execution_output = executor_result.get("execution_output", "")
            
            print(f"✅ EXECUTION {execution_status.upper()}" if execution_status == "success" else f"❌ EXECUTION {execution_status.upper()}")
            progress_logs.append(f"[OK] Fix executed (status: {execution_status})")
            
            # ✨ NEW: Send execution notification
            print(f"📢 Sending execution result notification...")
            self.notification_agent.notify_execution_result({
                "approval_id": approval_id,
                "kpi_name": kpi_name,
                "service": service,
                "execution_status": execution_status,
                "execution_output": execution_output,
                "execution_time_seconds": executor_result.get("execution_time_seconds", 0)
            })
            progress_logs.append(f"[NOTIFY] Execution notification sent")
            
            # Update stats
            if execution_status == "success":
                self.pipeline_stats["executions_successful"] += 1
            else:
                self.pipeline_stats["executions_failed"] += 1
        elif approval_status == "pending_approval":
            # ✨ CRITICAL: Don't execute, just wait for user approval from main.py
            print(f"⏳ PENDING APPROVAL - Awaiting user decision from main.py")
            progress_logs.append(f"[STEP 5] Pending approval - waiting for user decision")
            execution_status = "pending"
            # Notification already sent in Step 4.5
        else:
            print(f"❌ REJECTED - Fix NOT executed (approval={approval_status})")
            progress_logs.append(f"[STEP 5] Fix NOT executed (approval not granted)")
            execution_status = "skipped"
            
            # ✨ NEW: Send rejection notification
            print(f"📢 Sending rejection notification...")
            self.notification_agent.notify_rejection({
                "approval_id": approval_id,
                "kpi_name": kpi_name,
                "service": service,
                "reason": f"Approval decision: {approval_status}",
                "rejection_type": "approval_rejected"
            })
            progress_logs.append(f"[NOTIFY] Rejection notification sent")
            
            # Update stats
            self.pipeline_stats["approvals_rejected"] += 1
        
        if approval_status == "approved":
            self.pipeline_stats["approvals_granted"] += 1
        
        # ✨ CRITICAL CHANGE: Storage is now handled in main.py via post_approval_storage()
        # During pipeline run, we only prepare the data
        # After user approval in main.py, post_approval_storage() performs the actual ChromaDB write
        print(f"\n⏳ Storage will be handled AFTER user approval confirmation")
        progress_logs.append(f"[PENDING] Storage waiting for user approval in main.py")
        
        # ═══ FINAL RESULT ═══
        processing_time = time.time() - start_time
        print(f"""
╔════════════════════════════════════════╗
║          FINAL RESULT                  ║
╠════════════════════════════════════════╣
║ Incident ID: {incident_id:24} ║
║ KPI:         {kpi_name:30} ║
║ Service:     {service:30} ║
║ Path:        deep                      ║
║ RCA Source:  {analysis_source:30} ║
║ Confidence:  {confidence_score:30.2f}║
║ Approval:    {approval_status.upper():30} ║
║ Execution:   {execution_status.upper():30} ║
║ Storage:     PENDING (awaiting approval)║
║ Time:        {f"{processing_time:.2f}s":30} ║
╚════════════════════════════════════════╝
""")
        
        # ✨ NEW: Generate incident report with all metadata
        incident_report = {
            "incident_id": incident_id,
            "kpi_name": kpi_name,
            "service": service,
            "root_cause": root_cause,
            "fix_plan": fix_plan,
            "approval_id": approval_id,
            "approval_status": approval_status,
            "execution_status": execution_status,
            "execution_output": execution_output,
            "confidence_score": confidence_score,
            "decision_reason": decision_reason,
            "path": "deep",
            "rca_source": analysis_source,
            "stored_in_memory": False,  # Will be set to True after user approval + post_approval_storage
            "processing_time_seconds": round(processing_time, 2)
        }
        
        return {
            "incident_id": incident_id,  # ✨ NEW
            "kpi_name": kpi_name,
            "service": service,
            "path": "deep",
            "root_cause": root_cause,
            "analysis_source": analysis_source,
            "rca_report": rca_result.get("rca_report", ""),
            "fix_plan": fix_plan,
            "approval_id": approval_id,
            "approval_status": approval_status,  # Will be "pending_approval" from approval_agent
            "execution_status": execution_status,
            "execution_output": execution_output,
            "confidence_score": confidence_score,  # ✨ NEW
            "decision_reason": decision_reason,  # ✨ NEW
            "stored_in_memory": False,  # ✨ Will be set after post_approval_storage() in main.py
            "kb_id": None,
            "kb_status": None,
            "received_kpi": kpi,  # ✨ CRITICAL: Pass original KPI for storage in main.py
            "incident_report": incident_report,  # ✨ NEW: Full incident metadata
        }


    def post_approval_storage(self, result_item: Dict[str, Any], vector_db=None) -> Dict[str, Any]:
        """
        ✨ NEW: Execute storage AFTER user approval in main.py
        
        This separates the approval decision from the storage operation:
        1. Pipeline runs → approval_status = "pending_approval"
        2. main.py asks user → gets decision → calls this function
        3. This function performs the actual storage if approved
        
        Args:
            result_item: Single result dict from pipeline results with:
                - approval_status: "approved" or "rejected"
                - received_kpi: Original KPI data
                - service: Service name
                - root_cause: RCA result
                - fix_plan: Generated fix
                - incident_id: Unique incident ID
        
        Returns:
            Updated result_item with stored_in_memory = True/False
        """
        approval_status = result_item.get("approval_status", "pending")
        incident_id = result_item.get("incident_id", "unknown")
        kpi_name = result_item.get("kpi_name", "unknown")
        service = result_item.get("service", "unknown")
        
        print(f"\n[POST-APPROVAL] Processing Incident {incident_id}: {kpi_name}/{service}")
        print(f"[POST-APPROVAL] Approval Status: {approval_status.upper()}")
        
        if approval_status != "approved":
            print(f"[POST-APPROVAL] ❌ NOT approved - skipping storage")
            result_item["stored_in_memory"] = False
            return result_item
        
        print(f"[POST-APPROVAL] ✅ Approved - proceeding with storage")
        
        # Get required data from result
        received_kpi = result_item.get("received_kpi")
        if not received_kpi:
            # Fallback: build minimal KPI from available data
            received_kpi = {
                "kpi_name": kpi_name,
                "service": service,
                "host": "unknown"
            }
        
        root_cause = result_item.get("root_cause", "")
        fix_plan = result_item.get("fix_plan", {})
        
        # Check if USE_VECTOR_DB is enabled
        if not USE_VECTOR_DB:
            print(f"[POST-APPROVAL] ⚠️  ChromaDB disabled in config")
            result_item["stored_in_memory"] = False
            return result_item
        
        try:
            # FIX 3: Reuse passed vector_db instance instead of creating a new one
            if vector_db is None:
                vector_db = VectorDBWrapper()

            store_data = {
                "kpi": received_kpi,
                "service": service,
                "root_cause": root_cause,
                "fix": fix_plan
            }
            
            print(f"[POST-APPROVAL] 💾 Storing in ChromaDB...")
            print(f"[POST-APPROVAL] KPI: {kpi_name}")
            print(f"[POST-APPROVAL] Service: {service}")
            
            store_result = vector_db.store(store_data)
            
            if store_result:
                print(f"[POST-APPROVAL] ✅ STORED SUCCESSFULLY")
                print(f"[POST-APPROVAL] ✅ Fast path will now trigger for future runs")
                
                # Notify storage completion
                self.notification_agent.notify_memory_stored({
                    "approval_id": result_item.get("approval_id", ""),
                    "kpi_name": kpi_name,
                    "service": service,
                    "storage_location": "chromadb",
                    "success": True
                })
                
                result_item["stored_in_memory"] = True
                return result_item
            else:
                print(f"[POST-APPROVAL] ❌ Storage failed")
                result_item["stored_in_memory"] = False
                return result_item
                
        except Exception as e:
            print(f"[POST-APPROVAL] ❌ Exception during storage: {e}")
            import traceback
            traceback.print_exc()
            result_item["stored_in_memory"] = False
            return result_item

    def _create_result(self, results: List[Dict], start_time: float,
                      error: Optional[str] = None, progress_logs: Optional[List[str]] = None) -> Dict[str, Any]:
        processing_time = time.time() - start_time
        if progress_logs is None:
            progress_logs = []
        return {
            "timestamp": datetime.now().isoformat(),
            "processing_time_seconds": round(processing_time, 2),
            "kpis_processed": len(results),
            "pipeline_stats": self.pipeline_stats.copy(),
            "results": results,
            "error": error,
            "progress_logs": progress_logs
        }

    def get_stats(self) -> Dict[str, Any]:
        return self.pipeline_stats.copy()


orchestrator = PipelineOrchestrator()

def run_pipeline() -> Dict[str, Any]:
    return orchestrator.run_pipeline()

def get_pipeline_stats() -> Dict[str, Any]:
    return orchestrator.get_stats()
