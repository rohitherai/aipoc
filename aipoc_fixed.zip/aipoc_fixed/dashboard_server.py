#!/usr/bin/env python
"""
Enhanced Flask API Server with Professional Dashboard
Integrates real AIOps pipeline with beautiful UI for leadership demos
"""

from flask import Flask, render_template_string, jsonify, request, send_file
from pipeline_orchestrator import run_pipeline, get_pipeline_stats
from vector_db_wrapper import VectorDBWrapper
from datetime import datetime
import json
import os
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Store pipeline execution history for dashboard
execution_history = []
current_execution = None

@app.route('/')
def index():
    """Serve the professional dashboard"""
    with open('dashboard.html', 'r', encoding='utf-8') as f:
        return f.read()

@app.route('/approval-cache')
def approval_cache_dashboard():
    """Serve the approval & caching visualization dashboard"""
    with open('dashboard_approval_cache.html', 'r', encoding='utf-8') as f:
        return f.read()

@app.route('/api/dashboard')
def get_dashboard():
    """Get dashboard data"""
    try:
        db = VectorDBWrapper()
        validation = db.validate_persistence()
        
        return jsonify({
            'status': 'success',
            'execution_history': execution_history[-10:],  # Last 10 executions
            'current_execution': current_execution,
            'db_status': {
                'total_entries': validation['total_records'],
                'path': validation['db_path'],
                'is_valid': validation['is_valid']
            },
            'cache_metrics': {
                'hit_ratio': calculate_hit_ratio(),
                'avg_cache_time': 0.05,
                'avg_deep_time': 16.5
            }
        })
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/inject-fault', methods=['POST'])
def inject_fault():
    """Simulate fault injection and run pipeline"""
    global current_execution
    
    try:
        data = request.json
        fault_type = data.get('fault_type', 'throughput_collapse')
        
        logger.info(f"Injecting fault: {fault_type}")
        
        # Run the actual pipeline
        result = run_pipeline()
        
        # Extract key metrics from pipeline result
        results_list = result.get('results', [])
        first_result = results_list[0] if results_list else {}
        
        # ✨ Map pipeline output to dashboard format
        execution = {
            'timestamp': datetime.now().isoformat(),
            'fault_type': fault_type,
            'result': result,
            # Map approval/storage data
            'approval_status': first_result.get('approval_status', 'unknown'),
            'stored_in_memory': first_result.get('stored_in_memory', False),
            'path': first_result.get('path', 'unknown'),
            'confidence_score': first_result.get('confidence_score', 0),
            'incident_id': first_result.get('incident_id', 'N/A'),
            'kpi_name': first_result.get('kpi_name', 'unknown'),
            'service': first_result.get('service', 'unknown'),
            'root_cause': first_result.get('root_cause', 'N/A')[:200],  # First 200 chars
            'duration': result.get('processing_time_seconds', 0),
            'route': 'FAST_PATH' if first_result.get('path') == 'fast' else 'DEEP_PATH',
            'cache_score': first_result.get('confidence_score', 0),
            'progress_logs': result.get('progress_logs', [])
        }
        
        execution_history.append(execution)
        current_execution = execution
        
        logger.info(f"Execution completed: {execution['incident_id']} | {execution['path'].upper()} | Stored: {execution['stored_in_memory']}")
        
        return jsonify({
            'status': 'success',
            'execution': execution
        })
    except Exception as e:
        logger.error(f"Fault injection error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/pipeline-stats')
def pipeline_stats():
    """Get pipeline statistics"""
    try:
        stats = get_pipeline_stats()
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Stats error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/cache-status')
def cache_status():
    """Get cache status"""
    try:
        db = VectorDBWrapper()
        validation = db.validate_persistence()
        
        return jsonify({
            'status': 'success',
            'total_entries': validation['total_records'],
            'hit_ratio': calculate_hit_ratio(),
            'last_update': datetime.now().isoformat(),
            'message': validation['status_message']
        })
    except Exception as e:
        logger.error(f"Cache status error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

def calculate_hit_ratio():
    """Calculate cache hit ratio from execution history"""
    if not execution_history:
        return 0
    
    fast_path_count = sum(1 for ex in execution_history if ex.get('route') == 'FAST_PATH')
    return round((fast_path_count / len(execution_history)) * 100, 1)

@app.route('/api/analyze', methods=['GET', 'POST'])
def analyze():
    """API endpoint for KPI analysis"""
    try:
        result = run_pipeline()
        return jsonify(result)
    except Exception as e:
        logger.error(f"Analysis error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

if __name__ == '__main__':
    logger.info("Starting AIOps Dashboard Server...")
    logger.info("")
    logger.info("="*70)
    logger.info("📊 DASHBOARDS AVAILABLE:")
    logger.info("="*70)
    logger.info("✅ Main Dashboard:           http://localhost:5000/")
    logger.info("✅ Approval & Cache View:    http://localhost:5000/approval-cache")
    logger.info("")
    logger.info("📡 API ENDPOINTS:")
    logger.info("  • POST /api/inject-fault        - Run fault analysis")
    logger.info("  • GET  /api/cache-status        - Check cache metrics")
    logger.info("  • GET  /api/pipeline-stats      - Get pipeline statistics")
    logger.info("  • GET  /api/analyze             - Run pipeline analysis")
    logger.info("  • GET  /api/dashboard           - Get dashboard data")
    logger.info("")
    logger.info("🎯 HOW TO TEST:")
    logger.info("  1. Open http://localhost:5000/approval-cache in browser")
    logger.info("  2. Click '🚀 Run Pipeline Analysis' button")
    logger.info("  3. Watch the approval → storage → caching flow in real-time")
    logger.info("  4. Run again to see FAST PATH cache hit")
    logger.info("="*70)
    logger.info("")
    
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True)
