MODE = "demo"        # demo or real
USE_LLM = True       # enable/disable LLM
USE_VECTOR_DB = True # enable/disable Pinecone
USE_LOCAL_CACHE = True # enable/disable local file-based cache (faster than Pinecone, no proxy issues)

# ✨ AUTO APPROVAL FOR DEMO MODE
AUTO_APPROVE = True  # Set to True for demo/testing (no manual approval needed)
                     # Set to False for production (requires manual CLI approval)
