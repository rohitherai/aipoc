"""
grafana_agent.py — KPI Fetcher
================================
Fetches KPI data from:
  1. PROMETHEUS_URL — Direct Prometheus API (http://localhost:9090)
     Queries each KPI metric and parses Prometheus instant query response.
  2. dummy_kpis.json — fallback if Prometheus not reachable

Grafana is NOT needed.
"""

import json, os, logging, requests
from datetime import datetime

logger = logging.getLogger(__name__)

# ── Prometheus config ─────────────────────────────────────────────────────────
# Set this in .env:  PROMETHEUS_URL=http://localhost:9090
PROMETHEUS_URL = os.getenv("PROMETHEUS_URL", "").rstrip("/")

# ── KPI definitions ───────────────────────────────────────────────────────────
# Each entry:  KPI_name → (prometheus_metric_name, threshold, service, host_label)
# The metric_name is what Prometheus stores — adjust to match your actual metric names
KPI_DEFINITIONS = [
    # kpi_name                  metric_query (PromQL)                                    threshold  service   host_label
    ("SMF_CPU_Usage",           '{__name__=~"smf_cpu.*"}',                                70,       "smf",    "instance"),
    ("UPF_Memory_Usage",        '{__name__=~"upf_memory.*"}',                             80,       "upf",    "instance"),
    ("PFCP_Errors",             '{__name__=~"pfcp_error.*"}',                             10,       "smf",    "instance"),
    ("GTP_Packet_Loss",         '{__name__=~"gtp_packet_loss.*"}',                        2,        "upf",    "instance"),
    ("NRF_Connection_Latency",  '{__name__=~"nrf.*latency.*"}',                           0.25,     "nrf",    "instance"),
    ("AUSF_Auth_Failures",      '{__name__=~"ausf_auth.*"}',                              5,        "ausf",   "instance"),
    ("CPU_Usage",               '{__name__=~".*cpu_usage.*"}',                            80,       "unknown","instance"),
]


def _query_prometheus(query: str) -> list:
    """
    Call Prometheus instant query API.
    URL:  http://localhost:9090/api/v1/query?query=<promql>
    Returns list of {metric labels, value} from Prometheus response.
    
    Prometheus response format:
    {
      "status": "success",
      "data": {
        "resultType": "vector",
        "result": [
          {
            "metric": {"__name__": "smf_cpu_usage", "instance": "smf-core-01", ...},
            "value":  [<timestamp>, "<value_string>"]
          }
        ]
      }
    }
    """
    url  = f"{PROMETHEUS_URL}/api/v1/query"
    resp = requests.get(url, params={"query": query}, timeout=10)
    resp.raise_for_status()
    data = resp.json()

    if data.get("status") != "success":
        logger.warning("Prometheus query failed: %s", data.get("error", "unknown"))
        return []

    return data.get("data", {}).get("result", [])


def _fetch_from_prometheus() -> list:
    """
    Query Prometheus for each KPI using PromQL.
    Parses the instant vector response and maps to our KPI format.
    """
    results = []
    now = datetime.utcnow().isoformat() + "Z"

    for kpi_name, query, threshold, service, host_label in KPI_DEFINITIONS:
        try:
            prom_results = _query_prometheus(query)

            if not prom_results:
                logger.debug("No Prometheus data for %s (query: %s)", kpi_name, query)
                continue

            for result in prom_results:
                metric = result.get("metric", {})
                value_arr = result.get("value", [None, "0"])
                value = float(value_arr[1]) if len(value_arr) > 1 else 0.0

                # Get host from metric labels
                host = (metric.get(host_label) or
                        metric.get("instance") or
                        metric.get("host") or
                        "unknown")

                # Get service from metric labels if available
                svc = (metric.get("job") or
                       metric.get("service") or
                       service)

                results.append({
                    "kpi_name":  kpi_name,
                    "value":     round(value, 4),
                    "threshold": threshold,
                    "host":      host,
                    "service":   svc,
                    "timestamp": now,
                })
                logger.info("Prometheus KPI: %s = %s (threshold: %s, host: %s)",
                            kpi_name, value, threshold, host)

        except Exception as exc:
            logger.warning("Error fetching %s from Prometheus: %s", kpi_name, exc)

    return results


def _load_dummy_data() -> list:
    """Load fallback dummy KPI data from JSON file."""
    dummy_path = os.path.join(os.path.dirname(__file__), "data", "dummy_kpis.json")
    with open(dummy_path, "r") as f:
        return json.load(f)


def get_kpi_data() -> list:
    """
    Returns a list of KPI records.

    Priority:
      1. PROMETHEUS_URL set in .env → query Prometheus directly
         e.g. PROMETHEUS_URL=http://localhost:9090
         Queries: http://localhost:9090/api/v1/query?query={__name__=~"smf_.*"}

      2. Fallback → data/dummy_kpis.json
    """
    if PROMETHEUS_URL:
        try:
            logger.info("Fetching KPIs from Prometheus: %s", PROMETHEUS_URL)
            kpis = _fetch_from_prometheus()
            if kpis:
                logger.info("Got %d KPIs from Prometheus", len(kpis))
                return kpis
            else:
                logger.warning("Prometheus returned 0 KPIs — check metric names in KPI_DEFINITIONS")
                logger.warning("Falling back to dummy_kpis.json")
        except Exception as exc:
            logger.warning("Prometheus fetch failed: %s — falling back to dummy data", exc)

    logger.info("Using dummy KPI data from dummy_kpis.json")
    return _load_dummy_data()
