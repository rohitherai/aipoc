#!/usr/bin/env python
"""
Enhanced Flask API Server with Professional Dashboard
Integrates real AIOps pipeline with beautiful UI for leadership demos
"""

from flask import Flask, render_template_string, jsonify, request, send_file, redirect, Response, stream_with_context
from pipeline_orchestrator import run_pipeline, get_pipeline_stats
from vector_db_wrapper import VectorDBWrapper
from datetime import datetime
import json
import os
import logging
import threading
import time
import uuid
import random

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Store pipeline execution history for dashboard
execution_history = []
current_execution = None

# Get the directory where this script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# In-memory execution store for streaming pipeline runs
execution_store = {}


def make_execution_record():
    eid = uuid.uuid4().hex
    execution_store[eid] = {
        "status": "running",
        "logs": [],
        "current_step": None,
        "approval_required": False,
        "approved": False,
        "path": None,
        "confidence": 0.0,
        "kpi_name": None,
        "service": None,
        "duration": 0.0
    }
    return eid


def emit(eid, step, status, message, confidence=None, path=None):
    rec = execution_store.get(eid)
    if rec is None:
        return
    entry = {
        "timestamp": datetime.utcnow().isoformat() + 'Z',
        "step": step,
        "status": status,
        "message": message,
        "confidence": confidence if confidence is not None else rec.get('confidence'),
        "path": path if path is not None else rec.get('path')
    }
    rec['logs'].append(entry)
    rec['current_step'] = step
    if confidence is not None:
        rec['confidence'] = confidence
    if path is not None:
        rec['path'] = path

@app.route('/')
def index():
    """Serve the main dashboard"""
    demo_path = os.path.join(SCRIPT_DIR, 'hackathon_demo.html')
    fallback_path = os.path.join(SCRIPT_DIR, 'unified_dashboard.html')

    if os.path.exists(demo_path):
        try:
            return send_file(demo_path, mimetype='text/html', max_age=0)
        except Exception as e:
            return f"<h1>Error</h1><p>{str(e)}</p>", 500

    if os.path.exists(fallback_path):
        try:
            return send_file(fallback_path, mimetype='text/html', cache_timeout=0)
        except Exception as e:
            return f"<h1>Error</h1><p>{str(e)}</p>", 500

    return f"<h1>404 - Dashboard Not Found</h1><p>Looking for: {demo_path} or {fallback_path}</p>", 404

@app.route('/approval-cache', strict_slashes=False)
@app.route('/approval-cache/', strict_slashes=False)
@app.route('/approvalcache', strict_slashes=False)
def approval_cache():
    """Serve the same dashboard from the legacy approval-cache route"""
    logger.info("Serving legacy approval-cache route")
    return index()

@app.route('/api/dashboard')
def get_dashboard():
    """Get dashboard data"""
    try:
        db = VectorDBWrapper()
        validation = db.validate_persistence()
        
        return jsonify({
            'status': 'success',
            'execution_history': execution_history[-10:],  # Last 10 executions
            'current_execution': current_execution,
            'db_status': {
                'total_entries': validation['total_records'],
                'path': validation['db_path'],
                'is_valid': validation['is_valid']
            },
            'cache_metrics': {
                'hit_ratio': calculate_hit_ratio(),
                'avg_cache_time': 0.05,
                'avg_deep_time': 16.5
            }
        })
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/inject-fault', methods=['POST'])
def inject_fault():
    """Start a pipeline run in background and return execution id"""
    try:
        data = request.json or {}
        fault_type = data.get('fault_type', 'simulated_kpi')
        force_fast = bool(data.get('force_fast', False))

        eid = make_execution_record()
        execution_store[eid]['kpi_name'] = f"KPI_{fault_type}_{eid[:6]}"
        execution_store[eid]['service'] = data.get('service', 'demo-service')
        execution_store[eid]['force_fast'] = force_fast

        # Start background thread to stream pipeline steps
        t = threading.Thread(target=run_pipeline_stream, args=(eid,), daemon=True)
        t.start()

        return jsonify({'status': 'started', 'execution_id': eid}), 202
    except Exception as e:
        logger.error(f"Fault injection error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/pipeline-stats')
def pipeline_stats():
    """Get pipeline statistics"""
    try:
        stats = get_pipeline_stats()
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Stats error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/stream/<execution_id>')
def stream_execution(execution_id):
    """Server-Sent Events stream for a running execution"""
    rec = execution_store.get(execution_id)
    if rec is None:
        return jsonify({'status': 'error', 'message': 'execution not found'}), 404

    def event_stream():
        last_index = 0
        # Send existing logs first and then stream new ones
        while True:
            rec = execution_store.get(execution_id)
            if rec is None:
                break
            logs = rec.get('logs', [])
            while last_index < len(logs):
                data = logs[last_index]
                last_index += 1
                yield f"data: {json.dumps({**data, 'execution_id': execution_id})}\n\n"
            if rec.get('status') == 'done':
                break
            time.sleep(0.4)
        final = execution_store.get(execution_id) or {}
        yield f"data: {json.dumps({'step':'__complete__','status': final.get('status','done'),'message':'execution finished','execution_id':execution_id,'path': final.get('path'), 'confidence': final.get('confidence')})}\n\n"

    return Response(stream_with_context(event_stream()), mimetype='text/event-stream')


@app.route('/api/approve', methods=['POST'])
def approve_execution():
    data = request.json or {}
    eid = data.get('execution_id')
    decision = data.get('decision', 'approve')
    rec = execution_store.get(eid)
    if rec is None:
        return jsonify({'status': 'error', 'message': 'execution not found'}), 404
    if decision == 'approve':
        rec['approved'] = True
        rec['approval_required'] = False
        rec['decision'] = 'approve'
        emit(eid, 'Approval', 'completed', 'Operator approved')
        return jsonify({'status': 'ok'}), 200
    if decision == 'reject':
        rec['approved'] = True
        rec['approval_required'] = False
        rec['decision'] = 'reject'
        emit(eid, 'Approval', 'completed', 'Operator rejected')
        return jsonify({'status': 'ok'}), 200
    return jsonify({'status': 'ignored'}), 200


def run_pipeline_stream(eid):
    """Simulated step-by-step pipeline which emits logs into execution_store"""
    rec = execution_store.get(eid)
    start = time.time()

    try:
        # STEP 1: KPI received
        emit(eid, 'KPI', 'completed', 'KPI received')
        time.sleep(0.4)

        # STEP 2: Embedding
        emit(eid, 'Embedding', 'running', 'Encoding KPI vector')
        time.sleep(1.0)
        emit(eid, 'Embedding', 'completed', 'Embedding complete')

        # STEP 3: Cache check
        emit(eid, 'Cache', 'running', 'Checking semantic cache')
        time.sleep(0.6)
        cache_hit = rec.get('force_fast', False)
        if cache_hit:
            path = 'fast'
            confidence = round(0.90 + random.random() * 0.09, 2)
            emit(eid, 'Cache', 'completed', 'Cache hit', confidence=confidence, path=path)
        else:
            path = 'deep'
            confidence = round(0.4 + random.random() * 0.25, 2)
            emit(eid, 'Cache', 'completed', 'Cache miss', confidence=confidence, path=path)

        # STEP 4: Decision
        emit(eid, 'Decision', 'completed', f'{path.upper()} path selected', confidence=confidence, path=path)
        time.sleep(0.5)

        # STEP 5: RCA if deep
        if path == 'deep':
            emit(eid, 'RCA', 'running', 'Analyzing logs with LLM...')
            time.sleep(2.0)
            root = 'AMF NAS signalling delay spike. Registration procedure timeout cascade from AUSF leading to NAS T3560 timing breach.'
            emit(eid, 'RCA', 'completed', f'Root cause identified: {root}')
            # attach root cause to record
            rec = execution_store.get(eid)
            if rec is not None:
                rec['root_cause'] = root
        else:
            emit(eid, 'RCA', 'skipped', 'Skipped due to cache hit')

        # STEP 6: Approval required
        rec = execution_store.get(eid)
        # propose a fix
        proposed = 'Restart AUSF instance ausf-pod-02 with increased heap, enable AMF fallback authentication, and reduce NAS T3560 from 600ms to 300ms.'
        if rec is not None:
            rec['proposed_fix'] = proposed
        # emit proposed fix
        emit(eid, 'ProposedFix', 'ready', proposed)
        # now require approval
        rec['approval_required'] = True
        emit(eid, 'Approval', 'waiting', 'Operator approval required')

        # wait until approved or rejected
        while not rec.get('approved'):
            time.sleep(0.5)
            rec = execution_store.get(eid)

        if rec.get('decision') == 'reject':
            emit(eid, 'Execution', 'completed', 'Operator rejected fix — escalating to NOC')
            emit(eid, 'Learning', 'skipped', 'Rejected fix — learning skipped')
            rec['status'] = 'done'
            rec['duration'] = round(time.time() - start, 2)
            return

        # STEP 7: Execution
        emit(eid, 'Execution', 'running', 'Applying fix...')
        time.sleep(2.0)
        emit(eid, 'Execution', 'completed', 'Fix applied successfully')

        # STEP 8: Learning
        emit(eid, 'Learning', 'running', 'Updating memory with new example')
        time.sleep(1.0)
        emit(eid, 'Learning', 'completed', 'Stored in knowledge base')

        # finish
        rec['status'] = 'done'
        rec['duration'] = round(time.time() - start, 2)
    except Exception as e:
        rec['status'] = 'error'
        emit(eid, 'System', 'error', str(e))

@app.route('/hackathon-demo')
def hackathon_demo():
    demo_path = os.path.join(SCRIPT_DIR, 'hackathon_demo.html')
    if not os.path.exists(demo_path):
        return jsonify({'status': 'error', 'message': 'hackathon_demo.html not found'}), 404
    return send_file(demo_path, mimetype='text/html', max_age=0)


@app.route('/api/cache-status')
def cache_status():
    """Get cache status"""
    try:
        db = VectorDBWrapper()
        validation = db.validate_persistence()
        
        return jsonify({
            'status': 'success',
            'total_entries': validation['total_records'],
            'hit_ratio': calculate_hit_ratio(),
            'last_update': datetime.now().isoformat(),
            'message': validation['status_message']
        })
    except Exception as e:
        logger.error(f"Cache status error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

def calculate_hit_ratio():
    """Calculate cache hit ratio from execution history"""
    if not execution_history:
        return 0
    
    fast_path_count = sum(1 for ex in execution_history if ex.get('route') == 'FAST_PATH')
    return round((fast_path_count / len(execution_history)) * 100, 1)

@app.route('/api/analyze', methods=['GET', 'POST'])
def analyze():
    """API endpoint for KPI analysis"""
    try:
        result = run_pipeline()
        return jsonify(result)
    except Exception as e:
        logger.error(f"Analysis error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

if __name__ == '__main__':
    logger.info("Starting AIOps Dashboard Server...")
    logger.info("")
    logger.info("="*70)
    logger.info("📊 DASHBOARDS AVAILABLE:")
    logger.info("="*70)
    logger.info("✅ Main Dashboard:           http://localhost:5000/")
    logger.info("✅ Approval & Cache View:    http://localhost:5000/approval-cache")
    logger.info("")
    logger.info("📡 API ENDPOINTS:")
    logger.info("  • POST /api/inject-fault        - Run fault analysis")
    logger.info("  • GET  /api/cache-status        - Check cache metrics")
    logger.info("  • GET  /api/pipeline-stats      - Get pipeline statistics")
    logger.info("  • GET  /api/analyze             - Run pipeline analysis")
    logger.info("  • GET  /api/dashboard           - Get dashboard data")
    logger.info("")
    logger.info("🎯 HOW TO TEST:")
    logger.info("  1. Open http://localhost:5000/approval-cache in browser")
    logger.info("  2. Click '🚀 Run Pipeline Analysis' button")
    logger.info("  3. Watch the approval → storage → caching flow in real-time")
    logger.info("  4. Run again to see FAST PATH cache hit")
    logger.info("="*70)
    logger.info("")
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
