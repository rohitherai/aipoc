"""
history_agent.py — History Agent
================================

Records all KPI incidents, resolutions, and outcomes to a history database.
Provides audit trail for compliance and learning.
"""

import logging
import json
import os
from typing import Dict, Any
from datetime import datetime

logger = logging.getLogger("history_agent")


class HistoryAgent:
    """Record KPI incidents and resolutions to history database."""

    def __init__(self):
        self.history_file = os.path.join(
            os.path.dirname(__file__),
            "data",
            "kpi_history.json"
        )
        self._init_history_file()

    def _init_history_file(self):
        """Ensure history file exists."""
        if not os.path.exists(self.history_file):
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump({"incidents": []}, f, indent=2)

    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Record incident to history database.
        
        input_data expects:
        {
            "kpi_name": str,
            "service": str,
            "host": str,
            "root_cause": str,
            "fix_plan": dict,
            "approval_id": str,
            "approval_status": str,
            "execution_status": str,
            "execution_output": str,
            "kb_id": str (optional),
            "processing_time": float,
        }
        """
        logger.info("Running HistoryAgent")
        
        # Build history record
        record = {
            "timestamp": datetime.now().isoformat(),
            "kpi_name": input_data.get("kpi_name", "unknown"),
            "service": input_data.get("service", "unknown"),
            "host": input_data.get("host", "unknown"),
            "root_cause_summary": input_data.get("root_cause", "")[:100],  # First 100 chars
            "approval_id": input_data.get("approval_id", "unknown"),
            "approval_status": input_data.get("approval_status", "unknown"),
            "execution_status": input_data.get("execution_status", "pending"),
            "kb_id": input_data.get("kb_id"),
            "processing_time_seconds": input_data.get("processing_time", 0),
        }
        
        # Append to history
        self._append_history(record)
        
        logger.info(
            "History recorded: %s/%s (approval=%s, execution=%s)",
            record["service"],
            record["kpi_name"],
            record["approval_status"],
            record["execution_status"]
        )
        
        return {
            "history_status": "recorded",
            "timestamp": record["timestamp"],
            "record_count": self._get_history_count(),
        }

    def _append_history(self, record: Dict[str, Any]):
        """Append record to history file."""
        try:
            with open(self.history_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {"incidents": []}
        
        data["incidents"].append(record)
        
        try:
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error("Failed to write history: %s", str(e))

    def _get_history_count(self) -> int:
        """Return total incident count."""
        try:
            with open(self.history_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            return len(data.get("incidents", []))
        except Exception:
            return 0

    def get_history(self, service: str = None, limit: int = 10) -> Dict[str, Any]:
        """Retrieve history records (optionally filtered by service)."""
        try:
            with open(self.history_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            incidents = data.get("incidents", [])
            
            if service:
                incidents = [i for i in incidents if i.get("service") == service]
            
            return {
                "total": len(incidents),
                "incidents": incidents[-limit:],  # Last N
            }
        except Exception as e:
            logger.error("Failed to retrieve history: %s", str(e))
            return {"total": 0, "incidents": []}
