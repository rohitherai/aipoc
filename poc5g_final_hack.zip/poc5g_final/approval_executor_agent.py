"""
approval_executor_agent.py — Approval Executor Agent
=====================================================

Checks approval status and executes approved fixes.
Post-approval gate: if approved, execute fix commands (safely).
If rejected, log rejection and skip execution.
"""

import logging
import time
from typing import Dict, Any, Optional

logger = logging.getLogger("approval_executor_agent")


class ApprovalExecutorAgent:
    """Check approval status and execute approved fixes."""

    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Check approval status; if approved, execute fix.
        
        input_data expects:
        {
            "approval_id": str,
            "approval_status": str ("pending_approval", "approved", "rejected"),
            "fix_plan": dict with "actions", "commands", "auto_fix_enabled"
        }
        """
        logger.info("Running ApprovalExecutorAgent")
        
        approval_id = input_data.get("approval_id")
        approval_status = input_data.get("approval_status", "pending_approval")
        fix_plan = input_data.get("fix_plan", {})
        
        if approval_status == "approved":
            logger.info("Approval %s is APPROVED. Proceeding with fix execution.", approval_id)
            execution_result = self._execute_fix(approval_id, fix_plan)
            return {
                "approval_id": approval_id,
                "approval_status": "approved",
                "execution_status": execution_result["status"],
                "execution_output": execution_result.get("output", ""),
                "execution_time_seconds": execution_result.get("time", 0),
            }
        elif approval_status == "rejected":
            logger.warning("Approval %s is REJECTED. Skipping fix execution.", approval_id)
            return {
                "approval_id": approval_id,
                "approval_status": "rejected",
                "execution_status": "skipped",
                "execution_output": "Fix rejected by operator; no execution.",
                "execution_time_seconds": 0,
            }
        else:
            logger.info("Approval %s is %s. Waiting for approval.", approval_id, approval_status)
            return {
                "approval_id": approval_id,
                "approval_status": approval_status,
                "execution_status": "pending",
                "execution_output": "Waiting for approval decision.",
                "execution_time_seconds": 0,
            }

    def _execute_fix(self, approval_id: str, fix_plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute fix plan commands (mock implementation).
        In production, this would safely execute shell commands with proper sandboxing.
        """
        start_time = time.time()
        
        auto_fix_enabled = fix_plan.get("auto_fix_enabled", False)
        commands = fix_plan.get("commands", [])
        actions = fix_plan.get("actions", [])
        
        if not auto_fix_enabled:
            logger.info(
                "Approval %s is approved and auto-fix is disabled, but execution is proceeding because approval was granted.",
                approval_id
            )
        
        # Mock execution (in production, would run commands with error handling)
        logger.info("Executing fix for approval %s: %s", approval_id, commands)
        output = f"[Mock Execution]\nApproval: {approval_id}\nCommands executed: {', '.join(commands)}\n"
        output += "✓ All commands executed successfully (mocked).\n"
        output += "Status: healthy post-remediation."
        
        return {
            "status": "success",
            "output": output,
            "time": time.time() - start_time,
        }
