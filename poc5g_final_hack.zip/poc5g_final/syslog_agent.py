"""
Agent 3 – Syslog Reader
Reads /var/log/syslog (Ubuntu) or falls back to dummy syslog.
Correlates log lines with the critical KPI names.
"""

import os
import logging

logger = logging.getLogger(__name__)

# Ubuntu syslog path; override via env
SYSLOG_PATH = os.getenv("SYSLOG_PATH", "/var/log/syslog")
DUMMY_LOG   = os.path.join(os.path.dirname(__file__), "data", "dummy_syslog.txt")

MAX_LINES_PER_KPI = 10  # cap to avoid huge LLM prompts


def _read_log_file(path: str) -> list[str]:
    with open(path, "r", errors="replace") as f:
        return f.readlines()


def get_related_logs(kpi_details: list[dict]) -> dict[str, list[str]]:
    """
    Returns { kpi_name: [matching log lines] } for each critical KPI.
    Tries real syslog first; falls back to dummy.
    """
    kpi_names = [k["kpi_name"] for k in kpi_details]

    # choose source
    if os.path.exists(SYSLOG_PATH):
        try:
            lines = _read_log_file(SYSLOG_PATH)
            logger.info("Reading real syslog from %s (%d lines)", SYSLOG_PATH, len(lines))
        except PermissionError:
            logger.warning("No permission to read %s – falling back to dummy", SYSLOG_PATH)
            lines = _read_log_file(DUMMY_LOG)
    else:
        logger.info("Syslog not found – using dummy log")
        lines = _read_log_file(DUMMY_LOG)

    matched: dict[str, list[str]] = {kpi: [] for kpi in kpi_names}

    for line in lines:
        line_lower = line.lower()
        for kpi in kpi_names:
            # match on kpi name (e.g. "cpu_usage" → "cpu") and variants
            keywords = [kpi.lower(), kpi.lower().replace("_", " "), kpi.split("_")[0].lower()]
            if any(kw in line_lower for kw in keywords):
                if len(matched[kpi]) < MAX_LINES_PER_KPI:
                    matched[kpi].append(line.strip())

    for kpi, logs in matched.items():
        logger.info("Found %d log lines for %s", len(logs), kpi)

    return matched
