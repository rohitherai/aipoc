# KB-GEN-001: Ubuntu Server General Health Checklist

**Domain:** GENERAL  
**Keywords:** health check, general diagnostics, ubuntu, first response, server health

## First Response — Any Alert

```bash
# 1. Overall system health
uptime && free -h && df -h

# 2. Top resource consumers
ps aux --sort=-%cpu | head -10
ps aux --sort=-%mem | head -10

# 3. Recent errors in syslog
sudo journalctl -xe --since "10 minutes ago" | grep -iE "error|fail|critical|kill"

# 4. Check all services
sudo systemctl --failed

# 5. Recent kernel messages
sudo dmesg | tail -30
```

## Quick Reference — Common Fixes

| Issue | Command |
|-------|---------|
| High CPU | `ps aux --sort=-%cpu \| head -5` then `sudo kill -15 <pid>` |
| High Memory | `sudo sysctl vm.swappiness=10` then find leak |
| High I/O | `sudo iotop -o` then find writing process |
| Service crashed | `sudo systemctl restart <name>` |
| Disk full | `du -sh /var/log/* \| sort -h \| tail -5` then clean |
| Network errors | `sudo ethtool -S eth0 \| grep -v ": 0"` |

## Escalation Path
- L1 → Check KB and attempt standard remediation (< 15 min)
- L2 → If issue persists or is P1 severity
- L3 → If root cause unknown or requires infrastructure change

**Owner:** NOC / SRE Team | **Last updated:** 2026-03-01
