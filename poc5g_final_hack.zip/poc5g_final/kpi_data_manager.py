"""
Dynamic KPI Data Manager
Handles loading KPI data from multiple sources: Grafana, files, or raw JSON
"""

import os
import json
import csv
import io
import logging
from typing import List, Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)

# Global cache for uploaded KPI data
_custom_kpi_data = None
_custom_kpi_source = None


def load_from_json_string(json_string: str) -> List[Dict[str, Any]]:
    """Parse JSON string containing KPI data."""
    try:
        data = json.loads(json_string)
        if isinstance(data, list):
            return data
        elif isinstance(data, dict):
            return [data]
        else:
            raise ValueError("JSON must be an object or array of objects")
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}")


def load_from_csv_string(csv_string: str) -> List[Dict[str, Any]]:
    """Parse CSV string containing KPI data."""
    try:
        lines = csv_string.strip().split('\n')
        reader = csv.DictReader(lines)
        data = []
        
        for row in reader:
            # Convert numeric values
            kpi = {}
            for key, value in row.items():
                if key.lower() in ['value', 'threshold']:
                    try:
                        kpi[key.lower()] = float(value)
                    except ValueError:
                        kpi[key.lower()] = value
                else:
                    kpi[key.lower()] = value
            data.append(kpi)
        
        return data
    except Exception as e:
        raise ValueError(f"Invalid CSV format: {e}")


def upload_kpi_data(file_content: str, file_type: str) -> Dict[str, Any]:
    """
    Upload custom KPI data from file content.
    
    Args:
        file_content: File content as string
        file_type: "json" or "csv"
    
    Returns:
        Dict with status and loaded data
    """
    global _custom_kpi_data, _custom_kpi_source
    
    try:
        if file_type.lower() == "json":
            data = load_from_json_string(file_content)
        elif file_type.lower() == "csv":
            data = load_from_csv_string(file_content)
        else:
            return {
                "status": "error",
                "message": f"Unsupported file type: {file_type}. Use 'json' or 'csv'"
            }
        
        # Validate KPI data structure
        for i, kpi in enumerate(data):
            if "kpi_name" not in kpi:
                return {
                    "status": "error",
                    "message": f"KPI #{i} missing 'kpi_name' field"
                }
            if "value" not in kpi:
                return {
                    "status": "error",
                    "message": f"KPI #{i} missing 'value' field"
                }
            if "threshold" not in kpi:
                return {
                    "status": "error",
                    "message": f"KPI #{i} missing 'threshold' field"
                }
        
        # Store custom data
        _custom_kpi_data = data
        _custom_kpi_source = "custom_upload"
        
        logger.info(f"✅ Loaded {len(data)} KPIs from custom upload ({file_type})")
        
        return {
            "status": "success",
            "message": f"Successfully loaded {len(data)} KPIs",
            "kpi_count": len(data),
            "kpis": data[:3]  # Return first 3 for preview
        }
    
    except Exception as e:
        logger.error(f"KPI upload failed: {e}")
        return {
            "status": "error",
            "message": str(e)
        }


def get_custom_kpi_data() -> tuple[List[Dict[str, Any]], str]:
    """
    Get custom uploaded KPI data if available.
    
    Returns:
        (data, source) where data is list of KPIs or None, source describes origin
    """
    global _custom_kpi_data, _custom_kpi_source
    return _custom_kpi_data, _custom_kpi_source


def clear_custom_kpi_data() -> Dict[str, Any]:
    """Clear stored custom KPI data and revert to default sources."""
    global _custom_kpi_data, _custom_kpi_source
    _custom_kpi_data = None
    _custom_kpi_source = None
    logger.info("✅ Cleared custom KPI data, reverting to default sources")
    return {"status": "success", "message": "Custom KPI data cleared"}


def get_kpi_data_with_fallback():
    """
    Get KPI data in priority order:
    1. Custom uploaded data
    2. Grafana (if configured)
    3. Dummy data
    """
    from grafana_agent import get_kpi_data as get_grafana_data
    
    # Priority 1: Custom uploaded data
    custom_data, source = get_custom_kpi_data()
    if custom_data:
        logger.info(f"Using custom uploaded KPI data ({len(custom_data)} KPIs)")
        return custom_data
    
    # Priority 2 & 3: Grafana or dummy (handled by get_kpi_data)
    return get_grafana_data()


def get_data_source_info() -> Dict[str, Any]:
    """Get information about current KPI data source."""
    custom_data, source = get_custom_kpi_data()
    
    if custom_data:
        return {
            "source": "custom_upload",
            "kpi_count": len(custom_data),
            "kpi_names": [kpi.get("kpi_name") for kpi in custom_data[:5]]
        }
    
    # Check Grafana
    grafana_url = os.getenv("GRAFANA_URL", "")
    if grafana_url:
        return {
            "source": "grafana",
            "url": grafana_url,
            "configured": True
        }
    
    return {
        "source": "dummy_data",
        "file": "data/dummy_kpis.json"
    }
