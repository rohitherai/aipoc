import logging
import sys
import json
import os
from dotenv import load_dotenv

# Fix encoding for Windows emoji output
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')
if sys.stderr.encoding != 'utf-8':
    sys.stderr.reconfigure(encoding='utf-8')

load_dotenv()

from config import AUTO_APPROVE
from pipeline_orchestrator import orchestrator, run_pipeline as run_orchestrated_pipeline, get_pipeline_stats

logger = logging.getLogger(__name__)


def get_user_approval(result: dict, index: int) -> bool:
    """
    Handle approval decision with auto-approve support.
    
    Args:
        result: The fix result containing approval details
        index: Index of this approval in the batch
        
    Returns:
        bool: True if approved, False otherwise
    """
    res = result
    kpi_name = res.get("kpi_name", "unknown")
    service = res.get("service", "unknown")
    root_cause = res.get("root_cause", "Unknown cause")
    fix_plan = res.get("fix_plan", {})
    
    print("\n" + "="*70)
    print(f"📋 APPROVAL REQUEST #{index + 1}")
    print("="*70)
    print(f"KPI Name:     {kpi_name}")
    print(f"Service:      {service}")
    print(f"Root Cause:   {root_cause[:100]}..." if len(str(root_cause)) > 100 else f"Root Cause:   {root_cause}")
    
    if isinstance(fix_plan, dict):
        actions = fix_plan.get("actions", [])
        if actions:
            print(f"\nProposed Fix Actions:")
            for i, action in enumerate(actions[:3], 1):  # Show first 3 actions
                print(f"  {i}. {action}")
            if len(actions) > 3:
                print(f"  ... and {len(actions) - 3} more actions")
    
    print("\n" + "-"*70)
    
    # ✨ AUTO APPROVAL FOR DEMO MODE
    if AUTO_APPROVE:
        print("✅ AUTO-APPROVED (Demo Mode - Set AUTO_APPROVE=False for manual approval)")
        print("⚙️  Execution simulated: success")
        return True
    
    # Manual approval for production
    while True:
        user_input = input("Do you approve this fix? (yes/no): ").strip().lower()
        
        if user_input in ["yes", "y"]:
            print("✅ Fix APPROVED - Proceeding with execution")
            return True
        elif user_input in ["no", "n"]:
            print("❌ Fix REJECTED - Skipping execution")
            return False
        else:
            print("⚠️  Invalid input. Please enter 'yes' or 'no'")


def run_pipeline() -> dict:
    result = run_orchestrated_pipeline()
    
    # ✨ APPROVAL DECISION & STORAGE
    # Handles both auto-approval (demo) and manual approval (production)
    if isinstance(result, dict) and result.get("results"):
        pending_count = sum(1 for res in result["results"] if res.get("approval_status") == "pending_approval")
        
        if pending_count > 0:
            if AUTO_APPROVE:
                print(f"\n🤖 AUTO-MODE: {pending_count} fix(es) will be auto-approved")
            else:
                print(f"\n🔔 ATTENTION: {pending_count} fix(es) awaiting approval")
            
        for idx, res in enumerate(result["results"]):
            if res.get("approval_status") == "pending_approval":
                # Get approval decision (auto or manual)
                approved = get_user_approval(res, idx)
                
                if approved:
                    result["results"][idx]["approval_status"] = "approved"
                    result["results"][idx]["execution_status"] = "success"
                    result["results"][idx] = orchestrator.post_approval_storage(result["results"][idx])
                    kpi_name = res.get("kpi_name", "unknown")
                    if AUTO_APPROVE:
                        logger.info("✅ Auto-approved fix for %s", kpi_name)
                    else:
                        logger.info("✅ User approved fix for %s", kpi_name)
                else:
                    result["results"][idx]["approval_status"] = "rejected"
                    result["results"][idx]["execution_status"] = "skipped"
                    result["results"][idx]["stored_in_memory"] = False
                    logger.warning("❌ Fix rejected for %s", res.get("kpi_name", "unknown"))
    
    if result.get("error"):
        logger.error("Pipeline failed: %s", result["error"])
    return result


def report_fix_outcome(kpi_name: str, service: str, host: str, success: bool):
    """
    Called externally (e.g., from validation endpoint) after a fix is applied.
    Outcomes are tracked in Pinecone vector DB for future analysis.
    """
    if success:
        logger.info("✅ Fix SUCCESS: %s/%s on %s", kpi_name, service, host)
    else:
        logger.warning("❌ Fix FAILURE: %s/%s on %s", kpi_name, service, host)


def load_kpi_data():
    """
    Load KPI data with fallback logic.
    Priority:
    1. Live KPI from real-time agent: data/live_kpi.json
    2. Fallback to dummy KPIs: data/dummy_kpis.json
    """
    live_kpi_path = os.path.join(os.getcwd(), "data", "live_kpi.json")
    dummy_kpi_path = os.path.join(os.getcwd(), "data", "dummy_kpis.json")
    
    # Try to load live KPI data first
    if os.path.exists(live_kpi_path):
        try:
            with open(live_kpi_path, 'r') as f:
                kpis = json.load(f)
                print(f"\n📡 Loaded live KPI from: {live_kpi_path}")
                print(f"📊 KPI Data: {kpis}")
                return kpis
        except Exception as e:
            logger.warning(f"Failed to load live KPI: {e}. Falling back to dummy data.")
    
    # Fallback to dummy KPI data
    if os.path.exists(dummy_kpi_path):
        try:
            with open(dummy_kpi_path, 'r') as f:
                kpis = json.load(f)
                print(f"\n📦 Using dummy KPI data from: {dummy_kpi_path}")
                return kpis
        except Exception as e:
            logger.error(f"Failed to load dummy KPI data: {e}")
            return None
    
    logger.error(f"No KPI data found at {live_kpi_path} or {dummy_kpi_path}")
    return None


if __name__ == "__main__":
    import json
    print(json.dumps(run_pipeline(), indent=2))
