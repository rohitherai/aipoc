#!/usr/bin/env python3
"""
Local Vector Cache - File-based fallback when Pinecone is unreachable.
Stores embeddings locally and provides fast-path matching without network calls.
"""

import os
import json
import hashlib
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger(__name__)

class LocalVectorCache:
    """
    File-based vector cache that stores embeddings locally.
    Provides fast-path matching similar to Pinecone, but without network dependency.
    """
    
    def __init__(self, cache_dir: str = "vector_cache"):
        self.cache_dir = cache_dir
        self.cache_file = os.path.join(cache_dir, "vectors.jsonl")
        self.index_file = os.path.join(cache_dir, "index.json")
        self.vectors = {}
        self.index = {}
        
        # Create cache directory
        os.makedirs(cache_dir, exist_ok=True)
        
        # Load existing cache
        self._load_cache()
        
        print(f"[LocalCache] Initialized: {len(self.vectors)} vectors in cache")
    
    def _load_cache(self):
        """Load vectors from local cache file."""
        if not os.path.exists(self.cache_file):
            return
        
        try:
            with open(self.cache_file, 'r') as f:
                for line in f:
                    if line.strip():
                        entry = json.loads(line)
                        vector_id = entry.get("id")
                        self.vectors[vector_id] = entry
        except Exception as e:
            logger.error(f"Failed to load cache: {e}")
    
    def _save_cache(self):
        """Save vectors to local cache file."""
        try:
            with open(self.cache_file, 'w') as f:
                for entry in self.vectors.values():
                    f.write(json.dumps(entry) + '\n')
        except Exception as e:
            logger.error(f"Failed to save cache: {e}")
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        if len(vec1) != len(vec2):
            return 0.0
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = sum(a ** 2 for a in vec1) ** 0.5
        magnitude2 = sum(b ** 2 for b in vec2) ** 0.5
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    def store(self, vector_id: str, embedding: List[float], metadata: Dict[str, Any]) -> bool:
        """Store a vector with metadata."""
        try:
            self.vectors[vector_id] = {
                "id": vector_id,
                "values": embedding,
                "metadata": metadata
            }
            self._save_cache()
            print(f"[LocalCache] Stored vector: {vector_id}")
            return True
        except Exception as e:
            logger.error(f"Store failed: {e}")
            return False
    
    def search(self, embedding: List[float], topk: int = 1, threshold: float = 0.85) -> List[Dict]:
        """Search for similar vectors."""
        if not self.vectors:
            return []
        
        similarities = []
        for vector_id, entry in self.vectors.items():
            stored_embedding = entry.get("values", [])
            similarity = self._cosine_similarity(embedding, stored_embedding)
            if similarity >= threshold:
                similarities.append((vector_id, similarity, entry))
        
        # Sort by similarity (descending)
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        # Return top-k results
        results = []
        for vector_id, similarity, entry in similarities[:topk]:
            results.append({
                "id": vector_id,
                "score": similarity,
                "metadata": entry.get("metadata", {})
            })
        
        print(f"[LocalCache] Search found {len(results)} matches (threshold={threshold:.2f})")
        return results
    
    def get_stats(self) -> Dict:
        """Get cache statistics."""
        return {
            "total_vectors": len(self.vectors),
            "cache_file": self.cache_file,
            "cache_size_mb": os.path.getsize(self.cache_file) / (1024 * 1024) if os.path.exists(self.cache_file) else 0
        }


# Usage in vector_db_wrapper
if __name__ == "__main__":
    # Test
    cache = LocalVectorCache()
    
    # Store test vector
    test_embedding = [0.1, 0.2, 0.3] + [0.0] * 381  # 384 dims
    cache.store(
        "test_1",
        test_embedding,
        {"kpi_name": "TEST", "service": "test"}
    )
    
    # Search
    query_embedding = [0.11, 0.21, 0.31] + [0.0] * 381
    results = cache.search(query_embedding, threshold=0.85)
    print(f"Search results: {results}")
    
    # Stats
    print(f"Stats: {cache.get_stats()}")
