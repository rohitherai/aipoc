#!/usr/bin/env python3
"""
🚀 Quick Dashboard Setup Script
Just run this to get the dashboard running on localhost:5000
"""

import os
import sys
from pathlib import Path

def check_python():
    """Verify Python version"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print("❌ Python 3.7+ required. You have:", f"{version.major}.{version.minor}")
        return False
    print(f"✅ Python {version.major}.{version.minor} detected")
    return True

def check_flask():
    """Check if Flask is installed"""
    try:
        import flask
        print("✅ Flask is installed")
        return True
    except ImportError:
        print("⚠️  Flask not found. Installing...")
        os.system("pip install flask")
        print("✅ Flask installed")
        return True

def check_files():
    """Verify required files exist"""
    if not os.path.exists('gui_dashboard.js'):
        print("❌ gui_dashboard.js not found in current directory")
        return False
    print("✅ gui_dashboard.js found")
    return True

def create_server():
    """Create Flask server script"""
    server_code = '''#!/usr/bin/env python3
"""
5G AIOps Dashboard Server
Serves the React dashboard component at http://localhost:5000
"""

from flask import Flask, render_template_string
import os

app = Flask(__name__)

# HTML template with embedded React
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5G AIOps Dashboard</title>
    <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Roboto, sans-serif; overflow: hidden; }
    </style>
</head>
<body>
    <div id="root"></div>
    
    <script type="text/babel">
        // 5G AIOps Dashboard Component
        (function() {
''' + open('gui_dashboard.js', 'r').read() + '''
        
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(<App />);
        })();
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/health')
def health():
    return {"status": "ok", "service": "5G AIOps Dashboard"}

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 5G AIOps Dashboard Starting...")
    print("=" * 60)
    print()
    print("📊 Dashboard URL: http://localhost:5000")
    print()
    print("Instructions:")
    print("  1. Open browser and go to: http://localhost:5000")
    print("  2. Click on RED KPI cards to trigger pipeline demo")
    print("  3. Watch the 7-stage pipeline execute")
    print("  4. Approve the fix proposal when modal appears")
    print()
    print("Press Ctrl+C to stop the server")
    print("=" * 60)
    print()
    
    app.run(debug=False, port=5000, host='0.0.0.0')
'''
    
    with open('dashboard_server.py', 'w') as f:
        f.write(server_code)
    print("✅ Created dashboard_server.py")

def start_server():
    """Start the Flask server"""
    print()
    print("🎯 Starting dashboard server...")
    print("📂 Current directory:", os.getcwd())
    print()
    os.system("python dashboard_server.py")

def main():
    print("=" * 60)
    print("  5G AIOps Dashboard - Quick Setup")
    print("=" * 60)
    print()
    
    # Check Python
    if not check_python():
        sys.exit(1)
    
    # Check files
    if not check_files():
        sys.exit(1)
    
    # Check Flask
    if not check_flask():
        sys.exit(1)
    
    print()
    print("✅ All checks passed!")
    print()
    
    # Create server
    if not os.path.exists('dashboard_server.py'):
        create_server()
    else:
        print("✅ dashboard_server.py already exists")
    
    print()
    print("=" * 60)
    print("  Ready to start dashboard!")
    print("=" * 60)
    print()
    
    # Start
    start_server()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Dashboard stopped by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)
