"""
kb_search.py — Knowledge Base Search Engine
============================================
Reads all KB articles from knowledge_base/ folder (MD, TXT, PDF, DOCX).
Uses TF-IDF keyword matching to find the best article for a given KPI/fault.

Usage:
    from kb_search import KnowledgeBase
    kb = KnowledgeBase()
    result = kb.search("CPU_Usage spike soft lockup", domain="SYSTEM")
    if result:
        print(result["source"])       # "knowledge_base"
        print(result["root_cause"])
        print(result["remediation"])
"""

import logging
import math
import os
import re
from typing import Dict, List, Optional

log = logging.getLogger("kb_search")

KB_DIR           = os.path.join(os.path.dirname(__file__), "knowledge_base")
SCORE_THRESHOLD  = 0.30   # min relevance score to count as a KB hit


# ── Text extraction helpers ───────────────────────────────────────────────────

def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()

def _read_pdf(path: str) -> str:
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            return "\n".join(p.extract_text() or "" for p in pdf.pages)
    except Exception as e:
        log.warning("PDF read error %s: %s", path, e)
        return ""

def _read_docx(path: str) -> str:
    try:
        import docx
        return "\n".join(p.text for p in docx.Document(path).paragraphs)
    except Exception as e:
        log.warning("DOCX read error %s: %s", path, e)
        return ""

def extract_text(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".md", ".txt"):  return _read_text(path)
    if ext == ".pdf":           return _read_pdf(path)
    if ext in (".docx", ".doc"): return _read_docx(path)
    return ""


# ── TF-IDF helpers ────────────────────────────────────────────────────────────

STOPWORDS = {
    "the","a","an","and","or","is","in","to","of","for","on","at","by","with",
    "this","that","it","are","was","be","as","from","not","if","we","you",
    "will","can","set","use","check","add","get","run","also","more","each",
}

def _tokenize(text: str) -> List[str]:
    tokens = re.findall(r"[a-zA-Z0-9_\-]{2,}", text.lower())
    return [t for t in tokens if t not in STOPWORDS]

def _term_freq(tokens: List[str]) -> Dict[str, float]:
    tf: Dict[str, float] = {}
    for t in tokens:
        tf[t] = tf.get(t, 0) + 1
    n = len(tokens) or 1
    return {t: c / n for t, c in tf.items()}


# ── KB Article ────────────────────────────────────────────────────────────────

class KBArticle:
    def __init__(self, path: str, domain: str):
        self.path   = path
        self.domain = domain
        self.title  = os.path.splitext(os.path.basename(path))[0]
        self.raw    = extract_text(path)
        self.tokens = _tokenize(self.raw)
        self.tf     = _term_freq(self.tokens)

        # Clean summary (strip markdown symbols)
        clean = re.sub(r"[#*`|\\-]{1,}", " ", self.raw)
        clean = re.sub(r"\s+", " ", clean).strip()
        self.summary = clean[:900]

        # Extract key sections
        self.root_cause  = self._extract_section(
            r"root cause", r"(immediate|symptoms|long.term|remediation|steps)")
        self.remediation = self._extract_section(
            r"(immediate remediation|remediation steps|quick fix|immediate steps)",
            r"(long.term|prevention|runbook|owner|last updated|related)")

    def _extract_section(self, start_re: str, end_re: str) -> str:
        lines = self.raw.splitlines()
        capturing, result = False, []
        for line in lines:
            if re.search(start_re, line, re.IGNORECASE):
                capturing = True
                continue
            if capturing:
                if re.search(end_re, line, re.IGNORECASE) and result:
                    break
                result.append(line)
        return "\n".join(result).strip()[:700]


# ── Knowledge Base ─────────────────────────────────────────────────────────────

class KnowledgeBase:
    def __init__(self, kb_dir: str = KB_DIR):
        self.articles: List[KBArticle] = []
        self._idf: Dict[str, float]    = {}
        self._load(kb_dir)
        self._build_idf()
        log.info("KB loaded: %d articles", len(self.articles))

    def _load(self, kb_dir: str):
        if not os.path.isdir(kb_dir):
            log.warning("KB dir not found: %s", kb_dir)
            return
        for domain_dir in os.listdir(kb_dir):
            dp = os.path.join(kb_dir, domain_dir)
            if not os.path.isdir(dp):
                continue
            for fname in os.listdir(dp):
                fp = os.path.join(dp, fname)
                if os.path.isfile(fp):
                    try:
                        art = KBArticle(fp, domain_dir.upper())
                        if art.raw:
                            self.articles.append(art)
                    except Exception as e:
                        log.warning("KB load error %s: %s", fp, e)

    def _build_idf(self):
        N = len(self.articles) or 1
        doc_count: Dict[str, int] = {}
        for art in self.articles:
            for term in set(art.tokens):
                doc_count[term] = doc_count.get(term, 0) + 1
        self._idf = {t: math.log(N / (c + 1)) + 1 for t, c in doc_count.items()}

    def _score(self, q_tokens: List[str], art: KBArticle) -> float:
        q_tf  = _term_freq(q_tokens)
        dot   = q_norm = d_norm = 0.0
        for term in set(q_tf) | set(art.tf):
            idf   = self._idf.get(term, 1.0)
            q_val = q_tf.get(term, 0) * idf
            d_val = art.tf.get(term, 0) * idf
            dot   += q_val * d_val
            q_norm += q_val ** 2
            d_norm += d_val ** 2
        denom = math.sqrt(q_norm) * math.sqrt(d_norm)
        return dot / denom if denom else 0.0

    def search(self, query: str, domain: Optional[str] = None) -> Optional[Dict]:
        """
        Search KB for best matching article.
        Returns a result dict or None if no match above threshold.
        """
        if not self.articles:
            return None
        q_tokens = _tokenize(query)
        if not q_tokens:
            return None

        scored = []
        for art in self.articles:
            s = self._score(q_tokens, art)
            # Boost domain-matched articles by 30%
            if domain and art.domain == domain:
                s *= 1.3
            # Always include GENERAL domain articles in search
            scored.append((s, art))

        scored.sort(key=lambda x: x[0], reverse=True)
        best_score, best = scored[0]

        if best_score < SCORE_THRESHOLD:
            log.info("KB MISS (best=%.3f) for: %s", best_score, query[:80])
            return None

        log.info("KB HIT '%s' [%s] score=%.3f", best.title, best.domain, best_score)
        return {
            "title":        best.title,
            "domain":       best.domain,
            "score":        round(best_score, 3),
            "root_cause":   best.root_cause   or best.summary[:400],
            "remediation":  best.remediation  or best.summary[:400],
            "summary":      best.summary,
            "source":       "knowledge_base",
        }

    def get_stats(self) -> Dict:
        from collections import Counter
        return {
            "total":     len(self.articles),
            "by_domain": dict(Counter(a.domain for a in self.articles)),
            "articles":  [{"title": a.title, "domain": a.domain} for a in self.articles],
        }
