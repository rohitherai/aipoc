"""
Agent 1: Grafana KPI Fetcher
- Tries to connect to a real Grafana instance using env vars
- Falls back to dummy data if not configured
"""

import json
import os
import logging

import requests

logger = logging.getLogger(__name__)

# ── Grafana config from environment ──────────────────────────────────────────
GRAFANA_URL   = os.getenv("GRAFANA_URL", "")          # e.g. http://localhost:3000
GRAFANA_TOKEN = os.getenv("GRAFANA_TOKEN", "")        # Service-account token
GRAFANA_DS_UID = os.getenv("GRAFANA_DS_UID", "")      # Prometheus datasource UID

# ── Prometheus queries for 5G PoC KPIs ───────────────────────────────────
KPI_QUERIES = {
    "SMF_CPU_Usage":              '100 - (avg by(instance)(rate(node_cpu_seconds_total{job="smf"}[5m])) * 100)',
    "UPF_Memory_Usage":           '(1 - (node_memory_MemAvailable_bytes{job="upf"} / node_memory_MemTotal_bytes{job="upf"})) * 100',
    "PFCP_Errors":                'sum by(instance)(rate(pfcp_errors_total[5m]))',
    "GTP_Packet_Loss":            'sum by(instance)(rate(gtp_packet_loss_total[5m]))',
    "NRF_Connection_Latency":     'histogram_quantile(0.95, sum(rate(nrf_connection_latency_seconds_bucket[5m])) by (le, instance))',
    "AUSF_Auth_Failures":         'sum by(instance)(rate(ausf_auth_failures_total[5m]))',
    "CPU_Usage":                  '100 - (avg by(instance)(rate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)',
    "Memory_Usage":               '(1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100',
}

THRESHOLDS = {
    "SMF_CPU_Usage":              70,
    "UPF_Memory_Usage":           80,
    "PFCP_Errors":                10,
    "GTP_Packet_Loss":            2,
    "NRF_Connection_Latency":     0.25,
    "AUSF_Auth_Failures":         5,
    "CPU_Usage":                  80,
    "Memory_Usage":               85,
}


def _fetch_from_grafana() -> list[dict]:
    """Query Grafana Prometheus datasource for each KPI."""
    headers = {"Authorization": f"Bearer {GRAFANA_TOKEN}", "Content-Type": "application/json"}
    results = []

    for kpi_name, query in KPI_QUERIES.items():
        url = f"{GRAFANA_URL}/api/ds/query"
        payload = {
            "queries": [{
                "datasourceId": GRAFANA_DS_UID,
                "expr": query,
                "instant": True,
                "refId": "A"
            }],
            "from": "now-5m",
            "to":   "now"
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=5)
        resp.raise_for_status()
        data = resp.json()

        for frame in data.get("results", {}).get("A", {}).get("frames", []):
            for series in frame.get("data", {}).get("values", []):
                if isinstance(series, list) and series:
                    value = float(series[-1]) if series[-1] is not None else 0.0
                    host  = frame.get("schema", {}).get("fields", [{}])[0].get("labels", {}).get("instance", "unknown")
                    results.append({
                        "kpi_name":  kpi_name,
                        "value":     round(value, 2),
                        "threshold": THRESHOLDS.get(kpi_name, 100),
                        "host":      host,
                        "timestamp": "live"
                    })
    return results


def _load_dummy_data() -> list[dict]:
    dummy_path = os.path.join(os.path.dirname(__file__), "data", "dummy_kpis.json")
    with open(dummy_path, "r") as f:
        return json.load(f)


def get_kpi_data() -> list[dict]:
    """
    Returns a list of KPI records.
    Uses Grafana API if GRAFANA_URL + GRAFANA_TOKEN are set, else dummy data.
    """
    if GRAFANA_URL and GRAFANA_TOKEN and GRAFANA_DS_UID:
        try:
            logger.info("Fetching KPIs from Grafana at %s", GRAFANA_URL)
            return _fetch_from_grafana()
        except Exception as exc:
            logger.warning("Grafana fetch failed (%s) – falling back to dummy data", exc)

    logger.info("Using dummy KPI data")
    return _load_dummy_data()
