@echo off
REM ========================================
REM 5G AIOps Dashboard - Quick Start Script
REM ========================================

echo.
echo ╔════════════════════════════════════════════╗
echo ║  5G AIOps Fault Remediation Dashboard     ║
echo ║  Professional Demonstration Suite         ║
echo ╚════════════════════════════════════════════╝
echo.

REM Check if virtual environment exists
if not exist .\.venv (
    echo ❌ Virtual environment not found!
    echo Please run setup first:
    echo   python -m venv .venv
    echo   .\.venv\Scripts\activate.ps1
    exit /b 1
)

echo ✓ Virtual environment found
echo.

REM Activate virtual environment
call .\.venv\Scripts\activate.bat

echo ✓ Virtual environment activated
echo.

REM Check if Flask is installed
python -c "import flask" >nul 2>&1
if %errorlevel% neq 0 (
    echo ⚠️  Flask not found. Installing dependencies...
    pip install flask >/dev/null 2>&1
    if %errorlevel% equ 0 (
        echo ✓ Flask installed
    ) else (
        echo ❌ Failed to install Flask
        exit /b 1
    )
)

echo.
echo ════════════════════════════════════════════
echo Launching AIOps Dashboard...
echo ════════════════════════════════════════════
echo.
echo 🌐 Dashboard will be available at:
echo    http://localhost:5000/
echo.
echo 📊 API Endpoints:
echo    - POST  /api/inject-fault  - Run fault analysis
echo    - GET   /api/cache-status  - Check cache metrics
echo    - GET   /api/dashboard     - Dashboard data
echo.
echo Press Ctrl+C to stop the server
echo.
echo ════════════════════════════════════════════
echo.

REM Start the server
python dashboard_server.py

pause
