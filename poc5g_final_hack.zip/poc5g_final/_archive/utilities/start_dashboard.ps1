#!/usr/bin/env powershell
<#
.SYNOPSIS
    5G AIOps Fault Remediation Dashboard - Quick Start
.DESCRIPTION
    Launches the professional executive dashboard for POC demonstrations
.NOTES
    Date: May 27, 2026
    Version: 1.0
#>

param(
    [switch]$Web = $false,  # Default: Launch server
    [int]$Port = 5000
)

Write-Host ""
Write-Host "╔════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  5G AIOps Fault Remediation Dashboard     ║" -ForegroundColor Cyan
Write-Host "║  Professional Demonstration Suite         ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Check if in correct directory
if (-not (Test-Path "dashboard_pro.html")) {
    Write-Host "❌ Dashboard files not found!" -ForegroundColor Red
    Write-Host "Please ensure you're in the AI_POC_5G_V1 directory" -ForegroundColor Yellow
    exit 1
}

Write-Host "✓ Dashboard files found" -ForegroundColor Green

# Check virtual environment
if (-not (Test-Path ".\.venv")) {
    Write-Host "❌ Virtual environment not found!" -ForegroundColor Red
    Write-Host "Please create it first:" -ForegroundColor Yellow
    Write-Host "  python -m venv .venv" -ForegroundColor Yellow
    exit 1
}

Write-Host "✓ Virtual environment found" -ForegroundColor Green
Write-Host ""

# Activate virtual environment
& ".\.venv\Scripts\Activate.ps1"
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Virtual environment activated" -ForegroundColor Green
} else {
    Write-Host "⚠️  Could not activate virtual environment" -ForegroundColor Yellow
}

Write-Host ""

# Option 1: Just open HTML in browser (no server)
if ($Web) {
    Write-Host "🌐 Opening dashboard in browser..." -ForegroundColor Green
    Write-Host "   File: dashboard_pro.html" -ForegroundColor Cyan
    Write-Host ""
    
    $filePath = Resolve-Path "dashboard_pro.html"
    Start-Process $filePath
    
    Write-Host "✓ Dashboard opened!" -ForegroundColor Green
    Write-Host ""
    Write-Host "📌 Features:" -ForegroundColor Yellow
    Write-Host "   • Click on a fault scenario (left panel)" -ForegroundColor Cyan
    Write-Host "   • Click 'Start Analysis' to begin" -ForegroundColor Cyan
    Write-Host "   • Watch pipeline execute in real-time" -ForegroundColor Cyan
    Write-Host "   • View cache hits vs misses" -ForegroundColor Cyan
    Write-Host ""
    exit 0
}

# Option 2: Start Flask server with real data
Write-Host "════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "Launching AIOps Dashboard Server..." -ForegroundColor Green
Write-Host "════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

Write-Host "🌐 Dashboard will be available at:" -ForegroundColor Green
Write-Host "   http://localhost:$Port/" -ForegroundColor Cyan
Write-Host ""

Write-Host "📊 API Endpoints:" -ForegroundColor Yellow
Write-Host "   - POST  /api/inject-fault  - Run fault analysis" -ForegroundColor Cyan
Write-Host "   - GET   /api/cache-status  - Check cache metrics" -ForegroundColor Cyan
Write-Host "   - GET   /api/dashboard     - Dashboard data" -ForegroundColor Cyan
Write-Host "   - GET   /api/analyze       - Run pipeline" -ForegroundColor Cyan
Write-Host ""

Write-Host "🎯 Demo Scenarios:" -ForegroundColor Yellow
Write-Host "   1. Throughput Collapse - DEEP PATH (full analysis)" -ForegroundColor Cyan
Write-Host "   2. Latency Spike - FAST PATH (cache hit - 300x faster!)" -ForegroundColor Cyan
Write-Host "   3. Memory Leak - DEEP PATH (new scenario)" -ForegroundColor Cyan
Write-Host ""

Write-Host "💡 Pro Tips:" -ForegroundColor Yellow
Write-Host "   • Show Scenario 2 first (impressive cache hit)" -ForegroundColor Cyan
Write-Host "   • Then show Scenario 1 (full capability)" -ForegroundColor Cyan
Write-Host "   • Emphasize 300-2000x speed improvement" -ForegroundColor Cyan
Write-Host "   • Highlight self-learning capability" -ForegroundColor Cyan
Write-Host ""

Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""
Write-Host "════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Start Flask server
python dashboard_server.py
