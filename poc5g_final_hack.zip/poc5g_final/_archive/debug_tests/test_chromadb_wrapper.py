#!/usr/bin/env python3
"""
Quick test script for ChromaDB vector_db_wrapper.
Tests basic functionality: initialization, store, search.
"""

import sys
import json
from datetime import datetime

# Add current directory to path
sys.path.insert(0, '.')

from vector_db_wrapper import VectorDBWrapper

def test_chromadb_wrapper():
    """Test ChromaDB wrapper basic functionality."""
    
    print("=" * 70)
    print("ChromaDB Vector Wrapper Test Suite")
    print("=" * 70)
    
    # Test 1: Initialization
    print("\n[Test 1] Initialization")
    print("-" * 70)
    db = VectorDBWrapper()
    
    if db.use_mock:
        print("⚠️  VectorDB in mock mode (ChromaDB not available)")
        return False
    
    if db.client and db.collection:
        print(f"✅ ChromaDB initialized successfully")
        print(f"   - Client: {db.client}")
        print(f"   - Collection: kpi_memory")
        print(f"   - Current docs: {db.collection.count()}")
    else:
        print("❌ ChromaDB initialization failed")
        return False
    
    # Test 2: Store without embeddings (backward compatibility)
    print("\n[Test 2] Store without embeddings")
    print("-" * 70)
    
    kpi_1 = {
        "kpi_name": "CPU_UTILIZATION_HIGH",
        "timestamp": datetime.now().isoformat(),
        "host": "smf-pod-01",
        "service": "SMF"
    }
    
    store_data_1 = {
        "kpi": kpi_1,
        "service": "SMF",
        "root_cause": "Memory leak in worker process consuming 95% RAM",
        "fix": {
            "step1": "Restart service container",
            "step2": "Check for resource leaks",
            "step3": "Monitor for recurrence"
        }
    }
    
    result = db.store(store_data_1)
    if result:
        print(f"✅ Store without embeddings: SUCCESS")
        print(f"   - KPI: {kpi_1['kpi_name']}")
        print(f"   - Service: SMF")
        print(f"   - Collection docs: {db.collection.count()}")
    else:
        print(f"❌ Store without embeddings: FAILED")
        return False
    
    # Test 3: Store with placeholder embeddings
    print("\n[Test 3] Store with embeddings (simulated)")
    print("-" * 70)
    
    # Simulate embedding (real usage: from Azure/OpenAI API)
    simulated_embedding = [0.1 * (i % 10) for i in range(384)]
    
    kpi_2 = {
        "kpi_name": "DISK_IO_HIGH",
        "timestamp": datetime.now().isoformat(),
        "host": "upf-pod-02",
        "service": "UPF"
    }
    
    store_data_2 = {
        "kpi": kpi_2,
        "service": "UPF",
        "root_cause": "High disk I/O due to excessive logging",
        "fix": {
            "step1": "Reduce logging level",
            "step2": "Archive old logs",
            "step3": "Monitor disk usage"
        }
    }
    
    result = db.store(store_data_2, embeddings=simulated_embedding)
    if result:
        print(f"✅ Store with embeddings: SUCCESS")
        print(f"   - KPI: {kpi_2['kpi_name']}")
        print(f"   - Service: UPF")
        print(f"   - Embedding dims: {len(simulated_embedding)}")
        print(f"   - Collection docs: {db.collection.count()}")
    else:
        print(f"❌ Store with embeddings: FAILED")
        return False
    
    # Test 4: Search without embeddings
    print("\n[Test 4] Search without embeddings")
    print("-" * 70)
    
    search_kpi = {"kpi_name": "CPU_UTILIZATION_HIGH", "service": "SMF"}
    result = db.search(search_kpi)
    
    if result is None:
        print(f"✅ Search without embeddings: CORRECT (returns None as expected)")
        print(f"   - Reason: No embeddings provided (caller must generate)")
    else:
        print(f"⚠️  Search returned unexpected result: {result}")
    
    # Test 5: Search with embeddings
    print("\n[Test 5] Search with embeddings (simulated)")
    print("-" * 70)
    
    # Use a similar embedding (won't match - just testing the mechanism)
    search_embedding = [0.1 * (i % 10) for i in range(384)]
    
    search_kpi = {"kpi_name": "CPU_UTILIZATION_HIGH", "service": "SMF"}
    result = db.search(search_kpi, query_embeddings=search_embedding)
    
    if result is None:
        print(f"✅ Search with embeddings: Completed")
        print(f"   - Result: None (no high-confidence match found)")
        print(f"   - Reason: Embeddings differ, similarity <= 0.85 threshold")
    elif isinstance(result, dict):
        print(f"✅ Search with embeddings: MATCH FOUND!")
        print(f"   - Score: {result.get('score', 0):.4f}")
        print(f"   - Root cause: {result.get('root_cause', '')[:50]}...")
        fix_data = result.get('fix', {})
        # fix is already a dict (parsed by wrapper)
        fix_steps = fix_data if isinstance(fix_data, dict) else {}
        print(f"   - Fix steps: {len(fix_steps)} actions")
    else:
        print(f"❌ Search returned invalid result: {result}")
        return False
    
    # Test 6: Query collection
    print("\n[Test 6] Verify collection persistence")
    print("-" * 70)
    
    # Get all documents
    all_docs = db.collection.get(include=["metadatas", "documents"])
    
    if all_docs and len(all_docs["ids"]) > 0:
        print(f"✅ Collection persistence: SUCCESS")
        print(f"   - Total documents: {len(all_docs['ids'])}")
        for i, doc_id in enumerate(all_docs["ids"]):
            metadata = all_docs["metadatas"][i]
            print(f"   [{i+1}] {doc_id}")
            print(f"       └─ KPI: {metadata.get('kpi_name', 'N/A')}")
            print(f"       └─ Service: {metadata.get('service', 'N/A')}")
            print(f"       └─ Timestamp: {metadata.get('timestamp', 'N/A')[:19]}")
    else:
        print(f"❌ Collection persistence: FAILED (no documents found)")
        return False
    
    print("\n" + "=" * 70)
    print("✅ All tests completed successfully!")
    print("=" * 70)
    print("\nNext steps:")
    print("1. Run full pipeline: python main.py")
    print("2. Verify data persistence in chroma_db/ directory")
    print("3. Monitor vector_db logs for fast-path hits")
    print("4. (Optional) Integrate embedding service for better search")
    print("\n")
    
    return True


if __name__ == "__main__":
    try:
        success = test_chromadb_wrapper()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
