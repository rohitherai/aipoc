import requests

# 🔴 Replace with your actual Pinecone host
url = "https://kpi-index-c2y8jh7.svc.aped-4627-b74a.pinecone.io/query"

headers = {
    "Api-Key": "PAj75Tdrtn9n6F6bSdVEo9v85zh1dijp62GvGoGv",
    "Content-Type": "application/json"
}

data = {
    "vector": [0.1] * 8,
    "topK": 1,
    "includeMetadata": True
}

try:
    response = requests.post(url, headers=headers, json=data, timeout=10)

    print("\n=== TEST RESULT ===")
    print("Status Code:", response.status_code)
    print("Content-Type:", response.headers.get("Content-Type"))

    print("\n--- Response (first 300 chars) ---")
    print(response.text[:300])

    # ✅ Critical validation
    if "application/json" in response.headers.get("Content-Type", ""):
        print("\n✅ SUCCESS: Connected to Pinecone API")
    else:
        print("\n❌ FAILURE: Response is NOT JSON")
        print("❌ Likely intercepted by corporate proxy (e.g., ZScaler)")

except Exception as e:
    print("\n❌ ERROR:", str(e))