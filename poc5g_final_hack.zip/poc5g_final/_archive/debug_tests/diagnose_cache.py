#!/usr/bin/env python3
"""
🔍 CACHE DIAGNOSTICS SCRIPT
Debugs why cache similarity scores are low
Shows what's stored and what's being searched
"""

import os
import json
import sys
from vector_db_wrapper import VectorDBWrapper

def diagnose_cache():
    print("\n" + "="*80)
    print("🔍 CACHE DIAGNOSTICS - Debugging Low Similarity Scores")
    print("="*80)
    
    # Initialize vector DB
    print("\n1️⃣  Initializing ChromaDB...")
    vdb = VectorDBWrapper()
    
    if not vdb.client or not vdb.collection:
        print("❌ Failed to initialize ChromaDB")
        return
    
    # Check collection size
    print("\n2️⃣  Checking cache contents...")
    try:
        collection_data = vdb.collection.get(include=["embeddings", "documents", "metadatas"])
        total_records = len(collection_data.get("ids", []))
        print(f"✅ Total records in cache: {total_records}")
        
        if total_records == 0:
            print("\n⚠️  Cache is EMPTY - nothing to search!")
            print("📋 Next steps:")
            print("   1. Run main.py to generate initial cache data")
            print("   2. Approve the first run so it stores to ChromaDB")
            print("   3. Run this diagnostic again")
            return
        
        print("\n📊 Cache Contents:")
        print("-" * 80)
        
        for i, record_id in enumerate(collection_data.get("ids", []), 1):
            metadata = collection_data["metadatas"][i-1]
            doc = collection_data.get("documents", [""])[i-1]
            embedding = None
            if collection_data.get("embeddings") is not None:
                try:
                    embedding = collection_data.get("embeddings")[i-1] if len(collection_data.get("embeddings", [])) >= i else []
                except:
                    embedding = []
            
            print(f"\n📦 Record {i}/{total_records}:")
            print(f"   ID: {record_id}")
            print(f"   Document: {doc}")
            print(f"   KPI Name: {metadata.get('kpi_name', 'N/A')}")
            print(f"   Service: {metadata.get('service', 'N/A')}")
            print(f"   Timestamp: {metadata.get('timestamp', 'N/A')}")
            
            if embedding:
                try:
                    print(f"   Embedding dims: {len(embedding)}")
                    print(f"   Embedding preview (first 5 values): {embedding[:5]}")
                except:
                    print(f"   Embedding: [unable to display]")
            
            root_cause = metadata.get('root_cause_summary', '')
            if root_cause:
                print(f"   Root Cause: {root_cause[:100]}...")
            
            fix_actions = metadata.get('fix_actions', '{}')
            try:
                fix_parsed = json.loads(fix_actions) if isinstance(fix_actions, str) else fix_actions
                print(f"   Fix Actions: {len(fix_parsed)} actions")
            except:
                print(f"   Fix Actions: [parse error]")
    
    except Exception as e:
        print(f"❌ Error reading cache: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # Test search with current KPI
    print("\n3️⃣  Testing search with sample KPI...")
    print("-" * 80)
    
    test_kpi = {
        "kpi_name": "SMF_CPU_Usage",
        "service": "smf",
        "host": "unknown",
        "threshold": 80.0,
        "current_value": 95.0
    }
    
    print(f"Searching for: {test_kpi['kpi_name']} (service: {test_kpi['service']})")
    
    # Build embedding text
    embedding_text = vdb._build_embedding_text(test_kpi, test_kpi['service'])
    print(f"Embedding text: '{embedding_text}'")
    
    # Get embedding
    test_embedding = vdb._get_embedding(embedding_text)
    print(f"Generated embedding dims: {len(test_embedding)}")
    print(f"Embedding preview (first 5): {test_embedding[:5]}")
    
    # Search
    print("\n🔎 Querying ChromaDB...")
    try:
        results = vdb.collection.query(
            query_embeddings=[test_embedding],
            n_results=3,  # Get top 3 results
            include=["embeddings", "documents", "metadatas", "distances"]
        )
        
        if results and results.get("ids") and len(results["ids"]) > 0 and len(results["ids"][0]) > 0:
            print(f"✅ Found {len(results['ids'][0])} results:")
            
            for i, match_id in enumerate(results["ids"][0]):
                distance = results["distances"][0][i]
                score = 1 - distance
                doc = results["documents"][0][i]
                metadata = results["metadatas"][0][i]
                stored_embedding = results["embeddings"][0][i] if results.get("embeddings") else []
                
                print(f"\n   Result {i+1}:")
                print(f"   Match ID: {match_id}")
                print(f"   Distance: {distance:.6f}")
                print(f"   Similarity Score: {score:.6f}")
                print(f"   Document: {doc}")
                print(f"   Threshold (current): 0.3")
                
                if score >= 0.3:
                    print(f"   ✅ WOULD PASS (>= 0.3)")
                else:
                    print(f"   ❌ TOO LOW (< 0.3)")
                
                if stored_embedding:
                    print(f"   Stored embedding (first 5): {stored_embedding[:5]}")
                    print(f"   Query embedding (first 5): {test_embedding[:5]}")
                    
                    # Compare first few values
                    diff = sum(abs(a - b) for a, b in zip(stored_embedding[:5], test_embedding[:5]))
                    print(f"   Difference in first 5 values: {diff:.6f}")
        else:
            print("❌ No results found")
    
    except Exception as e:
        print(f"❌ Search failed: {e}")
        import traceback
        traceback.print_exc()
    
    # Recommendations
    print("\n" + "="*80)
    print("💡 RECOMMENDATIONS")
    print("="*80)
    
    print("""
1. EMBEDDING CONSISTENCY:
   ✓ Make sure the same KPI names are used in store() and search()
   ✓ Verify service names match (case-sensitive)
   ✓ Check if embedding API is working correctly
   
2. IF EMBEDDINGS ARE DIFFERENT:
   • Scores will be naturally low
   • Need to verify embedding generation is consistent
   • Check: CAPGEMINI_GENAI_API_KEY environment variable
   • Check: EMBEDDING_BASE_URL environment variable
   
3. IF EMBEDDINGS ARE SAME:
   • But scores still low, the KPIs might be genuinely different
   • Consider what the cache is for:
     - Same KPI name + service = should match
     - Different thresholds/values = shouldn't matter
   
4. NEXT STEPS:
   • Run: python main.py (to generate new cache data)
   • Approve the solution (stores to ChromaDB)
   • Run: python diagnose_cache.py (to verify what was stored)
   • Check if similarity improves on next run

5. TO VIEW CURRENT SETTINGS:
   • Threshold: 0.3 (DEBUG MODE - lowered from 0.65)
   • Embedding model: Check config.py or .env
   • ChromaDB path: ./chroma_db/
""")
    
    print("="*80)

if __name__ == "__main__":
    diagnose_cache()
