#!/usr/bin/env python3
"""
Diagnostic script to check Pinecone index status and data.
"""

import os
import requests
import json
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("PINECONE_API_KEY")
INDEX_HOST = os.getenv("PINECONE_INDEX_HOST")

print("=" * 70)
print("🔍 PINECONE DIAGNOSTIC REPORT")
print("=" * 70)

print("\n[1] Configuration")
print("-" * 70)
print(f"API Key: {'✅ Found' if API_KEY else '❌ Missing'}")
print(f"Index Host: {INDEX_HOST}")

if not API_KEY or not INDEX_HOST:
    print("❌ Missing configuration. Cannot proceed.")
    exit(1)

print("\n[2] Index Stats (Describe Index)")
print("-" * 70)

try:
    headers = {"Api-Key": API_KEY, "Content-Type": "application/json"}
    
    # Try describe endpoint to get index info
    response = requests.get(
        f"{INDEX_HOST.rstrip('/').rsplit('/', 1)[0]}/describe_index_stats",
        headers=headers,
        timeout=10,
        verify=False
    )
    
    print(f"Response Status: {response.status_code}")
    print(f"Response: {response.text}")
    
    if response.status_code == 200:
        stats = response.json()
        total_count = stats.get("total_vector_count", 0)
        namespaces = stats.get("namespaces", {})
        print(f"\n✅ Index Statistics:")
        print(f"   Total vectors: {total_count}")
        print(f"   Namespaces: {list(namespaces.keys())}")
        for ns, data in namespaces.items():
            print(f"     - '{ns}': {data.get('vector_count', 0)} vectors")
    else:
        print("⚠️  Could not retrieve index stats")
        
except Exception as e:
    print(f"❌ Error: {e}")

print("\n[3] Vector Query (Search for SMF_CPU_Usage)")
print("-" * 70)

try:
    # Create a test embedding (384 dims)
    test_embedding = [0.1] * 384
    
    headers = {"Api-Key": API_KEY, "Content-Type": "application/json"}
    payload = {
        "vector": test_embedding,
        "topK": 10,
        "includeMetadata": True
    }
    
    response = requests.post(
        f"{INDEX_HOST}/query",
        headers=headers,
        json=payload,
        timeout=10,
        verify=False
    )
    
    print(f"Query Status: {response.status_code}")
    
    if response.status_code == 200:
        results = response.json()
        matches = results.get("matches", [])
        print(f"✅ Query successful!")
        print(f"   Matches found: {len(matches)}")
        if matches:
            print(f"\n   Top matches:")
            for i, match in enumerate(matches[:3], 1):
                print(f"\n   [{i}] ID: {match.get('id')}")
                print(f"       Score: {match.get('score', 0):.4f}")
                meta = match.get("metadata", {})
                print(f"       KPI: {meta.get('kpi_name', 'N/A')}")
                print(f"       Service: {meta.get('service', 'N/A')}")
        else:
            print("   ⚠️  No vectors found in index!")
    else:
        print(f"❌ Query failed: {response.status_code}")
        print(f"   Response: {response.text[:200]}")
        
except Exception as e:
    print(f"❌ Error during query: {e}")

print("\n[4] Upsert Test (Store test vector)")
print("-" * 70)

try:
    test_id = "TEST_VECTOR_001"
    test_embedding = [0.2] * 384
    
    headers = {"Api-Key": API_KEY, "Content-Type": "application/json"}
    payload = {
        "vectors": [
            {
                "id": test_id,
                "values": test_embedding,
                "metadata": {
                    "kpi_name": "TEST_KPI",
                    "service": "test_service",
                    "root_cause_summary": "This is a test",
                    "fix_actions": "{'action': 'test'}",
                    "timestamp": "2026-05-25T20:00:00Z",
                    "host": "test-host"
                }
            }
        ]
    }
    
    response = requests.post(
        f"{INDEX_HOST}/vectors/upsert",
        headers=headers,
        json=payload,
        timeout=10,
        verify=False
    )
    
    print(f"Upsert Status: {response.status_code}")
    if response.status_code in [200, 201]:
        print(f"✅ Upsert successful!")
        print(f"   Vector ID: {test_id}")
        print(f"   Response: {response.text[:200]}")
    else:
        print(f"❌ Upsert failed: {response.status_code}")
        print(f"   Response: {response.text}")
        
except Exception as e:
    print(f"❌ Error during upsert: {e}")

print("\n[5] Index Configuration Details")
print("-" * 70)
print(f"Index Name: kpi-index")
print(f"Dimensions: 384")
print(f"Metric: cosine")
print(f"Host: {INDEX_HOST}")

print("\n" + "=" * 70)
print("Report Complete")
print("=" * 70)
