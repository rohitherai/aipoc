#!/usr/bin/env python3
"""
Diagnostic tool to check ChromaDB persistence issues in Flask UI.
Identifies why cache hits aren't working between runs.
"""

import os
import json
import shutil
from vector_db_wrapper import VectorDBWrapper
from datetime import datetime

def check_chroma_db_state():
    """Check if chroma_db folder exists and has data."""
    print("\n" + "="*70)
    print("CHROMADB PERSISTENCE DIAGNOSTIC")
    print("="*70)
    
    chroma_path = os.path.join(os.getcwd(), "chroma_db")
    
    print(f"\n1. DATABASE FOLDER STATE")
    print(f"   Path: {chroma_path}")
    print(f"   Exists: {os.path.exists(chroma_path)}")
    
    if os.path.exists(chroma_path):
        files = []
        for root, dirs, filenames in os.walk(chroma_path):
            for f in filenames:
                files.append(os.path.join(root, f))
        print(f"   Total files: {len(files)}")
        print(f"   Files:")
        for f in files[:10]:  # Show first 10
            rel_path = f.replace(chroma_path, ".")
            size_kb = os.path.getsize(f) / 1024
            print(f"      {rel_path} ({size_kb:.1f} KB)")
    else:
        print("   ⚠️  Database folder missing! Will be created on next store()")
    
    print(f"\n2. DATABASE INSTANCE CHECK")
    db = VectorDBWrapper()
    print(f"   VectorDB initialized: {db.client is not None}")
    print(f"   Using mock mode: {db.use_mock}")
    
    if db.collection:
        count = db.collection.count()
        print(f"   Collection 'kpi_memory' document count: {count}")
        
        if count > 0:
            print(f"   ✅ Database has data!")
        else:
            print(f"   ⚠️  Database is empty (no cached KPIs)")
    
    return db, chroma_path

def test_embedding_consistency():
    """Test if embeddings are consistent for the same KPI."""
    print(f"\n3. EMBEDDING CONSISTENCY TEST")
    print("   Checking if same KPI generates consistent embeddings...\n")
    
    db = VectorDBWrapper()
    kpi_name = "TEST_CONSISTENCY_CHECK"
    
    # Generate embedding twice for same KPI
    print(f"   Generating embedding 1 for '{kpi_name}'...")
    embedding1 = db._get_embedding(kpi_name)
    print(f"   Vector size: {len(embedding1)} dimensions")
    print(f"   First 5 values: {embedding1[:5]}")
    
    print(f"\n   Generating embedding 2 for '{kpi_name}'...")
    embedding2 = db._get_embedding(kpi_name)
    print(f"   First 5 values: {embedding2[:5]}")
    
    # Compare
    if embedding1 == embedding2:
        print(f"\n   ✅ CONSISTENT: Same KPI generates identical embeddings")
        return True
    else:
        # Check similarity
        from numpy import dot
        from numpy.linalg import norm
        
        similarity = dot(embedding1, embedding2) / (norm(embedding1) * norm(embedding2))
        print(f"\n   ⚠️  DIFFERENT: Embeddings are different!")
        print(f"      Cosine similarity: {similarity:.4f}")
        
        if similarity < 0.85:
            print(f"      ❌ PROBLEM: Score {similarity:.4f} < 0.85 threshold!")
            print(f"      This explains why cache hits fail!")
            return False
        else:
            print(f"      ✓ Score {similarity:.4f} would still trigger cache hit")
            return True

def test_store_and_search():
    """Test storing and searching in same process."""
    print(f"\n4. STORE AND SEARCH TEST (Same Process)")
    
    db = VectorDBWrapper()
    
    # Store a test KPI
    test_data = {
        "kpi": {
            "kpi_name": "TEST_STORE_SEARCH",
            "timestamp": str(datetime.now()),
            "host": "test-host"
        },
        "service": "TEST_SERVICE",
        "root_cause": "Test root cause for diagnostic",
        "fix": {"action": "test_fix"}
    }
    
    print(f"   Storing test KPI: {test_data['kpi']['kpi_name']}")
    store_result = db.store(test_data)
    print(f"   Store result: {store_result}")
    
    # Search immediately
    print(f"\n   Searching for same KPI (in same process)...")
    search_result = db.search(test_data["kpi"])
    
    if search_result:
        print(f"   ✅ FOUND in cache!")
        print(f"      Score: {search_result['score']:.4f}")
        print(f"      Root cause match: {search_result['root_cause'][:50]}...")
        return True
    else:
        print(f"   ❌ NOT FOUND in cache!")
        print(f"      This would cause DEEP PATH on second run")
        return False

def test_restart_simulation():
    """Simulate Flask restart: create new DB instance and search."""
    print(f"\n5. RESTART SIMULATION TEST (New Instance)")
    
    print(f"   Creating NEW VectorDBWrapper instance (simulating Flask restart)...")
    new_db = VectorDBWrapper()
    
    print(f"   Checking collection doc count...")
    count = new_db.collection.count() if new_db.collection else 0
    print(f"   Documents in collection: {count}")
    
    if count == 0:
        print(f"   ⚠️  Database is empty!")
        print(f"      Data wasn't persisted from previous test")
        return False
    
    test_kpi = {"kpi_name": "TEST_STORE_SEARCH"}
    print(f"\n   Searching for 'TEST_STORE_SEARCH' from first test...")
    search_result = new_db.search(test_kpi)
    
    if search_result:
        print(f"   ✅ FOUND after restart!")
        print(f"      Score: {search_result['score']:.4f}")
        print(f"      Persistence verified!")
        return True
    else:
        print(f"   ❌ NOT FOUND after restart!")
        print(f"      Data wasn't persisted properly")
        return False

def test_flask_api_simulation():
    """Simulate Flask API calls."""
    print(f"\n6. FLASK API CALL SIMULATION")
    
    from pipeline_orchestrator import PipelineOrchestrator
    
    print(f"   Simulating first /api/analyze call...")
    orchestrator1 = PipelineOrchestrator()
    result1 = orchestrator1.run_pipeline()
    
    # Check if any fast-path hits
    if result1.get("fast_path_results"):
        print(f"   ✅ First call result: FAST PATH hit!")
    else:
        print(f"   - First call result: DEEP PATH (expected for new KPIs)")
    
    print(f"\n   Simulating second /api/analyze call (same KPIs)...")
    print(f"   (Creating new orchestrator instance, like Flask would)")
    orchestrator2 = PipelineOrchestrator()
    result2 = orchestrator2.run_pipeline()
    
    # Check if fast-path hits on second call
    fast_paths = len(result2.get("fast_path_results", []))
    deep_paths = len(result2.get("results", []))
    
    print(f"   Second call result: {fast_paths} fast-path, {deep_paths} deep-path")
    
    if fast_paths > 0:
        print(f"   ✅ CACHE WORKING! Fast-path hit on second run")
        return True
    else:
        print(f"   ❌ CACHE NOT WORKING! All DEEP PATH again")
        print(f"      This is the issue you're seeing in the UI")
        return False

def main():
    print("\n🔍 Diagnosing ChromaDB persistence issues...\n")
    
    results = {}
    
    try:
        db, chroma_path = check_chroma_db_state()
        results["Database State"] = "✅ OK" if os.path.exists(chroma_path) else "⚠️ Missing"
    except Exception as e:
        print(f"❌ Error checking DB state: {e}")
        results["Database State"] = "❌ Error"
    
    try:
        results["Embedding Consistency"] = "✅ OK" if test_embedding_consistency() else "❌ PROBLEM"
    except Exception as e:
        print(f"❌ Error testing embeddings: {e}")
        results["Embedding Consistency"] = "❌ Error"
    
    try:
        results["Store & Search (Same Process)"] = "✅ OK" if test_store_and_search() else "❌ PROBLEM"
    except Exception as e:
        print(f"❌ Error in store/search: {e}")
        results["Store & Search"] = "❌ Error"
    
    try:
        results["Restart Simulation"] = "✅ OK" if test_restart_simulation() else "❌ PROBLEM"
    except Exception as e:
        print(f"❌ Error in restart test: {e}")
        results["Restart Simulation"] = "❌ Error"
    
    try:
        results["Flask API Simulation"] = "✅ OK" if test_flask_api_simulation() else "❌ PROBLEM"
    except Exception as e:
        print(f"❌ Error in Flask simulation: {e}")
        results["Flask API Simulation"] = "❌ Error"
    
    # Summary
    print(f"\n\n" + "="*70)
    print("DIAGNOSTIC SUMMARY")
    print("="*70)
    
    for test_name, result in results.items():
        print(f"{result}: {test_name}")
    
    failed = [t for t, r in results.items() if "PROBLEM" in r or "Error" in r]
    if failed:
        print(f"\n❌ Issues found in: {', '.join(failed)}")
        print(f"\nNext steps:")
        print(f"1. Check if Flask is deleting chroma_db folder between restarts")
        print(f"2. Verify embeddings are consistent (not random)")
        print(f"3. Check if pipeline is properly searching ChromaDB")
        return False
    else:
        print(f"\n✅ All tests passed! Persistence should be working.")
        print(f"   If still seeing DEEP PATH in UI, check Flask app state management.")
        return True

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)
