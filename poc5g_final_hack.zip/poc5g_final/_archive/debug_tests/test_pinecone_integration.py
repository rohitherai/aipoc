#!/usr/bin/env python
"""
Test script for Pinecone integration.
Verifies connection, embedding, storage, and retrieval.
"""

import os
import json
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_pinecone_integration():
    """Test all Pinecone integration components."""
    
    print("\n" + "="*60)
    print("🔍 PINECONE INTEGRATION TEST")
    print("="*60)
    
    # Test 1: Configuration
    print("\n[TEST 1] Configuration")
    print("-" * 40)
    
    api_key = os.getenv("PINECONE_API_KEY")
    index_host = os.getenv("PINECONE_INDEX_HOST")
    
    if not api_key:
        print("❌ PINECONE_API_KEY not found in .env")
        return False
    print(f"✅ API Key found: {api_key[:20]}...")
    
    if not index_host or "xxxxx" in index_host:
        print("⚠️  PINECONE_INDEX_HOST not properly configured")
        print("   Update .env with actual index host from https://app.pinecone.io/")
        return False
    print(f"✅ Index Host configured: {index_host}")
    
    # Test 2: Import VectorDBWrapper
    print("\n[TEST 2] Vector DB Wrapper Import")
    print("-" * 40)
    
    try:
        from vector_db_wrapper import VectorDBWrapper
        print("✅ VectorDBWrapper imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import VectorDBWrapper: {e}")
        return False
    
    # Test 3: Initialize connection
    print("\n[TEST 3] Pinecone Connection")
    print("-" * 40)
    
    try:
        vector_db = VectorDBWrapper()
        
        if vector_db.use_real:
            print("✅ Connected to real Pinecone")
            print(f"   Mode: Real (REST API)")
            print(f"   Host: {vector_db.index_host}")
        elif vector_db.use_mock:
            print("⚠️  Using mock Pinecone (fallback)")
            print("   Reason: Real connection unavailable")
            print("   → Data will be stored locally in memory")
            print("   → Fast-path caching will not work")
            return False
        else:
            print("❌ VectorDB not initialized")
            return False
            
    except Exception as e:
        print(f"❌ Failed to initialize VectorDBWrapper: {e}")
        return False
    
    # Test 4: Embedding generation
    print("\n[TEST 4] Embedding Generation (via API or Fallback)")
    print("-" * 40)
    
    try:
        test_text = "SMF_CPU_Usage"
        embedding = vector_db._get_embedding(test_text)
        print(f"✅ Generated embedding for: '{test_text}'")
        print(f"   Dimension: {len(embedding)}")
        print(f"   Method: {'Capgemini GenAI API (reduced to 384d)' if vector_db.openai_client else 'Local Hash (Fallback)'}")
        print(f"   Sample values: {[round(x, 4) for x in embedding[:3]]}")
    except Exception as e:
        print(f"❌ Embedding generation failed: {e}")
        return False
    
    # Test 5: Storage
    print("\n[TEST 5] Vector Storage")
    print("-" * 40)
    
    if vector_db.use_real:
        try:
            test_data = {
                "kpi": {
                    "kpi_name": "SMF_CPU_Usage",
                    "value": 78,
                    "threshold": 70,
                    "host": "smf-core-01",
                    "timestamp": "2026-05-25T14:00:00Z"
                },
                "service": "smf",
                "root_cause": "Session surge causing CPU saturation",
                "fix": {
                    "actions": ["Increase SMF capacity", "Rate limit sessions"],
                    "severity": "high"
                }
            }
            
            success = vector_db.store(test_data)
            if success:
                print("✅ Successfully stored test data in Pinecone")
            else:
                print("⚠️  Storage returned False (check logs above)")
                
        except Exception as e:
            print(f"❌ Storage failed: {e}")
            return False
    else:
        print("⚠️  Skipping storage test (using mock mode)")
    
    # Test 6: Search/Retrieval
    print("\n[TEST 6] Vector Search")
    print("-" * 40)
    
    if vector_db.use_real:
        try:
            test_kpi = {
                "kpi_name": "SMF_CPU_Usage",
                "service": "smf"
            }
            
            result = vector_db.search(test_kpi)
            if result:
                print("✅ Found cached result in Pinecone")
                print(f"   Score: {result.get('score', 0):.2f}")
                if result.get('root_cause'):
                    print(f"   Has cached RCA: Yes")
                if result.get('fix'):
                    print(f"   Has cached fix: Yes")
            else:
                print("ℹ️  No matching result found (expected if first run)")
                print("   → Run pipeline first to populate cache")
                
        except Exception as e:
            print(f"❌ Search failed: {e}")
            return False
    else:
        print("⚠️  Skipping search test (using mock mode)")
    
    # Summary
    print("\n" + "="*60)
    print("📊 TEST SUMMARY")
    print("="*60)
    
    if vector_db.use_real:
        print("""
✅ All tests passed!

Next steps:
1. Run the pipeline: python server.py
2. Open GUI: http://localhost:5000/poc
3. Click "Run Pipeline" to analyze KPIs
4. First run: Full analysis (slow, populates cache)
5. Subsequent runs: Fast-path from cache (fast!)

Monitor the console for:
- [FAST-PATH] = Cached result used (fast)
- [ANALYSIS] = Deep path analysis (slow)

Expected behavior:
- Run 1: All deep-path (no cache)
- Run 2: Some fast-path (cache hits)
- Run 3+: Increasing fast-path hits
        """)
        return True
    else:
        print("""
⚠️  Running in mock mode (Pinecone unavailable)

To enable real Pinecone caching:
1. Verify PINECONE_API_KEY in .env
2. Get your index host: https://app.pinecone.io/
3. Update PINECONE_INDEX_HOST in .env
4. Restart the application

For now, the system works but:
- ❌ Cache is stored in memory only
- ❌ Will be lost on restart
- ❌ No fast-path optimization
        """)
        return False

if __name__ == "__main__":
    success = test_pinecone_integration()
    exit(0 if success else 1)
