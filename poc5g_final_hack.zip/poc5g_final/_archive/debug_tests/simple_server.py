#!/usr/bin/env python
"""
Minimal Flask server to test dashboard serving
"""
from flask import Flask, send_file
import os

app = Flask(__name__)

# Get the directory where this script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

@app.route('/')
def index():
    """Serve the new unified dashboard UI"""
    dashboard_path = os.path.join(SCRIPT_DIR, 'hackathon_demo.html')
    if not os.path.exists(dashboard_path):
        dashboard_path = os.path.join(SCRIPT_DIR, 'unified_dashboard.html')

    if not os.path.exists(dashboard_path):
        return f"<h1>404 - Not found</h1><p>{dashboard_path}</p>", 404

    return send_file(dashboard_path, mimetype='text/html', max_age=0)

if __name__ == '__main__':
    dashboard_path = os.path.join(SCRIPT_DIR, 'hackathon_demo.html')
    if not os.path.exists(dashboard_path):
        dashboard_path = os.path.join(SCRIPT_DIR, 'unified_dashboard.html')

    print("\n" + "="*70)
    print("🚀 SIMPLE SERVER STARTING")
    print("="*70)
    print(f"Script directory: {SCRIPT_DIR}")
    print(f"Dashboard file: {dashboard_path}")
    print(f"File exists: {os.path.exists(dashboard_path)}")
    print("\nServer running on: http://localhost:5000/")
    print("="*70 + "\n")

    app.run(host='0.0.0.0', port=5000, debug=False)
