#!/usr/bin/env python3
"""
Debug script to diagnose proxy/firewall issues and test Pinecone connectivity.
"""

import os
import requests
import json
from dotenv import load_dotenv
import urllib3

# Disable warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

load_dotenv()

API_KEY = os.getenv("PINECONE_API_KEY")
INDEX_HOST = os.getenv("PINECONE_INDEX_HOST")

print("=" * 70)
print("🔧 PROXY & CONNECTIVITY DIAGNOSTIC")
print("=" * 70)

print(f"\n[1] Environment")
print(f"Pinecone Host: {INDEX_HOST}")
print(f"API Key: {API_KEY[:20]}..." if API_KEY else "Missing")

print(f"\n[2] Direct Test to Pinecone (no verification)")
print("-" * 70)

try:
    headers = {
        "Api-Key": API_KEY,
        "Content-Type": "application/json",
        "User-Agent": "Python-VectorDB-Client"
    }
    
    # Test with different headers to bypass proxy
    response = requests.post(
        f"{INDEX_HOST}/query",
        headers=headers,
        json={"vector": [0.1] * 384, "topK": 1},
        timeout=10,
        verify=False,
        allow_redirects=False
    )
    
    print(f"Status: {response.status_code}")
    print(f"Headers: {dict(response.headers)}")
    print(f"Response starts with: {response.text[:100]}")
    
    # Check if it's HTML (proxy)
    if "<!DOCTYPE" in response.text or "<html" in response.text.lower():
        print("\n❌ ISSUE DETECTED: Response is HTML (Proxy/Firewall Interception)")
        print("   The Pinecone endpoint is being intercepted by ZScaler or similar proxy")
        print("\n   Possible solutions:")
        print("   1. Add Pinecone IP to proxy whitelist")
        print("   2. Use VPN/bypass proxy")
        print("   3. Request network team to whitelist Pinecone domain")
        print("   4. Use Pinecone serverless compute endpoint (if available)")
    elif response.status_code == 200:
        try:
            data = response.json()
            print(f"✅ Pinecone is accessible!")
            print(f"   Response is valid JSON")
            print(f"   Matches: {len(data.get('matches', []))}")
        except:
            print(f"❌ Invalid JSON response from Pinecone")
    else:
        print(f"⚠️  Unexpected status code: {response.status_code}")
        
except requests.exceptions.ConnectionError as e:
    print(f"❌ Connection Error: {e}")
except requests.exceptions.Timeout:
    print(f"❌ Timeout: Connection took too long")
except Exception as e:
    print(f"❌ Error: {e}")

print(f"\n[3] Proxy Detection")
print("-" * 70)

# Check for proxy environment variables
proxy_env_vars = ["HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY"]
found_proxy = False

for var in proxy_env_vars:
    value = os.getenv(var)
    if value:
        print(f"✓ {var}={value}")
        found_proxy = True

if not found_proxy:
    print("No explicit proxy environment variables found")
    print("(May be using system/OS-level proxy)")

print(f"\n[4] Recommendations")
print("-" * 70)

print("""
If you're hitting a proxy/firewall:

Option A - Use Local Vector DB (Development):
  - Switch to SQLite-based vector storage
  - Use: USE_VECTOR_DB=False in config
  - Perfect for demos and testing

Option B - Configure Proxy Bypass:
  - Contact your network team
  - Request whitelisting for: kpi-index-*.svc.*.pinecone.io
  - Or use VPN for Pinecone access

Option C - Use Alternative Embedding:
  - Store embeddings locally instead of Pinecone
  - Use file-based cache instead of vector DB
  - Modified vector_db_wrapper to use local JSON cache

Recommendation for NOW:
  - Continue with mock/fallback embeddings
  - System still works perfectly
  - Cache will use hash-based embeddings (always available)
  - Next run will still check Pinecone, but won't break if unreachable
""")

print("=" * 70)
