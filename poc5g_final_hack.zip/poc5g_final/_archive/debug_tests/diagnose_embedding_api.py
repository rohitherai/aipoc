#!/usr/bin/env python
"""
Diagnostic: Compare Embedding API vs LLM API calls
Shows exact URLs, headers, and error responses
"""

import os
import sys
import json
import requests
from dotenv import load_dotenv

# Load .env
load_dotenv()

# Configuration
CAPGEMINI_API_KEY = os.getenv("CAPGEMINI_GENAI_API_KEY", "your_capgemini_api_key_here")
EMBEDDING_BASE_URL = os.getenv("EMBEDDING_BASE_URL", "https://openai.generative.engine.capgemini.com/v1")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")

# LLM Configuration
CAPGEMINI_LLM_URL = "https://openai.generative.engine.capgemini.com/v1/chat/completions"
CAPGEMINI_LLM_MODEL = "anthropic.claude-sonnet-4-6"

print("="*80)
print("🔍 CAPGEMINI API DIAGNOSTIC")
print("="*80)

print("\n1️⃣  CONFIGURATION STATUS")
print("-" * 80)
print(f"✓ CAPGEMINI_GENAI_API_KEY present: {bool(CAPGEMINI_API_KEY and CAPGEMINI_API_KEY != 'your_capgemini_api_key_here')}")
print(f"✓ EMBEDDING_BASE_URL: {EMBEDDING_BASE_URL}")
print(f"✓ EMBEDDING_MODEL: {EMBEDDING_MODEL}")
print(f"✓ LLM URL: {CAPGEMINI_LLM_URL}")

print("\n2️⃣  LLM API CALL (WORKING)")
print("-" * 80)
llm_headers = {
    "Authorization": f"Bearer {CAPGEMINI_API_KEY}",
    "Content-Type": "application/json"
}
llm_payload = {
    "model": CAPGEMINI_LLM_MODEL,
    "messages": [
        {"role": "system", "content": "You are an AI assistant."},
        {"role": "user", "content": "Hello"}
    ],
    "temperature": 0.2
}

print(f"URL: {CAPGEMINI_LLM_URL}")
print(f"Method: POST")
print(f"Headers: {json.dumps(llm_headers, indent=2)}")
print(f"Payload: {json.dumps(llm_payload, indent=2)}")

if CAPGEMINI_API_KEY != "your_capgemini_api_key_here":
    print("\n📡 Testing LLM API...")
    try:
        response = requests.post(CAPGEMINI_LLM_URL, headers=llm_headers, json=llm_payload, timeout=10)
        print(f"✓ Status Code: {response.status_code}")
        if response.status_code == 200:
            print(f"✓ Response: SUCCESS")
            print(f"✓ Content: {response.json()['choices'][0]['message']['content'][:100]}...")
        else:
            print(f"✗ Response: {response.status_code}")
            print(f"✗ Error: {response.text[:200]}")
    except Exception as e:
        print(f"✗ Exception: {str(e)}")

print("\n3️⃣  EMBEDDING API CALL (VIA OpenAI CLIENT)")
print("-" * 80)
embedding_url_full = f"{EMBEDDING_BASE_URL}/embeddings"
embedding_headers = {
    "Authorization": f"Bearer {CAPGEMINI_API_KEY}",
    "Content-Type": "application/json"
}
embedding_payload = {
    "input": "test KPI",
    "model": EMBEDDING_MODEL
}

print(f"URL: {embedding_url_full}")
print(f"Method: POST")
print(f"Headers: {json.dumps(embedding_headers, indent=2)}")
print(f"Payload: {json.dumps(embedding_payload, indent=2)}")

if CAPGEMINI_API_KEY != "your_capgemini_api_key_here":
    print("\n📡 Testing Embedding API (Direct HTTP)...")
    try:
        response = requests.post(embedding_url_full, headers=embedding_headers, json=embedding_payload, timeout=10)
        print(f"✓ Status Code: {response.status_code}")
        if response.status_code == 200:
            print(f"✓ Response: SUCCESS")
            data = response.json()
            if 'data' in data and len(data['data']) > 0:
                embedding = data['data'][0].get('embedding', [])
                print(f"✓ Embedding dimensions: {len(embedding)}")
                print(f"✓ First 5 values: {embedding[:5]}")
        else:
            print(f"✗ Response: {response.status_code}")
            print(f"✗ Error: {response.text[:500]}")
    except Exception as e:
        print(f"✗ Exception: {str(e)}")

print("\n4️⃣  EMBEDDING API CALL (VIA OpenAI CLIENT LIBRARY)")
print("-" * 80)

try:
    from openai import OpenAI
    
    print(f"Initializing OpenAI client with:")
    print(f"  - base_url: {EMBEDDING_BASE_URL}")
    print(f"  - api_key: {CAPGEMINI_API_KEY[:10]}...{CAPGEMINI_API_KEY[-10:]}")
    
    client = OpenAI(base_url=EMBEDDING_BASE_URL, api_key=CAPGEMINI_API_KEY)
    
    if CAPGEMINI_API_KEY != "your_capgemini_api_key_here":
        print("\n📡 Testing Embedding API (OpenAI Client)...")
        try:
            response = client.embeddings.create(input="test KPI", model=EMBEDDING_MODEL)
            embedding = response.data[0].embedding
            print(f"✓ Status: SUCCESS")
            print(f"✓ Embedding dimensions: {len(embedding)}")
            print(f"✓ First 5 values: {embedding[:5]}")
        except Exception as e:
            print(f"✗ Error: {str(e)}")
            print(f"✗ Type: {type(e).__name__}")
            import traceback
            print(f"✗ Traceback:\n{traceback.format_exc()}")
    else:
        print("⚠️  Skipping OpenAI client test - API key is placeholder")
        
except ImportError:
    print("✗ OpenAI library not installed")

print("\n5️⃣  KEY DIFFERENCES")
print("-" * 80)
print("""
✓ LLM Endpoint: /v1/chat/completions
✓ Embedding Endpoint: /v1/embeddings

✓ LLM Model: anthropic.claude-sonnet-4-6
✓ Embedding Model: amazon.titan-embed-text-v2:0

✓ LLM Request: Direct requests.post()
✓ Embedding Request: OpenAI client library wrapper

POTENTIAL ISSUES:
- Embedding model name might be wrong for this API
- Embedding endpoint might have different format
- API key might not have embedding permissions
- Response format might be different
""")

print("\n" + "="*80)
print("Run with actual API key in .env to see full diagnostics")
print("="*80)
