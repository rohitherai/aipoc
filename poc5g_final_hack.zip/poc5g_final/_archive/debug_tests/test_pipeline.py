#!/usr/bin/env python
"""Test script to verify refactored AIOps pipeline flow"""

import os
import sys

# Fix encoding for Windows console
os.environ['PYTHONIOENCODING'] = 'utf-8'
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

os.environ['CAPGEMINI_GENAI_API_KEY'] = 'PAj75Tdrtn9n6F6bSdVEo9v85zh1dijp62GvGoGv'

from pipeline_orchestrator import run_pipeline

print("\n" + "="*60)
print("TESTING REFACTORED AIIOPS PIPELINE")
print("="*60)

result = run_pipeline()

print("\n" + "="*60)
print("PIPELINE RESULTS SUMMARY")
print("="*60)
print("KPIs Processed: {}".format(result['kpis_processed']))
print("Fast Path Hits: {}".format(result['pipeline_stats']['fast_path_hits']))
print("Deep Path Hits: {}".format(result['pipeline_stats']['deep_path_hits']))
print("Processing Time: {}s".format(result['processing_time_seconds']))

if result.get('error'):
    print("ERROR: {}".format(result['error']))
else:
    print("[OK] Pipeline executed successfully")
    
    # Show result breakdown
    for i, res in enumerate(result['results'], 1):
        kpi_name = res.get('kpi_name', 'unknown')
        service = res.get('service', 'unknown')
        path = res.get('path', 'unknown')
        approval = res.get('approval_status', 'unknown')
        execution = res.get('execution_status', 'unknown')
        
        print("\n[{}] {} ({})".format(i, kpi_name, service))
        print("    Path: {} | Approval: {} | Execution: {}".format(path, approval, execution))

print("\n" + "="*60)
