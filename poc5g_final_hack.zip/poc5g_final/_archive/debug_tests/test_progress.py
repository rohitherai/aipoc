#!/usr/bin/env python
"""Quick test to show progress tracking in action"""

import os
import sys

# Set environment variable for LLM
os.environ['CAPGEMINI_GENAI_API_KEY'] = 'PAj75Tdrtn9n6F6bSdVEo9v85zh1dijp62GvGoGv'

# Fix encoding for Windows console
os.environ['PYTHONIOENCODING'] = 'utf-8'
if sys.stdout:
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except:
        pass

from pipeline_orchestrator import run_pipeline

print("\n" + "=" * 70)
print("PROGRESS TRACKING TEST")
print("=" * 70)

# Run pipeline - this will print progress in real-time
result = run_pipeline()

print("\n" + "=" * 70)
print("PROGRESS LOG SUMMARY")
print("=" * 70)

if result.get('progress_logs'):
    print(f"\nTotal log entries: {len(result['progress_logs'])}\n")
    for i, log in enumerate(result['progress_logs'], 1):
        print(f"  {i:2d}. {log}")
else:
    print("No progress logs found")

print("\n" + "=" * 70)
print("RESULTS SUMMARY")
print("=" * 70)
print(f"Processing time: {result.get('processing_time_seconds', 0)}s")
print(f"KPIs processed: {result.get('kpis_processed', 0)}")
print(f"Fast path hits: {result.get('pipeline_stats', {}).get('fast_path_hits', 0)}")
print(f"Deep path hits: {result.get('pipeline_stats', {}).get('deep_path_hits', 0)}")
print(f"Results returned: {len(result.get('results', []))}")

# Show first result if available
if result.get('results'):
    print(f"\nFirst KPI Result:")
    first = result['results'][0]
    print(f"  KPI: {first.get('kpi_name')}")
    print(f"  Service: {first.get('service')}")
    print(f"  Path: {first.get('path')}")
    print(f"  Approval: {first.get('approval_status')}")
    print(f"  Execution: {first.get('execution_status')}")

print("\n" + "=" * 70)
