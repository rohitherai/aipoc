"""
Flask API — OpsBot v5
Serves chatbot UI + all pipeline endpoints including memory stats.
"""

import os
import logging
from flask import Flask, jsonify, request, send_from_directory, send_file
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

from main         import run_pipeline, report_fix_outcome
from kb_search    import KnowledgeBase
from service_fixer import propose_fix
from kb_writer_agent import KBWriterAgent
from history_agent import HistoryAgent
from approval_agent import approve_fix
from approval_executor_agent import ApprovalExecutorAgent
import json

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)

app    = Flask(__name__, static_folder=".")
CORS(app)
_kb    = KnowledgeBase()   # pre-load KB at startup


@app.route("/")
def index():
    if os.path.exists("hackathon_demo.html"):
        return send_file("hackathon_demo.html", mimetype='text/html', max_age=0)
    if os.path.exists("unified_dashboard.html"):
        return send_file("unified_dashboard.html", mimetype='text/html', max_age=0)
    return "<h1>404 - Dashboard file not found</h1>", 404


@app.route("/api/analyze", methods=["GET"])
def analyze():
    try:
        result = run_pipeline()
        return jsonify(result)
    except Exception as exc:
        logging.exception("Pipeline error")
        return jsonify({"status": "error", "message": str(exc)}), 500


# ── Memory Agent endpoints ────────────────────────────────────────────────────

@app.route("/api/memory/stats", methods=["GET"])
def memory_stats():
    """
    Vector DB stats (Pinecone).
    Shows resolution cache status.
    """
    return jsonify({
        "status": "ok",
        "vector_db": "pinecone",
        "message": "Using Pinecone for resolution caching"
    })


@app.route("/api/memory/feedback", methods=["POST"])
def memory_feedback():
    """
    Report whether a fix worked or not.
    Body: { "kpi_name": "CPU_Usage", "host": "ubuntu-node-01", "success": true }
    This updates the confidence score in DynamoDB.
    """
    body    = request.get_json(force=True) or {}
    kpi     = body.get("kpi_name", "")
    host    = body.get("host", "unknown")
    success = bool(body.get("success", True))

    if not kpi:
        return jsonify({"error": "kpi_name required"}), 400

    report_fix_outcome(kpi, host, success)
    return jsonify({
        "status":  "ok",
        "kpi":     kpi,
        "host":    host,
        "outcome": "success" if success else "failure",
        "message": "Confidence updated in DynamoDB"
    })


@app.route("/api/fix/propose", methods=["POST"])
def fix_propose():
    """
    Generate a safe fix proposal for a KPI result.
    Body: { "kpi": { ...pipeline result object... } }
    """
    body = request.get_json(force=True) or {}
    kpi = body.get("kpi")

    if not isinstance(kpi, dict) or not kpi.get("kpi_name"):
        return jsonify({"error": "kpi object with kpi_name required"}), 400

    return jsonify(propose_fix(kpi))


# ── KB endpoints ──────────────────────────────────────────────────────────────

@app.route("/api/kb/stats", methods=["GET"])
def kb_stats():
    return jsonify(_kb.get_stats())


@app.route("/api/kb/search", methods=["GET"])
def kb_search():
    query  = request.args.get("q", "")
    domain = request.args.get("domain", None)
    if not query:
        return jsonify({"error": "Pass ?q=your+query"}), 400
    result = _kb.search(query, domain=domain)
    return jsonify(result or {"message": "No KB match found"})


# ── Health ────────────────────────────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def health():
    kb_stats  = _kb.get_stats()
    return jsonify({
        "status":               "ok",
        "version":              "v5-poc",
        "kb_articles":          kb_stats["total"],
        "vector_db":            "pinecone",
        "llm_engine":           "capgemini",
        "llm_key_set":          bool(os.getenv("CAPGEMINI_GENAI_API_KEY")),
        "grafana_configured":   bool(os.getenv("GRAFANA_URL")),
    })


@app.route("/poc", methods=["GET"])
def poc_ui():
    """Serve the unified dashboard UI for the PoC route."""
    if os.path.exists("hackathon_demo.html"):
        return send_from_directory(".", "hackathon_demo.html")
    if os.path.exists("unified_dashboard.html"):
        return send_from_directory(".", "unified_dashboard.html")
    return "<h1>404 - Dashboard file not found</h1>", 404


# ── Approval / Executor endpoints for PoC GUI ─────────────────────────────────
@app.route("/api/approve", methods=["POST"])
def api_approve():
    """
    Accepts JSON: { approval_id, approved: true|false, fix_plan: {...}, kpi_name, service, host }
    Calls approval_agent.approve_fix and then runs ApprovalExecutorAgent to simulate execution.
    """
    try:
        body = request.get_json(force=True) or {}
        approval_id = body.get("approval_id")
        approved = bool(body.get("approved", True))
        fix_plan = body.get("fix_plan", {})
        kpi_name = body.get("kpi_name", None)
        service = body.get("service", None)
        host = body.get("host", None)

        if not approval_id:
            return jsonify({"error": "approval_id required"}), 400

        decision = approve_fix(approval_id, approved=approved, notes=body.get("notes", ""))

        executor = ApprovalExecutorAgent()
        exec_input = {
            "approval_id": approval_id,
            "approval_status": "approved" if approved else "rejected",
            "fix_plan": fix_plan,
        }
        exec_result = executor.run(exec_input)

        response_payload = {"decision": decision, "execution": exec_result}

        # If execution was successful, write KB/history and update memory confidence
        if exec_result.get("execution_status") == "success" and kpi_name and service and host:
            try:
                kb_writer = KBWriterAgent()
                kb_result = kb_writer.run({
                    "kpi_name": kpi_name,
                    "service": service,
                    "root_cause": body.get("root_cause", ""),
                    "fix_plan": fix_plan,
                    "execution_status": exec_result.get("execution_status"),
                    "execution_output": exec_result.get("execution_output", ""),
                    "approval_id": approval_id,
                })

                history_agent = HistoryAgent()
                history_agent.run({
                    "kpi_name": kpi_name,
                    "service": service,
                    "host": host,
                    "root_cause": body.get("root_cause", "")[:100],
                    "fix_plan": fix_plan,
                    "approval_id": approval_id,
                    "approval_status": exec_result.get("approval_status", "approved"),
                    "execution_status": exec_result.get("execution_status", "success"),
                    "execution_output": exec_result.get("execution_output", ""),
                    "kb_id": kb_result.get("kb_id"),
                    "processing_time": 0,
                })

                # Resolution is stored in Pinecone vector DB by pipeline_orchestrator
                # No additional storage needed here

                response_payload["kb_result"] = kb_result
            except Exception as exc:
                logging.exception("Post-approval persistence failed")
                response_payload["post_approval_error"] = str(exc)

            try:
                report_fix_outcome(kpi_name, service, host, True)
            except Exception:
                pass

        return jsonify(response_payload)
    except Exception as exc:
        logging.exception("Approval/Executor error")
        return jsonify({"error": str(exc)}), 500


@app.route("/api/history", methods=["GET"])
def api_history():
    """Return the pipeline history file content for inspection in the UI."""
    history_path = os.path.join("data", "kpi_history.json")
    if not os.path.exists(history_path):
        return jsonify([])
    try:
        with open(history_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return jsonify(data)
    except Exception:
        return jsonify([])


# ── KPI Data Management endpoints ───────────────────────────────────────────

@app.route("/api/kpi/source", methods=["GET"])
def kpi_source():
    """
    Get current KPI data source info.
    Returns which source is being used: custom upload, Grafana, or dummy data.
    """
    from kpi_data_manager import get_data_source_info
    return jsonify(get_data_source_info())


@app.route("/api/kpi/upload", methods=["POST"])
def upload_kpi():
    """
    Upload custom KPI data from file.
    
    Supports:
    - JSON: {"file": "<json_content>", "type": "json"}
    - CSV: {"file": "<csv_content>", "type": "csv"}
    
    CSV must have columns: kpi_name, value, threshold, host (optional: timestamp)
    JSON must be array or object with fields: kpi_name, value, threshold, host (optional: timestamp)
    """
    from kpi_data_manager import upload_kpi_data
    
    try:
        # Handle file upload
        if 'file' in request.files:
            file = request.files['file']
            if not file or file.filename == '':
                return jsonify({"status": "error", "message": "No file selected"}), 400
            
            file_content = file.read().decode('utf-8')
            file_ext = file.filename.split('.')[-1].lower()
            file_type = "json" if file_ext == "json" else "csv" if file_ext == "csv" else file_ext
        
        # Handle JSON body
        elif request.is_json:
            data = request.get_json()
            file_content = data.get("file", "")
            file_type = data.get("type", "json")
        else:
            return jsonify({"status": "error", "message": "No file or JSON data provided"}), 400
        
        result = upload_kpi_data(file_content, file_type)
        status_code = 200 if result["status"] == "success" else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logging.exception("KPI upload error")
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/kpi/data", methods=["POST"])
def upload_kpi_json():
    """
    Upload custom KPI data as raw JSON.
    
    Example:
    {
      "kpis": [
        {"kpi_name": "CPU_Usage", "value": 85, "threshold": 80, "host": "server-01"},
        {"kpi_name": "Memory_Usage", "value": 75, "threshold": 85, "host": "server-01"}
      ]
    }
    """
    from kpi_data_manager import upload_kpi_data
    import json
    
    try:
        body = request.get_json(force=True)
        kpis = body.get("kpis", [])
        
        if not kpis:
            return jsonify({"status": "error", "message": "No 'kpis' array provided"}), 400
        
        # Convert to JSON string for processing
        json_string = json.dumps(kpis)
        result = upload_kpi_data(json_string, "json")
        
        status_code = 200 if result["status"] == "success" else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logging.exception("KPI data upload error")
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/kpi/custom", methods=["DELETE"])
def clear_custom_kpi():
    """Clear custom uploaded KPI data and revert to default sources."""
    from kpi_data_manager import clear_custom_kpi_data
    result = clear_custom_kpi_data()
    return jsonify(result)


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    print(f"\n{'='*60}")
    print(f"  OpsBot v5 running at:    http://localhost:{port}")
    print(f"{'='*60}")
    print(f"  Pipeline:")
    print(f"    Analyze:               GET  http://localhost:{port}/api/analyze")
    print(f"    Approve fix:           POST http://localhost:{port}/api/approve")
    print(f"  KPI Data Management:")
    print(f"    Upload file:           POST http://localhost:{port}/api/kpi/upload")
    print(f"    Upload JSON data:      POST http://localhost:{port}/api/kpi/data")
    print(f"    Current source:        GET  http://localhost:{port}/api/kpi/source")
    print(f"    Clear custom data:     DELETE http://localhost:{port}/api/kpi/custom")
    print(f"  Memory & Knowledge:")
    print(f"    Memory stats:          GET  http://localhost:{port}/api/memory/stats")
    print(f"    Memory feedback:       POST http://localhost:{port}/api/memory/feedback")
    print(f"    KB search:             GET  http://localhost:{port}/api/kb/search")
    print(f"    KB stats:              GET  http://localhost:{port}/api/kb/stats")
    print(f"  Health:")
    print(f"    Health check:          GET  http://localhost:{port}/api/health")
    print(f"{'='*60}\n")
    app.run(debug=True, port=port)
