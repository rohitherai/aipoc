#!/usr/bin/env python3
"""
Test vector DB caching to ensure:
1. First run stores KPI in ChromaDB
2. Second run with same KPI retrieves from cache (FAST PATH)
3. Similarity score is high (>= 0.30 for debug, >= 0.70 for testing)
4. LLM is NOT called on cache hit
"""

import json
import os
import sys
from vector_db_wrapper import VectorDBWrapper

def create_test_kpi(name="throughput_collapse", service="RAN", host="cell_7b"):
    """Create a test KPI object"""
    return {
        "kpi_name": name,
        "service": service,
        "host": host,
        "value": 12.4,
        "threshold": 80.0,
        "timestamp": "2024-05-28T09:15:00Z"
    }

def test_cache_workflow():
    """Test the complete cache workflow"""
    
    print("\n" + "="*80)
    print("🧪 VECTOR DB CACHE TEST")
    print("="*80)
    
    # Initialize vector DB
    print("\n[TEST] Initializing Vector DB...")
    db = VectorDBWrapper()
    
    print("\n[TEST] ✅ Vector DB initialized")
    print(f"[TEST] Collection has {db.collection.count()} documents before test")
    
    # ============================================================
    # PHASE 1: FIRST RUN - Store KPI (DEEP PATH)
    # ============================================================
    print("\n" + "="*80)
    print("📍 PHASE 1: FIRST RUN - Store KPI (should go DEEP PATH)")
    print("="*80)
    
    kpi = create_test_kpi("throughput_collapse", "RAN", "cell_7b")
    print(f"\n[TEST] Searching for: {kpi['kpi_name']}")
    
    # Search should return None (no cache yet)
    search_result = db.search(kpi)
    
    if search_result is None:
        print("\n✅ PHASE 1 PASS: Search returned None (no cache)")
        print("   → Will proceed with DEEP PATH (LLM analysis)")
    else:
        print("\n❌ PHASE 1 FAIL: Unexpected cache hit on first run")
        print(f"   Result: {search_result}")
        return False
    
    # Simulate storing the KPI after LLM analysis
    print("\n[TEST] Simulating LLM analysis and storing result...")
    store_data = {
        "kpi": kpi,
        "service": "RAN",
        "root_cause": "Uplink interference detected on Band n78. Transmitting at max power causing pilot pollution.",
        "fix": {
            "command": "reduce_tx_power",
            "parameters": {"cell": "7A", "reduction_db": 3},
            "expected_result": "Throughput recovery to 78+ Mbps"
        }
    }
    
    store_result = db.store(store_data)
    
    if store_result:
        print(f"\n✅ PHASE 1 PASS: KPI stored successfully")
        print(f"[TEST] Collection now has {db.collection.count()} documents")
    else:
        print(f"\n❌ PHASE 1 FAIL: Failed to store KPI")
        return False
    
    # ============================================================
    # PHASE 2: SECOND RUN - Retrieve from cache (FAST PATH)
    # ============================================================
    print("\n" + "="*80)
    print("📍 PHASE 2: SECOND RUN - Retrieve from cache (should go FAST PATH)")
    print("="*80)
    
    # Create identical KPI (same name, service, host)
    kpi_2 = create_test_kpi("throughput_collapse", "RAN", "cell_7b")
    print(f"\n[TEST] Searching for: {kpi_2['kpi_name']}")
    
    # Search should return cached result
    search_result = db.search(kpi_2)
    
    if search_result is not None:
        print(f"\n✅ PHASE 2 PASS: Cache hit!")
        print(f"[TEST] Score: {search_result['score']:.6f}")
        print(f"[TEST] Root cause: {search_result['root_cause'][:80]}...")
        print(f"[TEST] Fix: {search_result['fix']}")
    else:
        print(f"\n❌ PHASE 2 FAIL: Cache miss on second run")
        print(f"   → Check if threshold is too high, or embedding inconsistency")
        return False
    
    # ============================================================
    # PHASE 3: THIRD RUN - Different KPI should NOT hit cache
    # ============================================================
    print("\n" + "="*80)
    print("📍 PHASE 3: THIRD RUN - Different KPI (should go DEEP PATH)")
    print("="*80)
    
    # Create different KPI
    kpi_3 = create_test_kpi("memory_leak", "RAN", "cell_7a")  # Different name and host
    print(f"\n[TEST] Searching for: {kpi_3['kpi_name']}")
    
    search_result = db.search(kpi_3)
    
    if search_result is None:
        print(f"\n✅ PHASE 3 PASS: No cache hit for different KPI (correct)")
        print(f"[TEST] → Will proceed with DEEP PATH for this new KPI")
    else:
        print(f"\n❌ PHASE 3 FAIL: Cache hit for different KPI (should be DEEP PATH)")
        print(f"   → Threshold may be too low, causing false positives")
        return False
    
    # ============================================================
    # SUMMARY
    # ============================================================
    print("\n" + "="*80)
    print("✅ ALL TESTS PASSED!")
    print("="*80)
    print(f"\n📊 Final Status:")
    print(f"   ✅ Phase 1 (Store): PASSED - KPI stored in ChromaDB")
    print(f"   ✅ Phase 2 (Retrieve): PASSED - Cache hit on second run")
    print(f"   ✅ Phase 3 (Specificity): PASSED - Different KPI correctly went DEEP PATH")
    print(f"   📈 Collection size: {db.collection.count()} documents")
    print(f"\n🎯 Caching is working correctly!")
    print(f"   → Same KPI triggers FAST PATH (no LLM call)")
    print(f"   → Different KPI triggers DEEP PATH (LLM analysis)")
    
    return True

if __name__ == "__main__":
    try:
        success = test_cache_workflow()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ TEST FAILED WITH EXCEPTION:")
        import traceback
        traceback.print_exc()
        sys.exit(1)
