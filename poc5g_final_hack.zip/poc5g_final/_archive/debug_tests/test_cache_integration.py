#!/usr/bin/env python3
"""
Test script to verify cache hit functionality.
"""

import os
import json
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Test 1: Check if local cache has data
print("=" * 70)
print("TEST 1: Check Local Cache Contents")
print("=" * 70)

try:
    from local_vector_cache import LocalVectorCache
    cache = LocalVectorCache()
    stats = cache.get_stats()
    print(f"Cache file: {stats.get('cache_file')}")
    print(f"Total vectors: {stats.get('total_vectors')}")
    print(f"Cache size: {stats.get('cache_size_mb')} MB")
    
    if stats.get('total_vectors', 0) > 0:
        print("\n[OK] Cache contains data")
    else:
        print("\n[EMPTY] Cache is empty")
except Exception as e:
    print(f"[ERROR] {e}")

# Test 2: Verify Vector DB wrapper with current settings
print("\n" + "=" * 70)
print("TEST 2: VectorDB Initialization")
print("=" * 70)

try:
    from vector_db_wrapper import VectorDBWrapper
    vdb = VectorDBWrapper()
    
    print(f"use_mock: {vdb.use_mock}")
    print(f"use_real: {vdb.use_real}")
    print(f"use_fallback: {vdb.use_fallback}")
    print(f"use_local_cache: {vdb.use_local_cache}")
    
    if vdb.use_local_cache:
        print("\n[OK] Local cache is ACTIVE")
    else:
        print("\n[WARNING] Local cache is NOT active (using:", 
              "mock" if vdb.use_mock else "fallback" if vdb.use_fallback else "real")
        
except Exception as e:
    print(f"[ERROR] {e}")
    import traceback
    traceback.print_exc()

# Test 3: Test search and store
print("\n" + "=" * 70)
print("TEST 3: Search and Store Operation")
print("=" * 70)

try:
    from vector_db_wrapper import VectorDBWrapper
    vdb = VectorDBWrapper()
    
    # Try to store a test KPI
    test_data = {
        "kpi": {
            "kpi_name": "TEST_CPU",
            "threshold": 70,
            "value": 75,
            "host": "test-host",
            "timestamp": "2026-05-15T10:00:00Z"
        },
        "service": "test_service",
        "root_cause": "Test root cause analysis",
        "fix": {"actions": ["Test action 1", "Test action 2"]}
    }
    
    print("\nStoring test data...")
    store_result = vdb.store(test_data)
    print(f"Store result: {store_result}")
    
    # Try to search
    print("\nSearching for test data...")
    search_result = vdb.search({"kpi_name": "TEST_CPU"})
    print(f"Search result: {search_result}")
    
    if search_result:
        print("\n[OK] CACHE HIT! Fast-path would be activated")
    else:
        print("\n[MISS] Cache miss - deep path will be used")
        
except Exception as e:
    print(f"[ERROR] {e}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 70)
print("Test Complete")
print("=" * 70)
