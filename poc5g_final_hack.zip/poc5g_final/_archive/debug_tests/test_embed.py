import requests
import os
from dotenv import load_dotenv

load_dotenv()

api_key = os.getenv("CAPGEMINI_GENAI_API_KEY")
base_url = os.getenv("EMBEDDING_BASE_URL")
model = os.getenv("EMBEDDING_MODEL")

url = f"{base_url}/embeddings"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

payload = {
    "input": "test embedding text",
    "model": model
}

try:
    print("🔍 Testing embedding API...")
    print("URL:", url)

    response = requests.post(url, headers=headers, json=payload, timeout=10)

    print("Status Code:", response.status_code)
    print("Response:", response.text[:300])

    if response.status_code == 200:
        data = response.json()
        embedding = data["data"][0]["embedding"]

        print("✅ SUCCESS!")
        print("Embedding length:", len(embedding))

    else:
        print("❌ API call failed")

except Exception as e:
    print("❌ CONNECTION ERROR:", e)