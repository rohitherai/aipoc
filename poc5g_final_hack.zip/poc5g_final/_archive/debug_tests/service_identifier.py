import logging
from typing import Dict, Optional, Tuple, Any

logger = logging.getLogger("service_identifier")

SERVICES = ["smf", "upf", "amf", "pcf", "nrf", "nssf", "ausf", "oam"]


def extract_service_from_labels(labels: Optional[Dict[str, str]]) -> Optional[Tuple[str, float, str]]:
    if not labels:
        return None

    labels_lower = {k.lower(): v.lower() for k, v in labels.items()}
    for field in ["service", "nf_type", "app", "component"]:
        value = labels_lower.get(field)
        if not value:
            continue

        for service in SERVICES:
            if service == value or service in value or value in service:
                return service, 0.95, "labels"

    return None


def extract_service_from_instance(instance: Optional[str]) -> Optional[Tuple[str, float, str]]:
    if not instance:
        return None

    instance_lower = instance.lower()
    for service in SERVICES:
        if service in instance_lower:
            return service, 0.8, "instance"

    return None


def extract_service_from_kpi_name(kpi_name: Optional[str]) -> Optional[Tuple[str, float, str]]:
    if not kpi_name:
        return None

    kpi_lower = kpi_name.lower()
    for service in SERVICES:
        if service in kpi_lower:
            return service, 0.6, "kpi_name"

    return None


def identify_service(
    kpi_name: str,
    labels: Optional[Dict[str, str]] = None,
    instance: Optional[str] = None,
) -> Dict[str, Any]:
    result = extract_service_from_labels(labels)
    if result:
        service, confidence, _ = result
        logger.info("Service identified via labels: %s", service)
        return {"service": service, "confidence": confidence, "source": "labels"}

    result = extract_service_from_instance(instance)
    if result:
        service, confidence, _ = result
        logger.info("Service identified via instance: %s", service)
        return {"service": service, "confidence": confidence, "source": "instance"}

    result = extract_service_from_kpi_name(kpi_name)
    if result:
        service, confidence, _ = result
        logger.info("Service identified via kpi_name: %s", service)
        return {"service": service, "confidence": confidence, "source": "kpi_name"}

    logger.warning("Service unknown for KPI '%s'", kpi_name)
    return {"service": "unknown", "confidence": 0.3, "source": "unknown"}
