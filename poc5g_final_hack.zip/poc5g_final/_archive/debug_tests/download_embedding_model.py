#!/usr/bin/env python
"""Pre-download embedding model with SSL bypass"""

import os
import ssl
import urllib3
import certifi

# Disable SSL verification 
os.environ['REQUESTS_CA_BUNDLE'] = ''
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['TRANSFORMERS_OFFLINE'] = '0'

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Patch SSL before any imports
import ssl
_original_create_context = ssl.create_default_context

def _create_unverified_context(*args, **kwargs):
    context = _original_create_context(*args, **kwargs)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context

ssl.create_default_context = _create_unverified_context

print("Downloading embedding model...")
print("(This may take 1-2 minutes on first run)")

try:
    from sentence_transformers import SentenceTransformer
    print("Loading model: all-MiniLM-L6-v2")
    model = SentenceTransformer('all-MiniLM-L6-v2')
    print("✅ Model downloaded and cached successfully!")
    
    # Test embedding
    test_embedding = model.encode("test")
    print(f"✅ Model working! Embedding dimension: {len(test_embedding)}")
    
except Exception as e:
    print(f"❌ Failed to download model: {e}")
    import traceback
    traceback.print_exc()
