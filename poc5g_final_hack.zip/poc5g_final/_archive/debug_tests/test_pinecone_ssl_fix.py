#!/usr/bin/env python
"""Pinecone test with SSL verification bypass for Windows environment"""

import ssl
import urllib3
import os
import sys

# Disable SSL verification warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Set environment variables
os.environ['PYTHONHTTPSVERIFY'] = '0'

# Create unverified SSL context
ssl._create_default_https_context = ssl._create_unverified_context

# Now run the actual test
from vector_db_wrapper import VectorDBWrapper
from config import USE_VECTOR_DB

print("="*60)
print("🔍 PINECONE CONNECTION TEST (SSL BYPASS)")
print("="*60)

print("\n[TEST] Initializing VectorDBWrapper...")
try:
    vdb = VectorDBWrapper()
    
    if vdb.use_real:
        print("✅ REAL Pinecone connection SUCCESS!")
        print(f"   Index Host: {vdb.index_host}")
        print(f"   Status: Ready for data storage")
        
        # Test storing a sample KPI
        print("\n[TEST] Testing data storage...")
        test_data = {
            "kpi_name": "CPU_Utilization",
            "service": "SMF",
            "root_cause_summary": "High CPU caused by memory leak",
            "fix_actions": "Restart SMF service and monitor"
        }
        vdb.store(test_data)
        print("✅ Sample KPI stored successfully!")
        
    elif vdb.use_mock:
        print("⚠️  Mock mode (fallback)")
        print("   Reason: Real connection unavailable")
        print("   → Data stored locally in memory")
        print("   → Fast-path caching will not persist")
        
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "="*60)
print("Test complete!")
print("="*60)
