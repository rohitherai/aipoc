#!/usr/bin/env python
"""
Test Flask UI cache hit simulation with fixed embeddings.
Verifies that FAST PATH works when same KPI is searched twice.
"""

from pipeline_orchestrator import run_pipeline
from datetime import datetime
import json

# Set up test KPI data
import os
os.environ['TEST_KPI_NAME'] = 'API_LATENCY'
os.environ['TEST_HOST'] = 'api-server-01'

print('=' * 70)
print('FLASK UI CACHE HIT SIMULATION - TESTING FIXED EMBEDDINGS')
print('=' * 70)

# Simulate first request (should store)
print('\n📋 FIRST REQUEST (New KPI - should go DEEP PATH and store)')
result1 = run_pipeline()
print(f'Status: {result1.get("status")}')
print(f'Route: {result1.get("route")}')

print('\n' + '=' * 70)

# Simulate second request (should hit cache)
print('\n📋 SECOND REQUEST (Same KPI - should hit FAST PATH cache)')
result2 = run_pipeline()
print(f'Status: {result2.get("status")}')
print(f'Route: {result2.get("route")}')

# Verify results
print('\n' + '=' * 70)
print('VERIFICATION')
print('=' * 70)

if result1.get('route') == 'DEEP_PATH':
    print('✅ Request 1: Correctly went DEEP PATH (no cache for new KPI)')
else:
    print('❌ Request 1: Should have gone DEEP PATH but went', result1.get('route'))

if result2.get('route') == 'FAST_PATH':
    print('✅ Request 2: Correctly went FAST PATH (cache hit!)')
    print(f'   Cache Score: {result2.get("cache_score", "N/A")}')
else:
    print('❌ Request 2: Should have gone FAST PATH but went', result2.get('route'))
    
if result1.get('route') == 'DEEP_PATH' and result2.get('route') == 'FAST_PATH':
    print('\n🎉 SUCCESS! Cache matching is working correctly!')
else:
    print('\n⚠️ WARNING! Cache matching may have issues.')
