# Pinecone Integration Setup Guide

## Overview
The system now uses Pinecone to cache KPI analysis results, enabling:
- **First run**: Full analysis pipeline (logs → RCA via LLM → fix generation → approval)
- **Subsequent runs**: Fast-path retrieval from Pinecone (skip LLM call)
- **Result**: Dramatic speedup from 12-15 seconds per KPI → <1 second for cached hits

## Prerequisites
1. Pinecone account: https://www.pinecone.io/
2. An existing `kpi-index` with:
   - Dimension: 384
   - Metric: cosine
   - Index status: Active

## Configuration Steps

### 1. Get Your Pinecone Index Host

1. Go to https://app.pinecone.io/
2. Navigate to your project → `kpi-index`
3. Copy the **Index Host** (looks like: `kpi-index-xxxxx.svc.pinecone.io`)
4. Update `.env` file:
   ```env
   PINECONE_INDEX_HOST=https://kpi-index-xxxxx.svc.pinecone.io
   ```

### 2. Verify Your API Key

The API key is already in `.env`:
```env
PINECONE_API_KEY=pcsk_3bJovq_5UPhr8UcamTE6PVxWw5oGbH5Gy7PArVo8UPtxd9BFa5swTPpBvJA9GdYdTHocn
```

### 3. Enable Vector DB in Config

Ensure `config.py` has:
```python
USE_VECTOR_DB = True
```

## How It Works

### First Run (No Cache)
```
Pipeline starts
  ↓
Search Pinecone for similar KPI
  ↓ (No match found)
Route to deep-path analysis
  ↓
Step 1: Collect logs
Step 2: RCA (KB search + LLM call if no KB match)  ← LLM CALLED HERE (~12 seconds)
Step 3: Generate fix plan
Step 4: Request approval
Step 5: Execute (if approved)
Step 6: Store result in Pinecone ← SAVES FOR NEXT TIME
Step 7: Write to KB
Step 8: Update history
  ↓
Return results
```

### Subsequent Runs (Cache Hit)
```
Pipeline starts
  ↓
Search Pinecone for similar KPI
  ↓ (Match found with score > 0.85)
Use cached root_cause and fix_plan
  ↓
Step 4: Request approval (still needed for security)
  ↓
Return fast-path results (~<1 second)
```

## Testing the Integration

### Run Test Script
```bash
python test_pinecone_integration.py
```

This script will:
1. ✅ Verify Pinecone connection
2. ✅ Test embedding generation
3. ✅ Test vector storage
4. ✅ Test vector search
5. ✅ Report cache hit rates

### Manual Testing
1. Start the server: `python server.py`
2. Open GUI: http://localhost:5000/poc
3. Click "Run Pipeline" for KPI: `SMF_CPU_Usage`
   - First run: Takes ~12 seconds (deep path)
   - Logs show: `[ANALYSIS] Starting deep path for SMF_CPU_Usage`
4. Click "Run Pipeline" again
   - Second run: Takes <1 second (fast path)
   - Logs show: `[FAST-PATH] Requesting approval for cached SMF_CPU_Usage`

## Monitoring

### Check Pinecone Storage
```bash
# View stored resolutions
curl -X POST "https://kpi-index-xxxxx.svc.pinecone.io/query" \
  -H "Api-Key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"vector": [0.1, 0.2, ...], "topK": 5, "includeMetadata": true}'
```

### Check Cache Hit Rate
1. Run multiple analyses
2. Check logs for `[FAST-PATH]` entries
3. Compare with total `[ANALYSIS]` entries

Expected ratio after first run: 50%+ cache hits

## Troubleshooting

### "Connection failed" Error
**Cause**: Incorrect `PINECONE_INDEX_HOST`
**Fix**: 
1. Verify host in Pinecone dashboard
2. Ensure format: `https://index-name-xxxxx.svc.pinecone.io`
3. Check for typos

### "Cannot import __version__"
**Cause**: Old Pinecone SDK version installed
**Fix**: 
```bash
pip uninstall pinecone -y
pip install pinecone==2.2.4
# OR use the REST API (current implementation - no SDK needed)
```

### No Matches Found (always deep path)
**Cause**: Empty Pinecone index or low similarity threshold
**Fix**:
1. Run several analyses to populate Pinecone
2. Check similarity scores in logs
3. Adjust threshold in `vector_db_wrapper.py` (currently 0.85)

### Storage Failures
**Cause**: Index dimension mismatch or metadata size
**Fix**:
1. Ensure embedding model matches dimension: `all-MiniLM-L6-v2` → 384 dims
2. Keep metadata < 40KB per vector
3. Check index status in Pinecone dashboard

## Performance Optimization

### Cache Hit Metrics
Monitor your terminal logs:
```
📊 Pipeline Stats
├─ Deep Path: 3 KPIs
├─ Fast Path: 2 KPIs  ← From Pinecone cache
├─ Avg Time: 8.5s
└─ Cache Hit Rate: 40%
```

### Tuning Similarity Threshold
In `vector_db_wrapper.py`, adjust the score threshold:
```python
if score > 0.85:  # Increase to 0.90 for stricter matching
    # Return cached result
```

### Embedding Model Options
Current: `all-MiniLM-L6-v2` (384 dims, fast)
Alternatives:
- `all-MiniLM-L6-v2` (lightweight)
- `all-mpnet-base-v2` (512 dims, more accurate)
- `multilingual-e5-base` (768 dims, multilingual)

## Next Steps

1. ✅ Configure `PINECONE_INDEX_HOST` in `.env`
2. ✅ Start server: `python server.py`
3. ✅ Run first pipeline to populate cache
4. ✅ Monitor cache hit rate in subsequent runs
5. ✅ Fine-tune similarity threshold based on your data

## Support

For issues:
1. Check logs in terminal for `[VectorDB]` messages
2. Verify Pinecone index status: https://app.pinecone.io/
3. Test connectivity: `curl https://your-index-host/describe_index_stats`
4. Review `vector_db_wrapper.py` for connection details
