# 📋 Manual Pipeline Execution - Step by Step Guide

## 🎯 Overview

The pipeline has **8 main stages**. You can run them manually to understand the complete flow.

```
Stage 1: Get KPI Data
   ↓
Stage 2: Initialize Vector DB
   ↓
Stage 3: Search Cache
   ├─ CACHE HIT → Stage 7 (Skip LLM)
   └─ CACHE MISS → Stage 4 (Deep Analysis)
   ↓
Stage 4: Deep Analysis (LLM)
   ├─ Log Collection
   ├─ Root Cause Analysis
   └─ Fix Generation
   ↓
Stage 5: Create Approval Request
   ↓
Stage 6: Execute Approved Fixes
   ↓
Stage 7: Store Result to Cache
   ↓
Stage 8: Return Result
```

---

## 🚀 Manual Execution - Step by Step

### STAGE 1: Get KPI Data

**File:** `kpi_data_manager.py`

**Command:**
```bash
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

python -c "
from kpi_data_manager import get_kpi_data_with_fallback
kpi_data = get_kpi_data_with_fallback()
import json
print(json.dumps(kpi_data, indent=2))
"
```

**Expected Output:**
```json
[
  {
    "kpi_name": "SMF_CPU_Usage",
    "value": 78,
    "threshold": 70,
    "service": "smf",
    "host": "smf-core-01",
    "timestamp": "2026-05-15T06:00:00Z"
  }
]
```

**What Happens:**
- Loads dummy KPI data from `data/dummy_kpis.json`
- Or custom uploaded data if available
- Returns list of KPI metrics

---

### STAGE 2: Initialize Vector DB

**File:** `vector_db_wrapper.py`

**Command:**
```bash
python -c "
from vector_db_wrapper import VectorDBWrapper
db = VectorDBWrapper()
print(f'use_local_cache: {db.use_local_cache}')
print(f'use_real: {db.use_real}')
print(f'use_fallback: {db.use_fallback}')
print(f'use_mock: {db.use_mock}')
"
```

**Expected Output:**
```
use_local_cache: True        ← Local cache FORCED (from config.py)
use_real: False              ← Pinecone disabled (proxy issue)
use_fallback: False
use_mock: False
```

**What Happens:**
- Reads `config.py` → `USE_LOCAL_CACHE = True`
- Initializes `LocalVectorCache`
- Ready for search/store operations

---

### STAGE 3: Search Cache

**File:** `vector_db_wrapper.py` + `local_vector_cache.py`

**Command:**
```bash
python -c "
from vector_db_wrapper import VectorDBWrapper

# Initialize DB
db = VectorDBWrapper()

# Create sample KPI
kpi = {
    'kpi_name': 'SMF_CPU_Usage',
    'value': 78,
    'service': 'smf'
}

# Search cache
result = db.search(kpi)
print(f'Search result: {result}')
"
```

**Expected Output (First Run - Cache Miss):**
```
Search result: None
```

**Expected Output (Second Run - Cache Hit):**
```
Search result: {
  'score': 0.998,
  'root_cause': 'Session setup surge triggering cascading PFCP association failures',
  'fix': {
    'actions': ['Check session rate limits', 'Restart SMF if needed'],
    'estimated_time': '5-10 minutes'
  }
}
```

**What Happens:**
- **First run:** Cache empty → No match → Returns `None`
- **Second run:** Cache has entry → Calculates similarity → Match > 0.85 → Returns cached RCA

**Cache File:** `vector_cache/vectors.jsonl`

---

### STAGE 4A: Deep Analysis - Log Collection

**File:** `log_agent.py`

**Command:**
```bash
python -c "
from log_agent import LogAgent

agent = LogAgent()
logs = agent.collect_logs('SMF_CPU_Usage')
print(f'Logs collected: {len(logs)} entries')
print(logs[:200] if logs else 'No logs')
"
```

**Expected Output:**
```
Logs collected: 45 entries
[2026-05-15 06:00:00] SMF WARN: High session setup rate
[2026-05-15 06:01:00] SMF ERROR: PFCP association timeout
...
```

**What Happens:**
- Reads `data/dummy_syslog.txt`
- Filters logs related to KPI
- Returns relevant log lines

---

### STAGE 4B: Deep Analysis - Root Cause Analysis (RCA)

**File:** `rca_agent.py` (calls LLM)

**Command:**
```bash
python -c "
from rca_agent import RCAAgent
from vector_db_wrapper import VectorDBWrapper

# Get logs first
from log_agent import LogAgent
log_agent = LogAgent()
logs = log_agent.collect_logs('SMF_CPU_Usage')

# Create RCA agent
rca_agent = RCAAgent()

# Generate RCA (this calls Capgemini LLM - takes ~10 seconds)
rca_result = rca_agent.analyze(
    kpi_name='SMF_CPU_Usage',
    kpi_value=78,
    threshold=70,
    logs=logs
)

print('RCA Result:')
print(rca_result)
"
```

**Expected Output:**
```
RCA Result:
{
  'root_cause_summary': 'Session setup surge triggering cascading PFCP association failures',
  'affected_systems': ['SMF Core', 'UPF', 'PFCP Protocol'],
  'severity': 'HIGH',
  'confidence': 0.92,
  'detailed_analysis': '...',
  'next_steps': ['Check session rate', 'Monitor PFCP associations']
}
```

**Time:** ~10 seconds (calls Capgemini API)

**What Happens:**
- Takes logs + KPI data
- Sends to Capgemini Claude LLM
- LLM analyzes and returns RCA
- This is the LONGEST step (why we cache!)

---

### STAGE 4C: Deep Analysis - Fix Generation

**File:** `fixer_agent.py`

**Command:**
```bash
python -c "
from fixer_agent import FixerAgent

# Create fixer agent
fixer = FixerAgent()

# Generate fix
fix_plan = fixer.generate_fix(
    rca_summary='Session setup surge...',
    kpi_name='SMF_CPU_Usage',
    service='smf'
)

print('Fix Plan:')
print(fix_plan)
"
```

**Expected Output:**
```
Fix Plan:
{
  'actions': [
    'Check SMF configuration for session limits',
    'Monitor PFCP association states',
    'Restart SMF if associations timeout',
    'Scale out UPF if needed'
  ],
  'priority': 'HIGH',
  'estimated_duration': '5-10 minutes',
  'rollback_plan': 'Reload previous config'
}
```

**What Happens:**
- Takes RCA summary
- Generates actionable fix steps
- Estimates time and risk

---

### STAGE 5: Create Approval Request

**File:** `approval_agent.py`

**Command:**
```bash
python -c "
from approval_agent import ApprovalAgent
import json

# Create approval request
approval_agent = ApprovalAgent()

request = approval_agent.create_approval_request(
    kpi_name='SMF_CPU_Usage',
    rca_summary='Session setup surge...',
    fix_plan=['Check config', 'Restart SMF'],
    severity='HIGH'
)

print(f'Approval Request ID: {request[\"approval_id\"]}')
print(f'Status: {request[\"status\"]}')
print(f'Awaiting: {request[\"awaiting_action\"]}')
"
```

**Expected Output:**
```
Approval Request ID: APPR-20260526-SMF001
Status: pending
Awaiting: manual_approval
```

**What Happens:**
- Creates approval request with unique ID
- Stores in memory
- Waits for approval/rejection

---

### STAGE 6: Execute Approved Fixes

**File:** `approval_executor_agent.py`

**Command:**
```bash
python -c "
from approval_executor_agent import ApprovalExecutorAgent

executor = ApprovalExecutorAgent()

# Execute with APPROVED status
result = executor.execute(
    approval_id='APPR-20260526-SMF001',
    action='approve',
    fix_actions=['Check config', 'Restart SMF']
)

print('Execution Result:')
print(result)
"
```

**Expected Output:**
```
Execution Result:
{
  'approval_id': 'APPR-20260526-SMF001',
  'status': 'executed',
  'actions_executed': 2,
  'execution_log': [
    '14:25:33 - Checked SMF configuration',
    '14:25:45 - SMF restart initiated',
    '14:26:10 - SMF online, health: OK'
  ],
  'result': 'success'
}
```

**What Happens:**
- Checks approval status
- If approved: executes fix actions
- If rejected: skips execution
- Returns execution log

---

### STAGE 7: Store Result to Cache

**File:** `vector_db_wrapper.py` + `local_vector_cache.py`

**Command:**
```bash
python -c "
from vector_db_wrapper import VectorDBWrapper

db = VectorDBWrapper()

# Store analysis result
analysis_result = {
    'kpi_name': 'SMF_CPU_Usage',
    'service': 'smf',
    'host': 'smf-core-01',
    'root_cause_summary': 'Session setup surge...',
    'fix_actions': ['Check config', 'Restart SMF']
}

db.store(analysis_result)
print('Stored to cache successfully')
"
```

**Expected Output:**
```
Stored to cache successfully
```

**Stored File:** `vector_cache/vectors.jsonl`

**Content Example:**
```json
{
  \"id\": \"SMF_CPU_Usage_smf_smf-core-01\",
  \"values\": [0.12, 0.45, 0.89, ...],
  \"metadata\": {
    \"kpi_name\": \"SMF_CPU_Usage\",
    \"root_cause_summary\": \"Session setup surge...\",
    \"fix_actions\": \"[\\\"Check config\\\", \\\"Restart SMF\\\"]\"
  }
}
```

**What Happens:**
- Generates embedding from KPI name
- Stores embedding + metadata
- Persists to `vectors.jsonl`
- Ready for next cache hit!

---

### STAGE 8: Return Complete Result

**File:** `pipeline_orchestrator.py`

**Command:**
```bash
python -c "
from pipeline_orchestrator import PipelineOrchestrator

orchestrator = PipelineOrchestrator()

# Run complete pipeline
result = orchestrator.run()

import json
print(json.dumps(result, indent=2))
"
```

**Expected Output:**
```json
{
  "status": "success",
  "pipeline_path": "deep",
  "cache_hit": false,
  "timing": {
    "total_time_sec": 19.06,
    "stages": {
      "kpi_fetch": 0.5,
      "cache_search": 0.1,
      "log_collection": 1.2,
      "rca_generation": 10.5,
      "fix_generation": 2.1,
      "approval": 1.2,
      "execution": 2.5,
      "storage": 0.5
    }
  },
  "analysis": {
    "kpi_name": "SMF_CPU_Usage",
    "root_cause": "Session setup surge...",
    "fix_plan": ["Check config", "Restart SMF"],
    "severity": "HIGH"
  },
  "approval": {
    "approval_id": "APPR-20260526-SMF001",
    "status": "executed"
  }
}
```

**What Happens:**
- Orchestrates all 8 stages
- Captures timing for each
- Returns complete result
- Includes cache status

---

## 🔄 Complete Manual Run (Full Pipeline)

### Full Command (All-in-One)

```bash
python -c "
from pipeline_orchestrator import PipelineOrchestrator
import json
import time

start = time.time()

# Run full pipeline
orchestrator = PipelineOrchestrator()
result = orchestrator.run()

elapsed = time.time() - start

print('='*60)
print('PIPELINE EXECUTION COMPLETE')
print('='*60)
print(f'Total Time: {elapsed:.2f} seconds')
print(f'Path: {result.get(\"pipeline_path\", \"unknown\")}')
print(f'Cache Hit: {result.get(\"cache_hit\", False)}')
print()
print('Result:')
print(json.dumps(result, indent=2))
"
```

---

## 📊 Files and Their Roles

### Core Orchestration
| File | Purpose | Stage |
|------|---------|-------|
| `pipeline_orchestrator.py` | Main orchestrator | All |
| `server.py` | Flask API | HTTP interface |

### Data Management
| File | Purpose | Stage |
|------|---------|-------|
| `kpi_data_manager.py` | Load KPI data | 1 |
| `data/dummy_kpis.json` | Sample KPI data | 1 |
| `data/dummy_syslog.txt` | Sample logs | 4A |

### Analysis Agents
| File | Purpose | Stage |
|------|---------|-------|
| `log_agent.py` | Collect logs | 4A |
| `rca_agent.py` | Root cause analysis | 4B |
| `service_identifier.py` | Identify service | - |
| `fixer_agent.py` | Generate fixes | 4C |

### Approval & Execution
| File | Purpose | Stage |
|------|---------|-------|
| `approval_agent.py` | Create approval requests | 5 |
| `approval_executor_agent.py` | Execute approved fixes | 6 |
| `memory_agent.py` | Manage memory | Various |

### Caching
| File | Purpose | Stage |
|------|---------|-------|
| `vector_db_wrapper.py` | Cache interface | 3, 7 |
| `local_vector_cache.py` | Cache engine | 3, 7 |
| `vector_cache/vectors.jsonl` | Cache storage | 3, 7 |

### Configuration
| File | Purpose |
|------|---------|
| `config.py` | Settings (USE_LOCAL_CACHE=True) |
| `.env` | Environment variables |

---

## 🧪 Test Scenarios

### Scenario 1: Run Pipeline Twice (Cache Test)

**Terminal Commands:**
```bash
# RUN 1 (Cache Miss)
python -c "
from pipeline_orchestrator import PipelineOrchestrator
import time
start = time.time()
result = PipelineOrchestrator().run()
print(f'Time: {time.time()-start:.2f}s')
print(f'Path: {result[\"pipeline_path\"]}')
"

# Wait for completion, then:

# RUN 2 (Cache Hit)
python -c "
from pipeline_orchestrator import PipelineOrchestrator
import time
start = time.time()
result = PipelineOrchestrator().run()
print(f'Time: {time.time()-start:.2f}s')
print(f'Path: {result[\"pipeline_path\"]}')
"
```

**Expected:**
- Run 1: ~19 seconds, path="deep"
- Run 2: ~2 seconds, path="fast" ⚡

---

### Scenario 2: Test Each Stage Independently

```bash
# Stage 1: Get KPI
python -c "from kpi_data_manager import get_kpi_data_with_fallback; print(get_kpi_data_with_fallback())"

# Stage 2: Init Vector DB
python -c "from vector_db_wrapper import VectorDBWrapper; db=VectorDBWrapper(); print(f'Cache active: {db.use_local_cache}')"

# Stage 3: Search Cache
python -c "from vector_db_wrapper import VectorDBWrapper; db=VectorDBWrapper(); print(db.search({'kpi_name':'SMF_CPU_Usage'}))"

# Stage 4: Collect Logs
python -c "from log_agent import LogAgent; logs=LogAgent().collect_logs('SMF_CPU_Usage'); print(f'Logs: {len(logs)}')"

# Stage 5: Generate RCA (LLM - slow!)
python -c "from rca_agent import RCAAgent; from log_agent import LogAgent; logs=LogAgent().collect_logs('SMF_CPU_Usage'); rca=RCAAgent().analyze('SMF_CPU_Usage', 78, 70, logs); print(rca['root_cause_summary'][:100])"

# Stage 6: Generate Fix
python -c "from fixer_agent import FixerAgent; fix=FixerAgent().generate_fix('Session surge...', 'SMF_CPU_Usage', 'smf'); print(fix['actions'])"

# Stage 7: Store Cache
python -c "from vector_db_wrapper import VectorDBWrapper; db=VectorDBWrapper(); db.store({'kpi_name':'SMF_CPU_Usage','service':'smf','root_cause_summary':'test','fix_actions':['test']}); print('Stored')"
```

---

## 🔍 Verification Steps

### Check Cache File
```bash
# Windows PowerShell
Get-Content C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1\vector_cache\vectors.jsonl | ConvertFrom-Json

# Should show your stored vectors
```

### Check Server Logs
```bash
# Terminal running server.py will show:
[LocalCache] Stored vector: SMF_CPU_Usage_smf_smf-core-01
[LocalCache] Search found 1 matches (threshold=0.85)
[FAST-PATH] Cache hit! Confidence: 0.998
```

### Check GUI Progress
```
http://localhost:5000/poc → Run Pipeline → Watch logs
```

---

## ⏱️ Timing Reference

| Stage | Time | Cumulative |
|-------|------|-----------|
| KPI Fetch | 0.5s | 0.5s |
| Cache Search (Miss) | 0.1s | 0.6s |
| Log Collection | 1.2s | 1.8s |
| **LLM RCA (LONGEST)** | **10.5s** | **12.3s** |
| Fix Generation | 2.1s | 14.4s |
| Approval | 1.2s | 15.6s |
| Execution | 2.5s | 18.1s |
| Cache Store | 0.5s | 18.6s |
| **Total (First Run)** | **~19 seconds** | - |

**Cache Hit (Second Run):**
- Cache Search (Hit): 0.1s
- Return cached result: <1s
- **Total: ~2 seconds** ⚡

---

## 🎯 Summary

**Manual Execution Flow:**

```
1. python -c "from kpi_data_manager import get_kpi_data_with_fallback; ..."
   ↓
2. python -c "from vector_db_wrapper import VectorDBWrapper; db = VectorDBWrapper(); ..."
   ↓
3. python -c "result = db.search(kpi); print(result)"
   ├─ Hit: Return (DONE in 2s)
   └─ Miss: Continue
   ↓
4. python -c "from log_agent import LogAgent; logs = LogAgent().collect_logs(...); ..."
   ↓
5. python -c "from rca_agent import RCAAgent; rca = RCAAgent().analyze(...); ..."
   ↓
6. python -c "from fixer_agent import FixerAgent; fix = FixerAgent().generate_fix(...); ..."
   ↓
7. python -c "from approval_agent import ApprovalAgent; approval = ApprovalAgent().create_approval_request(...); ..."
   ↓
8. python -c "from approval_executor_agent import ApprovalExecutorAgent; executor = ApprovalExecutorAgent().execute(...); ..."
   ↓
9. python -c "db.store(result); ..."
   ↓
10. COMPLETE!
```

**Or just run:**
```bash
python -c "from pipeline_orchestrator import PipelineOrchestrator; result = PipelineOrchestrator().run(); print(result)"
```

---

## 🚀 Ready to Test?

Start with full pipeline:
```bash
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1
python -c "from pipeline_orchestrator import PipelineOrchestrator; import time; start=time.time(); result=PipelineOrchestrator().run(); print(f'Total time: {time.time()-start:.2f}s'); print(result['pipeline_path'])"
```

Or use GUI:
```
http://localhost:5000/poc → Click "Run Pipeline"
```
