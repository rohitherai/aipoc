# ⚡ Cache Testing Checklist

## ✅ LOCAL CACHE IS NOW ENABLED!

Config updated: `config.py` → `USE_LOCAL_CACHE = True`

---

## 🎯 How to Test (5 Minutes)

### Step 1: Start Server
```bash
cd AI_POC_5G_V1
python server.py
```

**Wait for output:**
```
[VectorDB] Local cache FORCED via config (USE_LOCAL_CACHE=True)
[LocalCache] Initialized: 0 vectors in cache
```

---

### Step 2: Open GUI
Open browser to:
```
http://localhost:5000/poc
```

You should see:
- Title: "5G KPI PoC — Interactive Tester"
- Button: "Run Pipeline"

---

### Step 3: First Run (19 seconds expected)
1. Click **"Run Pipeline"** button
2. Watch progress log in real-time
3. After ~19 seconds, you'll see:
   - RCA report
   - Fix plan
   - Timeline showing "19.06s"

**Check the log for:**
```
[LocalCache] Search found 0 matches (threshold=0.85)
[DEEP-PATH] no cached match
[OK] Stored in local cache
```

---

### Step 4: Check Cache File Created
Open terminal and run:
```bash
# Windows:
type vector_cache\vectors.jsonl

# Or view in editor:
# vector_cache/vectors.jsonl should have 1 JSON entry
```

**You should see:**
```json
{"id":"SMF_CPU_Usage_smf_smf-core-01","values":[...],"metadata":{...}}
```

---

### Step 5: Second Run (2 seconds expected) ⚡
1. Click **"Run Pipeline"** button AGAIN
2. Watch for FAST result
3. After ~2 seconds, you'll see:
   - SAME RCA as before (from cache)
   - SAME fix plan (from cache)
   - Timeline showing **"2.15s"** ⚡⚡⚡

**Check the log for:**
```
[LocalCache] Search found 1 matches (threshold=0.85)
[VectorDB] FAST-PATH: Cache hit (score: 0.998)
[FAST-PATH] Cache hit! Confidence: 0.998
```

**GUI will show:**
- Path: `fast` (instead of `deep`)
- Memory hit: `yes` (instead of `no`)
- Confidence: `0.998` (99.8% match)

---

## 📊 Expected Results

| Test | Time | Path | Cache Hit | LLM Called |
|------|------|------|-----------|-----------|
| Run 1 (SMF_CPU_Usage) | 19 sec | deep | ❌ | ✅ |
| Run 2 (SMF_CPU_Usage) | 2 sec | **fast** | **✅** | **❌** |
| Run 3 (UPF_Latency - different KPI) | 19 sec | deep | ❌ | ✅ |
| Run 4 (UPF_Latency again) | 2 sec | **fast** | **✅** | **❌** |

---

## 🔍 Verification Points

### ✅ Point 1: Cache File Exists
```bash
ls -la vector_cache/vectors.jsonl
```
Should show file exists after first run.

### ✅ Point 2: Cache Contains Data
```bash
wc -l vector_cache/vectors.jsonl
```
Should show increasing lines after each new KPI analysis.

### ✅ Point 3: GUI Shows Fast Path
In GUI, look for:
- Path: `fast` (not `deep`)
- Time: `~2 seconds` (not ~19)
- Memory hit: `yes` (not `no`)

### ✅ Point 4: Server Logs Show Cache Hit
Terminal should show:
```
[LocalCache] Search found 1 matches (threshold=0.85)
```

---

## 🎯 What You Should Observe

### Before Cache (if it didn't work):
```
Run 1: 19 seconds
Run 2: 19 seconds (LLM runs AGAIN)
Run 3: 19 seconds (LLM runs AGAIN)
Problem: No speedup!
```

### After Cache (NOW - what you'll see):
```
Run 1: 19 seconds (LLM runs, data stored to cache)
Run 2: 2 seconds (cache hit! LLM skipped!) ⚡⚡⚡
Run 3: 2 seconds (cache hit! LLM skipped!) ⚡⚡⚡
Success: 89% faster on repeats!
```

---

## 📁 Files to Check

### Cache Storage
```
vector_cache/
└── vectors.jsonl    ← Persistent cache file
```

### Server Logs
Look in terminal running `python server.py` for:
- `[LocalCache]` messages
- `[FAST-PATH]` indicators
- `[DEEP-PATH]` indicators

### GUI Progress Log
In browser at `http://localhost:5000/poc`, look for:
- "CACHE HIT" messages
- Path indicator: "fast" or "deep"
- Time metrics

---

## 🐛 Troubleshooting

### Problem: Still showing "deep" on second run
**Solution**: Make sure you're using EXACT same KPI name
- Run 1: SMF_CPU_Usage ✅
- Run 2: SMF_CPU_Usage ✅ (not "smf_cpu_usage" or "SMF CPU Usage")

### Problem: Cache file not created
**Solution**: Check permissions on `vector_cache/` directory
```bash
mkdir vector_cache
chmod 777 vector_cache
```

### Problem: Time still ~19 seconds on second run
**Solution**: Check config.py:
```python
USE_LOCAL_CACHE = True  # This line must exist
```

Restart server after adding it.

### Problem: Getting "use_local_cache: False" in logs
**Solution**: Restart Python server (changes to config require restart)
```bash
# Kill server
Ctrl+C

# Start again
python server.py
```

---

## 🚀 Success Criteria

You'll know it's working when:

1. ✅ Run pipeline twice with same KPI
2. ✅ First run takes ~19 seconds
3. ✅ Second run takes ~2 seconds
4. ✅ GUI shows "fast" path on second run
5. ✅ Terminal logs show "cache hit"
6. ✅ Cache file exists: `vector_cache/vectors.jsonl`

**All 6 checkmarks = SUCCESS! 🎉**

---

## 📚 For More Details

See: `CACHE_FLOW_GUIDE.md` - Complete node-by-node flow explanation

---

## ⏱️ Time Estimate for Testing

- Setup: 1 minute
- First run: 19 seconds
- Check cache file: 1 minute
- Second run: 2 seconds
- Verification: 2 minutes
- **Total: ~7 minutes**

Start now! 🚀
