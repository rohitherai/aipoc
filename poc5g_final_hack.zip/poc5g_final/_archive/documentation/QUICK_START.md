# Quick Start Guide - 5G KPI PoC

## Start the Server

```bash
cd AI_POC_5G_V1
python server.py
```

The server starts at: **http://localhost:5000**

---

## Access the GUI

### Main Dashboard
- **URL**: http://localhost:5000
- **Features**: KPI upload, pipeline analysis, approval workflow

### Analysis Interface  
- **URL**: http://localhost:5000/poc
- **Features**: Real-time pipeline logs, decision trees, RCA reports

---

## Test the Pipeline

### Option 1: Via GUI (Easiest)
1. Open http://localhost:5000/poc
2. Click "**Run Pipeline**"
3. Wait ~19 seconds
4. Review RCA and fix plan
5. Click "Approve" or "Reject"

### Option 2: Via API
```bash
# Run analysis
curl http://localhost:5000/api/analyze

# Approve a fix
curl -X POST http://localhost:5000/api/approve \
  -H "Content-Type: application/json" \
  -d '{"approval_id":"smf_SMF_CPU_Usage_7280","decision":"approved"}'
```

---

## Upload Custom KPI Data

### Upload CSV
```bash
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@kpis.csv"
```

### Upload JSON
```bash
curl -X POST http://localhost:5000/api/kpi/data \
  -H "Content-Type: application/json" \
  -d '[
    {"kpi_name":"CPU_Load","value":85,"threshold":70,"service":"smf"},
    {"kpi_name":"Memory_Usage","value":92,"threshold":80,"service":"upf"}
  ]'
```

---

## Check System Status

```bash
# Health check
curl http://localhost:5000/api/health

# Vector DB status
python diagnose_pinecone.py

# Proxy detection
python diagnose_proxy.py

# Memory stats
curl http://localhost:5000/api/memory/stats
```

---

## Important Notes

### ⚠️ Pinecone Caching
- **Status**: Blocked by corporate proxy
- **Impact**: All runs use deep-path analysis (~19 sec each)
- **Workaround**: System still works, just no fast-path optimization
- **Fix**: Connect to VPN or contact network team to whitelist Pinecone

### ✅ What Works
- KPI ingestion (files, APIs, dummy data)
- Service identification
- LLM-based root cause analysis
- Knowledge base integration
- Approval workflow
- Fix execution tracking
- History and memory

---

## File Locations

```
AI_POC_5G_V1/
├── server.py                    # Main Flask app
├── poc_ui.html                  # GUI interface
├── pipeline_orchestrator.py     # Pipeline logic
├── vector_db_wrapper.py         # Pinecone integration
├── local_vector_cache.py        # Local cache fallback
├── diagnose_pinecone.py         # Pinecone diagnostic
├── diagnose_proxy.py            # Proxy detection
├── requirements.txt             # Python dependencies
├── .env                         # API keys & credentials
├── PINECONE_STATUS_REPORT.md   # Detailed status report
└── data/
    ├── dummy_kpis.json         # Sample KPI data
    ├── kpi_history.json        # Past analyses
    └── kpi_memory.json         # Cached results
```

---

## Troubleshooting

### Server won't start
```bash
# Check if port 5000 is in use
netstat -ano | findstr :5000

# Kill existing process
taskkill /PID <PID> /F

# Try different port
FLASK_PORT=5001 python server.py
```

### GUI shows "No results"
- Check: Did pipeline complete? (Look for "COMPLETE" in logs)
- Wait: Pipeline takes ~19 seconds first time
- Approve: Some results require approval before display

### Pinecone not working
- **Expected**: Returns HTML (ZScaler proxy)
- **Workaround**: System uses deep-path analysis
- **Solution**: Run with VPN or contact network team

---

## Performance Expectations

| Scenario | Time | Cache |
|----------|------|-------|
| First analysis | ~19 sec | Miss |
| Repeat (no fix) | ~19 sec | Miss (proxy blocks) |
| With VPN | ~2 sec | Hit (if available) |

---

## Example Workflow

```
1. Open GUI: http://localhost:5000/poc
   ↓
2. Click "Run Pipeline"
   ├─ System fetches KPI data
   ├─ Identifies affected service
   ├─ Checks memory (currently always miss)
   ├─ Analyzes with LLM
   └─ Generates fix plan
   ↓
3. Review RCA and actions
   ↓
4. Approve or Reject
   ├─ Approved → Fix executed, recorded
   └─ Rejected → Issue documented
   ↓
5. View history and trends
```

---

## Support

For more details, see: **PINECONE_STATUS_REPORT.md**

Key sections:
- Problem diagnosis
- Solution options
- Performance metrics
- Next steps

---

## Quick Commands Reference

```bash
# Start server
python server.py

# Run diagnostics
python diagnose_pinecone.py
python diagnose_proxy.py
python test_cache_integration.py

# Check health
curl http://localhost:5000/api/health

# View memory
curl http://localhost:5000/api/memory/stats

# View KB
curl http://localhost:5000/api/kb/stats

# Upload data
curl -X POST http://localhost:5000/api/kpi/data \
  -H "Content-Type: application/json" \
  -d '[{"kpi_name":"TEST","value":90,"threshold":70,"service":"test"}]'

# Run analysis
curl http://localhost:5000/api/analyze
```

---

## Next Steps

1. **Try the GUI**: http://localhost:5000/poc
2. **Run a pipeline**: Click "Run Pipeline"
3. **Check status**: See PINECONE_STATUS_REPORT.md
4. **Test with VPN** (optional): Verify Pinecone if access available
5. **Deploy**: Ready for production with network configuration
