# 🚀 QUICK START - 2 MINUTES TO DEMO

## Step 1: Start Dashboard (30 seconds)

```powershell
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1
python dashboard_server.py
```

**Expected:**
```
 * Running on http://127.0.0.1:5000
 * Press CTRL+C to quit
```

---

## Step 2: Open Browser (10 seconds)

```
http://localhost:5000
```

You should see the professional blue dashboard with:
- System architecture diagram
- Pipeline flow visualization
- KPI stream monitor
- Metrics and controls

---

## Step 3: Test It (60+ seconds)

### Quick Test: Single KPI
```
Click: "▶️ Run Single KPI"

Watch:
  ✅ Pipeline stages light up
  ✅ KPI appears in stream
  ✅ Metrics increment
  ✅ Console shows logs
  
Takes: 2-15 seconds depending on cache
```

### Full Demo: KPI Stream
```
Click: "📡 Start KPI Stream (60s)"

Watch:
  ✅ Button changes to "⏸️ Stop Stream"
  ✅ KPIs process every 10 seconds
  ✅ Green ✅ = Cache Hit (fast)
  ✅ Red 🔬 = Deep Path (slow)
  ✅ Cache hit rate climbs
  ✅ 6 total KPIs over 60 seconds
  
Takes: 60 seconds for full demo
```

---

## What You're Seeing

### Architecture (6 Components)
```
📡 KPI Agent → 🔍 Embedding → 💾 Vector DB
                ↓
         🧠 LLM Analysis
                ↓
         ✅ Auto-Approval
                ↓
         📈 Execution
```

### Pipeline (6 Stages)
```
1. KPI Input
2. Embedding (text → vector)
3. Cache Search (find similar)
4. LLM or Cache (new or cached)
5. Approval (auto-approve)
6. Storage (save for next time)
```

### KPI Stream
```
✅ CACHE HIT = Green border
   - Found similar problem
   - Returned cached solution
   - 2-3 seconds
   - No LLM call

🔬 DEEP PATH = Red border
   - New/different problem
   - Called LLM for analysis
   - 15+ seconds
   - Stored for next time
```

### Metrics
```
Total: How many KPIs processed
Hits: How many were cache hits
Avg Time: Average response time
Errors: How many failed
Cache Rate: Percentage of hits
```

### Console
```
🟢 Green = Success (✅)
🟡 Orange = Warning (⚠️)
🔴 Red = Error (❌)
🔵 Gray = Info (ℹ️)
```

---

## Expected Behavior

### Single KPI Run
```
[12:34:56] 🚀 Triggering single KPI execution...
[12:34:58] ✅ CACHE HIT for SMF_CPU_Usage (Score: 0.95)
[12:34:58] ✅ AUTO-APPROVED (Demo Mode)
[12:34:58] 💾 STORED: YES
[12:34:59] ✅ Execution completed successfully
```

### KPI Stream (60 seconds)
```
T=0s:   [12:35:00] 🚀 Triggering KPI #1...
T=2s:   [12:35:02] ✅ CACHE HIT - SMF_CPU_Usage
T=10s:  [12:35:10] 🚀 Triggering KPI #2...
T=15s:  [12:35:15] 🔬 DEEP PATH - UPF_Latency
T=20s:  [12:35:20] 🚀 Triggering KPI #3...
T=22s:  [12:35:22] ✅ CACHE HIT - SMF_CPU_Usage (same as #1)
T=30s:  [12:35:30] 🚀 Triggering KPI #4...
T=47s:  [12:35:47] 🔬 DEEP PATH - AMF_Sessions
T=50s:  [12:35:50] 🚀 Triggering KPI #5...
T=52s:  [12:35:52] ✅ CACHE HIT - UPF_Latency (same as #2)

Result:
  Total: 6 KPIs
  Hits: 3 (50%)
  Misses: 3 (50%)
  Cache Hit Rate: 50%
  Avg Time: 8.5s
```

---

## Key Indicators

### Pipeline Lights Up
```
🟦 Blue = Not executed (waiting)
🟨 Yellow = In progress (processing)
🟩 Green = Complete (done)
🔴 Red = Error (failed)
```

### KPI Colors
```
🟢 Green border + ✅ Badge = CACHE HIT (instant)
🔴 Red border + 🔬 Badge = DEEP PATH (LLM call)
```

### Status Text
```
✅ AUTO-APPROVED: YES = Automatic approval worked
💾 STORED: YES = Data saved for next time
⏱️ Processing time: 2-15s = How long it took
```

---

## Most Important Things to Show

### Intelligence #1: Semantic Caching
```
Run 1: SMF_CPU_Usage = 95% 
  → 🔬 DEEP PATH → 15 seconds → Call LLM → Cache result

Run 2: SMF_CPU_Usage = 92%
  → ✅ CACHE HIT → 2 seconds → Return cached
  
SAME problem = INSTANT solution (7x faster)
Shows the system LEARNS and IMPROVES
```

### Intelligence #2: Cost Savings
```
6 KPIs, 3 cache hits = 50% savings
- LLM calls avoided: 3
- Cost saved: $0.15 (3 × $0.05)
- Time saved: 36 seconds
- Over 1000 KPIs/day: $150 saved/day
```

### Intelligence #3: Automation
```
Every KPI shows: "✅ AUTO-APPROVED"
No human needed
24/7 operation
Perfect for unattended infrastructure
```

---

## Troubleshooting

### "Connection refused"
```
❌ Server not running
✅ Run: python dashboard_server.py
```

### "404 Not Found"
```
❌ Wrong file name
✅ Check: unified_dashboard.html exists
```

### "No KPIs appear"
```
❌ API endpoint not working
✅ Check: /api/inject-fault endpoint in dashboard_server.py
```

### Button doesn't respond
```
❌ Browser cache
✅ Press: F5 to refresh
❌ JavaScript error
✅ Check: Browser console (F12)
```

---

## Full 60-Second Script

```
"Let me show you our intelligent AIOps system.

[Open dashboard]

This dashboard shows our 6-stage intelligent pipeline:
- Takes a KPI problem
- Converts to AI embedding
- Searches database for similar issues
- Either returns cached solution or asks our LLM
- Auto-approves and stores for next time

[Click: Run Single KPI]

Watch the pipeline light up. See all 6 stages execute in real-time.
This took 15 seconds because it was a new problem. 
The system called our AI, generated a solution, approved it, 
and stored it for next time.

[Click: Run Single KPI again with same type]

See that? Cache HIT! 2 seconds! Same problem came up again, 
and we returned our cached solution instantly. 
No AI call. Zero cost. That's intelligence.

[Click: Start KPI Stream]

Now watch continuous operation. This will process KPIs every 10 seconds 
for 60 seconds, simulating real production traffic.

[Point to incoming KPIs]

See the green check marks? Those are cache hits. 
The system is learning the problem patterns and returning instant solutions.

[Point to metrics]

Look at the cache hit rate climbing. By the end, 50% of problems 
are solved from cache. That's 50% cost savings and instant response.

[Show console]

Every log is green - all successful. Zero errors. Zero manual intervention.
This runs 24/7 unattended. This is what intelligent automation looks like.
"
```

---

## One-Click Demo Command

Copy-paste this to do everything at once:

```powershell
# Terminal 1: Start server
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1
python dashboard_server.py

# Terminal 2: Open browser (after server starts)
start http://localhost:5000

# Then click "Start KPI Stream (60s)" button
```

---

## What Each Button Does

| Button | Action | Duration | Demo Value |
|--------|--------|----------|-----------|
| ▶️ Run Single KPI | Process one random KPI | 2-15s | Shows pipeline stages |
| 📡 Start KPI Stream | Process 6 KPIs every 10s | 60s | Shows cache effectiveness |
| 🗑️ Clear Logs | Empty console | instant | Clean slate |
| ↺ Reset Metrics | Reset counters to 0 | instant | New demo run |

---

## Success Indicators

✅ All of these should happen:

- [ ] Dashboard loads in browser
- [ ] Status bar shows "System Status: READY"
- [ ] Button "Run Single KPI" is clickable
- [ ] On click, pipeline stages light up
- [ ] KPI appears in stream within 1 second
- [ ] Status shows ✅ CACHE HIT or 🔬 DEEP PATH
- [ ] Console shows green success logs
- [ ] Metrics increment (Total, Hits, etc.)
- [ ] Second similar KPI shows CACHE HIT
- [ ] Cache hit rate shows >0%
- [ ] Stream button works for continuous run

If all ✅, your system is working perfectly!

---

## Ready?

```bash
# 1. Start server
python dashboard_server.py

# 2. Open browser
http://localhost:5000

# 3. Click buttons to see intelligence in action!
```

**Recommended demo: Click "Start KPI Stream" for impressive 60-second continuous run!** 🚀
