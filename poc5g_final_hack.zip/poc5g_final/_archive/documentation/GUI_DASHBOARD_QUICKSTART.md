# GUI Dashboard Quick Start

## 5-Minute Setup

### 1. Install React (if not already done)
```bash
npm install react react-dom
```

### 2. Mount Dashboard
```jsx
import GUIDashboard from './gui_dashboard';

export default function App() {
  return <GUIDashboard />;
}
```

### 3. View Dashboard
```bash
npm start
```

Open browser → http://localhost:3000

---

## Key Features at a Glance

| Feature | What It Does |
|---------|-------------|
| **KPI Cards** (left) | Real-time metrics with trend sparklines. Click when red = fault. |
| **Pipeline Stages** (center) | 7-step visualization: Ingest → Embed → Cache → Decision → RCA → Exec → Learn |
| **Approval Modal** | Shows RCA analysis and proposed fix. Approve/Reject to execute. |
| **Live Log** (right) | Timestamped events with color coding (green=success, orange=warning, blue=info). |
| **Metrics** (top-right) | Total runs, cache hit rate, average fix time. |

---

## How It Works

### Auto-Demo Mode (Default)
1. **Dashboard boots** with 5 KPI cards streaming fake data
2. **Auto-fault injection** triggers every 8-14 seconds on random KPI
3. **Pipeline executes** automatically:
   - First run → DEEP PATH (LLM analysis)
   - Second run (same KPI) → FAST PATH (cached result)
4. **Approval modal** appears → you approve/reject
5. **KB entry** stored to ChromaDB for future cache hits

### Manual Trigger
- Click any red (faulted) KPI card to manually start pipeline
- Non-faulted cards are non-interactive

---

## Configuration (Easy Changes)

### Change KPI Thresholds
```javascript
// Line 10-14 in gui_dashboard.js
const KPI_POOL = [
  { 
    kpi_name: "SMF_CPU_Usage",
    threshold: 70,  // ← Change this
    baseline: 45,   // ← Or this
    ...
  }
];
```

### Adjust Fault Frequency
```javascript
// Line 51-52
const TIMING = {
  AUTO_FAULT: { min: 5000, max: 8000 },  // ← Every 5-8 seconds
  ...
};
```

### Change Colors
```javascript
// Line 54-60
const COLORS = {
  DONE: "#00e5a0",    // Green (success)
  ACTIVE: "#00c8ff",  // Cyan (active)
  WARN: "#ff9500",    // Orange (warning)
  FAULT: "#ff4444",   // Red (fault)
};
```

### Modify RCA/Fix Text
```javascript
// Line 18-24 and Line 26-31
const RCA_TEXTS = {
  SMF_CPU_Usage: "Your custom RCA text here...",
};

const FIX_TEXTS = {
  SMF_CPU_Usage: "Your custom fix procedure here...",
};
```

### Adjust Animation Speed
```javascript
// Line 41-52 TIMING
const TIMING = {
  KPI_STREAM: 1200,              // KPI update frequency
  STAGE_RCA_DEEP: 400,           // LLM analysis duration
  STAGE_LEARNING: 600,           // KB storage duration
  TOAST_DURATION: 4500,          // Notification lifespan
};
```

---

## Data Flow

```
Real-time KPI values (5 services)
    ↓
Sparkline chart + numerical display
    ↓
[Fault detected OR manual click]
    ↓
Pipeline orchestration (7 stages):
  ├─ Ingest: Parse KPI
  ├─ Embed: Vector representation (Capgemini API)
  ├─ Cache: Search ChromaDB
  ├─ Decision: Fast (score ≥0.85) or Deep (<0.85)
  ├─ RCA: Skip if fast-path, LLM analysis if deep-path
  ├─ Execution: Operator approval + fix application
  └─ Learning: Store to KB for future cache hits
    ↓
Metrics updated (run count, cache hit rate, avg time)
    ↓
Toast notification + KB entry ID
```

---

## API Endpoints to Integrate

When you're ready to connect to real services, add these API calls:

### 1. Embedding API
```javascript
// Replace in Stage 1 (Embed)
const embedResponse = await fetch(
  'https://openai.generative.engine.capgemini.com/v1/embeddings',
  {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${API_KEY}` },
    body: JSON.stringify({
      model: 'amazon.titan-embed-text-v2:0',
      input: `${kpi.kpi_name}|${kpi.service}|${kpi.host}`
    })
  }
);
```

### 2. ChromaDB Search
```javascript
// Replace in Stage 2 (Cache)
const cacheResponse = await fetch(
  'http://localhost:8000/api/cache/search',
  {
    method: 'POST',
    body: JSON.stringify({
      vector: embedResponse.embedding,
      threshold: 0.85
    })
  }
);
```

### 3. RCA LLM Call
```javascript
// Replace in Stage 4 (RCA)
const rcaResponse = await fetch(
  'http://localhost:8000/api/rca/analyze',
  {
    method: 'POST',
    body: JSON.stringify({
      kpi: kpi.kpi_name,
      logs: recentLogs,
      metrics: historicalMetrics
    })
  }
);
```

### 4. Execute Fix
```javascript
// Replace in Stage 5 (Execution)
await fetch(
  'http://localhost:8000/api/fix/execute',
  {
    method: 'POST',
    body: JSON.stringify({
      kpi: kpi.kpi_name,
      fix: approvalData.fix,
      approved: true
    })
  }
);
```

### 5. Store to KB
```javascript
// Replace in Stage 6 (Learning)
const storeResponse = await fetch(
  'http://localhost:8000/api/kb/store',
  {
    method: 'POST',
    body: JSON.stringify({
      kpi: kpi.kpi_name,
      rca: approvalData.rca,
      fix: approvalData.fix,
      confidence: confidence
    })
  }
);
```

---

## Real-Time KPI Streaming (WebSocket)

Replace mock KPI stream with live Prometheus data:

```javascript
// Add to useEffect in main component
useEffect(() => {
  const ws = new WebSocket('ws://localhost:9090/metrics');
  
  ws.onmessage = (event) => {
    const kpiUpdate = JSON.parse(event.data);
    setHistories(prev => ({
      ...prev,
      [kpiUpdate.name]: [
        ...prev[kpiUpdate.name],
        kpiUpdate.value
      ].slice(-20)  // Keep last 20 values
    }));
  };
  
  ws.onerror = () => console.error('WebSocket failed');
  
  return () => ws.close();
}, []);
```

---

## Customization Examples

### Example 1: Add New KPI (gNB RRC Release Rate)
```javascript
const KPI_POOL = [
  // ... existing
  {
    kpi_name: "gNB_RRC_Release_Rate",
    service: "gnb",
    host: "gnb-site-12",
    threshold: 5.0,
    unit: "calls/sec",
    baseline: 0.8,
    spike: 18.5
  }
];

const RCA_TEXTS = {
  gNB_RRC_Release_Rate: "Abnormal RRC connection release rate on gNB-site-12. Connected user count drop indicates radio link failures. Likely cause: strong interference on band n78."
};

const FIX_TEXTS = {
  gNB_RRC_Release_Rate: "Enable interference mitigation algorithm. Increase RRC connection reestablishment timer to 300ms. Activate DL power adjustment on affected sector."
};
```

### Example 2: Slower Animation (for slower networks)
```javascript
const TIMING = {
  KPI_STREAM: 2000,        // Update every 2s instead of 1.2s
  STAGE_EMBED: 1500,       // Longer API simulation
  STAGE_RCA_DEEP: 800,     // More realistic LLM time
  STAGE_LEARNING: 1000,    // Longer storage simulation
};
```

### Example 3: Dark/Light Theme Toggle
```javascript
const [isDark, setIsDark] = useState(true);

const COLORS = isDark ? {
  DONE: "#00e5a0",
  ACTIVE: "#00c8ff",
} : {
  DONE: "#00aa44",
  ACTIVE: "#0055ff",
};

// Add toggle button to header
<button onClick={() => setIsDark(!isDark)}>
  {isDark ? '☀️ Light' : '🌙 Dark'}
</button>
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Dashboard blank | Check React DevTools for errors. Verify `<style>` tag injected. |
| KPI values not updating | Check browser console. Verify `streamInterval` useEffect running. |
| Approval modal stuck | Try F12 DevTools → Console → check for JS errors. |
| Animations jerky | Disable other browser tabs. Check GPU acceleration settings. |
| Red KPI card not clickable | Ensure `faultedKpi` is set. Try clicking again. |
| Logs not scrolling | Check `logRef` ref is attached to log panel div. |

---

## Next Steps

1. ✅ Dashboard running locally with mock data
2. 🔲 Connect to real Prometheus KPI stream
3. 🔲 Connect to Capgemini embedding API
4. 🔲 Connect to ChromaDB instance
5. 🔲 Connect to LLM (RCA analysis)
6. 🔲 Connect to fix executor (NOC automation)
7. 🔲 Deploy to production Kubernetes

---

## Support Resources

- **React Docs**: https://react.dev
- **IBM Plex Font**: https://fonts.google.com/specimen/IBM+Plex+Mono
- **Capgemini API**: See `API_KEY_QUICK_REFERENCE.md`
- **ChromaDB**: See `CHROMADB_SUMMARY.md`

---

**Last Updated**: 2024 | **Dashboard Version**: 2.0-refactored
