# 🔑 API Configuration Quick Card

## Current Status: ✅ SAFE TO SHARE
All API keys removed and replaced with placeholders.

---

## 📋 What You Need to Add

```
┌─────────────────────────────────────────┐
│ 3 API Keys Required                      │
├─────────────────────────────────────────┤
│ 1. Capgemini GenAI Key                   │
│    Purpose: LLM + Embeddings             │
│    Length: ~40 chars                     │
│    Source: generative.engine.capgemini.com
│                                          │
│ 2. Pinecone API Key                      │
│    Purpose: Vector database access       │
│    Length: ~60+ chars (starts pcsk_)     │
│    Source: app.pinecone.io               │
│                                          │
│ 3. Pinecone Index Host                   │
│    Purpose: Database connection          │
│    Format: https://index-name-xxx.svc... │
│    Source: app.pinecone.io               │
└─────────────────────────────────────────┘
```

---

## 🚀 3-Minute Setup

### 1. Get Your Keys

| Service | URL | Copy |
|---------|-----|------|
| **Capgemini** | https://generative.engine.capgemini.com | Full API Key |
| **Pinecone Keys** | https://app.pinecone.io/api-keys | API Key |
| **Pinecone Indexes** | https://app.pinecone.io/indexes | Host URL |

### 2. Edit .env File

**Location:** `AI_POC_5G_V1/.env`

**Find & Replace:**
```env
CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here
    ↓ Replace with
CAPGEMINI_GENAI_API_KEY=<your_actual_capgemini_key>

PINECONE_API_KEY=your_pinecone_api_key_here
    ↓ Replace with
PINECONE_API_KEY=<your_actual_pinecone_key>

PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io
    ↓ Replace with
PINECONE_INDEX_HOST=<your_actual_index_host>
```

### 3. Verify

```powershell
cd AI_POC_5G_V1
python diagnose_pinecone.py
python main.py
```

---

## 📝 Complete .env Template

```env
# GenAI API Key (LLM + Embeddings)
CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here

# Pinecone API Key (Vector Database)
PINECONE_API_KEY=your_pinecone_api_key_here

# Pinecone Index Host (Database Connection)
PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io

# Embedding Configuration (Pre-configured - no change needed)
EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
EMBEDDING_BASE_URL=https://openai.generative.engine.capgemini.com/v1

# Flask (Pre-configured - no change needed)
FLASK_ENV=development
FLASK_DEBUG=True
```

---

## 🎯 Step-by-Step

### Step 1: Capgemini GenAI Key ⓵
```
1. https://generative.engine.capgemini.com/ → Login
2. Settings → API Keys
3. Create or View API Key
4. Copy full key
5. Paste in .env: CAPGEMINI_GENAI_API_KEY=<key>
```

### Step 2: Pinecone API Key ⓶
```
1. https://app.pinecone.io/ → Login
2. Left sidebar → API Keys
3. Create or View Key
4. Copy full key (shown only once!)
5. Paste in .env: PINECONE_API_KEY=<key>
```

### Step 3: Pinecone Index Host ⓷
```
1. https://app.pinecone.io/ → Login
2. Left sidebar → Indexes
3. Find your index (create if needed)
4. Copy Host URL from Host column
5. Paste in .env: PINECONE_INDEX_HOST=<host>
```

### Step 4: Verify ✅
```powershell
python diagnose_pinecone.py
# Should show: ✅ All checks passed
```

---

## 🚨 Common Mistakes

| ❌ Wrong | ✅ Correct |
|---------|-----------|
| Partial key copy | Copy full key left to right |
| Key in quotes | No quotes around key value |
| Typos in variable names | Use exact names (case-sensitive) |
| Old key not deleted | Delete old key from console |
| .env not saved | Save with Ctrl+S |
| Terminal not restarted | Restart after editing .env |

---

## 🔒 Security Checklist

- [ ] .env file NOT in Git (in .gitignore)
- [ ] .env file NOT shared with others
- [ ] Keys are full length (not truncated)
- [ ] Old keys revoked in consoles
- [ ] No hardcoded keys in Python files
- [ ] .env file exists in AI_POC_5G_V1/ folder only

---

## 📊 Where Keys Are Used

```
┌─────────────────────────┐
│ CAPGEMINI_GENAI_API_KEY │
└──────────────┬──────────┘
               ├→ analysis_agent.py (LLM RCA)
               └→ vector_db_wrapper.py (Embeddings)

┌────────────────────────┐
│ PINECONE_API_KEY       │
│ PINECONE_INDEX_HOST    │
└──────────────┬─────────┘
               ├→ vector_db_wrapper.py (Cache search)
               └→ vector_db_wrapper.py (Store embeddings)
```

---

## ✅ Test Commands

```powershell
# Verify keys are loaded
python -c "import os; print('GenAI:', '✅' if os.getenv('CAPGEMINI_GENAI_API_KEY') else '❌'); print('Pinecone:', '✅' if os.getenv('PINECONE_API_KEY') else '❌')"

# Test Pinecone connection
python diagnose_pinecone.py

# Test full pipeline
python main.py

# Check cache functionality
python diagnose_cache.py
```

---

## 📖 Full Documentation

For detailed setup, troubleshooting, and configuration:
→ See **COMPLETE_API_SETUP_GUIDE.md**

---

## 🎉 Ready?

1. ✅ Get your 3 API keys from consoles
2. ✅ Edit `.env` file with your keys
3. ✅ Save file
4. ✅ Run `python diagnose_pinecone.py`
5. ✅ See ✅ symbols = Success! 🚀
