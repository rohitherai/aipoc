# ChromaDB Persistence - Quick Reference Guide

## How to Use validate_persistence()

### Basic Usage
```python
from vector_db_wrapper import VectorDBWrapper

# Create DB instance
db = VectorDBWrapper()

# Check persistence status
status = db.validate_persistence()

print(status["status_message"])      # Human-readable status
print(f"Records: {status['total_records']}")  # Number of stored KPIs
print(f"DB Path: {status['db_path']}")        # Storage directory
print(f"Valid: {status['is_valid']}")         # Is persistence working
```

### Example Output

**First Run (Empty DB)**:
```
📂 Loading ChromaDB from: ./chroma_db
⚠️  Empty DB — no persisted data found (first run or cleared)
```

**After Storage**:
```
✅ Persistence verified — 1 KPI records in ChromaDB
DB Path: C:\...\chroma_db
Valid: True
```

---

## Demo Scenario

### Step 1: Initial Run
```python
db = VectorDBWrapper()
# Output: "⚠️  Empty DB — no persisted data found"

# Search (will be empty)
result = db.search({"kpi_name": "CPU_UTILIZATION"})
# Output: "🔍 DEEP PATH (no cache found)"

# Store a solution
db.store({
    "kpi": {"kpi_name": "CPU_UTILIZATION", ...},
    "service": "SMF",
    "root_cause": "High memory pressure",
    "fix": {"action": "restart_service"}
})
# Output: "💾 Stored vector in ChromaDB"
#         "💾 Data persisted to disk (automatic)"
```

### Step 2: After Restart
```python
db = VectorDBWrapper()
# Output: "✅ Persistence verified — 1 KPI records loaded from previous run"

# Same search (will hit cache)
result = db.search({"kpi_name": "CPU_UTILIZATION"})
# Output: "✅ FAST PATH (cache hit) — Score 1.0000 > 0.85 threshold"
#         "💾 Reusing cached resolution"

# Result contains:
# {
#     "score": 1.0,
#     "root_cause": "High memory pressure",
#     "fix": {"action": "restart_service"}
# }
```

---

## Key Thresholds

| Score | Decision | Action |
|-------|----------|--------|
| > 0.85 | ✅ FAST PATH | Use cached resolution |
| 0.70-0.85 | 🔍 DEEP PATH | Force fresh RCA |
| < 0.70 | 🔍 DEEP PATH | Force fresh RCA |

---

## Storage Location

**Database Path**: `./chroma_db/`

**Structure**:
```
chroma_db/
├── {collection-id}/
│   ├── data.db (embeddings)
│   ├── header.pkl (metadata)
│   └── index/ (HNSW index files)
```

**Automatic Features**:
- Auto-created if missing
- Auto-persisted after each upsert
- Auto-reloaded on initialization
- No manual flush required

---

## Common Scenarios

### Check if Data Persisted
```python
validation = db.validate_persistence()
if validation["total_records"] > 0:
    print(f"✅ {validation['total_records']} KPI records stored")
else:
    print("⚠️  No records in database")
```

### Verify Persistence Before Using Cache
```python
status = db.validate_persistence()
if not status["is_valid"]:
    print("❌ Persistence error, falling back to fresh analysis")
    # Force DEEP PATH, don't use cache
```

### Monitor Database Growth
```python
before = db.validate_persistence()["total_records"]
# ... run pipeline ...
after = db.validate_persistence()["total_records"]
print(f"Added {after - before} KPI vectors")
```

---

## Troubleshooting

### Issue: "⚠️ ChromaDB not initialized (mock mode)"
- **Cause**: ChromaDB library not installed
- **Fix**: `pip install chromadb`

### Issue: Empty database after restart
- **Cause**: Permission issues or disk full
- **Fix**: Check write permissions on `./chroma_db/` directory

### Issue: Cache not being used (always DEEP PATH)
- **Cause**: Score < 0.85 threshold
- **Fix**: Check embedding quality or adjust threshold in code

---

## Integration with Pipeline

### In pipeline_orchestrator.py
```python
# Check cache before RCA
from vector_db_wrapper import VectorDBWrapper
db = VectorDBWrapper()

search_result = db.search(kpi)
validation = db.validate_persistence()

if search_result and search_result["score"] > 0.85:
    print("✅ FAST PATH — Using cached solution")
    # Skip RCA, use cache
else:
    print("🔍 DEEP PATH — Running fresh RCA")
    # Run RCA as normal
```

---

## Performance Impact

- **First Run**: RCA analysis (slow) → Cache write (~10ms)
- **Subsequent Runs**: Cache lookup (~5ms) → Use cached solution
- **Speedup**: ~5-10x faster when cache hits

---

## Testing

Run the validation test suite:
```bash
python test_persistence_validation.py
```

Expected output:
```
✅ PASS: Run 1 (First Execution)
✅ PASS: Run 2 (Restart Simulation)
✅ PASS: Different KPI Test
✅ PASS: validate_persistence() Function

Total: 4/4 tests passed
```

---

## Notes

- Persistence is **automatic** - no manual calls required
- Data stored in **dense vector format** (384 dimensions)
- Embeddings from **Capgemini GenAI** (with hash fallback)
- Collection uses **cosine similarity** for matching
- All operations are **fail-safe** (graceful degradation on errors)
