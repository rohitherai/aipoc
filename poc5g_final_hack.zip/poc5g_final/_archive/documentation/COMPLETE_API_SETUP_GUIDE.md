# 🔐 Complete API Setup Guide - GenAI, Embedding & Pinecone

## Overview

Your AIOps pipeline uses **3 external APIs**:

| API | Purpose | Status |
|-----|---------|--------|
| **Capgemini GenAI** | LLM for RCA analysis + Embeddings | ✅ Removed |
| **Embedding API** | Text vectorization (same as GenAI) | ✅ Removed |
| **Pinecone** | Vector database for semantic search | ✅ Removed |

All API keys have been **REMOVED** and replaced with placeholders. This guide shows you how to add them back.

---

## 📊 What Each API Does

### 1️⃣ Capgemini GenAI API
```
Used by: LLM RCA Analysis
Function: Generates root cause analysis and fixes for KPI issues
Example: "SMF_CPU_Usage = 95%" → "Restart SMF service"
Location in code: analysis_agent.py
```

### 2️⃣ Embedding API (Capgemini)
```
Used by: Vector DB Embedding
Function: Converts KPI text to embeddings for semantic search
Example: "SMF_CPU_Usage|smf|host1" → [0.234, -0.567, ...]
Location in code: vector_db_wrapper.py
Note: Uses SAME API key as GenAI
```

### 3️⃣ Pinecone API
```
Used by: Vector Database Storage & Search
Function: Stores embeddings and finds similar KPIs
Example: Query embedding → Find similar cached KPIs → Get cached RCA
Location in code: vector_db_wrapper.py
```

---

## 🔄 Architecture

```
KPI Input
    ↓
[Embedding API] Convert to vector → Uses CAPGEMINI_GENAI_API_KEY
    ↓
[Pinecone] Search cache → Uses PINECONE_API_KEY + PINECONE_INDEX_HOST
    ↓
├─ Cache HIT → Return cached RCA ✅ (No LLM call)
└─ Cache MISS → Call LLM → Uses CAPGEMINI_GENAI_API_KEY
                    ↓
                [GenAI API] Generate RCA
                    ↓
                Store embedding + RCA in Pinecone
```

---

## 📋 Current .env Status

**File:** `AI_POC_5G_V1/.env`

```
# ✅ PLACEHOLDER (needs your key)
CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here

# ✅ PLACEHOLDER (needs your key)
PINECONE_API_KEY=your_pinecone_api_key_here

# ✅ PLACEHOLDER (needs your index host)
PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io

# ⚙️ ALREADY CONFIGURED (no secrets)
EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
EMBEDDING_BASE_URL=https://openai.generative.engine.capgemini.com/v1
```

---

## 🚀 STEP-BY-STEP SETUP PROCEDURE

### STEP 1: Get Capgemini GenAI API Key

**Path:** Capgemini Console → API Keys

```
1. Go to: https://generative.engine.capgemini.com/
2. Log in with your Capgemini credentials
3. Click: "API Keys" (or "Settings" → "API Keys")
4. Click: "Create API Key" or "View Existing Keys"
5. Copy the FULL API key (it will be ~40 alphanumeric characters)
6. Save it temporarily (e.g., in a text editor)

Example format: PAj75Tdrtn9n6F6bSdVEo9v85zh1dijp62GvGoGv
```

**⚠️ Important:**
- Copy the FULL key from left to right
- Don't miss any characters
- This key is case-sensitive
- Never share it with others

---

### STEP 2: Get Pinecone API Key & Index Host

**Path:** Pinecone Console → API Keys & Indexes

#### 2A: Get API Key
```
1. Go to: https://app.pinecone.io/
2. Log in with your Pinecone account
3. Left sidebar → Click "API Keys"
4. Click "Create API Key" or copy existing
5. Copy the FULL API key
6. ⚠️ WARNING: Pinecone only shows the key ONCE
   - Save it in your password manager
   - If lost, regenerate and delete old one

Example format: pcsk_3bJovq_5UPhr8UcamTE6PVxWw5oGbH5Ygy7PArVo8UPtxd9BFa5swTPpBvJA9GdYdTHocn
```

#### 2B: Get Index Host
```
1. Go to: https://app.pinecone.io/
2. Left sidebar → Click "Indexes"
3. Find your index (or create one if needed)
4. Look at the "Host" column
5. Copy the host URL (it looks like a domain)

Example format: https://kpi-index-c2y8jh7.svc.aped-4627-b74a.pinecone.io
```

**Index Creation (if needed):**
```
1. In Pinecone console → "Indexes" tab
2. Click "Create Index"
3. Name: kpi-index
4. Dimension: 384 (for Amazon Titan embeddings)
5. Metric: Cosine
6. Wait for creation (~2-3 minutes)
7. Copy the Host URL
```

---

### STEP 3: Edit .env File

**Open:** `AI_POC_5G_V1/.env` in VS Code or text editor

**Find these lines:**
```env
CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here
PINECONE_API_KEY=your_pinecone_api_key_here
PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io
```

**Replace with YOUR keys from Step 1 & 2:**
```env
CAPGEMINI_GENAI_API_KEY=<your_actual_capgemini_key_from_step_1>
PINECONE_API_KEY=<your_actual_pinecone_key_from_step_2a>
PINECONE_INDEX_HOST=<your_actual_index_host_from_step_2b>
```

**Example (with dummy values):**
```env
CAPGEMINI_GENAI_API_KEY=abc123defg456hij789klm
PINECONE_API_KEY=pcsk_abc123defg456hij789klm123defg456hij789klm
PINECONE_INDEX_HOST=https://my-kpi-index-a1b2c3d.svc.pinecone.io
```

**Save:** Press Ctrl+S

---

### STEP 4: Verify All Three APIs

#### Test 1: Check if Keys Are Loaded
```powershell
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1
python -c "import os; print('GenAI:', 'OK' if os.getenv('CAPGEMINI_GENAI_API_KEY') else 'MISSING'); print('Pinecone:', 'OK' if os.getenv('PINECONE_API_KEY') else 'MISSING')"
```

Expected output:
```
GenAI: OK
Pinecone: OK
```

#### Test 2: Test Pinecone Connection
```powershell
python diagnose_pinecone.py
```

Expected output:
```
✅ Pinecone Configuration Check
✅ API Key: Found
✅ Index Host: Found
✅ Connection: Success
✅ Indexes: [your-index-name]
```

#### Test 3: Test Full Pipeline
```powershell
python main.py
```

Expected output:
```
🚀 AIOPS PIPELINE STARTED
✅ FAST PATH - CACHE HIT!
🤖 AUTO-MODE: 1 fix(es) will be auto-approved
✅ AUTO-APPROVED (Demo Mode)
💾 stored_in_memory: true
✅ Pipeline complete!
```

---

## 🧪 Complete Testing Checklist

| Test | Command | Expected Result |
|------|---------|-----------------|
| GenAI Key Loaded | `python -c "import os; print(os.getenv('CAPGEMINI_GENAI_API_KEY')[:20])"` | Shows 20 chars of key |
| Pinecone Key Loaded | `python -c "import os; print(os.getenv('PINECONE_API_KEY')[:20])"` | Shows 20 chars of key |
| Pinecone Connectivity | `python diagnose_pinecone.py` | ✅ Connection: Success |
| LLM + Embeddings | `python main.py` | Pipeline completes successfully |
| Cache Works | Run `main.py` twice | Second run shows CACHE HIT |

---

## 📝 Configuration Map

### What Each Variable Does

```
┌─────────────────────────────────────────────────────────┐
│ CAPGEMINI_GENAI_API_KEY                                 │
├─────────────────────────────────────────────────────────┤
│ Used by:                                                │
│  1. analysis_agent.py → LLM RCA generation             │
│  2. vector_db_wrapper.py → Text embeddings             │
│                                                          │
│ Format: ~40 alphanumeric characters                     │
│ Where: Capgemini console → API Keys                     │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ PINECONE_API_KEY                                        │
├─────────────────────────────────────────────────────────┤
│ Used by:                                                │
│  1. vector_db_wrapper.py → Search cache in Pinecone    │
│  2. Store embeddings in Pinecone                       │
│                                                          │
│ Format: ~60+ chars, starts with pcsk_                   │
│ Where: Pinecone console → API Keys                      │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ PINECONE_INDEX_HOST                                     │
├─────────────────────────────────────────────────────────┤
│ Used by:                                                │
│  1. vector_db_wrapper.py → Connect to Pinecone index   │
│                                                          │
│ Format: https://index-name-xxxxx.svc.pinecone.io       │
│ Where: Pinecone console → Indexes → Host column        │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ EMBEDDING_MODEL & EMBEDDING_BASE_URL                    │
├─────────────────────────────────────────────────────────┤
│ Status: ALREADY CONFIGURED (no secrets)                 │
│                                                          │
│ Model: amazon.titan-embed-text-v2:0                    │
│ Base URL: https://openai.generative.engine.capgemini.com/v1
│                                                          │
│ Note: These don't need to be changed                    │
└─────────────────────────────────────────────────────────┘
```

---

## 🔍 Troubleshooting

### Problem: "CAPGEMINI_GENAI_API_KEY not found"
```
Causes:
  1. Key not added to .env file
  2. .env file not in correct folder (AI_POC_5G_V1/)
  3. Typo in key name (case-sensitive)
  4. Terminal not restarted after editing .env

Solution:
  1. Open AI_POC_5G_V1/.env
  2. Check: CAPGEMINI_GENAI_API_KEY=your_actual_key
  3. Save and close
  4. Restart terminal/IDE
  5. Try again
```

### Problem: "Pinecone connection failed"
```
Causes:
  1. API key incorrect or expired
  2. Index host incorrect or copied partially
  3. Index doesn't exist in Pinecone
  4. Network/firewall blocking connection

Solution:
  1. Verify PINECONE_API_KEY is 60+ characters
  2. Re-copy PINECONE_INDEX_HOST from console (exactly)
  3. Check in Pinecone → Indexes that index exists
  4. Run: python diagnose_pinecone.py
  5. Check error message for details
```

### Problem: "Embedding API error"
```
Causes:
  1. GenAI key missing or incorrect
  2. Embedding URL misconfigured
  3. GenAI account out of credits

Solution:
  1. Verify CAPGEMINI_GENAI_API_KEY is set
  2. Check EMBEDDING_BASE_URL is correct:
     https://openai.generative.engine.capgemini.com/v1
  3. Log into Capgemini console → check account credits
  4. Try: python diagnose_cache.py
```

### Problem: "LLM API error - 401 Unauthorized"
```
Causes:
  1. API key invalid or expired
  2. API key doesn't have LLM permissions

Solution:
  1. Re-copy API key from Capgemini console
  2. Verify it's the FULL key (no truncation)
  3. Try creating a new API key
  4. Update .env with new key
  5. Restart terminal
  6. Try: python main.py
```

---

## 🔐 Security Best Practices

### DO ✅
- Keep `.env` file LOCAL ONLY
- Add `.env` to `.gitignore` (prevents accidental commits)
- Rotate API keys every 90 days
- Use different keys for dev/prod
- Store keys in password manager
- Revoke old keys immediately after rotation

### DON'T ❌
- Share `.env` file with anyone
- Commit `.env` to GitHub/Git
- Hardcode API keys in source code
- Use production keys in development
- Display full API keys in logs
- Leave expired keys active

---

## 📊 API Key Lifecycle

### Creation
```
Step 1: Log into provider console
Step 2: Navigate to API Keys section
Step 3: Create new key
Step 4: Copy immediately (may not show again)
Step 5: Save to password manager
```

### Usage
```
Step 1: Add to .env file
Step 2: Verify with diagnostic script
Step 3: Monitor usage/logs
Step 4: Set rotation reminder (90 days)
```

### Rotation
```
Step 1: Create new key in console
Step 2: Update .env with new key
Step 3: Test new key works
Step 4: Delete old key from console
Step 5: Document rotation
```

---

## 📚 Quick Reference

### Key Locations in .env
```env
Line 2:   CAPGEMINI_GENAI_API_KEY     (GenAI + Embeddings)
Line 5:   PINECONE_API_KEY             (Pinecone database)
Line 8:   PINECONE_INDEX_HOST          (Pinecone connection)
Line 12:  EMBEDDING_MODEL              (Fixed - no change needed)
Line 13:  EMBEDDING_BASE_URL           (Fixed - no change needed)
```

### API Key Sources
| API | Console | Section | Copy From |
|-----|---------|---------|-----------|
| Capgemini | generative.engine.capgemini.com | API Keys | "Key" field |
| Pinecone Key | app.pinecone.io | API Keys | "Key" column |
| Pinecone Host | app.pinecone.io | Indexes | "Host" column |

### Test Commands
```powershell
# Check keys loaded
python -c "import os; print('GenAI:', bool(os.getenv('CAPGEMINI_GENAI_API_KEY'))); print('Pinecone:', bool(os.getenv('PINECONE_API_KEY')))"

# Test Pinecone
python diagnose_pinecone.py

# Test full pipeline
python main.py

# Check cache
python diagnose_cache.py
```

---

## ✅ Verification Checklist

After adding all three API keys, verify:

- [ ] `.env` file updated with GenAI key
- [ ] `.env` file updated with Pinecone API key  
- [ ] `.env` file updated with Pinecone index host
- [ ] `CAPGEMINI_GENAI_API_KEY` is 40+ characters
- [ ] `PINECONE_API_KEY` starts with `pcsk_`
- [ ] `PINECONE_INDEX_HOST` starts with `https://`
- [ ] `.env` file saved (Ctrl+S)
- [ ] Terminal restarted
- [ ] `python diagnose_pinecone.py` returns ✅
- [ ] `python main.py` completes successfully
- [ ] Cache hit appears on second run
- [ ] No "API key not found" errors

---

## 🎯 Summary

| API | Key Name | Where to Get | Status |
|-----|----------|--------------|--------|
| **GenAI (LLM + Embeddings)** | `CAPGEMINI_GENAI_API_KEY` | generative.engine.capgemini.com/API Keys | Needs replacement |
| **Pinecone (Database)** | `PINECONE_API_KEY` | app.pinecone.io/API Keys | Needs replacement |
| **Pinecone (Connection)** | `PINECONE_INDEX_HOST` | app.pinecone.io/Indexes | Needs replacement |

**Next Step:** Follow STEP 1-4 above to add your keys! 🚀
