# 🏗️ API Integration Architecture

## System Overview

```
┌──────────────────────────────────────────────────────────────────┐
│                    AIOPS PIPELINE ARCHITECTURE                    │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│  INPUT: KPI Data (e.g., SMF_CPU_Usage = 95%)                    │
│         ↓                                                         │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │ STEP 1: Generate Embedding                                  │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │ • Convert KPI text to vector                                │ │
│  │ • Uses: EMBEDDING_API (Capgemini)                           │ │
│  │ • API Key: CAPGEMINI_GENAI_API_KEY                          │ │
│  │ • Output: [0.234, -0.567, 0.891, ...]  (384 dimensions)    │ │
│  └─────────────────────────────────────────────────────────────┘ │
│         ↓                                                         │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │ STEP 2: Search Pinecone Cache                               │ │
│  ├─────────────────────────────────────────────────────────────┤ │
│  │ • Query vector in Pinecone                                  │ │
│  │ • Uses: PINECONE_API (Vector DB)                            │ │
│  │ • API Key: PINECONE_API_KEY                                 │ │
│  │ • Host: PINECONE_INDEX_HOST                                 │ │
│  │ • Search: Find similar KPIs (cosine similarity)             │ │
│  └─────────────────────────────────────────────────────────────┘ │
│         ↓                                                         │
│    ┌────┴────┐                                                   │
│    │          │                                                  │
│  CACHE HIT ✅   CACHE MISS ❌                                     │
│    │          │                                                  │
│    ↓          ↓                                                  │
│ Return    ┌──────────────────────────────┐                       │
│ Cached    │ STEP 3: Call LLM Analysis   │                       │
│ RCA       ├──────────────────────────────┤                       │
│ (FAST)    │ • Generate RCA + Fix         │                       │
│           │ • Uses: GenAI API            │                       │
│           │ • API Key: CAPGEMINI_GENAI_API_KEY                  │
│           │ • Output: Fix recommendations│                       │
│           └──────────────────────────────┘                       │
│                    ↓                                             │
│           ┌──────────────────────────────┐                       │
│           │ STEP 4: Store in Pinecone   │                       │
│           ├──────────────────────────────┤                       │
│           │ • Save embedding + RCA       │                       │
│           │ • Uses: PINECONE_API         │                       │
│           │ • For: Future cache hits     │                       │
│           └──────────────────────────────┘                       │
│    ↓          ↓                                                  │
│    └────┬─────┘                                                  │
│         ↓                                                         │
│  OUTPUT: RCA + Fix (either cached or newly generated)            │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🔑 API KEY REQUIREMENTS

### Capgemini GenAI API Key

```
┌────────────────────────────────────────────┐
│ CAPGEMINI_GENAI_API_KEY                    │
├────────────────────────────────────────────┤
│ Purpose: LLM + Embeddings                  │
│ Single Key: Used for 2 purposes            │
│                                            │
│ Used By:                                   │
│  1. Text Embedding Service                 │
│     - Convert KPI to vector                │
│     - Called: EVERY pipeline run           │
│     - File: vector_db_wrapper.py           │
│                                            │
│  2. LLM Analysis Service                   │
│     - Generate RCA & fixes                 │
│     - Called: On cache MISS only           │
│     - File: analysis_agent.py              │
│                                            │
│ Technical Details:                         │
│  - Endpoint: https://openai.generative...  │
│  - Model: amazon.titan-embed-text-v2:0    │
│  - Format: Bearer token in Authorization  │
│  - Length: ~40 alphanumeric characters     │
│                                            │
│ Where to Get:                              │
│  1. Visit: https://generative.engine...   │
│  2. Login with Capgemini credentials       │
│  3. Navigate: API Keys section             │
│  4. Click: Create API Key                  │
│  5. Copy: Full key value                   │
└────────────────────────────────────────────┘
```

### Pinecone API Key

```
┌────────────────────────────────────────────┐
│ PINECONE_API_KEY                           │
├────────────────────────────────────────────┤
│ Purpose: Vector Database Authentication    │
│ Single Key: Authorizes all Pinecone ops   │
│                                            │
│ Used By:                                   │
│  - Search cached embeddings                │
│  - Store new embeddings                    │
│  - File: vector_db_wrapper.py              │
│                                            │
│ Technical Details:                         │
│  - Format: Authorization header            │
│  - Prefix: Usually starts with "pcsk_"     │
│  - Length: ~60+ characters                 │
│  - Case-sensitive: Yes                     │
│  - Show-once: Pinecone shows key once only │
│                                            │
│ Where to Get:                              │
│  1. Visit: https://app.pinecone.io        │
│  2. Login with Pinecone account            │
│  3. Navigate: API Keys (left sidebar)      │
│  4. Click: Create API Key                  │
│  5. Copy: Full key immediately             │
│  ⚠️  WARNING: Not shown again!              │
│      Save in password manager              │
└────────────────────────────────────────────┘
```

### Pinecone Index Host

```
┌────────────────────────────────────────────┐
│ PINECONE_INDEX_HOST                        │
├────────────────────────────────────────────┤
│ Purpose: Connect to Vector DB Index        │
│ Single Key: Specifies which index to use   │
│                                            │
│ Used By:                                   │
│  - All Pinecone queries                    │
│  - Search & store embeddings               │
│  - File: vector_db_wrapper.py              │
│                                            │
│ Technical Details:                         │
│  - Format: URL (HTTPS)                     │
│  - Pattern: https://index-name-xxxxx...    │
│  - Example: https://kpi-index-c2y8jh7...  │
│  - Contains: Index name + project ID       │
│  - Index Dimension: 384 (for Titan)        │
│                                            │
│ Where to Get:                              │
│  1. Visit: https://app.pinecone.io        │
│  2. Login with Pinecone account            │
│  3. Navigate: Indexes (left sidebar)       │
│  4. Find Your Index: kpi-index (or create) │
│  5. Copy: Host column value                │
│                                            │
│ Create Index If Needed:                    │
│  - Name: kpi-index                         │
│  - Dimension: 384 (Amazon Titan)           │
│  - Metric: Cosine                          │
│  - Wait: 2-3 minutes for creation          │
└────────────────────────────────────────────┘
```

---

## 📊 API Call Sequence

### Scenario 1: Cache HIT (Fast Path)

```
┌──────────────────────────────────────────────────┐
│ USER TRIGGERS PIPELINE: python main.py            │
└──────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────┐
│ CALL 1: Embedding API (Capgemini)                │
├──────────────────────────────────────────────────┤
│ Method: POST                                      │
│ URL: https://openai.generative.engine.capgemini..│
│ Headers:                                          │
│   Authorization: Bearer {CAPGEMINI_GENAI_API_KEY}│
│   Content-Type: application/json                 │
│ Body: { "input": "SMF_CPU_Usage|smf|..." }      │
│ Returns: Vector [0.234, -0.567, ...]             │
│ Time: ~1-2 seconds                               │
└──────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────┐
│ CALL 2: Pinecone Query (Search Cache)            │
├──────────────────────────────────────────────────┤
│ Method: POST                                      │
│ URL: {PINECONE_INDEX_HOST}/query                 │
│ Headers:                                          │
│   Api-Key: {PINECONE_API_KEY}                    │
│   Content-Type: application/json                 │
│ Body: { "vector": [0.234, -0.567, ...] }        │
│ Returns: Similar embeddings (if found)           │
│ Time: ~1-2 seconds                               │
└──────────────────────────────────────────────────┘
                       ↓
              ✅ MATCH FOUND! (Similarity: 1.0)
                       ↓
┌──────────────────────────────────────────────────┐
│ RETURN CACHED RCA (NO MORE API CALLS)            │
├──────────────────────────────────────────────────┤
│ Output: Cached fix from previous run             │
│ Time: ~3-4 seconds total                         │
│ LLM Calls: 0                                     │
│ Cost: Minimal (no LLM)                           │
└──────────────────────────────────────────────────┘
```

### Scenario 2: Cache MISS (Deep Path)

```
┌──────────────────────────────────────────────────┐
│ USER TRIGGERS PIPELINE: python main.py            │
└──────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────┐
│ CALL 1: Embedding API (Capgemini)                │
├──────────────────────────────────────────────────┤
│ Same as above: Generate embedding                │
│ Time: ~1-2 seconds                               │
└──────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────┐
│ CALL 2: Pinecone Query (Search Cache)            │
├──────────────────────────────────────────────────┤
│ Same as above: Search for similar embeddings     │
│ Time: ~1-2 seconds                               │
└──────────────────────────────────────────────────┘
                       ↓
              ❌ NO MATCH FOUND! (Similarity: 0.2)
                       ↓
┌──────────────────────────────────────────────────┐
│ CALL 3: LLM API (Capgemini GenAI)                │
├──────────────────────────────────────────────────┤
│ Method: POST                                      │
│ URL: https://openai.generative.engine.capgemini..│
│ Headers:                                          │
│   Authorization: Bearer {CAPGEMINI_GENAI_API_KEY}│
│   Content-Type: application/json                 │
│ Body: { "prompt": "RCA analysis prompt..." }     │
│ Returns: Generated RCA & fix                     │
│ Time: ~10-15 seconds                             │
└──────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────┐
│ CALL 4: Pinecone Store (Save to Cache)           │
├──────────────────────────────────────────────────┤
│ Method: UPSERT                                    │
│ URL: {PINECONE_INDEX_HOST}/vectors/upsert        │
│ Headers:                                          │
│   Api-Key: {PINECONE_API_KEY}                    │
│   Content-Type: application/json                 │
│ Body: { "vectors": [{ "id": "...", "values": ...│
│ Returns: Success confirmation                    │
│ Time: ~2-3 seconds                               │
└──────────────────────────────────────────────────┘
                       ↓
┌──────────────────────────────────────────────────┐
│ RETURN NEWLY GENERATED RCA                       │
├──────────────────────────────────────────────────┤
│ Output: Fresh RCA from LLM                       │
│ Time: ~15-20 seconds total                       │
│ LLM Calls: 1                                     │
│ Cost: Higher (LLM generation)                    │
│ Benefit: Now cached for future runs              │
└──────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Details

### Input to Embedding

```
Raw KPI Data:
{
  "name": "SMF_CPU_Usage",
  "value": 95,
  "service": "smf",
  "host": "host-001"
}
            ↓
Build Embedding Text:
"SMF_CPU_Usage|smf|host-001"
            ↓
Capgemini Embedding API:
EMBEDDING_BASE_URL/embeddings
+ CAPGEMINI_GENAI_API_KEY
            ↓
384-Dimensional Vector:
[0.234, -0.567, 0.891, ... (384 values)]
```

### Vector to Pinecone

```
Vector: [0.234, -0.567, 0.891, ...]
            ↓
Pinecone Query:
POST {PINECONE_INDEX_HOST}/query
Headers: Api-Key: {PINECONE_API_KEY}
Body: { "vector": [...], "topK": 5 }
            ↓
Pinecone Response:
{
  "matches": [
    {
      "id": "cache-id-001",
      "score": 0.95,  // Cosine similarity
      "metadata": {
        "rca": "Restart SMF service",
        "fix_id": "FIX-001"
      }
    }
  ]
}
            ↓
Compare Similarity Score:
If score >= THRESHOLD (0.65):
  → CACHE HIT ✅
Else:
  → CACHE MISS ❌ (call LLM)
```

---

## 🧪 API Testing Sequence

```
1. Test Embedding API
   Command: python -c "from vector_db_wrapper import VectorDBWrapper; v = VectorDBWrapper(); print(v._get_embedding('test'))"
   Expected: 384-dimensional vector
   
2. Test Pinecone Connection
   Command: python diagnose_pinecone.py
   Expected: ✅ All checks passed
   
3. Test Full Pipeline
   Command: python main.py
   Expected: Pipeline completes, data stored
   
4. Test Cache Reuse
   Command: python main.py (run again)
   Expected: ⚡ FAST PATH - CACHE HIT! message
```

---

## 📝 Summary Table

| Component | API | Key | Purpose | Called |
|-----------|-----|-----|---------|--------|
| **Embedding** | Capgemini | CAPGEMINI_GENAI_API_KEY | Convert text to vector | EVERY run |
| **LLM Analysis** | Capgemini | CAPGEMINI_GENAI_API_KEY | Generate RCA | On cache miss |
| **Cache Search** | Pinecone | PINECONE_API_KEY | Find similar KPIs | EVERY run |
| **Cache Store** | Pinecone | PINECONE_API_KEY | Save new RCA | On cache miss |
| **Connection** | Pinecone | PINECONE_INDEX_HOST | Index location | EVERY run |

---

## ✅ Configuration Checklist

Before running pipeline, ensure:

- [ ] `CAPGEMINI_GENAI_API_KEY` is set and valid
- [ ] `PINECONE_API_KEY` is set and valid
- [ ] `PINECONE_INDEX_HOST` is set and accessible
- [ ] `.env` file is in `AI_POC_5G_V1/` folder
- [ ] `EMBEDDING_MODEL` is set to `amazon.titan-embed-text-v2:0`
- [ ] `EMBEDDING_BASE_URL` is `https://openai.generative.engine.capgemini.com/v1`

**Then run:**
```powershell
python main.py
```

**Expected output:**
```
✅ Pipeline executed successfully
💾 Data stored in ChromaDB/Pinecone
```

---

## 🎯 Next Steps

1. **Add Capgemini API Key** → CAPGEMINI_GENAI_API_KEY
2. **Add Pinecone API Key** → PINECONE_API_KEY
3. **Add Pinecone Index Host** → PINECONE_INDEX_HOST
4. **Test with:** `python diagnose_pinecone.py`
5. **Run pipeline:** `python main.py`

See **COMPLETE_API_SETUP_GUIDE.md** for detailed steps! 🚀
