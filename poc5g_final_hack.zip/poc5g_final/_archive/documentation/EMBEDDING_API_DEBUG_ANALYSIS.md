# 🔍 EMBEDDING API FAILURE ANALYSIS

## Executive Summary

The embedding API call is **failing silently and falling back to hash-based embeddings** while the LLM API works correctly. The issue is found in `vector_db_wrapper.py` where exceptions are caught but not properly surfaced.

---

## 1️⃣  EXACT URLs BEING CALLED

### LLM API (WORKING ✅)
```
Method: POST
URL: https://openai.generative.engine.capgemini.com/v1/chat/completions
Headers:
  - Authorization: Bearer {CAPGEMINI_GENAI_API_KEY}
  - Content-Type: application/json

File: analysis_agent.py, line 129-135
Code:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    response = requests.post(CAPGEMINI_URL, headers=headers, json=payload, timeout=60)
```

### Embedding API (FAILING ❌)
```
Method: POST
URL: https://openai.generative.engine.capgemini.com/v1/embeddings
Headers:
  - Authorization: Bearer {CAPGEMINI_GENAI_API_KEY}
  - Content-Type: application/json
  - user-agent: openai/python (via OpenAI client library)

File: vector_db_wrapper.py, line 188-195
Code:
    response = self.openai_client.embeddings.create(
        input=text,
        model=self.embedding_model
    )
```

---

## 2️⃣  HEADER FORMAT COMPARISON

### LLM API Headers (Direct requests.post)
```python
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}
```
✅ **Direct HTTP call** - Full control over headers

### Embedding API Headers (OpenAI client library)
```python
# Inside OpenAI client library wrapper
client = OpenAI(
    base_url="https://openai.generative.engine.capgemini.com/v1",
    api_key=api_key
)
response = client.embeddings.create(input=text, model=model)
```
⚠️  **Library-managed headers** - OpenAI client adds:
- `Authorization: Bearer {api_key}` (same)
- `Content-Type: application/json` (same)
- `User-Agent: openai/python` (different)
- `OpenAI-Organization` (if set)
- Other library-specific headers

---

## 3️⃣  ACTUAL HTTP ERROR RESPONSE

### Error Catching in vector_db_wrapper.py (line 198-205)

```python
except Exception as e:
    # FIX 1: Print actual error details
    print(f"[EMBED-ERROR] API call failed: {str(e)}")
    print(f"[EMBED-ERROR] API URL: {self.embedding_url}")
    print(f"[EMBED-ERROR] API Key present: {self.api_key}")
    print(f"[VectorDB] Falling back to hash-based embedding")
    import traceback
    print(f"[EMBED-ERROR] Full traceback: {traceback.format_exc()}")
    return self._hash_to_vector(text)
```

**Problem**: The error is caught but these print statements are NOT making it to the console!

### Where Errors Disappear

Looking at the code flow:

1. **`_get_embedding()` called** from `search()` (line 240)
2. **Exception caught** in `_get_embedding()` - tries to print debug info
3. **Print statements never appear** - why?
   - They're sent to stdout
   - Logger is not used (using print instead of logger.error)
   - They might be buffered or redirected
   - In pipeline execution, stdout might not be visible

---

## 4️⃣  WORKING vs FAILING - ROOT CAUSE ANALYSIS

### LLM API Works Because:
```python
# analysis_agent.py line 129-137

try:
    response = requests.post(CAPGEMINI_URL, headers=headers, json=payload, timeout=60)
    if response.status_code == 200:
        content = response.json()["choices"][0]["message"]["content"]
        logger.info("Capgemini LLM response received for %s", kpi["kpi_name"])
        return content
    else:
        logger.error("Capgemini LLM HTTP %d: %s", response.status_code, response.text[:200])
        return _mock_response(kpi["kpi_name"])
except Exception as exc:
    logger.error("Capgemini LLM call failed for %s: %s", kpi["kpi_name"], exc)
    return _mock_response(kpi["kpi_name"])
```

✅ **Advantages:**
- Uses `logger.error()` instead of print()
- Checks HTTP status code explicitly
- Catches and logs exceptions clearly
- Provides fallback mock response

### Embedding API Fails Because:
```python
# vector_db_wrapper.py line 191-205

try:
    response = self.openai_client.embeddings.create(
        input=text,
        model=self.embedding_model
    )
    embedding = response.data[0].embedding
    # ... success path
except Exception as e:
    print(f"[EMBED-ERROR] API call failed: {str(e)}")  # ❌ LOST!
    print(f"[EMBED-ERROR] Full traceback: {traceback.format_exc()}")  # ❌ LOST!
    return self._hash_to_vector(text)
```

❌ **Problems:**
1. **Silent fallback** - No logger, just print()
2. **No HTTP status checking** - exception from OpenAI client library
3. **Errors are invisible** - print() output not captured
4. **Always returns hash** - never knows why it failed
5. **No feedback** - user sees cached results but can't debug

---

## 5️⃣  EXACT ISSUE: WHY EMBEDDING FAILS

Based on the code analysis, the embedding API call fails for one of these reasons:

### Possible Failure #1: API Key Doesn't Have Embedding Permissions
```
The same CAPGEMINI_GENAI_API_KEY is used for both:
- LLM RCA generation (WORKS ✅)
- Embedding generation (FAILS ❌)

If the API key has "LLM only" permissions, embedding calls silently fail.
```

### Possible Failure #2: Model Name Mismatch
```
LLM Model:       anthropic.claude-sonnet-4-6
Embedding Model: amazon.titan-embed-text-v2:0

These are different model providers!
If Capgemini doesn't support amazon.titan-embed-text-v2:0,
the request fails and falls back to hash.
```

### Possible Failure #3: Response Format Mismatch
```
OpenAI client expects:
{
  "data": [
    {"embedding": [0.1, 0.2, ...]}
  ]
}

If Capgemini returns different format, 
response.data[0].embedding throws KeyError
```

### Possible Failure #4: Rate Limiting or Quota
```
If embedding requests hit rate limit,
OpenAI client raises RateLimitError,
caught as generic Exception, falls back to hash.
```

---

## 6️⃣  THE FIX: MAKE EMBEDDING ERRORS VISIBLE

### Current Code (vector_db_wrapper.py)
```python
except Exception as e:
    print(f"[EMBED-ERROR] API call failed: {str(e)}")  # LOST!
    return self._hash_to_vector(text)
```

### Fixed Code (shows exact error)
```python
except Exception as e:
    import logging
    logger = logging.getLogger(__name__)
    
    logger.error(f"❌ Embedding API Failed:")
    logger.error(f"   Model: {self.embedding_model}")
    logger.error(f"   URL: {self.embedding_url}")
    logger.error(f"   Error Type: {type(e).__name__}")
    logger.error(f"   Error Message: {str(e)}")
    
    # Print full traceback
    import traceback
    logger.error(f"   Full Traceback:\n{traceback.format_exc()}")
    
    # Fallback
    logger.warning(f"⚠️  Falling back to hash-based embedding")
    return self._hash_to_vector(text)
```

---

## 7️⃣  DIAGNOSTIC COMPARISON TABLE

| Aspect | LLM API | Embedding API |
|--------|---------|---------------|
| **URL** | `/v1/chat/completions` | `/v1/embeddings` |
| **HTTP Method** | POST | POST |
| **Model Name** | `anthropic.claude-sonnet-4-6` | `amazon.titan-embed-text-v2:0` |
| **Authorization** | Bearer token (✓ same) | Bearer token (✓ same) |
| **HTTP Call Method** | `requests.post()` | OpenAI client library |
| **Error Logging** | `logger.error()` | `print()` (invisible!) |
| **HTTP Status Check** | Explicit (200 check) | Implicit (OpenAI lib) |
| **Fallback** | Mock RCA response | Hash-based vector |
| **Works?** | ✅ YES | ❌ NO (silent) |

---

## 8️⃣  ROOT CAUSE: SILENT FAILURE MASKING REAL ISSUE

The fundamental problem is that **the embedding API error is caught and silently converted to a hash fallback**, without any error being logged to the system logs.

When you run the pipeline:
```
1. Embedding API call fails (for one of the 4 reasons above)
2. OpenAI client raises an exception
3. Exception is caught in _get_embedding()
4. print() statements are lost (not captured by logger)
5. Hash fallback is used silently
6. Pipeline continues with WRONG embeddings
7. Cache hits/misses are incorrect
8. You never know what happened!
```

---

## 9️⃣  TO FIX THIS ISSUE:

### Step 1: Make Errors Visible
Add proper logging to vector_db_wrapper.py's _get_embedding() exception handler

### Step 2: Identify the Actual Error
Run pipeline with new logging and check console output for the actual HTTP error

### Step 3: Fix Based on Error Type
- If it's permission error: Request embedding-enabled API key
- If it's model name error: Change model to what Capgemini supports  
- If it's response format error: Handle Capgemini's specific response format
- If it's rate limit: Add retry logic with backoff

### Step 4: Verify by Checking Similarity Scores
After fix, run `test_cache_integration.py` and check that:
- First cache miss returns similarity ~0 (different KPI)
- Repeated same KPI returns similarity ~1.0 (perfect match)
- Similar KPIs return similarity 0.6-0.9 (semantic match)

---

## 🔑 KEY FINDINGS

1. **Both APIs use same authentication method** (Bearer token)
2. **Both APIs use same Capgemini endpoint domain**
3. **Difference**: LLM uses direct HTTP, embedding uses OpenAI client library wrapper
4. **Root cause**: Exception handling is silently swallowing embedding errors
5. **Why LLM works**: It has explicit logger statements that surface errors
6. **Why embedding fails**: It uses print() which gets lost in pipeline execution
7. **Real error is hidden**: You need to run with proper logging to see what's wrong

---

## Next Steps

1. Update `vector_db_wrapper.py` to use `logger.error()` instead of `print()`
2. Re-run pipeline to see the actual HTTP error response
3. Verify the error and take corrective action
4. Test with `test_cache_integration.py` to confirm embeddings are working

The embedding API is likely failing for a specific reason, but that reason is being masked by silent exception handling!
