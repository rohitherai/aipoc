# 🔐 API Key Replacement Guide

## Overview

Your API keys have been **REMOVED** from the `.env` file. This guide provides step-by-step instructions to replace them with your new API keys.

---

## ⚠️ IMPORTANT SECURITY NOTES

✅ **ALWAYS:**
- Keep `.env` file locally and **NEVER** commit to Git/GitHub
- Add `.env` to `.gitignore` (already done)
- Use environment variables for all sensitive data
- Rotate API keys regularly
- Use different keys for dev/prod environments

❌ **NEVER:**
- Share `.env` file with others
- Hardcode API keys in source code
- Commit sensitive data to version control
- Use production keys in development

---

## 📝 Current .env Status

**Before:**
```
CAPGEMINI_GENAI_API_KEY=PAj75Tdrtn9n6F6bSdVEo9v85zh1dijp62GvGoGv
PINECONE_API_KEY=pcsk_3bJovq_5UPhr8UcamTE6PVxWw5oGbH5Ygy7PArVo8UPtxd9BFa5swTPpBvJA9GdYdTHocn
PINECONE_INDEX_HOST=https://kpi-index-c2y8jh7.svc.aped-4627-b74a.pinecone.io
```

**After (Safe for sharing):**
```
CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here
PINECONE_API_KEY=your_pinecone_api_key_here
PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io
```

✅ **Status:** Your code is now safe to share!

---

## 🔄 Step-by-Step Replacement Procedure

### STEP 1: Get Your Capgemini API Key

1. Go to Capgemini GenAI Platform: https://generative.engine.capgemini.com/
2. Log in with your credentials
3. Navigate to **API Keys** or **Settings**
4. Create a new API key or copy existing one
5. Copy the full API key

### STEP 2: Get Your Pinecone API Key

1. Go to Pinecone Console: https://app.pinecone.io/
2. Log in with your account
3. Navigate to **API Keys** section (left sidebar)
4. Click **Create API Key** or copy existing key
5. Save the key securely (Pinecone only shows it once)
6. Also note your **Index Host** from the indexes page

### STEP 3: Edit .env File

**Option A: Using VS Code**
```
1. Open .env file in VS Code
2. Locate these lines:
   CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here
   PINECONE_API_KEY=your_pinecone_api_key_here
   PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io

3. Replace with your actual keys:
   CAPGEMINI_GENAI_API_KEY=<your_real_capgemini_key>
   PINECONE_API_KEY=<your_real_pinecone_key>
   PINECONE_INDEX_HOST=<your_real_index_host>

4. Save file (Ctrl+S)
```

**Option B: Using PowerShell**
```powershell
# Navigate to project
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# Edit using Windows notepad (slower method)
notepad .env

# Or use VS Code
code .env
```

### STEP 4: Verify Configuration

```powershell
# Navigate to project
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Run verification script
python diagnose_pinecone.py
```

**Expected Output:**
```
✅ Pinecone Configuration Check
✅ API Key: Found
✅ Index Host: Found
✅ Connection: Success
```

---

## 🧪 Testing Your New API Keys

### Test 1: Pinecone Connection
```powershell
python diagnose_pinecone.py
```

### Test 2: Capgemini LLM Connection
```powershell
python -c "import os; print('LLM Key:', '✅' if os.getenv('CAPGEMINI_GENAI_API_KEY') else '❌')"
```

### Test 3: Full Pipeline Test
```powershell
python main.py
```

Expected output should show:
- ✅ No "API Key not found" errors
- ✅ Cache operations working
- ✅ Auto-approval message appearing
- ✅ "stored_in_memory: true"

---

## 📋 API Key Format Reference

### Capgemini GenAI API Key Format
- **Length:** ~40 characters
- **Format:** Alphanumeric string
- **Example:** `PAj75Tdrtn9n6F6bSdVEo9v85zh1dijp62GvGoGv`

### Pinecone API Key Format
- **Length:** ~60+ characters
- **Prefix:** Usually starts with `pcsk_`
- **Format:** Contains letters, numbers, underscores
- **Example:** `pcsk_3bJovq_5UPhr8UcamTE6PVxWw5oGbH5Ygy7PArVo8UPtxd9BFa5swTPpBvJA9GdYdTHocn`

### Pinecone Index Host Format
- **Format:** `https://<index-name>-<project-id>.svc.pinecone.io`
- **Example:** `https://kpi-index-c2y8jh7.svc.aped-4627-b74a.pinecone.io`
- **Location:** Find in Pinecone Console under Indexes > Host column

---

## 🛠️ Troubleshooting

### Problem: "API Key not found"
```
Solution:
1. Check .env file exists in AI_POC_5G_V1 folder
2. Verify file is named exactly ".env" (no .txt extension)
3. Check file contains correct key names (no typos)
4. Restart terminal/IDE after editing .env
```

### Problem: Pinecone Connection Failed
```
Solution:
1. Verify PINECONE_API_KEY is correct
2. Verify PINECONE_INDEX_HOST is correct (copy exact format)
3. Check index still exists in Pinecone console
4. Check network/firewall allows https requests
```

### Problem: LLM API Errors
```
Solution:
1. Verify CAPGEMINI_GENAI_API_KEY is correct
2. Check API key hasn't expired
3. Verify account has credits
4. Check Capgemini service status
```

### Problem: "Key starts with wrong prefix"
```
Solution:
1. Make sure you copied the FULL key
2. Keys may not display completely in UI
3. Re-copy from source dashboard
4. Avoid spaces or line breaks around key
```

---

## 📁 Files That Use API Keys

These files reference API keys from `.env`:

| File | Purpose | Key Used |
|------|---------|----------|
| `analysis_agent.py` | LLM RCA analysis | CAPGEMINI_GENAI_API_KEY |
| `grafana_agent.py` | Grafana integration | GRAFANA_TOKEN (optional) |
| `diagnose_pinecone.py` | Pinecone diagnostics | PINECONE_API_KEY |
| `test_pinecone_integration.py` | Pinecone tests | PINECONE_API_KEY |
| `vector_db_wrapper.py` | Vector DB operations | PINECONE_API_KEY |

✅ **All files properly use `os.getenv()` - NO hardcoded keys!**

---

## ✅ Checklist After Adding New Keys

- [ ] `.env` file updated with new API keys
- [ ] `.env` file is in `.gitignore` (not committed to Git)
- [ ] No old API keys visible in git history
- [ ] Ran `diagnose_pinecone.py` - all checks passed
- [ ] Ran `main.py` - pipeline executed successfully
- [ ] Verified auto-approval message appears
- [ ] Verified cache operations working
- [ ] Old API keys revoked in respective dashboards

---

## 🔒 Best Practices Going Forward

### For Development
```bash
# Each developer has own .env (not in Git)
# Keys are environment-specific
USE_LLM=True          # Enable in dev
AUTO_APPROVE=True     # Demo mode
```

### For Production
```bash
# Use environment variables set in deployment system
# Example: GitHub Secrets, AWS Systems Manager, etc.
USE_LLM=True          # Enable in production
AUTO_APPROVE=False    # Manual approval required
```

### Key Rotation Schedule
```
Every 90 days:
- Generate new Capgemini API key
- Generate new Pinecone API key
- Update .env
- Revoke old keys
```

---

## 📞 Support

**If API key issues occur:**

1. **Capgemini Support:** https://generative.engine.capgemini.com/support
2. **Pinecone Support:** https://support.pinecone.io
3. **Run diagnostics:**
   ```powershell
   python diagnose_pinecone.py
   python diagnose_cache.py
   ```

---

## 🎉 You're All Set!

Your code is now:
- ✅ Safe to share with others
- ✅ Safe to commit to version control
- ✅ Ready for production deployment
- ✅ Protected with environment-based secrets

**Next step:** Add your new API keys following the steps above!
