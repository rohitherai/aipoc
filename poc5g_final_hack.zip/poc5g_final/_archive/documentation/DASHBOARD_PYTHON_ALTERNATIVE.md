# 🐍 Alternative: Serve Dashboard with Python (Simpler Option)

If you don't want to set up a full React environment, here's a simpler alternative using Python to serve the dashboard.

---

## Option 1: Python Flask Server (Easiest)

Create a file named **dashboard_server.py** in the AI_POC_5G_V1 folder:

```python
from flask import Flask, render_template_string
import os

app = Flask(__name__, static_folder='.', static_url_path='')

# Load gui_dashboard.js
with open('gui_dashboard.js', 'r') as f:
    dashboard_code = f.read()

# Create HTML template
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5G AIOps Dashboard</title>
    <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <div id="root"></div>
    
    <script type="text/babel">
        // Dashboard Code Here
        ''' + dashboard_code + '''
        
        // Mount dashboard
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(<App />);
    </script>
</body>
</html>
'''

@app.route('/')
def dashboard():
    return render_template_string(HTML_TEMPLATE)

if __name__ == '__main__':
    print("🚀 Dashboard running at http://localhost:5000")
    print("Open your browser and go to: http://localhost:5000")
    app.run(debug=True, port=5000)
```

**Run it:**
```bash
# Install Flask if needed
pip install flask

# Navigate to folder
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# Run the server
python dashboard_server.py

# Open browser at: http://localhost:5000 ✅
```

---

## Option 2: Simple HTTP Server (No Dependencies)

**Python 3.7+** - No installation needed:

```bash
# Navigate to folder with gui_dashboard.html
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# Start HTTP server
python -m http.server 5000

# Open browser at: http://localhost:5000 ✅
```

Then create **dashboard.html**:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5G AIOps Dashboard</title>
    <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="root"></div>
    
    <script type="text/babel">
        // Paste entire gui_dashboard.js code here
        // (Replace this comment with the full component code)
        
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(<App />);
    </script>
</body>
</html>
```

---

## Option 3: NodeJS Without React Build Tools

Install express locally:

```bash
# In your AI_POC_5G_V1 folder
npm init -y
npm install express

# Create server.js
```

**server.js:**
```javascript
const express = require('express');
const path = require('path');

const app = express();
const PORT = 5000;

// Serve static files
app.use(express.static('.'));

// Serve dashboard
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'dashboard.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Dashboard running at http://localhost:${PORT}`);
});
```

**Run:**
```bash
node server.js
# Opens at http://localhost:5000 ✅
```

---

## 🎯 Quick Comparison

| Option | Setup Time | Dependencies | Best For |
|--------|-----------|--------------|----------|
| **React (npx)** | 3-5 min | Node.js | Production, full features |
| **Flask** | 2-3 min | Python, Flask | Quick demo |
| **HTTP Server** | <1 min | Python 3.7+ | Simplest |
| **Express** | 2 min | Node.js, npm | JavaScript preference |

---

## ⚡ Quickest Start (30 seconds)

```bash
# Copy this entire command and paste in PowerShell

# 1. Go to folder
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# 2. Install Flask
pip install flask

# 3. Save dashboard_server.py (create file with content above)

# 4. Run it
python dashboard_server.py

# 5. Open browser: http://localhost:5000
```

That's it! Dashboard will be live at **http://localhost:5000** ✅

---

## 📋 Which Option Should You Choose?

**Choose Python Flask if:**
- ✅ You want localhost:5000
- ✅ You have Python installed
- ✅ You want minimal setup
- ✅ You're testing the demo

**Choose React (npm) if:**
- ✅ You want to eventually integrate with real API
- ✅ You want production deployment ready
- ✅ You have Node.js installed
- ✅ You need advanced features

**Choose HTTP Server if:**
- ✅ You want absolutely simplest setup
- ✅ You only have Python (no npm)
- ✅ You just want to see it working NOW

---

## 🚀 Try Python Flask Version (Recommended for Quick Demo)

1. **Install Flask** (one time):
```bash
pip install flask
```

2. **Create dashboard_server.py** in AI_POC_5G_V1 folder (paste code from Option 1 above)

3. **Run it**:
```bash
python dashboard_server.py
```

4. **Open browser**: http://localhost:5000

5. **You'll see the dashboard!** Click red KPI cards to run the demo

---

## 💡 Pro Tip

Once you have it running, you can:

**Access from other computers:**
```
http://<your-computer-ip>:5000
# Example: http://192.168.1.100:5000
```

**Get your IP:**
```bash
ipconfig
# Look for "IPv4 Address" under your network adapter
```

---

## 🎓 Why Three Options?

- **React**: Most powerful, production-ready, but requires setup
- **Flask**: Good balance, Python-native, easy to add backend
- **HTTP**: Absolute fastest, but limited functionality

**Recommendation:** Use **Flask** for immediate results with localhost:5000 ✅

---

## Next: Connecting to Real Pipeline

Once dashboard is running, you can update it to use real data:

```python
# In dashboard_server.py, add route to connect pipeline:

@app.route('/api/pipeline/execute', methods=['POST'])
def execute_pipeline():
    # Call your actual main.py pipeline here
    from main import run_orchestrated_pipeline
    result = run_orchestrated_pipeline()
    return result
```

Then update gui_dashboard.js to call this endpoint instead of mock data.

---

**Ready? Pick an option above and start!** 🚀
