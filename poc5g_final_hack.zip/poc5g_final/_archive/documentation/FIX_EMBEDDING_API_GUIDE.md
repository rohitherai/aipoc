# 🔧 HOW TO FIX THE EMBEDDING API (STEP-BY-STEP)

## 🎯 Quick Start - 3 Steps to Fix

### STEP 1: Update vector_db_wrapper.py ✅ (DONE)
The code now has **proper error logging** instead of silent print statements.

**What was fixed:**
- Changed `print()` to `logger.error()` and `logger.warning()`
- Errors are now captured in system logs
- Full traceback is logged for debugging
- Clear error messages show what went wrong

### STEP 2: Run Pipeline to See the Actual Error
```bash
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1
python main.py 2>&1 | tee embedding_error.log
```

This will show:
- The exact error message
- Error type (e.g., `AuthenticationError`, `APIError`, `APIStatusError`)
- Full Python traceback
- API URL and configuration being used

**Look for output like:**
```
❌ EMBEDDING API CALL FAILED!
================================================================================
Error Type: APIStatusError
Error Message: Error code: 401 - {'error': 'Invalid API key'}
Model: amazon.titan-embed-text-v2:0
URL: https://openai.generative.engine.capgemini.com/v1
API Key Present: True
Full Traceback:
  ...
```

### STEP 3: Fix Based on the Error Type

---

## 🔍 COMMON ERRORS & FIXES

### ❌ ERROR #1: 401 Unauthorized

**Error Message:**
```
Error code: 401 - {'error': 'Invalid API key'}
```

**Cause:** API key is wrong, missing, or doesn't have embedding permissions

**Fix:**
```bash
# 1. Verify API key is in .env
cat .env | grep CAPGEMINI_GENAI_API_KEY

# 2. Check if key is still placeholder
# Should NOT look like: "your_capgemini_api_key_here"
# Should look like: "abc123xyz789..." (40+ alphanumeric chars)

# 3. If placeholder, get real key from Capgemini console:
#    - Go to: https://generative.engine.capgemini.com/
#    - Login with Capgemini credentials
#    - Navigate to: API Keys section
#    - Create or copy existing key
#    - Paste into .env

# 4. Verify with test:
python -c "from openai import OpenAI; c=OpenAI(base_url='https://openai.generative.engine.capgemini.com/v1', api_key='YOUR_KEY'); print(c.embeddings.create(input='test', model='amazon.titan-embed-text-v2:0'))"
```

---

### ❌ ERROR #2: 400 Bad Request - Invalid Model

**Error Message:**
```
Error code: 400 - {'error': 'The model `amazon.titan-embed-text-v2:0` does not exist'}
```

**Cause:** Capgemini doesn't support this model name for embeddings

**Fix:**
```bash
# 1. Check what models Capgemini supports for embeddings
#    Option A: Check Capgemini documentation
#    Option B: Try these common embedding models:
#       - "text-embedding-3-small" (OpenAI compatible)
#       - "text-embedding-3-large" (OpenAI compatible)
#       - "embed-text" (generic)

# 2. Update .env:
#    Find: EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
#    Replace with: EMBEDDING_MODEL=text-embedding-3-small
#    (or whatever Capgemini supports)

# 3. Verify the model exists with Capgemini
```

---

### ❌ ERROR #3: 403 Forbidden - Insufficient Permissions

**Error Message:**
```
Error code: 403 - {'error': 'Insufficient permissions for embeddings'}
```

**Cause:** API key has "LLM only" permissions, not embeddings

**Fix:**
```bash
# 1. Go to Capgemini console:
#    https://generative.engine.capgemini.com/

# 2. Check API key permissions in: Settings → API Keys

# 3. If key is "LLM only":
#    - Option A: Create NEW key with embedding permissions
#    - Option B: Request admin to grant embedding permission

# 4. Update .env with new key:
CAPGEMINI_GENAI_API_KEY=new_key_with_permissions

# 5. Test again
```

---

### ❌ ERROR #4: 429 Too Many Requests (Rate Limit)

**Error Message:**
```
Error code: 429 - {'error': 'Rate limit exceeded'}
```

**Cause:** Too many embedding requests in short time

**Fix:**
```bash
# 1. Wait a few minutes and try again

# 2. If it keeps happening, add retry logic to vector_db_wrapper.py:

# Replace the try block in _get_embedding() with:
for attempt in range(3):  # Retry up to 3 times
    try:
        response = self.openai_client.embeddings.create(
            input=text,
            model=self.embedding_model
        )
        return response.data[0].embedding[:384]
    except Exception as e:
        if attempt < 2:
            time.sleep(2 ** attempt)  # Exponential backoff
            continue
        else:
            raise
```

---

### ❌ ERROR #5: CERTIFICATE_VERIFY_FAILED (SSL/TLS Issue)

**Error Message:**
```
SSL: CERTIFICATE_VERIFY_FAILED
```

**Cause:** SSL certificate validation failing (corporate proxy, firewall)

**Fix:**
```bash
# Option 1: Disable SSL verification (NOT RECOMMENDED for production)
import os
os.environ['REQUESTS_CA_BUNDLE'] = ''

# Option 2: Update CA certificates
pip install --upgrade certifi

# Option 3: Configure corporate proxy
# Create .env with proxy settings:
# HTTP_PROXY=http://proxy.corp.com:8080
# HTTPS_PROXY=http://proxy.corp.com:8080
```

---

## ✅ IF NO ERROR APPEARS

If embedding API works after the logging update:
1. ✅ Congratulations! Embedding API is working
2. Run test to verify cache behavior:
   ```bash
   python test_cache_integration.py
   ```
3. Look for:
   - First KPI: similarity ~0 (new, cache miss) ✓
   - Same KPI again: similarity ~1.0 (cache hit) ✓
   - Similar KPI: similarity 0.6-0.9 (semantic match) ✓

---

## 🧪 VERIFICATION STEPS

After fixing, run these tests:

### Test 1: Direct API Call
```bash
python -c "
from openai import OpenAI
import os
from dotenv import load_dotenv
load_dotenv()

client = OpenAI(
    base_url=os.getenv('EMBEDDING_BASE_URL'),
    api_key=os.getenv('CAPGEMINI_GENAI_API_KEY')
)

response = client.embeddings.create(
    input='test',
    model=os.getenv('EMBEDDING_MODEL')
)

print(f'✅ Embedding works!')
print(f'Dimensions: {len(response.data[0].embedding)}')
print(f'First 5 values: {response.data[0].embedding[:5]}')
"
```

### Test 2: Pipeline Run
```bash
python main.py
```

Check console output:
- Should see: `✅ Using Capgemini API embedding`
- NOT: `⚠️ Using hash-based fallback embedding`

### Test 3: Cache Integration
```bash
python test_cache_integration.py
```

---

## 📋 TROUBLESHOOTING CHECKLIST

- [ ] API key is in `.env` and not placeholder
- [ ] API key has embedding permissions (not LLM-only)
- [ ] EMBEDDING_BASE_URL is correct
- [ ] EMBEDDING_MODEL exists in Capgemini
- [ ] Network connectivity to Capgemini API works
- [ ] No SSL/certificate issues
- [ ] Python OpenAI library installed: `pip install openai`
- [ ] Not hitting rate limits

---

## 🆘 IF STILL STUCK

### Get Full Diagnostic Output:
```bash
python diagnose_embedding_api.py 2>&1 | tee diagnostic_output.txt
```

This shows:
- Configuration status
- Exact URLs being called
- Headers being sent
- Error responses

### Compare LLM vs Embedding:
```bash
# If LLM works but embedding doesn't, there's a specific incompatibility
# See EMBEDDING_API_DEBUG_ANALYSIS.md for detailed comparison

cat EMBEDDING_API_DEBUG_ANALYSIS.md
```

---

## 🎯 SUMMARY

The embedding API is now **properly instrumented with logging**.

**To fix:**
1. ✅ Code is updated (done)
2. ▶️ Run `python main.py` and capture the error
3. ▶️ Match your error to the common fixes above
4. ▶️ Apply the fix
5. ▶️ Run tests to verify

**The actual problem is now VISIBLE** instead of silently falling back to hash!
