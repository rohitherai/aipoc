# 🚀 How to Access & Run the GUI Dashboard

## The Issue

The `gui_dashboard.js` is a **React component**, not a standalone server. It won't run on localhost:5000 by itself because it needs to be:
1. ✅ Inside a React application
2. ✅ Built/compiled by React
3. ✅ Served by a React development server

---

## ✅ Quick Start: 3 Steps to View Dashboard

### Step 1: Create React App (First time only)

```bash
# Navigate to the project directory
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# Option A: Create a new React app
npx create-react-app dashboard
cd dashboard

# Option B: If you already have a React project, skip this step
```

### Step 2: Copy Dashboard Component

```bash
# Copy the component into the React app
cp ..\gui_dashboard.js .\src\

# Or manually:
# 1. Open gui_dashboard.js
# 2. Copy the entire file
# 3. Paste into src/gui_dashboard.js in your React project
```

### Step 3: Mount Component in App

**File:** `src/App.jsx` (or `src/App.js`)

```jsx
// Replace entire contents with:
import GUIDashboard from './gui_dashboard';

export default function App() {
  return <GUIDashboard />;
}
```

### Step 4: Run the Dashboard

```bash
# Start the React development server
npm start

# Opens automatically at: http://localhost:3000
```

**That's it! Dashboard loads at http://localhost:3000** ✅

---

## 📋 Pre-requisites

### Required
- ✅ Node.js installed (download from nodejs.org)
- ✅ npm (comes with Node.js)

### Verify Installation

```bash
# Check Node.js version (should be 14+)
node --version

# Check npm version (should be 6+)
npm --version
```

---

## 🔧 Manual Setup (Step-by-Step)

### Option 1: Create React App from Scratch

```bash
# 1. Navigate to your project directory
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# 2. Create a new React app
npx create-react-app my-dashboard

# 3. Navigate into the app
cd my-dashboard

# 4. Copy gui_dashboard.js to src/
copy ..\gui_dashboard.js src\

# 5. Edit src/App.jsx
notepad src\App.jsx
```

**Edit src/App.jsx to look like this:**
```jsx
import GUIDashboard from './gui_dashboard';

export default function App() {
  return <GUIDashboard />;
}
```

**Then run:**
```bash
npm start
```

Opens at: **http://localhost:3000** ✅

---

### Option 2: Existing React Project

If you already have a React project:

```bash
# 1. Navigate to your React project root
cd your-project-folder

# 2. Copy gui_dashboard.js to src/
copy C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1\gui_dashboard.js src\

# 3. Import in your main component (usually App.jsx or main.jsx):
```

**In your main component file:**
```jsx
import GUIDashboard from './gui_dashboard';

function App() {
  return (
    <div>
      {/* Your other components */}
      <GUIDashboard />
    </div>
  );
}

export default App;
```

**Then run:**
```bash
npm start
```

---

## 🖥️ Windows Batch Script Setup (Automated)

Save this as **setup_dashboard.bat** in the AI_POC_5G_V1 folder:

```batch
@echo off
echo Creating React Dashboard Application...

REM Create React app
call npx create-react-app dashboard

REM Navigate into app
cd dashboard

REM Copy gui_dashboard.js
copy ..\gui_dashboard.js src\

REM Create new App.jsx
(
  echo import GUIDashboard from './gui_dashboard';
  echo.
  echo export default function App() {
  echo   return ^<GUIDashboard /^>;
  echo }
) > src\App.jsx

echo.
echo ✅ Setup complete!
echo.
echo To start the dashboard, run:
echo   cd dashboard
echo   npm start
echo.
echo Dashboard will open at: http://localhost:3000
pause
```

**Run it:**
```bash
setup_dashboard.bat
```

---

## 🎯 What You'll See

Once running at http://localhost:3000, you'll see:

```
┌─────────────────────────────────────────────────────┐
│  5G AIOps Fault Remediation · Capgemini             │
│  Real-time KPI monitoring with intelligent pipeline│
│                                                     │
│  LIVE KPI STREAM          PIPELINE STAGES   LIVE LOG│
│  ┌──────────────────┐    ┌──────────────────┐      │
│  │ SMF_CPU_Usage    │    │ 1. Ingest        │      │
│  │ 78% (RED FAULT)  │    │ 2. Embed         │      │
│  │ ▟▜▜▜▜▜▜▜▜▜▜▜▜  │    │ 3. Cache         │      │
│  │ ⚡ Click to run  │    │ 4. Decision      │      │
│  │                  │    │ 5. RCA           │      │
│  │ UPF_Throughput   │    │ 6. Execution     │      │
│  │ 31Gbps (↓)       │    │ 7. Learning      │      │
│  │ ▟▜▜▜▜▜▜         │    │                  │      │
│  └──────────────────┘    └──────────────────┘      │
└─────────────────────────────────────────────────────┘

Metrics:
  • Total Runs: 0
  • Cache Hit Rate: 0%
  • Avg Fix Time: —
  • Status: ● MONITORING
```

Click on any red KPI card to trigger the demo pipeline! 🎬

---

## 🔗 Port Information

| Port | Service | URL |
|------|---------|-----|
| 3000 | React Dev Server | http://localhost:3000 |
| 5000 | (Not used by React) | - |
| 8000 | Optional: Python API Backend | http://localhost:8000 |

**React defaults to port 3000, not 5000** ✅

---

## 📊 How to Integrate with Real Pipeline

Once dashboard is running, update it to use real data:

### Option A: Direct API Calls
```javascript
// In gui_dashboard.js runPipeline function, replace mock timings with:

const embedResponse = await fetch('http://localhost:8000/api/embed', {
  method: 'POST',
  body: JSON.stringify({ kpi_name: kpi.kpi_name })
});

const cacheResponse = await fetch('http://localhost:8000/api/cache/search', {
  method: 'POST',
  body: JSON.stringify({ vector: embedResponse.embedding })
});
```

### Option B: WebSocket Real-Time Updates
```javascript
// Add to useEffect in gui_dashboard.js:

useEffect(() => {
  const ws = new WebSocket('ws://localhost:8000/kpi-stream');
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    setHistories(prev => ({
      ...prev,
      [data.kpi_name]: [...prev[data.kpi_name], data.value].slice(-20)
    }));
  };
  return () => ws.close();
}, []);
```

---

## ⚠️ Troubleshooting

### "npm: command not found"
```bash
# Install Node.js from: https://nodejs.org/
# Then restart terminal and try again
npm --version
```

### "Port 3000 is already in use"
```bash
# Either:
# 1. Stop other process using port 3000, OR
# 2. Use different port:
PORT=3001 npm start
# Opens at http://localhost:3001
```

### "Cannot find module 'react'"
```bash
# Install dependencies
npm install

# Then try again
npm start
```

### Dashboard blank/not rendering
```bash
# Clear cache and reinstall
rm -r node_modules
npm install
npm start
```

### "gui_dashboard.js not found"
```bash
# Make sure you copied it to src/ folder:
# ✓ src/gui_dashboard.js (should exist)
# ✓ src/App.jsx (should import from './gui_dashboard')

# Check with:
dir src\gui_dashboard.js
```

---

## 🎓 Understanding the Architecture

```
┌─ YOUR COMPUTER ──────────────────────────────────┐
│                                                  │
│  ┌─ React Development Server ──────────────┐    │
│  │ http://localhost:3000                   │    │
│  │                                          │    │
│  │  ┌─ App.jsx ──────────────────────────┐ │    │
│  │  │ import GUIDashboard from './...'  │ │    │
│  │  │ <GUIDashboard />                   │ │    │
│  │  └──────────────────────────────────── │    │
│  │         │                               │    │
│  │         ▼                               │    │
│  │  ┌─ gui_dashboard.js ──────────────┐  │    │
│  │  │ - React Component               │  │    │
│  │  │ - 7 Pipeline Stages             │  │    │
│  │  │ - KPI Cards (mock data)         │  │    │
│  │  │ - Approval Modal                │  │    │
│  │  │ - Live Logging                  │  │    │
│  │  └─────────────────────────────────   │    │
│  └──────────────────────────────────────── │    │
│                                            │    │
└────────────────────────────────────────────────┘

Browser sees: Interactive dashboard at localhost:3000
```

---

## 📝 Complete Example: From Scratch

```bash
# 1. Go to project folder
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# 2. Create React app
npx create-react-app dashboard

# 3. Navigate into it
cd dashboard

# 4. Copy dashboard component
copy ..\gui_dashboard.js src\

# 5. Edit App.jsx
# Replace contents with:
#   import GUIDashboard from './gui_dashboard';
#   export default function App() {
#     return <GUIDashboard />;
#   }

# 6. Start development server
npm start

# 7. Browser opens automatically to http://localhost:3000
```

Done! ✅ Dashboard is live!

---

## 🚀 Next Steps

1. ✅ Get dashboard running (follow steps above)
2. ⚠️ Click on red KPI cards to trigger demo
3. 📊 Watch pipeline stages execute (1-7)
4. 💾 Observe approval modal
5. 🔗 Connect real API endpoints (when ready)
6. 📈 Stream live KPI data (when ready)

---

## 📚 Additional Resources

- **React Docs:** https://react.dev
- **Node.js Download:** https://nodejs.org/
- **Dashboard Guide:** See [GUI_DASHBOARD_QUICKSTART.md](GUI_DASHBOARD_QUICKSTART.md)
- **API Integration:** See [GUI_DASHBOARD_IMPROVEMENTS.md](GUI_DASHBOARD_IMPROVEMENTS.md) Section 8

---

**TL;DR:** gui_dashboard.js is React code → needs React app → run `npm start` → opens at http://localhost:3000
