# Dashboard Messaging Quick Reference

## What Does Each Message Mean?

### 🎯 KPI Card Messages

| Message | What It Means | What To Do |
|---------|---------------|-----------|
| `✅ Stable — No anomaly detected` | KPI is healthy, no issues | Monitor (no action needed) |
| `▸ Click to run pipeline` | KPI has a fault, first time seeing this | Click to analyze and fix |
| `⚡ Click to re-run (Instant via cache)` | KPI has a fault we've seen before | Click for instant cached fix |

---

### 🚨 Status Pill Messages (Top Right)

| Status | What It Means |
|--------|---------------|
| `● MONITORING` | System is idle, watching for faults |
| `● PIPELINE ACTIVE` | Analysis and fix running (be patient) |
| `● AWAITING APPROVAL` | Operator decision needed - check approval modal |
| `● COMPLETE` | Pipeline finished successfully |

---

### 🛤️ Path Badges (Pipeline Stages)

| Badge | What It Means | Speed |
|-------|---------------|-------|
| `🔍 DEEP PATH` | Full AI analysis required (new fault) | ~15-20 seconds |
| `⚡ FAST PATH` | Using cached solution (we've seen this before) | ~3-5 seconds |

---

### ⚡ Toast Notifications (Auto-Dismiss)

| Toast | What It Means |
|-------|---------------|
| `⚠ Fault detected: {KPI} on {host}` | System found an issue |
| `⚡ FAST PATH — Cache hit detected (score: X%)` | Using learned solution (no AI needed) |
| `✅ Using cached analysis (RCA skipped)` | We skipped analysis step (it's cached) |
| `✅ Fix applied successfully` | Operator approved, fix was executed |
| `🧠 Learning stored in knowledge base` | System learned this solution for next time |
| `✅ Issue resolved and learning stored` | All done, ready for next fault |

---

### 📋 Completion Summary (Below Pipeline Stages)

Appears after successful pipeline completion:

```
✅ Issue Resolved — KPI returned to normal range
🧠 Solution stored in memory
⚡ Future occurrences will be resolved instantly
```

**Translation:**
- Issue is fixed ✓
- We learned how to fix it ✓
- Next time will be MUCH faster ✓

---

### 💬 Approval Modal Messages

**Deep Path (First Time Seeing This):**
- Shows Root Cause and Proposed Fix
- Takes ~15-20 seconds for LLM analysis
- Click ✓ to approve and execute

**Fast Path (Cached Solution):**
- Shows: `⚡ FAST PATH EXECUTION`
- Shows: `✅ RCA SKIPPED — Using cached knowledge`
- No LLM analysis (instant)
- Takes ~3-5 seconds

---

### 📊 Metrics (Top Right Corner)

| Metric | Meaning |
|--------|---------|
| **Total Runs** | How many pipeline executions completed |
| **Cache Hit Rate** | % of executions that used cached solutions |
| **Avg Fix Time** | Average seconds to complete a pipeline run |

---

## 🔄 Typical User Journeys

### Journey 1: First-Time Fault (Deep Path)
```
1. KPI shows "▸ Click to run pipeline" 
2. You click it
3. Status changes to "● PIPELINE ACTIVE"
4. Log shows: "🔍 DEEP PATH" badge appears
5. Approval modal appears: "Root Cause" + "Proposed Fix" shown
6. You click "✓ Approve & Execute"
7. Toast: "✅ Fix applied successfully"
8. Toast: "🧠 Learning stored in knowledge base"
9. Completion summary shows 3 green checkmarks
10. KPI returns to normal
11. KPI label changes to "⚡ Click to re-run (Instant via cache)"
```

### Journey 2: Repeat Fault (Fast Path)
```
1. KPI shows "⚡ Click to re-run (Instant via cache)" 
2. You click it
3. Toast: "⚡ FAST PATH — Cache hit detected (score: 92%)"
4. Status changes to "● PIPELINE ACTIVE"
5. Path badge shows "⚡ FAST PATH" (green)
6. Toast: "✅ Using cached analysis (RCA skipped)"
7. Approval modal appears but says: "⚡ FAST PATH EXECUTION" + "✅ RCA SKIPPED"
8. You click "✓ Approve & Execute"
9. Toast: "✅ Fix applied successfully" (instant!)
10. Completion summary shows (much faster than first time)
11. KPI returns to normal
12. Status shows "● COMPLETE"
```

---

## ✨ Key Differences: First vs. Subsequent Runs

| Aspect | First Run | Subsequent Run |
|--------|-----------|-----------------|
| Path Badge | 🔍 DEEP PATH (orange) | ⚡ FAST PATH (green) |
| Duration | ~15-20 seconds | ~3-5 seconds |
| Analysis | Full LLM RCA | Cached knowledge |
| RCA Stage | Runs (⚙ icon animated) | Skipped (greyed out) |
| Toast | "Fix applied..." | "Cache hit detected..." |
| Approval Modal | Long analysis text | Short cache confirmation |

---

## 🎨 Color Guide

- 🟢 **Green** = Good, Success, Stable, Fast Path
- 🔵 **Blue** = Active, In-Progress, Information
- 🟠 **Orange** = Warning, Action Needed, Deep Path
- ⚪ **Gray** = Neutral, Inactive, Stable

---

## 💡 Pro Tips

1. **Watch the Status Pill** - Know at a glance what's happening
2. **Read Toast Notifications** - They tell you key events (bottom-right)
3. **Check Path Badge** - Green ⚡ is fast, Orange 🔍 is deep
4. **Review Approval Modal** - Shows why this is the fix
5. **Monitor Metrics** - Higher cache hit % = more efficient operations
6. **Check Completion Summary** - Confirms issue, learning, and future benefit

---

## ❓ FAQ

**Q: What does "Cache Hit" mean?**
A: System recognized this fault from a previous incident and is using the learned solution instead of re-analyzing it. Much faster!

**Q: Why is "RCA SKIPPED"?**
A: Because we've analyzed this issue before, so we skip the Root Cause Analysis and go straight to the proven fix.

**Q: Will the same issue always use cache?**
A: Yes, if it's similar enough to previous issues. The system learns patterns.

**Q: What if I reject the fix?**
A: The fault stays unresolved, but the system still learns what was proposed for next time.

**Q: How long does a deep analysis take?**
A: Typically 15-20 seconds (LLM analysis + log parsing).

**Q: How long does a fast path take?**
A: Typically 3-5 seconds (cached resolution, no LLM).

**Q: Can I trust cached solutions?**
A: Yes! They only use cache when confidence > 85%. Otherwise it defaults to deep path.

---

## 🚀 Summary

The dashboard now **clearly shows**:
- What went wrong ✓
- How we're fixing it ✓
- That we learned ✓
- Why it'll be faster next time ✓

All through intuitive messages, colors, badges, and toasts!
