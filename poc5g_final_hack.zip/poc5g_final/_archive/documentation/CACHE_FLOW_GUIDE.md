# Local Cache Flow Guide - Complete Walkthrough

## 🚀 Quick Start (3 Steps)

### Step 1: Start the Server
```bash
cd AI_POC_5G_V1
python server.py
```

Expected output:
```
* Running on http://localhost:5000
* Debugger is active!
```

### Step 2: Open GUI
```
http://localhost:5000/poc
```

### Step 3: Run Pipeline Twice
1. **Click "Run Pipeline"** → Wait ~19 seconds (LLM runs, stores to cache)
2. **Click "Run Pipeline"** again → Wait ~2 seconds (cache hit, LLM skipped)

---

## 📊 Complete Flow: Node by Node

### RUN 1: First Analysis (Cache Miss)

```
┌─────────────────────────────────────────────────────────────────┐
│ USER CLICKS "RUN PIPELINE"                                      │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: server.py                                                 │
│ ENDPOINT: GET /api/analyze                                      │
│ ACTION: Calls pipeline_orchestrator.run()                       │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: pipeline_orchestrator.py (Line 59)                        │
│ ACTION: kpis = get_kpi_data_with_fallback()                     │
│ RESULT: Gets dummy KPI: {"kpi_name": "SMF_CPU_Usage", ...}      │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: pipeline_orchestrator.py (Line 109)                       │
│ ACTION: vector_db = VectorDBWrapper()                           │
│ WHAT HAPPENS:                                                   │
│  - Tries Pinecone connection                                    │
│  - Pinecone blocked by proxy (ZScaler)                          │
│  - Detects proxy: status 200 but HTML response                  │
│  - Falls back to LOCAL CACHE ✅                                 │
│                                                                 │
│ RESULT: vector_db.use_local_cache = True                        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: pipeline_orchestrator.py (Line 127-150)                   │
│ ACTION: vector_db.search(kpi)                                   │
│                                                                 │
│ SEARCH FLOW:                                                    │
│  1. Check if local_cache is active → YES ✅                     │
│  2. Call _search_local_cache(kpi_name)                          │
│  3. Generate hash embedding of "SMF_CPU_Usage"                  │
│  4. Search vector_cache/vectors.jsonl                           │
│  5. Look for vectors with similarity > 0.85                     │
│  6. Result: EMPTY (first time, cache is new)                    │
│                                                                 │
│ RESULT: search_result = None (CACHE MISS)                       │
│ LOG: "[DEEP-PATH] no cached match"                              │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: pipeline_orchestrator.py (Line 151+)                      │
│ ACTION: Deep path analysis (because cache miss)                 │
│                                                                 │
│ FLOW:                                                           │
│  1. log_agent.py → Collect logs for KPI                         │
│  2. rca_agent.py → Check KB (knowledge base)                    │
│  3. KB not found → Call LLM (Capgemini API)                      │
│  4. Wait ~10 seconds for LLM response                           │
│  5. Generate detailed RCA report                                │
│  6. fixer_agent.py → Generate fix plan                          │
│  7. approval_agent.py → Create approval request                 │
│                                                                 │
│ TOTAL TIME: ~19 seconds ⏱️                                       │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: pipeline_orchestrator.py (Line 261)                       │
│ ACTION: vector_db.store(analysis_result)                        │
│                                                                 │
│ STORE FLOW:                                                     │
│  1. Extract KPI name: "SMF_CPU_Usage"                           │
│  2. Generate embedding (hash-based, no network)                 │
│  3. Create metadata (RCA, fix, etc.)                            │
│  4. Call local_cache.store(vector_id, embedding, metadata)      │
│  5. Write to: vector_cache/vectors.jsonl                        │
│  6. Append: {"id":"...", "values":[...], "metadata":{...}}      │
│                                                                 │
│ RESULT: Data stored successfully ✅                             │
│ LOG: "[OK] Stored in Pinecone memory" (local cache)             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: server.py / poc_ui.html                                   │
│ ACTION: Return results to GUI                                   │
│                                                                 │
│ DISPLAY:                                                        │
│  - RCA report                                                   │
│  - Fix plan                                                     │
│  - Approve/Reject buttons                                       │
│  - Timeline showing "19.06s"                                    │
└─────────────────────────────────────────────────────────────────┘

TIME ELAPSED: ~19 seconds ⏱️
CACHE STATUS: 1 vector stored in vector_cache/vectors.jsonl ✅
```

---

### RUN 2: Second Analysis (Cache Hit) ⚡

```
┌─────────────────────────────────────────────────────────────────┐
│ USER CLICKS "RUN PIPELINE" AGAIN                                │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: server.py → pipeline_orchestrator.py                      │
│ ACTION: Same as before, but cache exists now                    │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: pipeline_orchestrator.py (Line 127-150)                   │
│ ACTION: vector_db.search(kpi)                                   │
│                                                                 │
│ SEARCH FLOW (2ND TIME):                                         │
│  1. Check if local_cache is active → YES ✅                     │
│  2. Call _search_local_cache("SMF_CPU_Usage")                   │
│  3. Generate hash embedding of "SMF_CPU_Usage"                  │
│  4. Open vector_cache/vectors.jsonl                             │
│  5. Find: 1 stored vector (from RUN 1)                          │
│  6. Compare embeddings: 99.8% similarity match! ✅              │
│  7. Similarity > 0.85 threshold → MATCH FOUND!                  │
│                                                                 │
│ RESULT: search_result = {                                       │
│   "score": 0.998,                                               │
│   "root_cause": "Session setup surge...",                       │
│   "fix": {"actions": [...]}                                     │
│ }                                                               │
│                                                                 │
│ LOG: "[FAST-PATH] Cache hit! Confidence: 0.998"                 │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: pipeline_orchestrator.py (Line 146-150)                   │
│ ACTION: Return cached result (SKIP LLM ENTIRELY) ⚡              │
│                                                                 │
│ WHAT DOESN'T HAPPEN:                                            │
│  ✗ No log collection                                            │
│  ✗ No KB search                                                 │
│  ✗ No LLM call (SAVES ~10 seconds)                              │
│  ✗ No fix generation needed                                     │
│                                                                 │
│ WHAT HAPPENS:                                                   │
│  ✓ Return cached RCA                                            │
│  ✓ Return cached fix                                            │
│  ✓ Show "FAST-PATH" in GUI                                      │
│  ✓ Display confidence score 0.998                               │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│ FILE: server.py / poc_ui.html                                   │
│ ACTION: Return cached results to GUI                            │
│                                                                 │
│ DISPLAY:                                                        │
│  - Same RCA as before (from cache)                              │
│  - Same fix plan (from cache)                                   │
│  - Path: "fast" (not "deep")                                    │
│  - Confidence: 0.998 (99.8% match)                              │
│  - Timeline showing "2.15s" ⚡⚡⚡                                │
└─────────────────────────────────────────────────────────────────┘

TIME ELAPSED: ~2 seconds ⚡⚡⚡ (90% FASTER!)
CACHE STATUS: Same 1 vector used
```

---

## 📁 Files Involved in the Flow

### Main Files

| File | Role | Line Numbers |
|------|------|--------------|
| `server.py` | Flask server, routes requests | Line 1-50 (endpoints) |
| `pipeline_orchestrator.py` | Main logic, orchestrates all agents | Line 59-280 (main flow) |
| `vector_db_wrapper.py` | Cache initialization & search/store | Line 1-400 |
| `local_vector_cache.py` | Local file-based cache engine | Line 1-150 |
| `config.py` | Configuration (USE_LOCAL_CACHE flag) | Line 4 |
| `poc_ui.html` | Frontend GUI | Line 1-500 |

### Cache Storage File

| Path | Purpose | Content |
|------|---------|---------|
| `vector_cache/vectors.jsonl` | Persistent cache storage | One JSON object per line |

### Support Files

| File | Purpose |
|------|---------|
| `rca_agent.py` | Root cause analysis (LLM call) |
| `log_agent.py` | Collects logs for analysis |
| `fixer_agent.py` | Generates fix plans |
| `approval_agent.py` | Manages approvals |
| `kb_search.py` | Knowledge base search |

---

## 🔍 How to Verify Cache is Working

### Method 1: Check the Cache File

```bash
# On Windows PowerShell:
cat vector_cache\vectors.jsonl | ConvertFrom-Json

# Or on Linux/Mac:
cat vector_cache/vectors.jsonl | jq .
```

**Expected output after RUN 1:**
```json
{
  "id": "SMF_CPU_Usage_smf_smf-core-01",
  "values": [0.12, 0.45, 0.89, ...],  // 384 numbers
  "metadata": {
    "kpi_name": "SMF_CPU_Usage",
    "root_cause_summary": "Session setup surge...",
    "fix_actions": "[\"action1\", \"action2\"]"
  }
}
```

### Method 2: Check GUI Console Logs

**RUN 1 (should show):**
```
[LocalCache] Stored vector: SMF_CPU_Usage_smf_smf-core-01
[LocalCache] Search found 0 matches (threshold=0.85)
[DEEP-PATH] no cached match
```

**RUN 2 (should show):**
```
[LocalCache] Search found 1 matches (threshold=0.85)
[VectorDB] FAST-PATH: Cache hit (score: 0.998)
[FAST-PATH] Cache hit! Confidence: 0.998
```

### Method 3: Check Terminal Output

```bash
# Start server with:
python server.py

# Look for these logs:

# After RUN 1:
[VectorDB] Stored in local cache

# After RUN 2:
[VectorDB] Local cache hit (score: 0.998)
[ANALYSIS] Using cached RCA (skipping LLM)
```

### Method 4: Check GUI Display

**RUN 1:**
- Path shows: `deep`
- Time shows: `~19s`
- Memory hit shows: `no`

**RUN 2:**
- Path shows: `fast` ⚡
- Time shows: `~2s` ⚡
- Memory hit shows: `yes` ✅
- Confidence shows: `0.998` (99.8%)

---

## 📝 Data Flow Through Each File

### Flow Diagram

```
poc_ui.html (User clicks)
    ↓
server.py (GET /api/analyze)
    ↓
pipeline_orchestrator.py
    ├─ Line 59: Get KPI data
    ├─ Line 109: Init VectorDB (detect local cache)
    ├─ Line 127: Search cache ← HERE IS MAGIC
    │   ├─ RUN 1: Cache miss → continue
    │   └─ RUN 2: Cache hit → RETURN EARLY ⚡
    ├─ Line 151: If cache miss → Deep analysis
    │   ├─ log_agent.py
    │   ├─ rca_agent.py (calls LLM if KB miss)
    │   ├─ fixer_agent.py
    │   └─ approval_agent.py
    ├─ Line 261: Store to cache
    │   └─ vector_db_wrapper.py
    │       └─ local_vector_cache.py (writes to vectors.jsonl)
    └─ Return to server.py
        └─ Return to poc_ui.html (display results)
```

---

## ⏱️ Time Breakdown

### RUN 1 (Deep Path - First Analysis)
```
Initialization:        1 sec
KPI fetch:            <1 sec
Service identify:      1 sec
Cache search:         <1 sec (empty, fast)
Log collection:        1 sec
KB search:            <1 sec
LLM call:            10 secs ⏳ (LONGEST)
Fix generation:        2 secs
Approval creation:     1 sec
Cache store:          <1 sec
─────────────────────────
TOTAL:               ~19 seconds
```

### RUN 2 (Fast Path - With Cache)
```
Initialization:        1 sec
KPI fetch:            <1 sec
Service identify:      1 sec
Cache search:         <1 sec (HIT! ⚡)
Return cached RCA:    <1 sec
─────────────────────────
TOTAL:               ~2 seconds ⚡⚡⚡
```

### Time Saved
```
19 sec - 2 sec = 17 seconds saved
17 / 19 = 89% faster ⚡⚡⚡
```

---

## 🧪 Test Scenarios

### Test 1: Verify Fast Path with Same KPI
```
1. Run pipeline (SMF_CPU_Usage) → 19 seconds
2. Run pipeline (SMF_CPU_Usage again) → 2 seconds ✅
```

### Test 2: Verify Different KPI Uses Deep Path
```
1. Run pipeline (SMF_CPU_Usage) → 19 seconds
2. Run pipeline (UPF_Latency) → 19 seconds (different KPI, new cache)
3. Run pipeline (UPF_Latency again) → 2 seconds (cache hit) ✅
```

### Test 3: Clear Cache and Verify Reset
```bash
# Delete cache file
rm vector_cache/vectors.jsonl

# Run pipeline → 19 seconds (cache rebuilt)
```

---

## ✅ Expected Behavior

### Before Cache Implementation
```
Every run: 19 seconds
Repeat runs: Still 19 seconds
Issue: No optimization
```

### After Cache Implementation (NOW)
```
First run: 19 seconds (store to cache)
Second run: 2 seconds (cache hit) ⚡⚡⚡
Third run: 2 seconds (cache hit) ⚡⚡⚡
Fourth run: 2 seconds (cache hit) ⚡⚡⚡
...
Different KPI: 19 seconds (new cache entry)
```

---

## 🎯 Summary

**You're done!** Local cache is now enabled in `config.py`:

```python
USE_LOCAL_CACHE = True
```

**To see it in action:**

1. Start server: `python server.py`
2. Open GUI: `http://localhost:5000/poc`
3. Click "Run Pipeline" → Wait 19 seconds
4. Click "Run Pipeline" again → See 2 seconds ⚡

**To verify:**
- Check `vector_cache/vectors.jsonl` file (should have 1 entry after RUN 1, 2 after testing different KPI)
- Watch GUI for path change: "deep" → "fast" ⚡
- Watch time: 19s → 2s ⚡⚡⚡
