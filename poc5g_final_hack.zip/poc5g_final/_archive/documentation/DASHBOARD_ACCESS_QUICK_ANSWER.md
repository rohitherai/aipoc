# 🎯 Dashboard Access - Quick Answer

## **TL;DR: How to View the Dashboard**

Your `gui_dashboard.js` is **React code** that needs to run inside a React application. Here are your options:

---

## ✅ **FASTEST: Use Python Flask (5 minutes)**

```bash
# 1. Navigate to the folder
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1

# 2. Install Flask (one time only)
pip install flask

# 3. Run the setup script
python run_dashboard.py

# 4. Open browser to: http://localhost:5000
```

**That's it!** Dashboard appears at **http://localhost:5000** ✅

---

## 📋 **Why localhost:5000 Didn't Work Initially**

- ❌ `gui_dashboard.js` is a **React component** (not a running server)
- ❌ React components need to be inside a React app
- ❌ You were trying to access a non-existent server
- ✅ Now you'll create a server to serve it

---

## 🎬 **Three Setup Options (Pick One)**

### **Option A: Python (Easiest) - ⭐ Recommended**
```bash
python run_dashboard.py
# Runs at http://localhost:5000
# Time: 2 minutes
```

### **Option B: React CLI (Best for Production)**
```bash
npx create-react-app dashboard
cd dashboard
copy ..\gui_dashboard.js src\
# Update src/App.jsx to import component
npm start
# Runs at http://localhost:3000
# Time: 5 minutes
```

### **Option C: Node.js Express (Middle Ground)**
```bash
npm init -y
npm install express
node server.js
# Runs at http://localhost:5000
# Time: 3 minutes
```

---

## 🚀 **I Recommend: Option A (Python)**

**Why?**
- ✅ Simplest setup
- ✅ Uses localhost:5000 (like you wanted)
- ✅ Works immediately
- ✅ Can easily add backend connections later

**Steps:**
```bash
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1
pip install flask
python run_dashboard.py
```

Then open: **http://localhost:5000**

---

## 🎨 **What You'll See**

Once running, you'll see:

```
┌─────────────────────────────────────┐
│  5G AIOps Fault Remediation Dashboard
│                                     │
│  LEFT: KPI Cards                    │
│  ├─ SMF_CPU_Usage (78%) 🔴 RED     │
│  ├─ UPF_Throughput_Drop            │
│  ├─ AMF_Latency_P99                │
│  ├─ gNB_PDCP_Loss                  │
│  └─ NSSF_Memory_Usage              │
│                                     │
│  CENTER: 7 Pipeline Stages          │
│  ├─ 1. Ingest ✓                    │
│  ├─ 2. Embed ✓                     │
│  ├─ 3. Cache ✓                     │
│  ├─ 4. Decision ✓                  │
│  ├─ 5. RCA (⚡ or 🔍)             │
│  ├─ 6. Execution ✓                 │
│  └─ 7. Learning ✓                  │
│                                     │
│  RIGHT: Live Log                    │
│  └─ Event stream output             │
│                                     │
│  TOP RIGHT: Metrics                 │
│  ├─ Total Runs: 0                  │
│  ├─ Cache Hit Rate: 0%             │
│  └─ Status: ● MONITORING           │
└─────────────────────────────────────┘
```

**Click on any RED KPI card to trigger demo** 🎬

---

## 🎯 **Next Steps After Dashboard Loads**

1. ✅ Dashboard running at http://localhost:5000
2. 🔴 Click on red KPI card (SMF_CPU_Usage)
3. 📊 Watch 7 stages execute in sequence
4. 💾 See approval modal appear
5. ✅ Click "Approve & Execute"
6. 📝 View KB entry stored
7. 📈 Check metrics updated

---

## 🔧 **If You Get Errors**

### "Flask not found"
```bash
pip install flask
```

### "Port 5000 in use"
```bash
# Edit run_dashboard.py and change:
app.run(port=5001)  # Use 5001 instead
```

### "gui_dashboard.js not found"
Make sure you're in the correct folder:
```bash
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1
dir gui_dashboard.js  # Should exist
```

### "Module not found: React"
The React CDN is loaded from internet. Make sure you have internet connection and the script can access `unpkg.com`.

---

## 📚 **Full Documentation Available**

If you need details, see:
- [DASHBOARD_SETUP_GUIDE.md](DASHBOARD_SETUP_GUIDE.md) - React/full setup
- [DASHBOARD_PYTHON_ALTERNATIVE.md](DASHBOARD_PYTHON_ALTERNATIVE.md) - Python options
- [GUI_DASHBOARD_QUICKSTART.md](GUI_DASHBOARD_QUICKSTART.md) - Feature overview
- [GUI_DASHBOARD_IMPROVEMENTS.md](GUI_DASHBOARD_IMPROVEMENTS.md) - Architecture details

---

## ✅ **Ready?**

Pick one command and run it:

```bash
# FASTEST (recommended)
cd C:\Users\vb20\Downloads\sourceCode_v5\AI_POC_5G_V1 && pip install flask && python run_dashboard.py
```

Then open: **http://localhost:5000** ✅

---

**Status:** Dashboard code is ready. Now you just need to serve it!
