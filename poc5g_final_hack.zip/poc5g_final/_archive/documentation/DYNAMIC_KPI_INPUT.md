# Dynamic KPI Input Guide

## Overview

The system now supports **dynamic KPI data input** from multiple sources in priority order:

1. **Custom Uploaded Data** (highest priority) - Upload your own CSV/JSON files
2. **Grafana** - If configured with GRAFANA_URL + GRAFANA_TOKEN
3. **Dummy Data** - Fallback `data/dummy_kpis.json` file

Once you upload custom data, the pipeline will use it automatically instead of dummy data.

## Data Format

### Required Fields (All)
Every KPI must have these fields:
- `kpi_name` - Name of the KPI (e.g., "CPU_Usage", "Memory_Usage")
- `value` - Current metric value (numeric)
- `threshold` - Alert threshold (numeric)

### Optional Fields
- `host` - Host/server name (default: "unknown")
- `timestamp` - ISO timestamp (default: current time)

### Recommended Fields (for context)
- `service` - Service name (e.g., "smf", "upf", "nrf")
- `source` - Where data came from (e.g., "prometheus", "custom")

---

## Method 1: Upload JSON File

### JSON File Format

**File: kpis.json**
```json
[
  {
    "kpi_name": "SMF_CPU_Usage",
    "value": 85,
    "threshold": 70,
    "host": "smf-core-01",
    "timestamp": "2026-05-25T14:30:00Z",
    "service": "smf"
  },
  {
    "kpi_name": "UPF_Memory_Usage",
    "value": 82,
    "threshold": 80,
    "host": "upf-node-01",
    "timestamp": "2026-05-25T14:30:00Z",
    "service": "upf"
  },
  {
    "kpi_name": "NRF_Connection_Latency",
    "value": 250,
    "threshold": 200,
    "host": "nrf-server",
    "timestamp": "2026-05-25T14:30:00Z",
    "service": "nrf"
  }
]
```

### Upload via cURL
```bash
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@kpis.json"
```

### Upload via Python
```python
import requests

with open('kpis.json', 'r') as f:
    files = {'file': f}
    response = requests.post(
        'http://localhost:5000/api/kpi/upload',
        files=files
    )
    print(response.json())
```

---

## Method 2: Upload CSV File

### CSV File Format

**File: kpis.csv**
```csv
kpi_name,value,threshold,host,timestamp,service
SMF_CPU_Usage,85,70,smf-core-01,2026-05-25T14:30:00Z,smf
UPF_Memory_Usage,82,80,upf-node-01,2026-05-25T14:30:00Z,upf
NRF_Connection_Latency,250,200,nrf-server,2026-05-25T14:30:00Z,nrf
PFCP_Errors,12,10,smf-core-01,2026-05-25T14:30:00Z,smf
GTP_Packet_Loss,1.5,2,upf-node-01,2026-05-25T14:30:00Z,upf
```

### Required CSV Columns
```
kpi_name, value, threshold, host (optional: timestamp, service)
```

### Upload via cURL
```bash
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@kpis.csv"
```

### Upload via Python
```python
import requests

with open('kpis.csv', 'r') as f:
    files = {'file': f}
    response = requests.post(
        'http://localhost:5000/api/kpi/upload',
        files=files
    )
    print(response.json())
```

---

## Method 3: Upload Raw JSON Data (POST)

### API Request
```bash
curl -X POST http://localhost:5000/api/kpi/data \
  -H "Content-Type: application/json" \
  -d '{
    "kpis": [
      {
        "kpi_name": "CPU_Usage",
        "value": 85,
        "threshold": 80,
        "host": "server-01"
      },
      {
        "kpi_name": "Memory_Usage",
        "value": 72,
        "threshold": 85,
        "host": "server-01"
      }
    ]
  }'
```

### Python Example
```python
import requests
import json

kpi_data = {
    "kpis": [
        {
            "kpi_name": "CPU_Usage",
            "value": 85,
            "threshold": 80,
            "host": "server-01",
            "timestamp": "2026-05-25T14:30:00Z"
        },
        {
            "kpi_name": "Memory_Usage",
            "value": 72,
            "threshold": 85,
            "host": "server-01",
            "timestamp": "2026-05-25T14:30:00Z"
        }
    ]
}

response = requests.post(
    'http://localhost:5000/api/kpi/data',
    json=kpi_data
)
print(response.json())
```

---

## Check Current Data Source

### API Request
```bash
curl http://localhost:5000/api/kpi/source
```

### Response Examples

**With Custom Upload:**
```json
{
  "source": "custom_upload",
  "kpi_count": 5,
  "kpi_names": ["SMF_CPU_Usage", "UPF_Memory_Usage", "PFCP_Errors"]
}
```

**With Grafana:**
```json
{
  "source": "grafana",
  "url": "http://localhost:3000",
  "configured": true
}
```

**With Dummy Data (Default):**
```json
{
  "source": "dummy_data",
  "file": "data/dummy_kpis.json"
}
```

---

## Clear Custom Data

### API Request
```bash
curl -X DELETE http://localhost:5000/api/kpi/custom
```

### Response
```json
{
  "status": "success",
  "message": "Custom KPI data cleared"
}
```

After clearing, the system will revert to Grafana (if configured) or dummy data.

---

## End-to-End Workflow

### Step 1: Upload Custom KPI Data
```bash
# Upload your CSV or JSON file
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@my_kpis.json"

# Response:
# {
#   "status": "success",
#   "message": "Successfully loaded 5 KPIs",
#   "kpi_count": 5,
#   "kpis": [...]
# }
```

### Step 2: Verify Data Source
```bash
curl http://localhost:5000/api/kpi/source

# Response shows your data is loaded and will be used
```

### Step 3: Run Pipeline
```bash
# Get analysis results (using your custom data)
curl http://localhost:5000/api/analyze

# Pipeline will process all KPIs from your custom upload
```

### Step 4: Optional - Clear and Revert
```bash
# When done, revert to default source
curl -X DELETE http://localhost:5000/api/kpi/custom
```

---

## Data Validation

The system validates all KPI data:

### ✅ Valid Example
```json
[
  {
    "kpi_name": "CPU_Usage",
    "value": 85.5,
    "threshold": 80,
    "host": "server-01"
  }
]
```

### ❌ Invalid Examples

**Missing required field:**
```json
[
  {
    "kpi_name": "CPU_Usage",
    "value": 85.5
    // Missing: threshold
  }
]
```
Error: `KPI #0 missing 'threshold' field`

**Wrong data type:**
```json
[
  {
    "kpi_name": "CPU_Usage",
    "value": "high",  // Should be numeric
    "threshold": 80
  }
]
```
Error: Will be converted to string in CSV mode or JSON parsing will try to handle it

---

## Common Scenarios

### Scenario 1: Analyze Real Prometheus Data

1. Export metrics from Prometheus as JSON:
```bash
# Query Prometheus API
curl 'http://prometheus:9090/api/v1/query?query=node_cpu_seconds_total' \
  > metrics.json
```

2. Convert/format to KPI structure:
```python
import json
import requests

with open('metrics.json', 'r') as f:
    metrics = json.load(f)

kpis = []
for result in metrics['data']['result']:
    kpis.append({
        "kpi_name": result['metric']['__name__'],
        "value": float(result['value'][1]),
        "threshold": 80,  # Set appropriate threshold
        "host": result['metric']['instance']
    })

# Upload to system
response = requests.post(
    'http://localhost:5000/api/kpi/data',
    json={"kpis": kpis}
)
```

### Scenario 2: Daily Batch Analysis

Create a scheduled job:
```bash
#!/bin/bash
# daily_analysis.sh

# 1. Export data from monitoring system
prometheus_query | format_as_json > daily_kpis.json

# 2. Upload to analysis system
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@daily_kpis.json"

# 3. Run pipeline
curl http://localhost:5000/api/analyze > results.json

# 4. Send results via email/notification
send_notifications results.json

# 5. Clear for next run
curl -X DELETE http://localhost:5000/api/kpi/custom
```

### Scenario 3: Real-Time Streaming

```python
import requests
import time

def stream_kpi_analysis():
    """Continuously send KPIs as they arrive."""
    
    while True:
        # Get latest KPIs from your source
        kpis = get_latest_kpis()  # Your function
        
        # Upload for immediate analysis
        response = requests.post(
            'http://localhost:5000/api/kpi/data',
            json={"kpis": kpis}
        )
        
        if response.ok:
            # Run pipeline
            analysis = requests.get(
                'http://localhost:5000/api/analyze'
            ).json()
            
            # Process results
            for result in analysis['results']:
                print(f"✅ {result['kpi_name']}: {result['root_cause']}")
        
        # Wait before next batch
        time.sleep(60)

stream_kpi_analysis()
```

---

## Error Handling

### Invalid JSON
```json
Error: Invalid JSON: Expecting value: line 1 column 1 (char 0)
```
✓ Fix: Ensure file is valid JSON format

### Missing Required Field
```json
Error: KPI #2 missing 'kpi_name' field
```
✓ Fix: Add missing field to all KPI objects

### Unsupported File Type
```json
Error: Unsupported file type: xml. Use 'json' or 'csv'
```
✓ Fix: Use .json or .csv file extension

### Empty File
```json
Error: No 'kpis' array provided
```
✓ Fix: Ensure JSON POST has `"kpis"` key with array value

---

## Performance Tips

1. **Batch uploads**: Upload multiple KPIs at once (faster than individual calls)
2. **Deduplicate**: Remove duplicate KPI entries before upload
3. **Timestamps**: Include timestamps for better correlation with events
4. **Clear regularly**: Clear old custom data after analysis to revert to defaults

---

## Integration Examples

### Apache Kafka Producer
```python
from kafka import KafkaProducer
import json
import requests

producer = KafkaProducer(bootstrap_servers=['localhost:9092'])

def send_kpi_to_analysis(kpi_event):
    """Send Kafka event to analysis system."""
    kpi_data = json.loads(kpi_event.value)
    
    response = requests.post(
        'http://localhost:5000/api/kpi/data',
        json={"kpis": [kpi_data]}
    )
    
    if response.ok:
        analysis = requests.get(
            'http://localhost:5000/api/analyze'
        ).json()
        producer.send('analysis-results', json.dumps(analysis).encode())

# Subscribe and process
consumer = KafkaConsumer('kpi-events', bootstrap_servers=['localhost:9092'])
for message in consumer:
    send_kpi_to_analysis(message)
```

---

## Summary

✅ **Fully dynamic KPI input** - Use any file or data source  
✅ **No hardcoding** - Data driven, not file driven  
✅ **Multiple formats** - JSON, CSV, or raw API data  
✅ **Fallback support** - Reverts to Grafana/dummy if needed  
✅ **Easy integration** - Simple REST API for all operations  

The system now adapts to **your data**, not the other way around!
