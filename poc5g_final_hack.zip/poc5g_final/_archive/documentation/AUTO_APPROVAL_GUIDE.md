# ✨ AUTO APPROVAL & REAL-TIME KPI SIMULATION GUIDE

## Overview

Your AIOps pipeline has been enhanced with:
1. ✅ **Auto-Approval** - No more manual approval prompts
2. ✅ **Real-Time KPI Simulation** - Generates live KPI data every 10 seconds
3. ✅ **Intelligent Data Loading** - Automatically uses live or dummy KPI data
4. ✅ **Production-Ready Logging** - Clear visibility into all pipeline stages

---

## PART 1: AUTO APPROVAL

### What Changed

**Before:** Pipeline stopped at "pending_approval" waiting for user input
```
⏳ Awaiting approval decision...
Do you approve this fix? (yes/no): [BLOCKED - waiting for input]
```

**After:** Pipeline automatically approves fixes in demo mode
```
✅ AUTO-APPROVED (Demo Mode)
⚙️ Execution simulated: success
💾 Data stored in ChromaDB
```

### How to Enable/Disable

**File:** `config.py`

**Enable Auto-Approval (Default - Demo Mode):**
```python
AUTO_APPROVE = True  # Auto-approve all fixes
```

**Disable for Manual Approval (Production):**
```python
AUTO_APPROVE = False  # Require manual CLI input
```

### Using Auto-Approval

```bash
# Demo mode - no manual input needed
python main.py
```

Output:
```
📡 Loaded live KPI from: data/live_kpi.json
🚀 AIOPS PIPELINE STARTED
✅ FAST PATH - CACHE HIT!
✅ AUTO-APPROVED (Demo Mode)
⚙️ Execution simulated: success
💾 STORED: Solution persisted to ChromaDB
```

### What Gets Stored

When auto-approval happens:
```json
{
  "approval_status": "approved",
  "execution_status": "success",
  "stored_in_memory": true,
  "memory_hit": true
}
```

✅ **Data is persisted to ChromaDB** - Next run will find it in cache!

---

## PART 2: REAL-TIME KPI SIMULATION

### What It Does

The `kpi_stream_agent.py` generates random but realistic KPI data every 10 seconds and automatically triggers the pipeline.

### Quick Start

```bash
# Run for 60 seconds with 10 second intervals (default)
python kpi_stream_agent.py

# Run for 120 seconds with 15 second intervals
python kpi_stream_agent.py 120 15
```

### Generated KPIs

The agent randomly generates one of three KPI types:

**1. SMF_CPU_Usage**
- Service: smf
- Host: smf-core-01
- Values: 60-95%
- Threshold: 70%

**2. UPF_Latency**
- Service: upf
- Host: upf-node-01
- Values: 30-80ms
- Threshold: 50ms

**3. AMF_Session_Count**
- Service: amf
- Host: amf-core-02
- Values: 40000-65000
- Threshold: 50000

### Output Example

```
[12:52:11] 🚀 KPI Stream Agent initialized
[12:52:11] 📂 Output file: C:\...\data\live_kpi.json
[12:52:11] 📡 STARTING KPI STREAM (Duration: 60s, Interval: 10s)

------
[12:52:11] 📊 Run #1 - 12:52:11
[12:52:11] 📡 Generated KPI: SMF_CPU_Usage = 78.45
[12:52:11] 💾 KPI saved to: data/live_kpi.json
[12:52:11] 🔄 Triggering pipeline...
[12:52:15] ✅ Pipeline execution completed
[12:52:15] 🔬 DEEP PATH: Full RCA executed
[12:52:15] ✅ AUTO-APPROVED: Fix approved automatically
[12:52:15] ⏳ Waiting 10s until next KPI...

------
[12:52:25] 📊 Run #2 - 12:52:25
[12:52:25] 📡 Generated KPI: UPF_Latency = 55.23
[12:52:25] 💾 KPI saved to: data/live_kpi.json
[12:52:25] 🔄 Triggering pipeline...
[12:52:27] ✅ Pipeline execution completed
[12:52:27] ⚡ FAST PATH: Cache hit detected
[12:52:27] ✅ AUTO-APPROVED: Fix approved automatically
```

---

## PART 3: DATA LOADING LOGIC

### How It Works

The pipeline now intelligently loads KPI data with fallback:

```
Priority Order:
1. Live KPI: data/live_kpi.json (created by KPI stream agent)
   ↓ [If not found or error]
2. Dummy KPI: data/dummy_kpis.json (static test data)
   ↓ [If not found]
3. Error - No KPI data available
```

### Testing Different Sources

**Test with Live KPI:**
```bash
# Terminal 1: Start KPI stream
python kpi_stream_agent.py 120 10

# Terminal 2: Runs will automatically use live_kpi.json
# (KPI stream agent creates it every 10 seconds)
```

Output:
```
📡 Loaded live KPI from: data/live_kpi.json
📊 KPI Data: [{'kpi_name': 'SMF_CPU_Usage', ...}]
```

**Test with Dummy KPI:**
```bash
# If no live KPI file exists, it falls back automatically
python main.py
```

Output:
```
📦 Using dummy KPI data from: data/dummy_kpis.json
```

---

## PART 4: COMPLETE WORKFLOW

### Scenario: Demo a Full Run

**Step 1: Start the KPI Stream (Opens new terminal)**
```bash
cd AI_POC_5G_V1
python kpi_stream_agent.py 60 10  # 60 sec duration, 10 sec interval
```

**Step 2: Watch the Logs**

The agent will:
1. Generate random KPI data
2. Save to `data/live_kpi.json`
3. Trigger `main.py` automatically
4. Show whether cache hit or deep path
5. Show auto-approval happening
6. Repeat every 10 seconds

**Example Timeline:**

```
[12:00:00] Run #1 - SMF_CPU_Usage
  → 🔬 DEEP PATH (first time, no cache)
  → ✅ AUTO-APPROVED
  → 💾 STORED in ChromaDB

[12:00:10] Run #2 - UPF_Latency
  → ⚡ FAST PATH (different KPI, first time)
  → ✅ AUTO-APPROVED
  → 💾 STORED

[12:00:20] Run #3 - SMF_CPU_Usage
  → ✅ CACHE HIT! (same KPI, second time)
  → ❌ NO LLM CALL (reused cached solution)
  → ✅ AUTO-APPROVED
  → 💾 UPDATED in ChromaDB

[12:00:30] Run #4 - AMF_Session_Count
  → 🔬 DEEP PATH (new KPI, first time)
  → ✅ AUTO-APPROVED
  → 💾 STORED
```

---

## PART 5: MANUAL TESTING

### Test 1: Single Run (Auto-Approval)

```bash
python main.py
```

Expected output:
```
✅ AUTO-APPROVED (Demo Mode)
⚙️ Execution simulated: success
💾 STORED: Solution persisted to ChromaDB
```

### Test 2: Manual Approval Mode

Edit `config.py`:
```python
AUTO_APPROVE = False  # Require manual input
```

Then run:
```bash
python main.py
```

Expected output:
```
Do you approve this fix? (yes/no): yes
✅ Fix APPROVED - Proceeding with execution
```

### Test 3: KPI Stream (60 seconds)

```bash
python kpi_stream_agent.py 60 10
```

Generates 6 runs over 60 seconds, demonstrates cache hits.

### Test 4: KPI Stream (2 minutes with realistic distribution)

```bash
python kpi_stream_agent.py 120 5  # 24 runs in 2 minutes
```

Shows clear pattern of cache hits increasing over time.

---

## PART 6: EXPECTED BEHAVIOR

### First Run (Empty Cache)

```
Pipeline: SMF_CPU_Usage
Cache: ❌ Not found
Path: 🔬 DEEP PATH
LLM: ✅ Called
Result: Analyzed and approved
Storage: 💾 Saved to ChromaDB
```

### Subsequent Runs (Same KPI)

```
Pipeline: SMF_CPU_Usage
Cache: ✅ Found! (Score: 1.0)
Path: ⚡ FAST PATH
LLM: ❌ NOT called
Result: Reused from cache
Storage: 💾 Updated in ChromaDB
```

### Cache Hit Statistics

After running KPI stream for 60 seconds (6 runs):
```
Fast Path Hits: 3-4 (50-67%)
Deep Path Runs: 2-3 (33-50%)
Total Records in Cache: 2-3
```

---

## PART 7: ARCHITECTURE UNCHANGED

✅ **What Stayed the Same:**
- Vector DB structure (ChromaDB)
- Embedding logic (Capgemini API)
- RCA agent functionality
- Storage conditions
- Cache matching algorithm

✅ **What's New:**
- AUTO_APPROVE config flag
- Auto-approval in get_user_approval()
- load_kpi_data() function
- kpi_stream_agent.py new file

✅ **What's Enhanced:**
- Approval workflow (auto + manual)
- KPI data source (live + dummy)
- Logging (more detailed)

---

## PART 8: TROUBLESHOOTING

### KPI Stream Not Triggering Pipeline

**Issue:** `python kpi_stream_agent.py` runs but pipeline doesn't execute

**Solution:** Make sure you're in the correct directory:
```bash
cd AI_POC_5G_V1
python kpi_stream_agent.py
```

### Auto-Approval Not Working

**Issue:** Still seeing "Do you approve?" prompt

**Solution:** Check `config.py`:
```python
# Make sure this is set to True
AUTO_APPROVE = True
```

### Cache Not Found on Second Run

**Issue:** Second run still goes through deep path instead of using cache

**Solution:** This is expected if:
1. First run hasn't completed yet
2. live_kpi.json has a different KPI name
3. ChromaDB is corrupted - clear `chroma_db/` and restart

### Data Not Persisting

**Issue:** `stored_in_memory: false` in results

**Solution:** Check:
1. AUTO_APPROVE is True
2. Approval status changes from "pending_approval" to "approved"
3. ChromaDB is writable (check `chroma_db/` directory)

---

## PART 9: QUICK REFERENCE

### Config Changes

```python
# config.py
AUTO_APPROVE = True   # Enable auto-approval (default)
AUTO_APPROVE = False  # Require manual approval
```

### New Files

- `kpi_stream_agent.py` - Real-time KPI simulation agent

### Modified Files

- `config.py` - Added AUTO_APPROVE flag
- `main.py` - Added auto-approval logic + load_kpi_data()

### Data Files

- `data/live_kpi.json` - Created by KPI stream agent
- `data/dummy_kpis.json` - Fallback static KPI data

---

## SUMMARY

| Feature | Before | After |
|---------|--------|-------|
| Approval | Manual CLI input | Auto + Manual support |
| KPI Source | Static dummy_kpis.json | Live JSON or dummy fallback |
| Pipeline Blocking | Yes (pending_approval) | No (auto-approved) |
| Storage | Conditional on approval | Guaranteed on approval |
| Demo Mode | Requires manual input | No manual input needed |
| Real-Time | Not supported | Full support (every 10 sec) |
| Cache Reuse | Works but setup hard | Works automatically |

---

## 🚀 YOU'RE READY!

Your AIOps pipeline is now:
- ✅ Demo-ready (no manual intervention)
- ✅ Real-time enabled (live KPI simulation)
- ✅ Cache-friendly (auto-approval enables storage)
- ✅ Production-capable (manual mode available)

Start with:
```bash
python kpi_stream_agent.py 60 10
```

Watch real-time KPI processing, cache hits, and auto-approvals happen automatically! 🎉
