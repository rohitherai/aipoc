# Dynamic KPI Input - Implementation Summary

## Confirmation: ✅ System is NOW Fully Dynamic

### Before
- ❌ Hardcoded dummy JSON file (`data/dummy_kpis.json`)
- ❌ Only Grafana or dummy data options
- ❌ No way to upload custom data

### After
- ✅ **Fully dynamic** - accepts any CSV/JSON file
- ✅ **Multiple sources** - Custom upload → Grafana → Dummy (priority order)
- ✅ **Easy upload** - REST API for file and JSON uploads
- ✅ **No hardcoding** - Data-driven, not file-driven

---

## What Was Added

### 1. **KPI Data Manager** (`kpi_data_manager.py`)
```python
# Handles multiple data sources with fallback
- load_from_json_string()      # Parse JSON files
- load_from_csv_string()       # Parse CSV files
- upload_kpi_data()            # Store custom data
- get_kpi_data_with_fallback() # Priority: custom → Grafana → dummy
- get_data_source_info()       # Check current source
- clear_custom_kpi_data()      # Revert to defaults
```

### 2. **Pipeline Updates** (`pipeline_orchestrator.py`)
- Updated to use `get_kpi_data_with_fallback()` instead of hardcoded `get_kpi_data()`
- Seamlessly supports any KPI source

### 3. **REST API Endpoints** (`server.py`)
```
POST   /api/kpi/upload      ← Upload CSV/JSON file
POST   /api/kpi/data        ← Upload raw JSON data
GET    /api/kpi/source      ← Check current data source
DELETE /api/kpi/custom      ← Clear custom data & revert
```

---

## Usage Examples

### Upload Custom CSV
```bash
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@my_kpis.csv"
```

### Upload Custom JSON
```bash
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@my_kpis.json"
```

### Upload Raw JSON Data (No File)
```bash
curl -X POST http://localhost:5000/api/kpi/data \
  -H "Content-Type: application/json" \
  -d '{
    "kpis": [
      {"kpi_name": "CPU", "value": 85, "threshold": 80, "host": "server1"}
    ]
  }'
```

### Check Current Source
```bash
curl http://localhost:5000/api/kpi/source
# Returns: {"source": "custom_upload", "kpi_count": 5, ...}
```

### Revert to Default
```bash
curl -X DELETE http://localhost:5000/api/kpi/custom
```

---

## Data Flow

### Priority Order (Automatic Fallback)
```
┌─────────────────────────────────────────┐
│  1. Custom Uploaded Data (Highest)      │
│     └─ Use if available                 │
└─────────────────┬───────────────────────┘
                  │ (if not available)
                  ▼
┌─────────────────────────────────────────┐
│  2. Grafana (if configured)             │
│     └─ Use if GRAFANA_URL + TOKEN set   │
└─────────────────┬───────────────────────┘
                  │ (if not available)
                  ▼
┌─────────────────────────────────────────┐
│  3. Dummy Data (Fallback)               │
│     └─ Always available (data/...)      │
└─────────────────────────────────────────┘
```

---

## Supported Data Formats

### CSV Format
```csv
kpi_name,value,threshold,host,timestamp,service
CPU_Usage,85,80,server1,2026-05-25T14:30:00Z,system
Memory_Usage,72,85,server1,2026-05-25T14:30:00Z,system
```

### JSON Format
```json
[
  {
    "kpi_name": "CPU_Usage",
    "value": 85,
    "threshold": 80,
    "host": "server1",
    "timestamp": "2026-05-25T14:30:00Z",
    "service": "system"
  }
]
```

### Required Fields
- `kpi_name` - KPI identifier (string)
- `value` - Current value (numeric)
- `threshold` - Alert threshold (numeric)

### Optional Fields
- `host` - Server/device name (default: "unknown")
- `timestamp` - ISO timestamp (default: now)
- `service` - Service identifier (default: derived from kpi_name)

---

## Real-World Scenarios

### Scenario 1: Daily Batch Analysis
```bash
# 1. Export from monitoring system
prometheus_export > daily_kpis.json

# 2. Upload to analysis system
curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@daily_kpis.json"

# 3. Run pipeline
curl http://localhost:5000/api/analyze > results.json

# 4. Clear for next day
curl -X DELETE http://localhost:5000/api/kpi/custom
```

### Scenario 2: Real-Time Analysis
```python
import requests

# Stream KPIs as they arrive
for kpi_batch in get_incoming_kpis():
    requests.post(
        'http://localhost:5000/api/kpi/data',
        json={"kpis": kpi_batch}
    )
    
    # Immediate analysis
    analysis = requests.get(
        'http://localhost:5000/api/analyze'
    ).json()
    
    # Process results
    for result in analysis['results']:
        send_alert(result)
```

### Scenario 3: Multi-Source Integration
```python
# Combine data from multiple sources
kpis = []

# Add Prometheus data
kpis.extend(fetch_from_prometheus())

# Add Grafana data
kpis.extend(fetch_from_grafana())

# Add custom metrics
kpis.extend(fetch_from_custom_app())

# Analyze all together
requests.post(
    'http://localhost:5000/api/kpi/data',
    json={"kpis": kpis}
)
```

---

## Key Benefits

### 🎯 Flexibility
- ✅ No file hardcoding required
- ✅ Accept any KPI source/format
- ✅ Easy integration with existing systems

### 📊 Fallback Support
- ✅ Graceful degradation
- ✅ Works offline (dummy data)
- ✅ Automatic source switching

### 🔄 Easy Workflow
- ✅ Single API call to upload
- ✅ Pipeline processes immediately
- ✅ Revert to defaults anytime

### 🛡️ Safety
- ✅ Data validation on upload
- ✅ Clear error messages
- ✅ No data loss (can always clear)

---

## Files Modified/Created

| File | Status | Change |
|------|--------|--------|
| `kpi_data_manager.py` | ✅ NEW | Core dynamic KPI handling |
| `pipeline_orchestrator.py` | ✅ UPDATED | Use dynamic KPI loading |
| `server.py` | ✅ UPDATED | Added 4 new REST endpoints |
| `DYNAMIC_KPI_INPUT.md` | ✅ NEW | Comprehensive user guide |

---

## Testing the Implementation

### Test 1: Upload CSV File
```bash
echo "kpi_name,value,threshold,host
CPU_Usage,85,80,server1
Memory_Usage,72,85,server1" > test.csv

curl -X POST http://localhost:5000/api/kpi/upload \
  -F "file=@test.csv"
  
# Expected: {"status": "success", "kpi_count": 2}
```

### Test 2: Upload JSON Data
```bash
curl -X POST http://localhost:5000/api/kpi/data \
  -H "Content-Type: application/json" \
  -d '{
    "kpis": [
      {"kpi_name": "CPU", "value": 85, "threshold": 80, "host": "server1"}
    ]
  }'

# Expected: {"status": "success", "kpi_count": 1}
```

### Test 3: Check Source
```bash
curl http://localhost:5000/api/kpi/source

# Expected: {"source": "custom_upload", "kpi_count": 1, "kpi_names": ["CPU"]}
```

### Test 4: Run Pipeline
```bash
curl http://localhost:5000/api/analyze

# Expected: Results analyzed using your custom KPI data
```

### Test 5: Clear & Revert
```bash
curl -X DELETE http://localhost:5000/api/kpi/custom

curl http://localhost:5000/api/kpi/source

# Expected: {"source": "dummy_data", "file": "data/dummy_kpis.json"}
```

---

## Next Steps

1. **Start the server**: `python server.py`
2. **Upload your data**: Use any of the methods above
3. **Verify loading**: `curl http://localhost:5000/api/kpi/source`
4. **Run pipeline**: `curl http://localhost:5000/api/analyze`
5. **View results**: Check the output for analysis

---

## Summary

The system is now **100% dynamic** - it can accept KPI data from:
- ✅ Uploaded CSV files
- ✅ Uploaded JSON files
- ✅ Raw JSON API calls
- ✅ Grafana (if configured)
- ✅ Dummy data (fallback)

**No hardcoding. No file modifications needed. Just upload and analyze!**
