# 🔐 API Key Security Guide

## Overview
This POC uses sensitive API keys for:
- **Capgemini GenAI** (LLM Analysis)
- **Pinecone** (Vector Database)  
- **AWS DynamoDB** (Optional Memory Backend)

**NEVER commit these keys to version control.**

---

## Setup Instructions

### 1️⃣ Create Your .env File

```bash
# Copy the template
cp .env.example .env

# Edit .env and add your actual API keys
# DO NOT commit .env to git!
```

### 2️⃣ Configure API Keys Securely

Edit `.env` with your credentials:

```env
# Capgemini GenAI (Required for LLM)
CAPGEMINI_GENAI_API_KEY=your_actual_key_here

# Pinecone (Optional, for vector search)
PINECONE_API_KEY=your_actual_key_here

# AWS (Optional, for DynamoDB memory)
AWS_ACCESS_KEY_ID=your_actual_key_here
AWS_SECRET_ACCESS_KEY=your_actual_key_here
```

### 3️⃣ Load Environment Variables

**On Linux/macOS:**
```bash
source .env
python server.py
```

**On Windows PowerShell:**
```powershell
Get-Content .env | ForEach-Object {
    $name, $value = $_.Split("=")
    if ($name) { [Environment]::SetEnvironmentVariable($name, $value) }
}
python server.py
```

**Or set them directly:**
```powershell
$env:CAPGEMINI_GENAI_API_KEY="your_key_here"
$env:PINECONE_API_KEY="your_key_here"
python server.py
```

---

## Security Best Practices

### ✅ DO:
- Use environment variables for all secrets
- Store keys in `.env` (not in code)
- Use `.env.example` as template only
- Enable `.gitignore` protection
- Rotate keys periodically
- Use least-privilege IAM roles (AWS)
- Set key expiration dates when possible

### ❌ DON'T:
- Hardcode API keys in Python files
- Commit `.env` to Git/GitHub
- Share API keys in logs or console output
- Use personal API keys for shared deployments
- Leave keys in browser developer tools
- Pass keys as command-line arguments

---

## Verification

Check that the server can access keys without exposing them:

```bash
curl http://localhost:5000/api/health
```

Response (keys are hidden):
```json
{
  "status": "ok",
  "capgemini_key_set": true,
  "pinecone_api_key_set": true,
  "grafana_configured": false
}
```

✅ Notice: Only boolean values shown, never the actual keys!

---

## Key Rotation

When you need to update keys:

1. Generate new API key in provider console
2. Update `.env` file with new key
3. Restart the application
4. Delete old key from provider console

---

## Production Deployment

For production, use a secrets management system:

### AWS Secrets Manager
```python
import boto3
client = boto3.client('secretsmanager')
secret = client.get_secret_value(SecretId='5g-poc-keys')
api_key = secret['SecretString']
```

### HashiCorp Vault
```python
import hvac
client = hvac.Client(url='http://vault.example.com')
secret = client.secrets.kv.v2.read_secret_version(path='5g-poc')
api_key = secret['data']['data']['capgemini_key']
```

### Azure Key Vault
```python
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
client = SecretClient(vault_url="https://myvault.vault.azure.net/", credential=DefaultAzureCredential())
api_key = client.get_secret("capgemini-key").value
```

---

## Troubleshooting

### "KeyError: CAPGEMINI_GENAI_API_KEY"
- Ensure `.env` is created and API key is set
- Check that .env file is in the AI_POC_5G_V1 directory
- Verify PowerShell executed the env setup command

### "SSL Certificate Verify Failed"
- This is NOT an API key issue
- Related to SSL/TLS certificate validation
- See: [SSL_CERTIFICATE_VERIFY_FAILED_RESOLUTION.md](./docs/ssl-resolution.md)

### API Key Accidentally Exposed?
1. **Immediately rotate** the key in provider console
2. **Delete** the old key
3. **Update** `.env` with new key
4. **Restart** the application

---

## Questions?

- Capgemini GenAI: Contact your Capgemini account manager
- Pinecone: https://docs.pinecone.io
- AWS: https://docs.aws.amazon.com/secretsmanager/
