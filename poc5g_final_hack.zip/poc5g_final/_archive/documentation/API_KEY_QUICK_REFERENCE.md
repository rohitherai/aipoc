# 🔑 API KEY QUICK REFERENCE

## ✅ Status: SAFE TO SHARE
Your API keys have been removed. Code is ready for sharing!

---

## 📝 Quick Update Steps

### 1️⃣ Open `.env` file
```
Location: AI_POC_5G_V1/.env
```

### 2️⃣ Find these lines
```
CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here
PINECONE_API_KEY=your_pinecone_api_key_here
PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io
```

### 3️⃣ Replace with your keys
```
CAPGEMINI_GENAI_API_KEY=<your_actual_capgemini_key>
PINECONE_API_KEY=<your_actual_pinecone_key>
PINECONE_INDEX_HOST=<your_actual_index_host>
```

### 4️⃣ Test connection
```powershell
python diagnose_pinecone.py
```

---

## 🔗 Where to Get Keys

| Service | URL | What to Copy |
|---------|-----|--------------|
| **Capgemini** | https://generative.engine.capgemini.com/ | API Key (Full string) |
| **Pinecone API** | https://app.pinecone.io/ | API Keys section |
| **Pinecone Index** | https://app.pinecone.io/ | Indexes > Host column |

---

## ⚡ Before/After

### BEFORE (With Keys)
```env
CAPGEMINI_GENAI_API_KEY=PAj75Tdrtn9n6F6bSdVEo9v85zh1dijp62GvGoGv
PINECONE_API_KEY=pcsk_3bJovq_5UPhr8UcamTE6PVxWw5oGbH5Ygy7PArVo8UPtxd9BFa5swTPpBvJA9GdYdTHocn
PINECONE_INDEX_HOST=https://kpi-index-c2y8jh7.svc.aped-4627-b74a.pinecone.io
```
❌ NOT SAFE TO SHARE

### AFTER (Placeholder)
```env
CAPGEMINI_GENAI_API_KEY=your_capgemini_api_key_here
PINECONE_API_KEY=your_pinecone_api_key_here
PINECONE_INDEX_HOST=https://your-index-name-xxxxx.svc.pinecone.io
```
✅ SAFE TO SHARE

---

## 🚨 Security Checklist

- [ ] Old API keys are removed from `.env`
- [ ] `.env` is in `.gitignore`
- [ ] No API keys in Python source files (only in `.env`)
- [ ] Ready to share code with others
- [ ] Ready to upload to GitHub (without `.env`)

---

## 📖 Full Guide
See **API_KEY_REPLACEMENT_GUIDE.md** for detailed instructions
