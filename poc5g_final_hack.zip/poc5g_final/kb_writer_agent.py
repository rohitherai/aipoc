"""
kb_writer_agent.py — KB Writer Agent
====================================

Writes successful resolutions back to the Knowledge Base.
Creates new KB articles for novel issues or updates existing ones.
"""

import logging
import json
import os
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger("kb_writer_agent")


class KBWriterAgent:
    """Write successful resolutions to Knowledge Base."""

    def __init__(self):
        self.kb_base = os.path.join(os.path.dirname(__file__), "knowledge_base", "AUTOMATED")
        os.makedirs(self.kb_base, exist_ok=True)

    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Write successful resolution to KB.
        
        input_data expects:
        {
            "kpi_name": str,
            "service": str,
            "root_cause": str,
            "fix_plan": dict,
            "execution_status": str,
            "execution_output": str,
            "approval_id": str
        }
        """
        logger.info("Running KBWriterAgent")
        
        kpi_name = input_data.get("kpi_name", "unknown")
        service = input_data.get("service", "unknown")
        root_cause = input_data.get("root_cause", "")
        fix_plan = input_data.get("fix_plan", {})
        execution_status = input_data.get("execution_status", "pending")
        execution_output = input_data.get("execution_output", "")
        approval_id = input_data.get("approval_id", "unknown")
        
        # Only write if execution was successful
        if execution_status != "success":
            logger.info("Execution status is '%s'; skipping KB write (not yet confirmed).", execution_status)
            return {
                "kb_write_status": "skipped",
                "kb_id": None,
                "reason": f"Execution status is {execution_status}; KB write deferred until confirmed.",
            }
        
        # Create KB article
        kb_article = {
            "title": f"{service.upper()}: {kpi_name} — Auto-Generated Resolution",
            "issue": f"KPI {kpi_name} on service {service} exceeded threshold.",
            "root_cause": root_cause,
            "resolution": "\n".join(fix_plan.get("actions", [])),
            "commands": fix_plan.get("commands", []),
            "approval_id": approval_id,
            "created_at": datetime.now().isoformat(),
            "source": "auto_generated_from_approval",
        }
        
        kb_id = self._write_kb(service, kpi_name, kb_article)
        
        logger.info("KB article created: %s", kb_id)
        return {
            "kb_write_status": "success",
            "kb_id": kb_id,
            "title": kb_article["title"],
            "reason": "Resolution successfully recorded in Knowledge Base.",
        }

    def _write_kb(self, service: str, kpi_name: str, article: Dict[str, Any]) -> str:
        """Write KB article to file."""
        service_dir = os.path.join(self.kb_base, service.upper())
        os.makedirs(service_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        kb_id = f"KB-AUTO-{service.upper()}-{timestamp}"
        filename = os.path.join(service_dir, f"{kb_id}.json")
        
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(article, f, indent=2)
        
        logger.debug("KB article written to %s", filename)
        return kb_id
