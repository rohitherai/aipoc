#!/usr/bin/env python3
"""
📡 REAL-TIME KPI STREAM AGENT

Simulates live KPI ingestion for the AIOps pipeline.

Features:
- Generates random KPI data every 10 seconds
- Saves to data/live_kpi.json for pipeline consumption
- Includes realistic KPI values (CPU, latency, sessions)
- Auto-triggers pipeline execution
- Production-ready logging
"""

import json
import time
import random
import os
import sys
import logging
import subprocess
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s'
)
logger = logging.getLogger(__name__)


class KPIStreamAgent:
    """Generates and streams KPI data in real-time"""
    
    # KPI Templates
    KPI_TEMPLATES = [
        {
            "kpi_name": "SMF_CPU_Usage",
            "service": "smf",
            "host": "smf-core-01",
            "threshold": 70,
            "value_range": (60, 95),
        },
        {
            "kpi_name": "UPF_Latency",
            "service": "upf",
            "host": "upf-node-01",
            "threshold": 50,
            "value_range": (30, 80),
        },
        {
            "kpi_name": "AMF_Session_Count",
            "service": "amf",
            "host": "amf-core-02",
            "threshold": 50000,
            "value_range": (40000, 65000),
        },
    ]
    
    def __init__(self):
        self.data_dir = os.path.join(os.getcwd(), "data")
        self.live_kpi_file = os.path.join(self.data_dir, "live_kpi.json")
        self.run_count = 0
        
        # Ensure data directory exists
        os.makedirs(self.data_dir, exist_ok=True)
        
        logger.info("🚀 KPI Stream Agent initialized")
        logger.info(f"📂 Output file: {self.live_kpi_file}")
    
    def generate_kpi(self):
        """Generate a random KPI from templates"""
        template = random.choice(self.KPI_TEMPLATES)
        min_val, max_val = template["value_range"]
        
        kpi = {
            "kpi_name": template["kpi_name"],
            "service": template["service"],
            "host": template["host"],
            "threshold": template["threshold"],
            "value": round(random.uniform(min_val, max_val), 2),
            "timestamp": datetime.now().isoformat(),
            "confidence": round(random.uniform(0.6, 0.95), 2),
            "source": "live_stream"
        }
        
        return [kpi]  # Return as list for pipeline compatibility
    
    def save_kpi(self, kpi_data):
        """Save KPI data to file"""
        try:
            with open(self.live_kpi_file, 'w') as f:
                json.dump(kpi_data, f, indent=2)
            logger.info(f"💾 KPI saved to: {self.live_kpi_file}")
        except Exception as e:
            logger.error(f"❌ Failed to save KPI: {e}")
    
    def trigger_pipeline(self):
        """Trigger pipeline execution"""
        try:
            logger.info("🔄 Triggering pipeline...")
            # Run main.py to process the KPI
            result = subprocess.run(
                [sys.executable, "main.py"],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                logger.info("✅ Pipeline execution completed")
                # Log relevant output
                if "CACHE HIT" in result.stdout:
                    logger.info("⚡ FAST PATH: Cache hit detected")
                if "DEEP PATH" in result.stdout:
                    logger.info("🔬 DEEP PATH: Full RCA executed")
                if "AUTO-APPROVED" in result.stdout:
                    logger.info("✅ AUTO-APPROVED: Fix approved automatically")
            else:
                logger.error(f"❌ Pipeline failed with return code {result.returncode}")
                if result.stderr:
                    logger.error(f"Error: {result.stderr[:200]}")
        
        except subprocess.TimeoutExpired:
            logger.error("❌ Pipeline execution timed out")
        except Exception as e:
            logger.error(f"❌ Failed to trigger pipeline: {e}")
    
    def run_stream(self, duration_seconds: int = 60, interval_seconds: int = 10):
        """
        Run KPI stream for specified duration
        
        Args:
            duration_seconds: Total duration to stream KPIs (default: 60 sec)
            interval_seconds: Interval between KPI generations (default: 10 sec)
        """
        logger.info("\n" + "="*70)
        logger.info(f"📡 STARTING KPI STREAM (Duration: {duration_seconds}s, Interval: {interval_seconds}s)")
        logger.info("="*70)
        
        start_time = time.time()
        
        while time.time() - start_time < duration_seconds:
            self.run_count += 1
            
            print("\n" + "-"*70)
            logger.info(f"📊 Run #{self.run_count} - {datetime.now().strftime('%H:%M:%S')}")
            print("-"*70)
            
            # Generate KPI
            kpi_data = self.generate_kpi()
            logger.info(f"📡 Generated KPI: {kpi_data[0]['kpi_name']} = {kpi_data[0]['value']}")
            
            # Save KPI
            self.save_kpi(kpi_data)
            
            # Trigger pipeline
            self.trigger_pipeline()
            
            # Wait before next KPI
            elapsed = time.time() - start_time
            remaining = duration_seconds - elapsed
            if remaining > 0:
                wait_time = min(interval_seconds, remaining)
                logger.info(f"⏳ Waiting {wait_time}s until next KPI...")
                time.sleep(wait_time)
        
        logger.info("\n" + "="*70)
        logger.info(f"✅ KPI STREAM COMPLETE ({self.run_count} runs)")
        logger.info("="*70)


def main():
    """
    Main entry point with CLI arguments
    
    Usage:
        python kpi_stream_agent.py [duration] [interval]
    
    Examples:
        python kpi_stream_agent.py          # 60 sec duration, 10 sec interval
        python kpi_stream_agent.py 120 15   # 120 sec duration, 15 sec interval
    """
    duration = 60
    interval = 10
    
    if len(sys.argv) > 1:
        try:
            duration = int(sys.argv[1])
        except ValueError:
            logger.error("Invalid duration. Using default: 60 seconds")
    
    if len(sys.argv) > 2:
        try:
            interval = int(sys.argv[2])
        except ValueError:
            logger.error("Invalid interval. Using default: 10 seconds")
    
    agent = KPIStreamAgent()
    agent.run_stream(duration_seconds=duration, interval_seconds=interval)


if __name__ == "__main__":
    main()
