# OpsBot v5 — with KPI Memory Agent (DynamoDB)

## What's new in v5

A new **KPI Memory Agent** sits before Agent 0 in the pipeline.
It checks DynamoDB for previously seen KPIs and returns cached
resolutions instantly — skipping the full analysis pipeline.

## Full Pipeline

```
Agent 1   — Grafana KPI Fetcher
    |
Agent 0   — Hybrid Smart Router (Regex + Semantic + LLM)
    |
Agent 2   — KPI Processor (rank by severity)
    |
Memory    — Check DynamoDB ←─────────────────────────────┐
Agent          |                                          │
         ┌─────┴──────┐                                  │
   Known +       Unknown or                               │
   High Conf     Low Conf                                 │
         |             |                                  │
   ⚡ FAST PATH   🔍 DEEP PATH                            │
   Return cache   Agent 3: Syslog                        │
   immediately    Agent 4: KB → LLM                      │
                       |                                  │
                  Store in DynamoDB ───────────────────────┘
                  confidence = 0.5

After fix validated:
  Success → confidence +0.1 → next time takes fast path
  Failure → confidence -0.2 → next time takes deep path
```

## VS Code Setup

```bash
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # Mac/Linux
pip install -r requirements.txt
cp .env.example .env
# Edit .env — add CAPGEMINI_GENAI_API_KEY
# Add AWS keys if you have DynamoDB (optional — local fallback works)
python server.py
```

## API Endpoints

| URL | Description |
|---|---|
| `GET /` | Chatbot UI |
| `GET /api/analyze` | Run full pipeline |
| `GET /api/memory/stats` | DynamoDB memory contents + confidence scores |
| `POST /api/memory/feedback` | Report fix success/failure → updates confidence |
| `POST /api/fix/propose` | Generate a safe fix proposal for a KPI result |
| `GET /api/kb/stats` | KB articles loaded |
| `GET /api/health` | Server + all components status |

## Report fix outcome (updates DynamoDB confidence)

```bash
# Fix worked → confidence goes up
curl -X POST http://localhost:5000/api/memory/feedback \
  -H "Content-Type: application/json" \
  -d '{"kpi_name":"CPU_Usage","host":"ubuntu-node-01","success":true}'

# Fix failed → confidence goes down
curl -X POST http://localhost:5000/api/memory/feedback \
  -H "Content-Type: application/json" \
  -d '{"kpi_name":"CPU_Usage","host":"ubuntu-node-01","success":false}'
```

## Fix proposal endpoint

```bash
curl -X POST http://localhost:5000/api/fix/propose \
  -H "Content-Type: application/json" \
  -d '{"kpi": {"kpi_name":"CPU_Usage","domain":"SYSTEM","analysis":"..."}}'
```

## DynamoDB vs Local fallback

- **With AWS keys set**: stores in real DynamoDB — persists across machines
- **Without AWS keys**: stores in `data/kpi_memory.json` — persists across restarts on your laptop

## File Structure

```
opsbot_v5/
├── server.py              # Flask API
├── main.py                # Pipeline (with Memory Agent) ← UPDATED
├── memory_agent.py        # KPI Memory Agent (DynamoDB) ← NEW
├── kpi_domain_router.py   # 5G KPI domain router
├── grafana_agent.py       # Agent 1 5G KPI fetcher
├── kpi_agent.py           # Agent 2 critical KPI selector
├── syslog_agent.py        # Agent 3 Syslog correlator
├── analysis_agent.py      # Agent 4 KB/LLM analysis
├── service_fixer.py       # 5G service remediation planner
├── service_classifier.py  # 5G service/application classifier
├── service_fixers.py      # 5G-specific fix templates
├── kb_search.py           # KB engine (unchanged)
├── knowledge_base/        # KB articles (unchanged)
├── data/
│   ├── dummy_kpis.json
│   ├── dummy_syslog.txt
│   └── kpi_memory.json    # ← NEW: local DynamoDB fallback
├── chatbot.html           # UI (memory badge added)
├── requirements.txt       # boto3 added
├── .env.example
└── README.md
```
