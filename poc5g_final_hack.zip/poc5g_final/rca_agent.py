import logging
from typing import Dict, Any

from analysis_agent import get_kb, _build_query, _call_capgemini_llm, _format_kb_analysis
from config import USE_LLM, USE_REAL_LLM

logger = logging.getLogger("rca_agent")


class RootCauseAgent:
    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        logger.info("Running RootCauseAgent")
        
        kpi = input_data.get("kpi", {})
        logs = input_data.get("logs", [])
        progress_logs = input_data.get("progress_logs", [])
        
        kpi_name = kpi.get("kpi_name", "unknown")
        service = kpi.get("service", "unknown")
        
        query = _build_query(kpi, logs)
        kb = get_kb()
        kb_result = kb.search(query)
        
        if kb_result:
            logger.info("RCA: KB HIT for %s", kpi_name)
            analysis_text = _format_kb_analysis(kb_result, kpi)
            progress_logs.append(f"[KB-HIT] Found knowledge base match for {kpi_name}")
            result = {
                "kpi_name": kpi_name,
                "service": service,
                "root_cause": kb_result.get("root_cause", ""),
                "contributing_factors": kb_result.get("contributing_factors", ""),
                "impact": kb_result.get("impact", ""),
                "analysis_source": "knowledge_base",
                "kb_title": kb_result["title"],
                "kb_score": kb_result["score"],
            }
        else:
            logger.info("RCA: KB MISS for %s — calling LLM", kpi_name)
            progress_logs.append(f"[KB-MISS] No KB match for {kpi_name}, calling LLM")
            if USE_LLM:
                if USE_REAL_LLM:
                    print("🔍 Running RCA using AI (this may take a few seconds)")
                    progress_logs.append(f"[LLM-CALL] Calling Capgemini Claude API")
                else:
                    print("[LLM] Real API disabled, using mock response")
                    progress_logs.append(f"[LLM-DISABLED] Real LLM API disabled - using mock response")
            else:
                print("[LLM] Disabled, using fallback logic")
                progress_logs.append(f"[LLM-DISABLED] Using fallback logic")
            llm_analysis = _call_capgemini_llm(kpi, logs)
            result = {
                "kpi_name": kpi_name,
                "service": service,
                "root_cause": llm_analysis,
                "contributing_factors": "",
                "impact": "",
                "analysis_source": "llm_generated",
                "kb_title": None,
                "kb_score": None,
            }
        
        logger.info("Generating RCA report")
        result["rca_report"] = self._generate_report(result)
        
        return result

    def _generate_report(self, analysis: Dict[str, Any]) -> str:
        lines = [
            "=" * 70,
            f"ROOT CAUSE ANALYSIS REPORT",
            "=" * 70,
            "",
            f"KPI: {analysis.get('kpi_name', 'unknown')}",
            f"Service: {analysis.get('service', 'unknown')}",
            f"Source: {analysis.get('analysis_source', 'unknown')}",
            "",
        ]
        
        if analysis.get("kb_title"):
            lines.append(f"Knowledge Base Article: {analysis.get('kb_title')} (score: {analysis.get('kb_score')})")
            lines.append("")
        
        lines.append("ROOT CAUSE:")
        lines.append("-" * 70)
        lines.append(analysis.get("root_cause", "N/A"))
        lines.append("")
        
        if analysis.get("contributing_factors"):
            lines.append("CONTRIBUTING FACTORS:")
            lines.append("-" * 70)
            lines.append(analysis.get("contributing_factors"))
            lines.append("")
        
        if analysis.get("impact"):
            lines.append("IMPACT ASSESSMENT:")
            lines.append("-" * 70)
            lines.append(analysis.get("impact"))
            lines.append("")
        
        lines.append("=" * 70)
        
        return "\n".join(lines)


def analyze_kpi(kpi: Dict[str, Any], logs: list) -> Dict[str, Any]:
    agent = RootCauseAgent()
    return agent.run({"kpi": kpi, "logs": logs})
