import logging
from typing import Dict, Any

from service_fixer import propose_fix

logger = logging.getLogger("fixer_agent")


class FixerAgent:
    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        logger.info("Running FixerAgent")
        
        rca_result = input_data.get("rca_result", {})
        kpi = input_data.get("kpi", {})
        
        kpi_name = rca_result.get("kpi_name", "unknown")
        service = rca_result.get("service", "unknown")
        
        kpi_for_fix = {**kpi, **rca_result}
        fix_plan = propose_fix(kpi_for_fix)
        
        logger.info("Generated fix plan with %d actions", len(fix_plan.get("actions", [])))
        
        return {
            "kpi_name": kpi_name,
            "service": service,
            "root_cause": rca_result.get("root_cause", ""),
            "analysis_source": rca_result.get("analysis_source", "unknown"),
            "fix_plan": {
                "actions": fix_plan.get("actions", []),
                "commands": fix_plan.get("commands", []),
                "notes": fix_plan.get("notes", []),
                "auto_fix_enabled": fix_plan.get("auto_fix_enabled", False),
            },
            "ready_for_approval": True,
        }


def generate_fix_plan(rca_result: Dict[str, Any], kpi: Dict[str, Any]) -> Dict[str, Any]:
    agent = FixerAgent()
    return agent.run({"rca_result": rca_result, "kpi": kpi})
