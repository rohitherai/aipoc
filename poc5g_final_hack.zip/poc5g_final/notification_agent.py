"""
notification_agent.py — Notification Agent
============================================

Sends notifications at key decision points in the pipeline:
- Before approval (RCA + fix ready for review)
- After execution (success/failure outcomes)
- On rejection or approval events

This is an enterprise-grade notification interface.
Currently uses log-based output; can be extended with email, Slack, webhooks, etc.
"""

import logging
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger("notification_agent")


class NotificationAgent:
    """Handle notifications at key pipeline decision points."""

    def __init__(self):
        self.notifications_sent = []

    def notify_rca_complete_awaiting_approval(self, incident_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Notify that RCA is complete and fix is ready for approval.

        This is sent BEFORE approval, to alert operators.

        Args:
            incident_data: {
                "kpi_name": str,
                "service": str,
                "root_cause": str,
                "proposed_fix": dict,
                "approval_id": str,
                "confidence_score": float,
                "decision_reason": str
            }

        Returns:
            notification_id (for tracking)
        """
        kpi_name = incident_data.get("kpi_name", "unknown")
        service = incident_data.get("service", "unknown")
        approval_id = incident_data.get("approval_id", "unknown")
        confidence_score = incident_data.get("confidence_score", 0.0)
        decision_reason = incident_data.get("decision_reason", "")
        root_cause = incident_data.get("root_cause", "")[:200]  # Truncate for readability
        proposed_fix = incident_data.get("proposed_fix", {})

        notification_id = f"notif_{approval_id}_{datetime.now().isoformat()}"

        message = (
            f"\n{'='*70}\n"
            f"📢 NOTIFICATION: RCA Complete - Approval Required\n"
            f"{'='*70}\n"
            f"Notification ID:   {notification_id}\n"
            f"KPI Name:          {kpi_name}\n"
            f"Service:           {service}\n"
            f"Approval ID:       {approval_id}\n"
            f"Confidence Score:  {confidence_score:.2f}\n"
            f"Decision Reason:   {decision_reason}\n"
            f"\nRoot Cause (summary):\n{root_cause}\n"
            f"\nProposed Actions:\n{self._format_fix_plan(proposed_fix)}\n"
            f"{'='*70}\n"
            f"⏳ Awaiting approval decision...\n"
            f"{'='*70}\n"
        )

        print(message)
        logger.info(
            "📢 RCA Complete notification: KPI=%s, Service=%s, Approval=%s, Confidence=%.2f",
            kpi_name, service, approval_id, confidence_score
        )

        self.notifications_sent.append({
            "notification_id": notification_id,
            "type": "rca_complete",
            "timestamp": datetime.now().isoformat(),
            "kpi_name": kpi_name,
            "service": service,
            "approval_id": approval_id
        })

        return {
            "notification_id": notification_id,
            "status": "sent",
            "timestamp": datetime.now().isoformat()
        }

    def notify_approval_decision(self, decision_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Notify of approval decision (approved or rejected).

        Args:
            decision_data: {
                "approval_id": str,
                "kpi_name": str,
                "service": str,
                "decision": "approved" | "rejected",
                "decision_reason": str (optional)
            }
        """
        approval_id = decision_data.get("approval_id", "unknown")
        kpi_name = decision_data.get("kpi_name", "unknown")
        service = decision_data.get("service", "unknown")
        decision = decision_data.get("decision", "unknown")
        decision_reason = decision_data.get("decision_reason", "")

        notification_id = f"notif_decision_{approval_id}_{datetime.now().isoformat()}"

        status_symbol = "✅" if decision == "approved" else "❌"
        status_text = "APPROVED" if decision == "approved" else "REJECTED"

        message = (
            f"\n{'='*70}\n"
            f"{status_symbol} NOTIFICATION: Approval Decision\n"
            f"{'='*70}\n"
            f"Notification ID:   {notification_id}\n"
            f"Approval ID:       {approval_id}\n"
            f"KPI Name:          {kpi_name}\n"
            f"Service:           {service}\n"
            f"Decision:          {status_text}\n"
            f"Reason:            {decision_reason}\n"
            f"{'='*70}\n"
        )

        print(message)
        logger.info(
            "%s Approval Decision: Approval=%s, Decision=%s, Reason=%s",
            status_symbol, approval_id, status_text, decision_reason
        )

        self.notifications_sent.append({
            "notification_id": notification_id,
            "type": "approval_decision",
            "timestamp": datetime.now().isoformat(),
            "approval_id": approval_id,
            "decision": decision
        })

        return {
            "notification_id": notification_id,
            "status": "sent",
            "timestamp": datetime.now().isoformat()
        }

    def notify_execution_result(self, execution_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Notify of execution result (success or failure).

        Args:
            execution_data: {
                "approval_id": str,
                "kpi_name": str,
                "service": str,
                "execution_status": "success" | "failed" | "skipped",
                "execution_output": str,
                "execution_time_seconds": float
            }
        """
        approval_id = execution_data.get("approval_id", "unknown")
        kpi_name = execution_data.get("kpi_name", "unknown")
        service = execution_data.get("service", "unknown")
        execution_status = execution_data.get("execution_status", "unknown")
        execution_output = execution_data.get("execution_output", "")[:500]  # Truncate
        execution_time = execution_data.get("execution_time_seconds", 0.0)

        notification_id = f"notif_exec_{approval_id}_{datetime.now().isoformat()}"

        if execution_status == "success":
            status_symbol = "✅"
            status_text = "SUCCESS"
        elif execution_status == "failed":
            status_symbol = "❌"
            status_text = "FAILED"
        else:
            status_symbol = "⏭️ "
            status_text = "SKIPPED"

        message = (
            f"\n{'='*70}\n"
            f"{status_symbol} NOTIFICATION: Execution Result\n"
            f"{'='*70}\n"
            f"Notification ID:      {notification_id}\n"
            f"Approval ID:          {approval_id}\n"
            f"KPI Name:             {kpi_name}\n"
            f"Service:              {service}\n"
            f"Execution Status:     {status_text}\n"
            f"Execution Time:       {execution_time:.2f}s\n"
            f"Output Summary:\n{execution_output}\n"
            f"{'='*70}\n"
        )

        print(message)
        logger.info(
            "%s Execution Result: Approval=%s, Status=%s, Time=%.2fs",
            status_symbol, approval_id, status_text, execution_time
        )

        self.notifications_sent.append({
            "notification_id": notification_id,
            "type": "execution_result",
            "timestamp": datetime.now().isoformat(),
            "approval_id": approval_id,
            "execution_status": execution_status
        })

        return {
            "notification_id": notification_id,
            "status": "sent",
            "timestamp": datetime.now().isoformat()
        }

    def notify_memory_stored(self, storage_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Notify that resolution has been stored in memory (ChromaDB).

        Args:
            storage_data: {
                "approval_id": str,
                "kpi_name": str,
                "service": str,
                "storage_location": "chromadb" | "kb" | "history",
                "success": bool
            }
        """
        approval_id = storage_data.get("approval_id", "unknown")
        kpi_name = storage_data.get("kpi_name", "unknown")
        service = storage_data.get("service", "unknown")
        storage_location = storage_data.get("storage_location", "unknown")
        success = storage_data.get("success", False)

        notification_id = f"notif_store_{approval_id}_{datetime.now().isoformat()}"

        status_symbol = "💾" if success else "⚠️ "
        status_text = "Stored" if success else "Failed to store"

        message = (
            f"{status_symbol} Memory: {status_text} in {storage_location.upper()} "
            f"(KPI={kpi_name}, Service={service})\n"
        )

        print(message)
        logger.info(
            "%s Memory Storage: KPI=%s, Service=%s, Location=%s, Success=%s",
            status_symbol, kpi_name, service, storage_location, success
        )

        self.notifications_sent.append({
            "notification_id": notification_id,
            "type": "memory_stored",
            "timestamp": datetime.now().isoformat(),
            "storage_location": storage_location,
            "success": success
        })

        return {
            "notification_id": notification_id,
            "status": "sent",
            "timestamp": datetime.now().isoformat()
        }

    def notify_rejection(self, rejection_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Notify when a resolution is rejected (not approved or execution failed).

        Args:
            rejection_data: {
                "approval_id": str,
                "kpi_name": str,
                "service": str,
                "reason": str,
                "rejection_type": "approval_rejected" | "execution_failed"
            }
        """
        approval_id = rejection_data.get("approval_id", "unknown")
        kpi_name = rejection_data.get("kpi_name", "unknown")
        service = rejection_data.get("service", "unknown")
        reason = rejection_data.get("reason", "")
        rejection_type = rejection_data.get("rejection_type", "unknown")

        notification_id = f"notif_reject_{approval_id}_{datetime.now().isoformat()}"

        message = (
            f"\n{'='*70}\n"
            f"❌ NOTIFICATION: Resolution Rejected\n"
            f"{'='*70}\n"
            f"Notification ID:   {notification_id}\n"
            f"Approval ID:       {approval_id}\n"
            f"KPI Name:          {kpi_name}\n"
            f"Service:           {service}\n"
            f"Rejection Type:    {rejection_type}\n"
            f"Reason:            {reason}\n"
            f"\n⚠️  This resolution will NOT be stored in memory.\n"
            f"{'='*70}\n"
        )

        print(message)
        logger.warning(
            "❌ Rejection: KPI=%s, Service=%s, Type=%s, Reason=%s",
            kpi_name, service, rejection_type, reason
        )

        self.notifications_sent.append({
            "notification_id": notification_id,
            "type": "rejection",
            "timestamp": datetime.now().isoformat(),
            "rejection_type": rejection_type,
            "approval_id": approval_id
        })

        return {
            "notification_id": notification_id,
            "status": "sent",
            "timestamp": datetime.now().isoformat()
        }

    @staticmethod
    def _format_fix_plan(fix_plan: Dict[str, Any]) -> str:
        """Format fix plan for readable output."""
        if not fix_plan:
            return "No fix plan available"

        output = ""
        if "actions" in fix_plan:
            output += "  Actions:\n"
            for i, action in enumerate(fix_plan["actions"], 1):
                output += f"    {i}. {action}\n"

        if "commands" in fix_plan:
            output += "  Commands:\n"
            for i, cmd in enumerate(fix_plan["commands"], 1):
                output += f"    {i}. {cmd}\n"

        if "notes" in fix_plan:
            output += f"  Notes:\n    {fix_plan['notes']}\n"

        return output if output else "No fix actions specified"

    def get_notification_history(self) -> list:
        """Get all notifications sent in this session."""
        return self.notifications_sent


def notify_rca_complete(incident_data: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience function for quick access."""
    agent = NotificationAgent()
    return agent.notify_rca_complete_awaiting_approval(incident_data)


def notify_approval(decision_data: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience function for approval notifications."""
    agent = NotificationAgent()
    return agent.notify_approval_decision(decision_data)


def notify_execution(execution_data: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience function for execution notifications."""
    agent = NotificationAgent()
    return agent.notify_execution_result(execution_data)
