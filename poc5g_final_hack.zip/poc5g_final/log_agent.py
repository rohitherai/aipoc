import logging
from typing import Dict, Any, List
from syslog_agent import get_related_logs

logger = logging.getLogger("log_agent")


class LogAgent:
    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        logger.info("Running LogAgent")
        
        kpis = input_data.get("kpis", [])
        if not kpis:
            return {"logs": {}}
        
        log_dict = get_related_logs(kpis)
        
        logger.info("Collected logs for %d KPIs", len(log_dict))
        return {"logs": log_dict}
