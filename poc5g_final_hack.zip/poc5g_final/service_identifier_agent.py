import json
import logging
import os
from typing import Dict, Any, Optional, Tuple, List

logger = logging.getLogger("service_identifier_agent")

DEFAULT_SERVICES: List[str] = []

def load_services() -> List[str]:
    try:
        base = os.path.dirname(__file__)
        path = os.path.join(base, "data", "services.json")
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            services = [str(x).lower() for x in data]
            if not services:
                logger.warning("data/services.json is empty; no services loaded")
            return services
        logger.warning("services.json has unexpected format; no services loaded")
    except Exception:
        logger.warning("Could not load data/services.json; no services loaded")
    return DEFAULT_SERVICES

SERVICES = load_services()
if not SERVICES:
    logger.warning("Service list is empty — service identification will only return 'unknown' unless services.json is populated.")


class ServiceIdentifierAgent:
    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        logger.info("Running ServiceIdentifierAgent")
        
        kpi_name = input_data.get("kpi_name")
        labels = input_data.get("labels")
        instance = input_data.get("instance")
        
        result = self._extract_from_labels(labels)
        if result:
            service, confidence, source = result
            return {"service": service, "confidence": confidence, "source": source}

        result = self._extract_from_instance(instance)
        if result:
            service, confidence, source = result
            return {"service": service, "confidence": confidence, "source": source}

        result = self._extract_from_kpi_name(kpi_name)
        if result:
            service, confidence, source = result
            return {"service": service, "confidence": confidence, "source": source}

        logger.warning("Service unknown for KPI '%s'", kpi_name)
        return {"service": "unknown", "confidence": 0.3, "source": "unknown"}

    def _extract_from_labels(self, labels: Optional[Dict[str, str]]) -> Optional[Tuple[str, float, str]]:
        if not labels:
            return None

        labels_lower = {k.lower(): v.lower() for k, v in labels.items()}
        for field in ["service", "nf_type", "app", "component"]:
            value = labels_lower.get(field)
            if not value:
                continue

            for service in SERVICES:
                if service == value or service in value or value in service:
                    return service, 0.95, "labels"

        return None

    def _extract_from_instance(self, instance: Optional[str]) -> Optional[Tuple[str, float, str]]:
        if not instance:
            return None

        instance_lower = instance.lower()
        for service in SERVICES:
            if service in instance_lower:
                return service, 0.8, "instance"

        return None

    def _extract_from_kpi_name(self, kpi_name: Optional[str]) -> Optional[Tuple[str, float, str]]:
        if not kpi_name:
            return None

        kpi_lower = kpi_name.lower()
        for service in SERVICES:
            if service in kpi_lower:
                return service, 0.6, "kpi_name"

        return None
