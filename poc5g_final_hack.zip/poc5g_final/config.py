MODE = "demo"        # demo or real
USE_LLM = True          # enable/disable LLM path
USE_REAL_LLM = False    # enable/disable live LLM API calls (safe dev mode)
USE_VECTOR_DB = True    # enable/disable ChromaDB vector memory
USE_REAL_EMBEDDING = False  # enable/disable live embedding API calls (safe dev mode)
ENABLE_EMBEDDING_CACHE = True  # cache embeddings locally to reduce repeated API calls
USE_LOCAL_CACHE = True  # enable/disable local file-based cache (faster than Pinecone, no proxy issues)

# ✨ AUTO APPROVAL FOR DEMO MODE
AUTO_APPROVE = True  # Set to True for demo/testing (no manual approval needed)
                     # Set to False for production (requires manual CLI approval)
