"""
service_fixer.py — 5G Service Fix Planner
========================================

Provides a safe, non-destructive fix proposal layer for KPI issues.
This agent does not execute commands by default. It generates
actionable remediation suggestions and optional candidate commands.

The actual execution path is intentionally disabled unless
`AUTO_FIX=true` is set and the user accepts the risk.
"""

import logging
import os
from typing import Any, Dict, List

from service_fixers import get_service_fix_actions, get_service_commands

logger = logging.getLogger("service_fixer")
AUTO_FIX = os.getenv("AUTO_FIX", "false").lower() in {"1", "true", "yes"}

DEFAULT_ACTIONS: Dict[str, List[str]] = {
    "CPU_Usage": [
        "Investigate top CPU consumers with top/htop.",
        "Consider restarting the most costly service if safe.",
        "Tune CPU limits or scale workload if sustained high usage continues."
    ],
    "Memory_Usage": [
        "Inspect recent OOM or memory pressure events.",
        "Check whether a specific process is leaking memory.",
        "Restart the offending service or add swap/RAM as needed."
    ],
    "Disk_IO_Wait": [
        "Identify disk-intensive processes and paused I/O.",
        "Check for weak RAID arrays, failing disks, or full partitions.",
        "Reduce I/O load or move heavy workloads to less busy storage."
    ],
    "Network_Errors": [
        "Verify interface status and packet error counters.",
        "Restart the network service or interface if appropriate.",
        "Check cabling, VLANs, and firewall rules for drops."
    ],
    "Load_Average": [
        "Inspect load-generating processes and runaway jobs.",
        "Consider removing unnecessary tasks or throttling batch jobs.",
        "Add capacity or tune scheduler limits if load is sustained."
    ],
    "Swap_Usage": [
        "Review swap usage patterns and active memory pressure.",
        "Tune swappiness or add physical memory to reduce swapping.",
        "Restart any service consuming excessive memory if safe."
    ],
}

SAFE_COMMAND_TEMPLATES: Dict[str, List[str]] = {
    "CPU_Usage": [
        "sudo systemctl restart <service>",
        "ps -eo pid,comm,%cpu --sort=-%cpu | head -n 10"
    ],
    "Memory_Usage": [
        "sudo journalctl -xe | grep -i oom",
        "ps -eo pid,comm,%mem --sort=-%mem | head -n 10"
    ],
    "Disk_IO_Wait": [
        "sudo iotop -o -b -n 5",
        "sudo smartctl -a /dev/sda"
    ],
    "Network_Errors": [
        "sudo ethtool -S <interface>",
        "sudo ip -s link show"
    ],
}


def _extract_fix_notes(analysis: str) -> List[str]:
    """Extract simple sentences from analysis text to reuse in the fix plan."""
    if not analysis:
        return []

    lines = [line.strip() for line in analysis.splitlines() if line.strip()]
    notes = []
    for line in lines:
        if any(line.lower().startswith(prefix) for prefix in ("-", "1.", "•", "*")):
            notes.append(line.lstrip("-•*1234567890. ").strip())
        elif len(line) > 40 and "." in line:
            notes.append(line)
        if len(notes) >= 4:
            break
    return notes


def propose_fix(kpi: Dict[str, Any]) -> Dict[str, Any]:
    """Return a safe fix proposal for a KPI issue, with service-specific actions."""
    kpi_name = kpi.get("kpi_name", "unknown")
    service = kpi.get("service", "generic")
    source = kpi.get("source", "unknown")
    analysis = kpi.get("analysis", "")

    # Get service-specific actions based on KPI type
    service_actions = get_service_fix_actions(service, kpi_name)
    
    # Fallback to generic actions if service-specific ones are empty
    if not service_actions:
        actions = DEFAULT_ACTIONS.get(kpi_name, [
            "Review the analysis and take the most urgent remediation steps.",
            "Verify relevant service health, logs, and resource usage.",
            "Apply a conservative fix and monitor KPI recovery."
        ])
    else:
        actions = service_actions

    # Extract notes from analysis and prepend them
    notes = _extract_fix_notes(analysis)
    if notes:
        actions = notes + [action for action in actions if action not in notes]

    # Get service-specific commands
    service_commands = get_service_commands(service)
    commands = service_commands if service_commands else SAFE_COMMAND_TEMPLATES.get(kpi_name, [])

    plan = {
        "kpi_name":        kpi_name,
        "service":         service,
        "source":          source,
        "auto_fix_enabled": AUTO_FIX,
        "actions":         actions,
        "commands":        commands,
        "notes": [
            f"This is a service-specific fix plan for {service} ({kpi_name}).",
            "No commands are executed automatically unless AUTO_FIX=true.",
            "Review commands carefully before running them in production.",
        ],
    }

    logger.info("Fixer Agent: proposed fix for %s on service %s (source=%s)", kpi_name, service, source)
    return plan


def execute_fix(fix_plan: Dict[str, Any]) -> Dict[str, Any]:
    """Execute a fix plan if AUTO_FIX is enabled.

    This function is intentionally conservative. It does not execute any
    commands unless AUTO_FIX is enabled and the plan includes explicit
    shell-safe commands.
    """
    if not AUTO_FIX:
        logger.warning("AUTO_FIX is disabled; skipping execution")
        return {
            "executed": False,
            "message": "AUTO_FIX is disabled. No commands were run.",
            "commands": fix_plan.get("commands", []),
        }

    commands = fix_plan.get("commands", [])
    if not commands:
        return {
            "executed": False,
            "message": "No commands available for execution.",
            "commands": []
        }

    logger.warning("AUTO_FIX is enabled, but execution is still stubbed for safety")
    return {
        "executed": False,
        "message": "Command execution is stubbed for safety. Set up a controlled fix runner if needed.",
        "commands": commands,
    }
