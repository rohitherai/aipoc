"""
analysis_agent.py — 5G KB/LLM Analysis Engine
===================================================
For each critical KPI received from Agent 3:

  Step 1 → Build a search query from (kpi_name + domain + log keywords)
  Step 2 → Search knowledge_base/ folder for a matching article
  Step 3a → KB HIT:  return KB article root cause + remediation steps
  Step 3b → KB MISS: call Capgemini GenAI platform (Bedrock Claude proxy)
                     using the exact API format from connection.txt

The LLM (Capgemini) is ONLY called when KB has no answer.
Every result is tagged with source: "knowledge_base" or "llm_generated"
so the chatbot UI can show the user where the answer came from.
"""

import logging
import os
import re
import requests
from typing import Dict, List, Optional

from kb_search import KnowledgeBase

logger = logging.getLogger("agent4.analysis")

# ── Capgemini GenAI platform (from connection.txt) ────────────────────────────
CAPGEMINI_URL   = os.getenv(
    "CAPGEMINI_GENAI_URL",
    "https://openai.generative.engine.capgemini.com/v1/chat/completions"
)
CAPGEMINI_MODEL = os.getenv(
    "CAPGEMINI_MODEL",
    "anthropic.claude-3-sonnet-20240229-v1:0"
)
CAPGEMINI_API_KEY = os.getenv("CAPGEMINI_GENAI_API_KEY", "")

# ── Singleton KB (loaded once) ────────────────────────────────────────────────
_kb: Optional[KnowledgeBase] = None

def get_kb(reload: bool = False) -> KnowledgeBase:
    """
    Return the KB instance.
    reload=True forces a fresh load from disk — used at start of each pipeline
    run so auto-written articles from the previous run are picked up immediately.
    """
    global _kb
    if _kb is None or reload:
        _kb = KnowledgeBase()
    return _kb


# ── Query builder ─────────────────────────────────────────────────────────────

def _build_query(kpi: Dict, logs: List[str]) -> str:
    """
    Build a focused search query from KPI name, service, and syslog keywords.
    Excludes hostnames (contain dashes+digits) to avoid diluting TF-IDF score.
    """
    import re as _re
    # Start with the most important fields: kpi_name and service
    seen = set()
    parts = []
    for p in [kpi.get("kpi_name", ""), kpi.get("service", "")]:
        if p and p.lower() not in seen:
            parts.append(p)
            seen.add(p.lower())

    # Pull meaningful keywords from syslog lines (deduplicated)
    hostname_pattern = _re.compile(r"[a-z]+-[a-z0-9]+-[0-9]+")
    for line in logs[:3]:
        words = [
            w for w in line.split()
            if len(w) > 4
            and not w[0].isdigit()
            and "." not in w
            and ":" not in w
            and "[" not in w
            and not hostname_pattern.match(w.lower())
        ]
        for w in words[:4]:
            if w.lower() not in seen:
                parts.append(w)
                seen.add(w.lower())

    return " ".join(filter(None, parts))


# ── Capgemini LLM call (exact format from connection.txt) ─────────────────────

def _call_capgemini_llm(kpi: Dict, logs: List[str]) -> str:
    """
    Calls the Capgemini GenAI platform using the format from connection.txt.
    Only called when KB has no answer.
    Returns raw analysis text.
    """
    api_key = CAPGEMINI_API_KEY
    if not api_key:
        return _mock_response(kpi["kpi_name"])

    # Build KPI summary block (same style as connection.txt)
    kpi_summary = f"""
KPI SUMMARY (Grafana):

- {kpi['kpi_name']} breached {kpi.get('breach_count', 1)} time(s)
  Peak: {kpi['peak_value']} (threshold {kpi['threshold']})
  Excess: +{kpi.get('avg_excess_pct', 0)}% over threshold
  Hosts: {', '.join(kpi.get('hosts', ['unknown']))}
  Domain: {kpi.get('domain', 'UNKNOWN')}
"""

    # Build syslog summary block
    if logs:
        syslog_summary = "SYSLOG EVENTS:\n" + "\n".join(f"- {l}" for l in logs[:8])
    else:
        syslog_summary = "SYSLOG EVENTS:\n- No matching log entries found"

    payload = {
        "model": CAPGEMINI_MODEL,
        "messages": [
            {
                "role": "system",
                "content": "You are a senior Linux/DevOps SRE specializing in Ubuntu systems and infrastructure monitoring."
            },
            {
                "role": "user",
                "content": f"""
Analyze the following incident.

{kpi_summary}

{syslog_summary}

Provide:
1. Root cause analysis
2. Contributing factors
3. Impact assessment
"""
            }
        ],
        "temperature": 0.2
    }

    try:
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        response = requests.post(CAPGEMINI_URL, headers=headers, json=payload, timeout=60)

        if response.status_code == 200:
            content = response.json()["choices"][0]["message"]["content"]
            logger.info("Capgemini LLM response received for %s", kpi["kpi_name"])
            return content
        else:
            logger.error("Capgemini LLM HTTP %d: %s", response.status_code, response.text[:200])
            return _mock_response(kpi["kpi_name"])

    except Exception as exc:
        logger.error("Capgemini LLM call failed for %s: %s", kpi["kpi_name"], exc)
        return _mock_response(kpi["kpi_name"])


def _mock_response(kpi_name: str) -> str:
    return (
        f"**[Mock — set CAPGEMINI_GENAI_API_KEY for real LLM analysis]**\n\n"
        f"**Root Cause:** {kpi_name} exceeded threshold repeatedly — likely resource contention.\n\n"
        f"**Contributing Factors:**\n"
        f"- High concurrent user sessions\n"
        f"- Insufficient resource allocation\n"
        f"- Potential configuration issues\n\n"
        f"**Impact Assessment:**\n"
        f"- Service degradation affecting user experience\n"
        f"- Potential cascading failures in dependent services\n"
        f"- Increased operational overhead"
    )


# ── KB result formatter ───────────────────────────────────────────────────────

def _format_kb_analysis(kb_result: Dict, kpi: Dict) -> str:
    """Format the KB article into a readable analysis string for the chatbot."""
    lines = []
    lines.append(f"📚 **Source: Knowledge Base** — `{kb_result['title']}` (relevance: {kb_result['score']})\n")

    if kb_result.get("root_cause"):
        lines.append("**Root Cause:**")
        lines.append(kb_result["root_cause"].strip())
        lines.append("")

    if kb_result.get("contributing_factors"):
        lines.append("**Contributing Factors:**")
        lines.append(kb_result["contributing_factors"].strip())
        lines.append("")

    if kb_result.get("impact"):
        lines.append("**Impact Assessment:**")
        lines.append(kb_result["impact"].strip())
        lines.append("")

    return "\n".join(lines)


# ── Main analysis function ────────────────────────────────────────────────────

def analyze_issues(kpi_details: List[Dict], log_dict: Dict[str, List[str]]) -> List[Dict]:
    """
    For each KPI:
      1. Search KB using KPI name + domain + log keywords
      2. If KB hit → use KB article (fast, free, reliable)
      3. If KB miss → call Capgemini LLM
    
    Returns list of result dicts with 'source' tagged as
    'knowledge_base' or 'llm_generated'.
    """
    kb     = get_kb()
    results = []

    logger.info(
        "Agent 4: KB has %d articles. Processing %d KPIs.",
        kb.get_stats()["total"], len(kpi_details)
    )

    for kpi in kpi_details:
        kpi_name = kpi["kpi_name"]
        service = kpi.get("service", "unknown")
        logs     = log_dict.get(kpi_name, [])

        # Build search query from KPI + service + log context
        query = _build_query(kpi, logs)
        logger.info("KB search: service=%s query='%s'", service, query[:100])

        # ── Step 1: Try KB first ──────────────────────────────────────────────
        kb_result = kb.search(query)

        if kb_result:
            logger.info(
                "✅ KB HIT for '%s' → '%s' (score=%.3f) — skipping LLM",
                kpi_name, kb_result["title"], kb_result["score"]
            )
            analysis = _format_kb_analysis(kb_result, kpi)
            source   = "knowledge_base"
            kb_title = kb_result["title"]
            kb_score = kb_result["score"]
        else:
            # ── Step 2: KB miss → call Capgemini LLM ─────────────────────────
            logger.info("⚡ KB MISS for '%s' — calling Capgemini LLM", kpi_name)
            analysis = _call_capgemini_llm(kpi, logs)
            source   = "llm_generated"
            kb_title = None
            kb_score = None

        results.append({
            "kpi_name":   kpi_name,
            "service":    service,
            "peak_value": kpi["peak_value"],
            "threshold":  kpi["threshold"],
            "excess_pct": kpi.get("avg_excess_pct", 0),
            "hosts":      kpi.get("hosts", []),
            "log_count":  len(logs),
            "analysis":   analysis,
            "source":     source,          # "knowledge_base" or "llm_generated"
            "kb_title":   kb_title,        # which KB article matched (or None)
            "kb_score":   kb_score,        # relevance score (or None)
        })

    # Summary log
    kb_hits  = sum(1 for r in results if r["source"] == "knowledge_base")
    llm_hits = sum(1 for r in results if r["source"] == "llm_generated")
    logger.info(
        "Agent 4 complete: %d KB hits, %d LLM calls", kb_hits, llm_hits
    )

    return results
