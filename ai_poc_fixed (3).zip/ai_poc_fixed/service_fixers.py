"""
service_fixers.py — Service-Specific Fix Recommendations
=========================================================

Provides targeted remediation actions for different services.
Each service has its own fix strategy based on common operational patterns.
"""

import logging
from typing import Dict, List, Any

logger = logging.getLogger("service_fixers")

SERVICE_FIX_STRATEGIES: Dict[str, Dict[str, Any]] = {
    "5g_core": {
        "cpu_actions": [
            "Review SMF/UPF/AMF CPU usage and 5G control-plane load patterns.",
            "Check PFCP and GTP session establishment rates.",
            "Validate scaling thresholds for impacted 5G core services.",
            "Consider throttling new session setup if CPU is saturated.",
        ],
        "memory_actions": [
            "Inspect SMF/UPF memory use for session context growth.",
            "Review PFCP association state and session retention settings.",
            "Look for repeated session rebuilds or memory leaks in core logs.",
            "Restart the impacted 5G core component safely after draining traffic.",
        ],
        "disk_actions": [
            "Check state store and log volume I/O for 5G core nodes.",
            "Ensure log rotation is not blocking disk writes.",
            "Clean up stale core trace files and expired state snapshots.",
            "Consider moving bulky logs off the main disk if needed.",
        ],
        "network_actions": [
            "Inspect PFCP/GTP tunnel errors and transport latency.",
            "Check N4/N11/N2/N1 interface errors and packet loss.",
            "Validate 5G transport path reliability between core nodes.",
            "Review packet forwarding and route configuration for UPF/SMF.",
        ],
        "commands": [
            "sudo systemctl status smf upf amf pcf nrf nssf ausf",
            "sudo journalctl -u smf -u upf -u amf -u pcf -u nrf -u nssf -u ausf --since '1 hour ago'",
            "sudo tail -n 100 /var/log/5g/core/*.log",
            "sudo ss -tunlp | grep -E '8805|8806|2123|8800|8842'",
        ],
    },
    "system": {
        "swap_actions": [
            "Check swap usage: free -h or swapon -s",
            "Review vm.swappiness setting: cat /proc/sys/vm/swappiness",
            "Lower swappiness if high: echo 10 | sudo tee /proc/sys/vm/swappiness",
            "Check for memory-hungry processes: ps aux --sort=-%mem | head",
        ],
        "load_actions": [
            "Check running processes: ps aux or top",
            "Review system uptime and load trend: uptime",
            "Identify CPU-bound vs I/O-bound loads: iostat or vmstat",
            "Consider scaling or optimizing workload",
        ],
        "commands": [
            "free -h && uptime",
            "top -b -n 1 | head -20",
            "vmstat 1 5",
            "iostat -x 1",
        ],
    },
    "generic": {
        "default_actions": [
            "Gather diagnostic data: top, free, df, journalctl -xe.",
            "Review the impacted 5G service and host health.",
            "Check service status and restart the impacted process if safe.",
            "Apply a conservative fix and monitor KPI recovery.",
        ],
        "commands": [
            "journalctl -xe",
            "systemctl --failed",
            "dmesg | tail -50",
        ],
    },
}


def get_service_fix_actions(service: str, kpi_name: str) -> List[str]:
    """Return service-specific fix actions based on the KPI and service type."""
    service = service.lower() if service else "generic"
    
    if service not in SERVICE_FIX_STRATEGIES:
        service = "generic"
    
    strategy = SERVICE_FIX_STRATEGIES[service]
    
    # Pick actions based on KPI type
    if "cpu" in kpi_name.lower():
        return strategy.get("cpu_actions", strategy.get("default_actions", []))
    elif "memory" in kpi_name.lower():
        return strategy.get("memory_actions", strategy.get("default_actions", []))
    elif "disk" in kpi_name.lower() or "io" in kpi_name.lower():
        return strategy.get("disk_actions", strategy.get("default_actions", []))
    elif "network" in kpi_name.lower() or "error" in kpi_name.lower():
        return strategy.get("network_actions", strategy.get("default_actions", []))
    elif "swap" in kpi_name.lower():
        return strategy.get("swap_actions", strategy.get("default_actions", []))
    elif "load" in kpi_name.lower():
        return strategy.get("load_actions", strategy.get("default_actions", []))
    else:
        return strategy.get("default_actions", [])


def get_service_commands(service: str) -> List[str]:
    """Return diagnostic commands for a service."""
    service = service.lower() if service else "generic"
    
    if service not in SERVICE_FIX_STRATEGIES:
        service = "generic"
    
    return SERVICE_FIX_STRATEGIES[service].get("commands", [])


def propose_fix(kpi: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main function called by fixer_agent.py.
    Builds a complete fix plan for a KPI based on its service.
    """
    service  = str(kpi.get("service", "unknown")).lower()
    kpi_name = str(kpi.get("kpi_name", "unknown"))

    actions  = get_service_fix_actions(service, kpi_name)
    commands = get_service_commands(service)

    return {
        "actions":          actions,
        "commands":         commands,
        "notes":            [f"Review fix plan before executing on {service} service."],
        "auto_fix_enabled": False,   # always False — manual approval required
    }
