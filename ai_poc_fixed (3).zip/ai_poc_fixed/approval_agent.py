import logging
from typing import Dict, Any
from datetime import datetime

logger = logging.getLogger("approval_agent")


class ApprovalAgent:
    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        logger.info("Running ApprovalAgent")
        
        fix_proposal = input_data.get("fix_proposal", {})
        
        kpi_name = fix_proposal.get("kpi_name", "unknown")
        service = fix_proposal.get("service", "unknown")
        approval_id = f"{service}_{kpi_name}_{hash(str(fix_proposal)) % 10000}"
        
        logger.info("Created approval request: %s", approval_id)
        
        return {
            "approval_id": approval_id,
            "kpi_name": kpi_name,
            "service": service,
            "root_cause": fix_proposal.get("root_cause", ""),
            "fix_actions": fix_proposal.get("fix_plan", {}).get("actions", []),
            "status": "pending_approval",
            "requires_approval": True,
        }

    def approve_fix(self, approval_id: str, approved: bool = True, notes: str = "") -> Dict[str, Any]:
        logger.info("Approval decision: %s — %s", approval_id, "APPROVED" if approved else "REJECTED")
        
        return {
            "approval_id": approval_id,
            "approved": approved,
            "timestamp": datetime.now().isoformat(),
            "notes": notes,
        }


def request_approval(fix_proposal: Dict[str, Any]) -> Dict[str, Any]:
    agent = ApprovalAgent()
    return agent.run({"fix_proposal": fix_proposal})


def approve_fix(approval_id: str, approved: bool = True, notes: str = "") -> Dict[str, Any]:
    agent = ApprovalAgent()
    return agent.approve_fix(approval_id, approved, notes)
