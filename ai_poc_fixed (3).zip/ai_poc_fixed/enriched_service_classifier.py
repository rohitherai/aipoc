"""
enriched_service_classifier.py — Enriched Service Classifier
=============================================================

Provides enhanced service classification using log content analysis.
Refines basic classification with syslog keyword matching.
"""

import logging
import re
from typing import Dict, List, Optional

logger = logging.getLogger("enriched_service_classifier")

# ── Enhanced patterns with log keywords ───────────────────────────────────────
ENRICHED_PATTERNS: Dict[str, List[tuple]] = {
    "5G Core": [
        (r"smf|upf|amf|pcf|nrf|nssf|ausf|oam", r"smf|upf|amf|pcf|nrf|nssf|ausf|oam|core|5g", r"session|pfcp|gtp|n1|n2|n4|n11|sbi", "5g_core"),
        (r"session.*failure|auth.*failure|attach.*failure|registration.*failure", r"", r"eap.*aka|authentication|registration", "5g_core"),
        (r"pfcp.*error|gtp.*loss|latency|jitter", r"", r"tunnel|packet|interface|n4|n11", "5g_core"),
    ],
    "System": [
        (r"cpu.*usage|memory.*usage|disk.*io|load.*average|swap.*usage", r"host|node|vm|infra", r"kernel|oom|swap|io.*wait", "system"),
    ],
}


def classify_service_enriched(kpi_name: str, host: str = "", logs: List[str] = None) -> Optional[str]:
    """
    Enhanced service classification using log content analysis.
    Refines basic classification with syslog keyword matching.

    Args:
        kpi_name: Name of the KPI
        host: Host where KPI occurred
        logs: List of related log lines

    Returns the service name or None if not determinable.
    """
    if logs is None:
        logs = []

    # Combine all logs for keyword search
    log_text = " ".join(logs).lower()
    kpi_lower = kpi_name.lower()
    host_lower = host.lower()

    # Check enhanced patterns with log keywords
    for service, rules in ENRICHED_PATTERNS.items():
        for kpi_pattern, host_pattern, log_pattern, service_name in rules:
            if re.search(kpi_pattern, kpi_lower, re.IGNORECASE):
                host_match = not host_pattern or re.search(host_pattern, host_lower, re.IGNORECASE)
                log_match = not log_pattern or re.search(log_pattern, log_text, re.IGNORECASE)

                if host_match and log_match:
                    logger.debug(
                        "Service enriched: %s (KPI='%s', host='%s', logs matched='%s')",
                        service_name, kpi_name, host, bool(log_pattern and log_match)
                    )
                    return service_name

    logger.debug("Service not enriched for KPI '%s' on host '%s'", kpi_name, host)
    return None


def enrich_kpis_with_enriched_service(kpis: List[Dict], log_dict: Optional[Dict[str, List[str]]] = None) -> List[Dict]:
    """
    Refine service classification using log content.
    Updates existing service field if better match found.
    """
    log_dict = log_dict or {}

    for kpi in kpis:
        kpi_name = kpi.get("kpi_name", "")
        host = kpi.get("host", "")
        logs = log_dict.get(kpi_name, [])

        enriched_service = classify_service_enriched(kpi_name, host, logs)
        if enriched_service:
            kpi["service"] = enriched_service
            logger.debug("Service refined for %s: %s", kpi_name, enriched_service)

    return kpis


def get_service_summary_enriched(enriched_kpis: List[Dict]) -> Dict[str, List[str]]:
    """Returns { service: [kpi_names] } — useful for logging and UI."""
    summary: Dict[str, List[str]] = {}
    for kpi in enriched_kpis:
        svc = kpi.get("service", "generic")
        summary.setdefault(svc, [])
        name = kpi.get("kpi_name", "")
        if name not in summary[svc]:
            summary[svc].append(name)
    return summary