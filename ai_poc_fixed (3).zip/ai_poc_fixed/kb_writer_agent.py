"""
kb_writer_agent.py — KB Writer Agent
======================================
Writes LLM-generated resolutions to the Knowledge Base immediately,
even when the fix is still pending approval.

WHY:
  Old behaviour — only wrote to KB after execution_status = "success"
  Problem       — AUTO_FIX=false means status is always "pending"
                  so KB was NEVER written and LLM answer was thrown away
  Fix           — write to KB as soon as LLM generates the answer
                  tag with status so operators know validation state

KB WRITE TRIGGERS:
  llm_generated + any status  → write immediately (tagged "pending_validation")
  knowledge_base source       → skip (already in KB — no need to duplicate)
  execution succeeded         → update existing article to "validated"
  fix rejected                → update article to "rejected" (won't be used as primary)

RESULT FOR DEMO:
  Run 1: LLM gives answer → written to KB immediately
  Run 2: Same KPI arrives → KB HIT → no LLM call → faster + free
"""

import json
import logging
import os
from datetime import datetime
from typing import Any, Dict, Optional

logger = logging.getLogger("kb_writer_agent")


class KBWriterAgent:

    def __init__(self):
        self.kb_base = os.path.join(
            os.path.dirname(__file__), "knowledge_base", "AUTOMATED"
        )
        os.makedirs(self.kb_base, exist_ok=True)

    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        kpi_name         = input_data.get("kpi_name",         "unknown")
        service          = input_data.get("service",          "unknown")
        root_cause       = input_data.get("root_cause",       "")
        fix_plan         = input_data.get("fix_plan",         {})
        execution_status = input_data.get("execution_status", "pending")
        approval_id      = input_data.get("approval_id",      "unknown")
        analysis_source  = input_data.get("analysis_source",  "llm_generated")

        # ── Skip if answer came from KB (already there — no need to duplicate) ─
        if analysis_source == "knowledge_base":
            logger.info(
                "KB write skipped for %s — answer already came from KB (no duplicate)",
                kpi_name
            )
            return {
                "kb_write_status": "skipped",
                "kb_id":           None,
                "reason":          "Answer sourced from existing KB article — no write needed.",
            }

        # ── Skip if no root cause (nothing useful to write) ──────────────────
        if not root_cause or root_cause.strip() == "":
            logger.info("KB write skipped for %s — no root cause content", kpi_name)
            return {
                "kb_write_status": "skipped",
                "kb_id":           None,
                "reason":          "No root cause content to write.",
            }

        # ── Determine KB article status tag ──────────────────────────────────
        if execution_status == "success":
            kb_status  = "validated"        # fix worked — fully trusted
            kb_tag     = "✅ Validated resolution"
        elif execution_status == "rejected":
            kb_status  = "rejected"         # operator rejected — flag it
            kb_tag     = "❌ Rejected — do not use as primary resolution"
        else:
            # pending / pending_approval / not_executed / any other status
            # Write immediately — this is the KEY FIX
            kb_status  = "pending_validation"
            kb_tag     = "⏳ Pending validation — LLM generated, not yet confirmed"

        # ── Build the KB article ──────────────────────────────────────────────
        actions  = fix_plan.get("actions",  [])
        commands = fix_plan.get("commands", [])

        article = {
            "title":        f"{service.upper()}: {kpi_name} Resolution",
            "kpi_name":     kpi_name,
            "service":      service,
            "status":       kb_status,
            "status_tag":   kb_tag,
            "root_cause":   root_cause,
            "resolution":   "\n".join(f"{i+1}. {a}" for i, a in enumerate(actions)),
            "commands":     commands,
            "approval_id":  approval_id,
            "source":       analysis_source,
            "created_at":   datetime.now().isoformat(),
            "updated_at":   datetime.now().isoformat(),
        }

        kb_id = self._write_kb(service, kpi_name, article)

        logger.info(
            "KB article written: %s (status=%s, source=%s)",
            kb_id, kb_status, analysis_source
        )
        # Print clear message showing which document was created/updated
        print(f"\n📚 KB UPDATED: knowledge_base/AUTOMATED/{service.upper()}/{kb_id}.json")
        print(f"   Document : {kb_id}")
        print(f"   KPI      : {kpi_name}")
        print(f"   Service  : {service}")
        print(f"   Status   : {kb_status}")
        print(f"   Created  : {article['created_at']}")
        print(f"   Source   : {analysis_source}\n")

        return {
            "kb_write_status": "success",
            "kb_id":           kb_id,
            "title":           article["title"],
            "kb_status":       kb_status,
            "reason":          f"Resolution written to KB with status '{kb_status}'.",
        }

    def _write_kb(self, service: str, kpi_name: str, article: Dict) -> str:
        """Write KB article as JSON file inside knowledge_base/AUTOMATED/<SERVICE>/"""
        service_dir = os.path.join(self.kb_base, service.upper())
        os.makedirs(service_dir, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%dT%H%M%SZ")
        kb_id     = f"KB-AUTO-{service.upper()}-{kpi_name}-{timestamp}"
        filename  = os.path.join(service_dir, f"{kb_id}.json")

        with open(filename, "w", encoding="utf-8") as f:
            json.dump(article, f, indent=2)

        logger.debug("KB article written to %s", filename)
        return kb_id
