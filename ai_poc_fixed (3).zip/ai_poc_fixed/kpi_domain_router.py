"""
kpi_domain_router.py — 5G KPI Domain Router
===========================================
Transforms raw KPI records into 5G-aligned domains:
  - CORE      : 5G control-plane / user-plane service KPIs
  - TRANSPORT : transport / PFCP / GTP / latency KPIs
  - SYSTEM    : node resource metrics and host-level capacity signals
  - UNKNOWN   : anything not matched yet

This router is optimized for a 5G PoC, not a generic data center.
"""

import logging
import re
from typing import List, Dict

logger = logging.getLogger("kpi_domain.router")


# ── Domain classification rules ───────────────────────────────────────────────
# Each rule: (compiled regex, domain label)
# Checked in order — first match wins.

_RULES = [
    # CORE — 5G control-plane / user-plane service KPIs
    (r"(smf|upf|amf|pcf|nrf|nssf|ausf|oam|5g|core)", "CORE"),
    (r"(session|attach|registration|authentication|pfcp|gtp|s11|s5|n4|n11)", "CORE"),

    # TRANSPORT — packet, tunnel, latency, and interface metrics
    (r"(packet.*loss|packet.*drop|latency|jitter|throughput|bandwidth)", "TRANSPORT"),
    (r"(pfcp|gtp|gtpv2|gtp_u|sbi|n1|n2|n3|n4|n6)", "TRANSPORT"),
    (r"(tunnel|path|route|transport|uplink|downlink)", "TRANSPORT"),

    # SYSTEM — host-level utilization and OS signals
    (r"cpu.*(usage|util|percent|load)",   "SYSTEM"),
    (r"memory.*(usage|util|bytes|percent)", "SYSTEM"),
    (r"disk.*(io|wait|read|write|latency)", "SYSTEM"),
    (r"(io_wait|iowait|swap|free|cache)", "SYSTEM"),
    (r"(process|thread|fd|file.desc)",       "SYSTEM"),
]

_COMPILED_RULES = [(re.compile(p, re.IGNORECASE), d) for p, d in _RULES]

# Explicit KPI name → domain map (fast lookup for known KPIs)
_KNOWN_KPIS: Dict[str, str] = {
    "SMF_CPU_Usage":                 "CORE",
    "UPF_Memory_Usage":              "CORE",
    "AMF_Session_Setup_Failure":     "CORE",
    "PCF_Rule_Evaluation_Delay":     "CORE",
    "NRF_Connection_Latency":        "CORE",
    "NSSF_Domain_Allocation_Errors": "CORE",
    "AUSF_Auth_Failures":            "CORE",
    "OAM_High_CPU":                  "CORE",
    "PFCP_Errors":                   "TRANSPORT",
    "GTP_Packet_Loss":               "TRANSPORT",
    "5G_Transport_Latency":          "TRANSPORT",
    "CPU_Usage":                     "SYSTEM",
    "Memory_Usage":                  "SYSTEM",
    "Disk_IO_Wait":                  "SYSTEM",
    "Load_Average":                  "SYSTEM",
    "Swap_Usage":                    "SYSTEM",
}


def classify_kpi(kpi_name: str) -> str:
    """
    Classify a single KPI name into a domain.
    Returns: 'SYSTEM', 'LINUX', 'NETWORK', or 'UNKNOWN'
    """
    # 1. Exact lookup (fastest)
    if kpi_name in _KNOWN_KPIS:
        domain = _KNOWN_KPIS[kpi_name]
        logger.debug("KPI '%s' → %s (exact match)", kpi_name, domain)
        return domain

    # 2. Regex rules
    for pattern, domain in _COMPILED_RULES:
        if pattern.search(kpi_name):
            logger.debug("KPI '%s' → %s (regex match)", kpi_name, domain)
            return domain

    logger.debug("KPI '%s' → UNKNOWN (no match)", kpi_name)
    return "UNKNOWN"


def route_kpis(raw_kpis: List[Dict]) -> List[Dict]:
    """
    Agent 0 main function.
    Takes a list of KPI records, attaches 'domain' to each one.
    Returns the enriched list.

    This is what makes the pipeline "agentic" — the system
    understands each KPI without being manually told.
    """
    if not raw_kpis:
        return []

    enriched = []
    domain_counts: Dict[str, int] = {}

    for kpi in raw_kpis:
        kpi_name = kpi.get("kpi_name", "")
        domain   = classify_kpi(kpi_name)

        enriched_kpi = {**kpi, "domain": domain}
        enriched.append(enriched_kpi)

        domain_counts[domain] = domain_counts.get(domain, 0) + 1

    logger.info(
        "Agent 0 routed %d KPIs → %s",
        len(enriched),
        ", ".join(f"{d}:{c}" for d, c in sorted(domain_counts.items()))
    )

    return enriched


def get_domain_summary(enriched_kpis: List[Dict]) -> Dict[str, List[str]]:
    """
    Returns { domain: [kpi_names] } — useful for logging and the chatbot UI.
    """
    summary: Dict[str, List[str]] = {}
    for kpi in enriched_kpis:
        d = kpi.get("domain", "UNKNOWN")
        summary.setdefault(d, [])
        name = kpi.get("kpi_name", "")
        if name not in summary[d]:
            summary[d].append(name)
    return summary
