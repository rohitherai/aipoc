# KB-UPF-001: GTP Packet Loss on N3 Interface

**Domain:** UPF
**Keywords:** GTP_Packet_Loss, GTP packet loss, gtp tunnel, N3 interface, packet loss, upf gtp, GTP-U, tunnel loss

## Symptoms
- `GTP_Packet_Loss` metric breaches threshold (e.g. 3% vs threshold 2%)
- Syslog: `GTP_Packet_Loss detected: packet loss on N3 interface, tunnel`
- User plane data degraded — subscribers experiencing slow data speeds
- GTP-U tunnel errors increasing on UPF N3 interface
- End-to-end latency spikes for active UE sessions

## Root Cause
GTP (GPRS Tunneling Protocol) packet loss on the N3 interface (UPF to RAN):
1. **N3 interface bandwidth saturation** — traffic exceeds physical or virtual NIC capacity
2. **RAN node congestion** — gNB/RAN is dropping packets due to buffer overflow
3. **MTU mismatch** — GTP-U encapsulation causing fragmentation and packet drops
4. **UPF NIC ring buffer overflow** — high traffic rate overflows NIC TX/RX buffers
5. **Routing issue** — incorrect routing table causing GTP packets to take suboptimal path

## Immediate Remediation Steps
1. Check UPF interface statistics: `oc exec -n 5gc-upf upf-0 -- ip -s link show n3`
2. Verify GTP tunnel status: `oc exec -n 5gc-upf upf-0 -- gtpinfo --list-tunnels | grep loss`
3. Check N3 bandwidth utilization: `oc exec -n 5gc-upf upf-0 -- sar -n DEV 1 5 | grep n3`
4. Verify MTU settings: `oc exec -n 5gc-upf upf-0 -- ip link show n3 | grep mtu`
5. Increase NIC ring buffer: `oc exec -n 5gc-upf upf-0 -- ethtool -G n3 rx 4096 tx 4096`
6. Check routing: `oc exec -n 5gc-upf upf-0 -- ip route show table main | grep -E "ran|gNB"`
7. Review UPF QoS policies: `oc get configmap upf-qos-config -n 5gc-upf -o yaml`

## Long-term Prevention
- Set MTU to 1400 on N3 to accommodate GTP-U overhead
- Enable DPDK on UPF for high-performance packet processing
- Configure QoS shaping to prevent bandwidth saturation
- Add Grafana alert at 1% packet loss (before threshold of 2%)
- Implement SR-IOV for UPF NIC to bypass kernel overhead

**Last updated:** 2026-05-15 | **Owner:** 5GC User Plane Team
