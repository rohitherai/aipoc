# KB-SYS-003: High Disk I/O Wait

**Domain:** SYSTEM  
**Keywords:** Disk_IO_Wait, disk io, disk wait, io wait high, blk_update_request, I/O error, disk error, sda, storage, disk threshold

## Symptoms
- `Disk_IO_Wait` breaches 30% threshold
- Syslog: `blk_update_request: I/O error`, `EXT4-fs error`, `blkcg: bio stuck`
- Applications hanging on disk reads/writes
- Database queries timing out

## Root Cause
1. Failing or degraded hard disk (bad sectors, hardware error)
2. Too many concurrent processes writing to disk simultaneously
3. RAID array in degraded state
4. NFS/network storage latency spike
5. Filesystem journal corruption (EXT4)

## Immediate Remediation Steps
1. Check disk errors: `sudo dmesg | grep -iE "error|fail|bad sector" | tail -20`
2. Check I/O wait per process: `sudo iotop -o -b -n3 | head -20`
3. Check disk health: `sudo smartctl -H /dev/sda`
4. Check filesystem errors: `sudo dmesg | grep "EXT4-fs error"`
5. Check disk usage: `df -h && du -sh /var/log/* 2>/dev/null | sort -h | tail -10`
6. If log files causing it: `sudo journalctl --vacuum-size=500M`
7. Check for stuck I/O: `sudo lsof | grep deleted | grep -v pts`
8. Remount if journal corrupted: `sudo mount -o remount,ro /dev/sda1 && sudo fsck /dev/sda1`

## Long-term Prevention
- Set up SMART monitoring: `sudo apt install smartmontools && sudo systemctl enable smartd`
- Separate log volumes from data volumes
- Enable I/O scheduler tuning: `echo mq-deadline > /sys/block/sda/queue/scheduler`
- Alert at 20% I/O wait for early warning
- Consider SSD upgrade for database servers

**Last updated:** 2026-02-01 | **Owner:** Infrastructure Team
