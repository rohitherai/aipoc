# KB-SYS-001: High CPU Usage

**Domain:** SYSTEM  
**Keywords:** CPU_Usage, cpu spike, cpu high, cpu utilization, cpu threshold, cpu 80, cpu 90, cpu 100

## Symptoms
- `CPU_Usage` metric breaches 80% threshold
- Syslog shows: `CPU spike detected`, `soft lockup`, `CPU stuck`, `irq took too long`
- System responsiveness degraded
- Load average also elevated

## Root Cause
High CPU is usually caused by:
1. A runaway process (Java JVM, MySQL, or web server consuming >80% CPU)
2. Kernel soft lockup on a specific CPU core
3. IRQ handler taking too long (network or disk interrupt storm)
4. Missing CPU limits on a container/service

## Immediate Remediation Steps
1. Find the top CPU consumer: `top -bn1 | head -20` or `ps aux --sort=-%cpu | head -10`
2. Check for soft lockups: `dmesg | grep -i "soft lockup"`
3. If Java process: get thread dump: `sudo jstack <pid> > /tmp/threaddump.txt`
4. If MySQL: check slow queries: `sudo mysqladmin processlist`
5. Kill or restart the offending process: `sudo systemctl restart <service-name>`
6. Verify CPU drops: `watch -n2 'ps aux --sort=-%cpu | head -5'`
7. If IRQ storm: `cat /proc/interrupts | sort -n -k2 | tail -10`

## Long-term Prevention
- Set CPU limits in `/etc/systemd/system/<service>.service` using `CPUQuota=80%`
- Enable cgroup CPU throttling for non-critical services
- Add Grafana alert at 70% CPU for early warning
- For JVM: set `-XX:+UseG1GC -XX:MaxGCPauseMillis=200`
- Consider horizontal scaling if sustained load > 70%

## Related KPIs
- Load_Average (check if also breached)
- Memory_Usage (often co-occurs with CPU spikes)

**Last updated:** 2026-01-10 | **Owner:** SRE Team
