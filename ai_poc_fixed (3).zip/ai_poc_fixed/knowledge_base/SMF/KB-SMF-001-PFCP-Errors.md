# KB-SMF-001: PFCP Errors — SMF to UPF Association Failures

**Domain:** SMF
**Keywords:** PFCP_Errors, PFCP association, pfcp failure, smf pfcp, UPF unreachable, PFCP heartbeat, pfcp timeout, N4 interface

## Symptoms
- `PFCP_Errors` metric breaches threshold (e.g. 18 errors vs threshold 10)
- Syslog: `PFCP_Errors: association failures in last 5 minutes, retrying connections`
- Syslog: `Session establishment failed: PFCP timeout to UPF`
- PDU session setup failures increasing
- SMF unable to establish N4 sessions with UPF

## Root Cause
PFCP (Packet Forwarding Control Protocol) errors on the N4 interface between SMF and UPF:
1. **UPF pod restarted or OOMKilled** — PFCP associations lost after UPF restart
2. **Network policy blocking UDP 8805** — firewall or CNI blocking PFCP traffic between SMF and UPF namespaces
3. **UPF IP changed after pod reschedule** — SMF N4 config pointing to stale UPF IP
4. **PFCP heartbeat timeout** — UPF not responding to SMF heartbeats within timeout window
5. **UPF resource exhaustion** — UPF out of memory cannot process PFCP messages

## Immediate Remediation Steps
1. Check UPF pod status: `oc get pods -n 5gc-upf -o wide`
2. Check PFCP connectivity from SMF: `oc exec -n 5gc-smf smf-0 -- pfcp-client ping <upf-n4-ip>`
3. View PFCP error logs: `oc logs -n 5gc-smf smf-0 --since=15m | grep -i "pfcp\|n4\|association"`
4. Check UPF memory: `oc top pod -n 5gc-upf`
5. Restart UPF if OOMKilled: `oc rollout restart deployment/upf -n 5gc-upf`
6. Wait for PFCP re-association: `oc logs -n 5gc-smf smf-0 --since=5m | grep "pfcp.*success"`
7. Verify N4 config: `oc get configmap smf-config -n 5gc-smf -o yaml | grep -A5 n4`

## Long-term Prevention
- Set PodDisruptionBudget for UPF to prevent simultaneous restarts
- Add liveness probe on PFCP port UDP/8805 in UPF deployment
- Configure SMF with multiple UPF endpoints for PFCP failover
- Set Grafana alert at 5 PFCP errors (before threshold of 10)

**Last updated:** 2026-05-15 | **Owner:** 5GC Network Team
