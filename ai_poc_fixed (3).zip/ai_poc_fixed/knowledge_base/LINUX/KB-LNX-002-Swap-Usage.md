# KB-LNX-002: High Swap Usage

**Domain:** LINUX  
**Keywords:** Swap_Usage, swap high, swapping, vm.swappiness, swap usage, swap threshold, memory swap

## Symptoms
- `Swap_Usage` approaches or exceeds 70% threshold
- System performance degraded (swap is much slower than RAM)
- Syslog: `memory_usage critical`, `vm.swappiness adjusted`
- Applications slow, high I/O wait

## Root Cause
Swap is being used heavily because physical RAM is exhausted.
1. Insufficient RAM for current workload
2. Memory leak causing RAM to be gradually consumed
3. vm.swappiness set too high (default 60 = swap aggressively)
4. Huge pages not configured for Java/database workloads

## Immediate Remediation Steps
1. Check swap usage: `free -h && swapon --show`
2. Check what's using swap: `for file in /proc/*/status; do awk '/VmSwap|Name/{printf $2 " " $3}' $file; echo ''; done | sort -k 3 -n -r | head -10`
3. Lower swappiness immediately: `sudo sysctl vm.swappiness=10`
4. Find and restart memory-leaking service
5. If swap critically full, flush (only if enough free RAM): `sudo swapoff -a && sudo swapon -a`
6. Add more swap space: `sudo fallocate -l 8G /swapfile2 && sudo chmod 600 /swapfile2 && sudo mkswap /swapfile2 && sudo swapon /swapfile2`

## Long-term Prevention
- Set `vm.swappiness=10` in `/etc/sysctl.conf` (persists across reboots)
- Use `vm.vfs_cache_pressure=50` to keep filesystem cache
- Consider upgrading RAM if swap is regularly used
- For Java: use `-Xmx` to cap heap and prevent OS-level swap

**Last updated:** 2026-01-25 | **Owner:** Linux SRE Team
