# KB-NET-001: High Network Errors / Tx Hang

**Domain:** NETWORK  
**Keywords:** Network_Errors, network errors, tx hang, transmit timeout, ixgbe, eth0, dropped packets, rx_error, network threshold, Tx Unit Hang

## Symptoms
- `Network_Errors` metric breaches 5 errors threshold
- Syslog: `Tx Unit Hang`, `transmit timeout`, `eth0: 5 transmit timeouts`, `dropped packets on eth1`
- Network connectivity intermittent
- High packet loss detected

## Root Cause
1. NIC (Network Interface Card) driver bug — common with Intel ixgbe 10GbE cards
2. Ring buffer overflow — TX/RX buffers too small for traffic volume
3. NIC firmware outdated, causing interrupt handling issues
4. Network cable or switch port degrading (physical layer issue)
5. CPU affinity conflict — NIC interrupts pinned to overloaded CPU

## Immediate Remediation Steps
1. Check error statistics: `ethtool -S eth0 | grep -iE "error|drop|miss|fail"`
2. Check driver info: `ethtool -i eth0`
3. Check ring buffer sizes: `ethtool -g eth0`
4. Increase ring buffers: `sudo ethtool -G eth0 rx 4096 tx 4096`
5. Reset the NIC (brief outage): `sudo ip link set eth0 down && sleep 2 && sudo ip link set eth0 up`
6. Update ixgbe driver: `sudo apt update && sudo apt install linux-modules-extra-$(uname -r)`
7. Check interrupt affinity: `cat /proc/interrupts | grep eth0`
8. Check for physical issues: `sudo ethtool eth0 | grep -E "Speed|Duplex|Link"`

## Long-term Prevention
- Enable IRQ balancing: `sudo systemctl enable irqbalance && sudo systemctl start irqbalance`
- Set RX/TX checksums: `sudo ethtool -K eth0 tx on rx on`
- Monitor with: `watch -n5 'ethtool -S eth0 | grep -v ": 0"'`
- Alert at 3 errors/sec for early warning
- Pin NIC interrupts away from CPU 0 using `irqaffinity`

**Last updated:** 2026-02-05 | **Owner:** Network / Infrastructure Team
