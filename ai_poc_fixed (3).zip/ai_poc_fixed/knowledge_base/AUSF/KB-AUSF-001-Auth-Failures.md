# KB-AUSF-001: AUSF Authentication Failures

**Domain:** AUSF
**Keywords:** AUSF_Auth_Failures, authentication failures, EAP-AKA, ausf, auth failure, SUCI, SUPI, UE authentication

## Symptoms
- `AUSF_Auth_Failures` metric breaches threshold (e.g. 12 failures vs threshold 5)
- Syslog: `AUSF_Auth_Failures: authentication failures, EAP-AKA prime validation errors`
- UE devices cannot attach to the 5G network
- AMF reporting authentication rejections
- NRF service discovery showing AUSF unavailable

## Root Cause
High AUSF authentication failure rate is typically caused by:
1. **EAP-AKA prime vector mismatch** — AUSF cannot validate authentication vectors from UDM
2. **UDM connectivity issue** — AUSF cannot reach UDM to fetch subscriber credentials (SUPI/SUCI)
3. **Expired or invalid AUTN tokens** — authentication tokens have exceeded their validity window
4. **Certificate rotation** — TLS certificates between AUSF and UDM expired or mismatched
5. **Subscriber data corruption** — K/OPc keys in UDM do not match SIM card data

## Immediate Remediation Steps
1. Check AUSF pod health: `oc get pods -n 5gc-ausf -o wide`
2. Verify AUSF-UDM connectivity: `oc exec -n 5gc-ausf ausf-0 -- curl -sk https://udm.5gc-udm.svc/nudm-ueau/v1/health`
3. Check authentication failure logs: `oc logs -n 5gc-ausf ausf-0 --since=15m | grep -i "auth\|eap\|fail"`
4. Verify UDM subscriber data integrity: `oc logs -n 5gc-udm udm-0 --since=15m | grep -i "supi\|vector"`
5. Restart AUSF if certificate issue: `oc rollout restart deployment/ausf -n 5gc-ausf`
6. Check TLS certificate expiry: `oc get secret ausf-tls -n 5gc-ausf -o jsonpath='{.data.tls\.crt}' | base64 -d | openssl x509 -noout -dates`
7. Monitor recovery: `watch -n5 'oc logs -n 5gc-ausf ausf-0 --since=2m | grep -c auth_success'`

## Long-term Prevention
- Set up automated certificate rotation with cert-manager
- Add Grafana alert at 3 failures (before threshold of 5)
- Implement authentication vector pre-fetching to reduce UDM latency impact
- Configure AUSF redundancy with multiple replicas across availability zones

**Last updated:** 2026-05-15 | **Owner:** 5GC Security Team
