"""
server.py — Flask API + SSE real-time + file watcher
=====================================================
Serves the NOC dashboard UI.
Auto-runs pipeline when dummy_kpis.json is saved.
Uses Server-Sent Events (SSE) to push updates to browser.
"""

import json, logging, os, queue, threading, time
from datetime import datetime
from flask import Flask, jsonify, request, send_from_directory, Response, stream_with_context
from dotenv import load_dotenv
load_dotenv()

from main           import run_pipeline, report_fix_outcome
from kb_search      import KnowledgeBase
from memory_lookup  import get_memory_stats
from history_agent  import HistoryAgent

logging.basicConfig(level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s")
logger = logging.getLogger("server")

app   = Flask(__name__, static_folder=".")
_kb   = KnowledgeBase()
_hist = HistoryAgent()

# ── Shared state ──────────────────────────────────────────────────────────────
_state = {"running": False, "last_result": None, "last_run_at": None, "cycle": 0, "file_hash": None}
_sse_clients = []
_lock = threading.Lock()

# ── CORS ──────────────────────────────────────────────────────────────────────
@app.after_request
def cors(r):
    r.headers["Access-Control-Allow-Origin"]  = "*"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    r.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return r

# ── SSE broadcast ─────────────────────────────────────────────────────────────
def broadcast(etype, data):
    msg = {"type": etype, "data": data, "ts": datetime.now().isoformat()}
    dead = []
    for q in list(_sse_clients):
        try: q.put_nowait(msg)
        except: dead.append(q)
    for q in dead:
        try: _sse_clients.remove(q)
        except: pass

# ── Pipeline runner (background) ─────────────────────────────────────────────
def _run_bg():
    with _lock:
        if _state["running"]: return
        _state["running"] = True
    broadcast("pipeline_status", {"running": True, "cycle": _state["cycle"]})

    steps = [
        ("agent1", "Grafana Fetcher — loading KPI data"),
        ("agent2", "Breach Detection — finding threshold violations"),
        ("agent3", "Service Identifier — mapping to 5G NFs"),
        ("agent4", "Memory Agent — fast path or deep path"),
        ("agent5", "Log Agent + RCA — syslog + root cause analysis"),
        ("agent6", "KB Writer + History — audit trail"),
        ("agent7", "Pipeline complete"),
    ]
    try:
        for aid, msg in steps[:-1]:
            broadcast("agent_status", {"agent": aid, "status": "active", "message": msg})
            time.sleep(0.3)
            broadcast("agent_status", {"agent": aid, "status": "ok"})

        result = run_pipeline()
        with _lock:
            _state["last_result"] = result
            _state["last_run_at"] = datetime.now().isoformat()
            _state["cycle"] += 1

        broadcast("agent_status", {"agent": "agent7", "status": "ok"})
        broadcast("pipeline_complete", result)
        broadcast("pipeline_status", {"running": False, "cycle": _state["cycle"], "last_run_at": _state["last_run_at"]})
        for r in result.get("results", []):
            broadcast("new_incident", r)
        logger.info("Pipeline done — %d KPIs", result.get("kpis_processed", 0))
    except Exception as exc:
        logger.exception("Pipeline error")
        broadcast("pipeline_error", {"error": str(exc)})
    finally:
        with _lock: _state["running"] = False

# ── File watcher ──────────────────────────────────────────────────────────────
def _watch():
    path = os.path.join(os.path.dirname(__file__), "data", "dummy_kpis.json")
    logger.info("Watching: %s", path)
    def mtime():
        try: return str(os.path.getmtime(path))
        except: return None
    _state["file_hash"] = mtime()
    while True:
        time.sleep(2)
        cur = mtime()
        if cur and cur != _state["file_hash"]:
            _state["file_hash"] = cur
            logger.info("dummy_kpis.json changed — auto-running pipeline")
            broadcast("kpi_file_changed", {"message": "KPI file changed — pipeline starting"})
            threading.Thread(target=_run_bg, daemon=True).start()

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index(): return send_from_directory(".", "chatbot.html")

@app.route("/api/stream")
def stream():
    q = queue.Queue(maxsize=50)
    _sse_clients.append(q)
    def gen():
        yield "data: " + json.dumps({"type": "connected", "data": {}}) + "\n\n"
        try:
            while True:
                try: yield "data: " + json.dumps(q.get(timeout=25)) + "\n\n"
                except queue.Empty: yield ": keepalive\n\n"
        except GeneratorExit: pass
        finally:
            try: _sse_clients.remove(q)
            except: pass
    return Response(stream_with_context(gen()), mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@app.route("/api/pipeline/run", methods=["POST","OPTIONS"])
def pipeline_run():
    if request.method == "OPTIONS": return jsonify({}), 200
    threading.Thread(target=_run_bg, daemon=True).start()
    return jsonify({"status": "ok"})

@app.route("/api/analyze", methods=["GET","POST"])
def analyze():
    threading.Thread(target=_run_bg, daemon=True).start()
    return jsonify({"status": "ok", "message": "Pipeline started"})

@app.route("/api/analyze/sync")
def analyze_sync():
    try: return jsonify(run_pipeline())
    except Exception as e: return jsonify({"error": str(e)}), 500

@app.route("/api/state")
def get_state():
    return jsonify({"running": _state["running"], "cycle": _state["cycle"],
                    "last_run_at": _state["last_run_at"], "last_result": _state["last_result"]})

@app.route("/api/kpis")
def get_kpis():
    try:
        f = os.path.join(os.path.dirname(__file__), "data", "dummy_kpis.json")
        raw = json.load(open(f))
        kpis = []
        for k in raw:
            v = float(k.get("value", 0)); t = float(k.get("threshold", 1))
            exc = round((v - t) / t * 100, 1) if v > t else 0
            sev = "CRITICAL" if exc >= 50 else "HIGH" if exc >= 20 else "WARNING" if exc > 0 else "HEALTHY"
            kpis.append({"metric": k.get("kpi_name",""), "value": v, "threshold": t,
                "excess": exc, "severity": sev, "unit": "%",
                "nf": k.get("host","?").split("-")[0].upper(), "host": k.get("host","?"),
                "service": k.get("service","")})
        return jsonify({"kpis": kpis, "ts": datetime.now().isoformat()})
    except Exception as e:
        return jsonify({"error": str(e), "kpis": []}), 500

@app.route("/api/kpis/history/<metric>")
def kpi_history(metric):
    import random
    try:
        f = os.path.join(os.path.dirname(__file__), "data", "dummy_kpis.json")
        raw = json.load(open(f))
        base = next((float(k["value"]) for k in raw if k.get("kpi_name") == metric), 50)
        hist = [{"v": round(base * (0.7 + 0.4 * i/29) + random.uniform(-3, 3), 1)} for i in range(30)]
        return jsonify({"metric": metric, "history": hist})
    except: return jsonify({"metric": metric, "history": []})

@app.route("/api/incidents")
def get_incidents():
    with _lock: result = _state.get("last_result")
    if not result: return jsonify({"incidents": []})
    return jsonify({"incidents": result.get("results", [])})

@app.route("/api/incidents/<inc_id>/ack", methods=["POST"])
def ack(inc_id): return jsonify({"status": "ok"})

@app.route("/api/chat", methods=["POST"])
def chat():
    body = request.get_json(force=True) or {}
    inc  = body.get("incident_id", ""); msg = body.get("message", "").lower()
    if "root cause" in msg or "cause" in msg:
        reply = "Root cause: resource contention on the NF pod. Check oc logs and pod resource limits."
    elif "fix" in msg or "resolve" in msg or "step" in msg:
        reply = "Steps:\n1. oc get pods -n 5gc-<nf>\n2. oc logs -n 5gc-<nf> <pod> --since=15m\n3. oc rollout restart deployment/<nf> (if safe)\n4. Monitor KPI recovery"
    elif "syslog" in msg or "log" in msg:
        reply = "Syslog correlation is shown in the incident card — expand it to see matching log lines from dummy_syslog.txt."
    elif "memory" in msg or "fast" in msg or "confidence" in msg:
        reply = "Memory key format: kpi_name::service::host\nFirst run: stored with confidence=0.3\nAfter 5 confirmed fixes: confidence=0.8 → FAST PATH\nFast path threshold: 0.75"
    elif "kb" in msg or "knowledge" in msg:
        reply = "KB search uses TF-IDF. Score ≥0.10 → KB HIT (free, instant). Miss → Capgemini LLM fallback. LLM answers are auto-written to knowledge_base/AUTOMATED/ for next run."
    elif "sla" in msg:
        reply = "P1: 15min ACK / 4hr resolve · P2: 1hr ACK / 24hr resolve · P3: 4hr ACK / 3 day resolve"
    else:
        reply = "I can help with: root cause, fix steps, syslog details, memory/confidence, KB articles, SLA. What do you need for " + inc + "?"
    return jsonify({"reply": reply, "model": "5G-PoC"})

@app.route("/api/kb/stats")
def kb_stats():
    stats = _kb.get_stats()
    arts = [{"title": a.title, "domain": a.domain,
             "auto": "AUTOMATED" in (a.path if hasattr(a,"path") else "")}
            for a in _kb.articles[:50]]
    return jsonify({**stats, "articles": arts})

@app.route("/api/kb/search")
def kb_search():
    q = request.args.get("q","")
    if not q: return jsonify({"error": "Pass ?q=query"}), 400
    return jsonify(_kb.search(q) or {"message": "No match"})

@app.route("/api/memory/stats")
def memory_stats(): return jsonify(get_memory_stats())

@app.route("/api/memory/feedback", methods=["POST","OPTIONS"])
def memory_feedback():
    if request.method == "OPTIONS": return jsonify({}), 200
    b = request.get_json(force=True) or {}
    kpi = b.get("kpi_name",""); svc = b.get("service","unknown"); host = b.get("host","unknown")
    if not kpi: return jsonify({"error": "kpi_name required"}), 400
    report_fix_outcome(kpi, svc, host, bool(b.get("success", True)))
    return jsonify({"status": "ok"})

@app.route("/api/history")
def get_history():
    return jsonify(_hist.get_history(service=request.args.get("service"), limit=int(request.args.get("limit",20))))

@app.route("/api/sla")
def get_sla():
    with _lock: result = _state.get("last_result")
    if not result: return jsonify([])
    sla = []
    for r in result.get("results", []):
        pri = "P1" if r.get("severity")=="CRITICAL" else "P2" if r.get("severity")=="HIGH" else "P3"
        sla.append({"incident_id": r.get("kpi_name",""), "title": (r.get("kpi_name","")).replace("_"," "),
            "priority": pri, "status": "OPEN", "sla_label": "P1–15min/4hr" if pri=="P1" else "P2–1hr/24hr",
            "acked": False, "ack_mins_left": 14 if pri=="P1" else 55, "res_hrs_left": 3.8 if pri=="P1" else 23})
    return jsonify(sla)

@app.route("/api/health")
def health():
    return jsonify({"status":"ok","version":"5G-PoC-v1","cycle":_state["cycle"],
        "running":_state["running"],"sse_clients":len(_sse_clients),
        "capgemini_key":bool(os.getenv("CAPGEMINI_GENAI_API_KEY")),
        "kb_articles":_kb.get_stats()["total"]})

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    threading.Thread(target=_watch, daemon=True).start()
    print(f"\n{'='*60}")
    print(f"  5G KPI NOC Dashboard: http://localhost:{port}")
    print(f"  Real-time SSE:        GET  /api/stream")
    print(f"  Run pipeline:         POST /api/pipeline/run")
    print(f"  File watcher:         watching data/dummy_kpis.json")
    print(f"{'='*60}\n")
    app.run(debug=False, port=port, threaded=True)
