"""
memory_lookup.py — Memory Lookup Agent
=======================================

Handles memory retrieval operations for known KPI resolutions.
Checks DynamoDB/local JSON for cached solutions.
"""

import logging
import os
from typing import Dict, List, Optional

logger = logging.getLogger("memory_lookup")

# ── Config ────────────────────────────────────────────────────────────────────
DYNAMODB_TABLE     = os.getenv("DYNAMODB_TABLE", "kpi_memory")
AWS_REGION         = os.getenv("AWS_REGION", "us-east-1")
LOCAL_FALLBACK_FILE  = os.path.join(os.path.dirname(__file__), "data", "kpi_memory.json")

# ── DynamoDB client (lazy) ────────────────────────────────────────────────────
_dynamo_table = None
_use_local    = False


def _get_table():
    """Get DynamoDB table resource. Falls back to local JSON silently."""
    global _dynamo_table, _use_local
    if _dynamo_table is not None:
        return _dynamo_table
    if _use_local:
        return None

    try:
        import boto3
        from botocore.exceptions import NoCredentialsError, ClientError

        aws_key    = os.getenv("AWS_ACCESS_KEY_ID", "")
        aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")

        if not aws_key or not aws_secret:
            raise ValueError("AWS credentials not set in .env")

        dynamodb = boto3.resource(
            "dynamodb",
            region_name=AWS_REGION,
            aws_access_key_id=aws_key,
            aws_secret_access_key=aws_secret,
        )
        table = dynamodb.Table(DYNAMODB_TABLE)

        # Create table if it doesn't exist
        try:
            table.load()
            logger.info("DynamoDB table '%s' found", DYNAMODB_TABLE)
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                logger.info("Creating DynamoDB table '%s'...", DYNAMODB_TABLE)
                dynamodb.create_table(
                    TableName=DYNAMODB_TABLE,
                    KeySchema=[{"AttributeName": "kpi_key", "AttributeType": "S"}],
                    AttributeDefinitions=[{"AttributeName": "kpi_key", "AttributeType": "S"}],
                    BillingMode="PAY_PER_REQUEST",
                )
                table.wait_until_exists()
                logger.info("DynamoDB table created")
            else:
                raise

        _dynamo_table = table
        return _dynamo_table

    except Exception as exc:
        logger.warning(
            "DynamoDB not available (%s) — using local JSON fallback: %s",
            type(exc).__name__, LOCAL_FALLBACK_FILE
        )
        _use_local = True
        return None


# ── Local JSON fallback ───────────────────────────────────────────────────────

def _local_read() -> Dict:
    """Read from local JSON file."""
    os.makedirs(os.path.dirname(LOCAL_FALLBACK_FILE), exist_ok=True)
    if not os.path.exists(LOCAL_FALLBACK_FILE):
        return {}
    try:
        with open(LOCAL_FALLBACK_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _make_key(kpi_name: str, service: str, host: str) -> str:
    """Unique key per KPI + service + host combination."""
    return f"{kpi_name}::{service}::{host}"


def lookup_resolution(kpi_name: str, service: str, host: str) -> Optional[Dict]:
    """
    Look up a resolution for a KPI+service+host combination.

    Returns the cached resolution dict if found, None otherwise.
    """
    kpi_key = _make_key(kpi_name, service, host)
    table   = _get_table()

    try:
        if table is not None:
            # DynamoDB lookup
            response = table.get_item(Key={"kpi_key": kpi_key})
            item     = response.get("Item")
        else:
            # Local JSON fallback
            import json
            item = _local_read().get(kpi_key)

        if item:
            logger.debug("Memory HIT: %s — found cached resolution", kpi_key)
            return item
        else:
            logger.debug("Memory MISS: %s — not found", kpi_key)
            return None

    except Exception as exc:
        logger.error("Memory lookup failed for %s: %s", kpi_key, exc)
        return None


def get_memory_stats() -> Dict:
    """
    Get statistics about the memory store.
    Returns: {total_records, high_confidence_count, low_confidence_count}
    """
    table = _get_table()

    try:
        if table is not None:
            # DynamoDB stats
            response = table.scan()
            items = response.get("Items", [])
        else:
            # Local JSON stats
            import json
            items = list(_local_read().values())

        total = len(items)
        high_conf = sum(1 for item in items if float(item.get("confidence", 0)) >= 0.75)
        low_conf = total - high_conf

        return {
            "total_records": total,
            "high_confidence_count": high_conf,
            "low_confidence_count": low_conf,
        }

    except Exception as exc:
        logger.error("Failed to get memory stats: %s", exc)
        return {"total_records": 0, "high_confidence_count": 0, "low_confidence_count": 0}