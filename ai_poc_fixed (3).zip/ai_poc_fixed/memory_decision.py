"""
memory_decision.py — Memory Decision Agent
===========================================

Makes fast-path vs deep-path decisions based on memory lookup results.
Determines whether to use cached resolution or run full analysis.
"""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger("memory_decision")

CONFIDENCE_THRESHOLD = float(os.getenv("MEMORY_CONFIDENCE_THRESHOLD", "0.75"))


def make_memory_decision(critical_kpis: List[Dict], memory_lookup_func) -> Dict:
    """
    For each critical KPI, check memory and decide fast path vs deep path.

    Args:
        critical_kpis: List of KPI dicts from priority detection
        memory_lookup_func: Function to lookup memory (for testability)

    Returns:
        {
          "fast_path": [ result dicts for high-confidence cached resolutions ],
          "deep_path": [ KPI dicts that need full analysis ]
        }
    """
    fast_path = []
    deep_path = []

    for kpi in critical_kpis:
        kpi_name = kpi["kpi_name"]
        hosts    = kpi.get("hosts", ["unknown"])

        # Check memory for each host (KPI+host is the unique key)
        best_hit = None
        for host in hosts:
            hit = memory_lookup_func(kpi_name, host)
            if hit:
                best_hit = hit
                break   # one hit is enough to take the fast path

        if best_hit and float(best_hit.get("confidence", 0)) >= CONFIDENCE_THRESHOLD:
            service = best_hit.get("service") or kpi.get("service") or "generic"
            logger.info(
                "⚡ FAST PATH: %s — using cached resolution (confidence=%.2f)",
                kpi_name, float(best_hit.get("confidence", 0))
            )
            fast_path.append({
                "kpi_name":    kpi_name,
                "domain":      best_hit.get("domain", kpi.get("domain", "UNKNOWN")),
                "service":     service,
                "peak_value":  kpi["peak_value"],
                "threshold":   kpi["threshold"],
                "excess_pct":  kpi.get("avg_excess_pct", 0),
                "hosts":       hosts,
                "log_count":   0,
                "logs":        [],
                "analysis":    best_hit.get("resolution", ""),
                "source":      "memory_cache",
                "kb_title":    best_hit.get("kb_title"),
                "kb_score":    None,
                "confidence":  float(best_hit.get("confidence", 0)),
                "memory_hit":  True,
                "success_count": int(best_hit.get("success_count", 0)),
            })
        else:
            reason = "no memory hit" if not best_hit else f"low confidence ({best_hit.get('confidence', 0):.2f})"
            logger.info("🔍 DEEP PATH: %s — %s, running full analysis", kpi_name, reason)
            deep_path.append(kpi)

    logger.info(
        "Memory Decision: %d fast path (cached) | %d deep path (new analysis)",
        len(fast_path), len(deep_path)
    )

    return {"fast_path": fast_path, "deep_path": deep_path}