"""
kpi_agent.py — KPI Processor (Agent 2)
========================================
Identifies ALL breached KPIs and ranks them by severity.

SEVERITY LOGIC:
  excess_pct = (value - threshold) / threshold * 100

  CRITICAL  → excess_pct >= 50%   e.g. AUSF_Auth_Failures: 12 vs 5 = 140% → CRITICAL
  HIGH      → excess_pct >= 20%   e.g. GTP_Packet_Loss: 3 vs 2 = 50% → CRITICAL
  WARNING   → excess_pct > 0%     e.g. SMF_CPU_Usage: 78 vs 70 = 11% → WARNING

WHY excess_pct matters more than raw value:
  AUSF_Auth_Failures: value=12, threshold=5  → 140% over = CRITICAL
  SMF_CPU_Usage:      value=78, threshold=70 → 11% over  = WARNING
  Even though 78 > 12, AUSF is MORE critical because it's proportionally more over its threshold.

OLD code issue: TOP_N=3 hardcoded → only returned top 3, dropped the rest silently.
NEW code: returns ALL breached KPIs sorted by excess_pct (most critical first).
"""

import pandas as pd
import logging

logger = logging.getLogger(__name__)

# Severity thresholds — based on how far OVER the threshold a KPI is
SEVERITY_CRITICAL = 50.0   # excess_pct >= 50% → CRITICAL
SEVERITY_HIGH     = 20.0   # excess_pct >= 20% → HIGH
# anything > 0% but below 20% → WARNING


def get_severity(excess_pct: float) -> str:
    """
    Map excess_pct to a severity label.

    Example:
      AUSF_Auth_Failures: excess=140% → CRITICAL
      NRF_Connection_Latency: excess=28% → HIGH
      SMF_CPU_Usage: excess=11.4% → WARNING
    """
    if excess_pct >= SEVERITY_CRITICAL:
        return "CRITICAL"
    elif excess_pct >= SEVERITY_HIGH:
        return "HIGH"
    else:
        return "WARNING"


def identify_priority_kpis(kpi_list: list) -> list:
    """
    Returns ALL KPIs that breached their threshold,
    sorted by excess_pct descending (most critical first).

    Each result has:
      kpi_name       — metric name
      breach_count   — how many records for this KPI breached
      avg_excess_pct — average % over threshold across all records
      peak_value     — highest value seen
      threshold      — the threshold value
      hosts          — list of affected hosts
      severity       — CRITICAL / HIGH / WARNING
      excess_ratio   — peak_value / threshold (e.g. 2.4x over)
    """
    if not kpi_list:
        logger.warning("No KPI data received")
        return []

    df = pd.DataFrame(kpi_list)

    # Step 1: mark every row that breached its threshold
    df["over_threshold"] = df["value"] > df["threshold"]

    # Step 2: calculate how far over the threshold each record is (in %)
    # Formula: (value - threshold) / threshold * 100
    # clip(lower=0) means non-breached rows get 0% (not negative)
    df["excess_pct"] = (
        (df["value"] - df["threshold"]) / df["threshold"] * 100
    ).clip(lower=0)

    # Step 3: keep only rows that actually breached
    breached = df[df["over_threshold"]]
    if breached.empty:
        logger.info("No KPIs breached their thresholds — all systems normal")
        return []

    # Step 4: group by KPI name and aggregate
    # This handles cases where the same KPI appears multiple times
    # (e.g. multiple data points, or multiple hosts)
    summary = (
        breached.groupby("kpi_name")
        .agg(
            breach_count   = ("kpi_name", "count"),      # how many records breached
            avg_excess_pct = ("excess_pct", "mean"),     # average % over threshold
            peak_value     = ("value", "max"),           # worst value seen
            threshold      = ("threshold", "first"),     # the threshold (same for all)
        )
        .reset_index()
        # Sort by avg_excess_pct descending — most critical first
        # Secondary sort by breach_count for ties
        .sort_values(
            ["avg_excess_pct", "breach_count"],
            ascending=[False, False]
        )
    )
    # NO .head(N) — return ALL breached KPIs, not just top 3

    # Step 5: collect affected hosts per KPI
    host_map = {}
    if "host" in breached.columns:
        host_map = (
            breached.groupby("kpi_name")["host"]
            .apply(lambda x: list(x.unique()))
            .to_dict()
        )

    # Step 6: build result list with severity labels
    result = []
    for _, row in summary.iterrows():
        excess    = round(float(row["avg_excess_pct"]), 1)
        severity  = get_severity(excess)
        peak      = round(float(row["peak_value"]), 2)
        thr       = round(float(row["threshold"]), 2)
        ratio     = round(peak / thr, 2) if thr > 0 else 0

        result.append({
            "kpi_name":       row["kpi_name"],
            "breach_count":   int(row["breach_count"]),
            "avg_excess_pct": excess,
            "peak_value":     peak,
            "threshold":      thr,
            "hosts":          host_map.get(row["kpi_name"], []),
            "severity":       severity,    # CRITICAL / HIGH / WARNING
            "excess_ratio":   ratio,       # e.g. 2.4x → peak is 2.4× the threshold
        })

    # Log a clear summary
    critical = [r for r in result if r["severity"] == "CRITICAL"]
    high     = [r for r in result if r["severity"] == "HIGH"]
    warning  = [r for r in result if r["severity"] == "WARNING"]

    logger.info(
        "KPI breach summary: %d CRITICAL | %d HIGH | %d WARNING",
        len(critical), len(high), len(warning)
    )
    for r in result:
        logger.info(
            "  [%s] %s: value=%.2f threshold=%.2f excess=%.1f%%",
            r["severity"], r["kpi_name"],
            r["peak_value"], r["threshold"], r["avg_excess_pct"]
        )

    return result
