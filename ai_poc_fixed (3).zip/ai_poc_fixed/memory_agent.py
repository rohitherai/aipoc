import logging
from typing import Dict, Any, Optional
from memory_lookup import lookup_resolution
from memory_writer import store_resolution

logger = logging.getLogger("memory_agent")


class MemoryAgent:
    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        logger.info("Running MemoryAgent")
        
        action = input_data.get("action", "lookup")
        
        if action == "lookup":
            return self._lookup(input_data)
        elif action == "store":
            return self._store(input_data)
        else:
            return {"error": f"Unknown action: {action}"}

    def _lookup(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        kpi_name = input_data.get("kpi_name")
        service = input_data.get("service")
        hosts = input_data.get("hosts", ["unknown"])

        for host in hosts:
            hit = lookup_resolution(kpi_name, service, host)
            if hit:
                logger.info("Memory HIT for %s/%s on %s", kpi_name, service, host)
                return {
                    "memory_hit": True,
                    "resolution": hit.get("resolution", ""),
                    "confidence": float(hit.get("confidence", 0.0)),
                    "source": hit.get("source", ""),
                }

        logger.info("Memory MISS for %s/%s", kpi_name, service)
        return {"memory_hit": False, "confidence": 0.0}

    def _store(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        kpi_name = input_data.get("kpi_name")
        service = input_data.get("service")
        hosts = input_data.get("hosts", ["unknown"])
        resolution = input_data.get("resolution")
        source = input_data.get("source")
        kb_title = input_data.get("kb_title")
        confidence = input_data.get("confidence", 0.5)

        for host in hosts:
            store_resolution(
                kpi_name=kpi_name,
                service=service,
                host=host,
                resolution=resolution,
                source=source,
                kb_title=kb_title,
                initial_confidence=confidence,
            )

        logger.info("Stored resolution for %s/%s", kpi_name, service)
        return {"stored": True}
