"""
service_identifier_agent.py — Service Identifier with Auto-Learning
====================================================================
Identifies which 5G NF service a KPI belongs to.

3 identification steps (in order, first match wins):
  Step A — labels field      conf 0.95  e.g. labels={"service":"smf"}
  Step B — hostname          conf 0.80  e.g. host="smf-core-01" → "smf" found
  Step C — kpi_name          conf 0.60  e.g. kpi="SMF_CPU_Usage" → "smf" found

If all 3 fail → service = unknown

AUTO-LEARNING (new):
  When service = unknown, asks Capgemini LLM to identify the service.
  If LLM identifies it → saves the new service name to services.json.
  Next time the same KPI/host arrives → Step B finds it immediately (no LLM cost).
"""

import json
import logging
import os
import re
import requests
from typing import Dict, Any, Optional, Tuple, List

logger = logging.getLogger("service_identifier_agent")

# ── services.json path ────────────────────────────────────────────────────────
BASE = os.path.dirname(__file__)
SERVICES_FILE = os.path.join(BASE, "data", "services.json")

DEFAULT_SERVICES: List[str] = []


def load_services() -> List[str]:
    """Load known service names from services.json."""
    try:
        with open(SERVICES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            services = [str(x).lower().strip() for x in data if x]
            logger.info("Loaded %d services from services.json: %s", len(services), services)
            return services
        logger.warning("services.json has unexpected format")
    except Exception as exc:
        logger.warning("Could not load services.json: %s", exc)
    return DEFAULT_SERVICES.copy()


def save_services(services: List[str]):
    """
    Save updated service list back to services.json.
    Called automatically when a new service is discovered via LLM.
    """
    try:
        # Remove duplicates, sort alphabetically
        cleaned = sorted(list(set(s.lower().strip() for s in services if s)))
        with open(SERVICES_FILE, "w", encoding="utf-8") as f:
            json.dump(cleaned, f, indent=2)
        logger.info("services.json updated: %s", cleaned)
    except Exception as exc:
        logger.error("Could not save services.json: %s", exc)


# Load at module startup
SERVICES: List[str] = load_services()


# ── Capgemini LLM — identify unknown service ─────────────────────────────────

_CAPGEMINI_URL   = os.getenv("CAPGEMINI_GENAI_URL",
    "https://openai.generative.engine.capgemini.com/v1/chat/completions")
_CAPGEMINI_MODEL = os.getenv("CAPGEMINI_MODEL",
    "anthropic.claude-3-sonnet-20240229-v1:0")

# Cache: remember LLM results in memory so same unknown is never asked twice per run
_llm_cache: Dict[str, str] = {}


def _ask_llm_for_service(kpi_name: str, host: str) -> Optional[str]:
    """
    Ask Capgemini LLM to identify which 5G NF service this KPI belongs to.
    Returns the service name (e.g. "udm") or None if LLM cannot identify it.
    Only called when all 3 identification steps fail.
    """
    # Check in-memory cache first
    cache_key = f"{kpi_name}::{host}".lower()
    if cache_key in _llm_cache:
        logger.info("LLM cache hit for '%s' → '%s'", kpi_name, _llm_cache[cache_key])
        return _llm_cache[cache_key]

    api_key = os.getenv("CAPGEMINI_GENAI_API_KEY", "")
    if not api_key:
        logger.info("No CAPGEMINI_GENAI_API_KEY — LLM service identification skipped")
        return None

    known = ", ".join(SERVICES) if SERVICES else "smf, upf, amf, pcf, nrf, nssf, ausf, oam, udm"
    prompt = (
        "You are a 5G core network expert.\n"
        f"KPI name: {kpi_name}\n"
        f"Host: {host}\n"
        f"Known 5G NF services: {known}\n\n"
        "Which 5G NF service does this KPI belong to?\n"
        "If it matches a known service, use that name exactly (lowercase).\n"
        "If it is a new service not in the list, suggest a short lowercase name.\n"
        "If you cannot determine the service, respond with 'unknown'.\n\n"
        "Respond ONLY with JSON: {\"service\": \"name\", \"description\": \"brief description\"}\n"
        "No markdown. No explanation."
    )

    try:
        resp = requests.post(
            _CAPGEMINI_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type":  "application/json"
            },
            json={
                "model": _CAPGEMINI_MODEL,
                "messages": [
                    {"role": "system", "content": "5G core network expert."},
                    {"role": "user",   "content": prompt}
                ],
                "temperature": 0.0,
            },
            timeout=20,
        )

        if resp.status_code == 200:
            raw    = resp.json()["choices"][0]["message"]["content"].strip()
            raw    = re.sub(r"```json|```", "", raw).strip()
            parsed = json.loads(raw)
            service = parsed.get("service", "").lower().strip()
            desc    = parsed.get("description", "")

            if service and service != "unknown":
                logger.info(
                    "LLM identified service for '%s' on '%s' → '%s' (%s)",
                    kpi_name, host, service, desc
                )
                _llm_cache[cache_key] = service
                return service
            else:
                logger.info("LLM could not identify service for '%s'", kpi_name)
                return None
        else:
            logger.warning("LLM HTTP %d: %s", resp.status_code, resp.text[:100])
            return None

    except Exception as exc:
        logger.warning("LLM service identification failed: %s", exc)
        return None


def _add_to_services_json(new_service: str):
    """
    Add a newly discovered service name to services.json.
    Also updates the in-memory SERVICES list so it works immediately
    for any remaining KPIs in the current pipeline run.
    """
    global SERVICES
    new_service = new_service.lower().strip()

    if new_service in SERVICES:
        return  # already known

    SERVICES.append(new_service)
    save_services(SERVICES)
    logger.info(
        "AUTO-LEARNED new service '%s' → saved to services.json. "
        "Next run will identify this service without LLM.",
        new_service
    )


# ── Main agent class ──────────────────────────────────────────────────────────

class ServiceIdentifierAgent:

    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        kpi_name = input_data.get("kpi_name", "")
        labels   = input_data.get("labels")
        instance = input_data.get("instance", "")

        # Step A: labels
        result = self._extract_from_labels(labels)
        if result:
            service, confidence, source = result
            return {"service": service, "confidence": confidence, "source": source}

        # Step B: hostname
        result = self._extract_from_instance(instance)
        if result:
            service, confidence, source = result
            return {"service": service, "confidence": confidence, "source": source}

        # Step C: kpi_name
        result = self._extract_from_kpi_name(kpi_name)
        if result:
            service, confidence, source = result
            return {"service": service, "confidence": confidence, "source": source}

        # All 3 steps failed — ask LLM (auto-learning)
        logger.warning(
            "Service unknown for KPI '%s' on host '%s' — trying LLM identification",
            kpi_name, instance
        )

        llm_service = _ask_llm_for_service(kpi_name, instance)

        if llm_service:
            # Save to services.json so future KPIs don't need LLM
            _add_to_services_json(llm_service)
            return {
                "service":    llm_service,
                "confidence": 0.70,
                "source":     "llm_discovered"
            }

        # Truly unknown — LLM also could not identify
        logger.warning(
            "Service truly unknown for KPI '%s' — no identification possible",
            kpi_name
        )
        return {"service": "unknown", "confidence": 0.30, "source": "unknown"}

    def _extract_from_labels(self, labels: Optional[Dict[str, str]]) -> Optional[Tuple[str, float, str]]:
        """Step A: check labels dict for service/nf_type/app/component fields."""
        if not labels:
            return None
        labels_lower = {k.lower(): v.lower() for k, v in labels.items()}
        for field in ["service", "nf_type", "app", "component"]:
            value = labels_lower.get(field)
            if not value:
                continue
            for service in SERVICES:
                if service == value or service in value or value in service:
                    return service, 0.95, "labels"
        return None

    def _extract_from_instance(self, instance: Optional[str]) -> Optional[Tuple[str, float, str]]:
        """Step B: check hostname for service name substring."""
        if not instance:
            return None
        instance_lower = str(instance).lower()
        for service in SERVICES:
            if service in instance_lower:
                return service, 0.80, "instance"
        return None

    def _extract_from_kpi_name(self, kpi_name: Optional[str]) -> Optional[Tuple[str, float, str]]:
        """Step C: check KPI name for service name substring."""
        if not kpi_name:
            return None
        kpi_lower = kpi_name.lower()
        for service in SERVICES:
            if service in kpi_lower:
                return service, 0.60, "kpi_name"
        return None
