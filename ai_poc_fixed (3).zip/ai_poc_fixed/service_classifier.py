"""
service_classifier.py — Service/Application Classifier
=======================================================

Identifies which service or application a KPI breach belongs to.
Maps KPI names, affected hosts, and syslog keywords to services like:
- Nginx, Apache, Haproxy (web servers)
- MySQL, PostgreSQL, Redis (databases)
- Kafka, RabbitMQ (message queues)
- application-specific services

This allows the pipeline to route fixes to service-specific agents.
"""

import logging
import re
from typing import Dict, List, Optional

logger = logging.getLogger("service_classifier")

# ── Service classification rules ──────────────────────────────────────────────
# Format: (kpi_pattern, syslog_keyword, service_name)

SERVICE_PATTERNS: Dict[str, List[tuple]] = {
    "5G Core": [
        (r"smf|upf|amf|pcf|nrf|nssf|ausf|oam", "smf|upf|amf|pcf|nrf|nssf|ausf|oam|5g|pfcp|gtp|ngap|n1|n2|n4|n11", "5g_core"),
        (r"session.*failure|auth.*failure|attach.*failure|registration.*failure", "smf|amf|ausf|pcf", "5g_core"),
        (r"pfcp.*error|gtp.*loss|latency|jitter", "pfcp|gtp|n4|sbi|transport|uplink|downlink", "5g_core"),
    ],
    "System": [
        (r"cpu.*usage|memory.*usage|disk.*io|load.*average|swap.*usage", "host|node|system|kernel|oom|iowait", "system"),
    ],
}

KNOWN_SERVICE_HOSTS: Dict[str, List[str]] = {
    "5g_core": ["smf", "upf", "amf", "pcf", "nrf", "nssf", "ausf", "oam", "core", "5g"],
    "system": ["host", "node", "vm", "baremetal", "infra"],
}


def classify_service_from_kpi(kpi_name: str, host: str = "", logs: List[str] = None) -> Optional[str]:
    """
    Infer service type from KPI name, host name, and syslog keywords.
    Returns the service name or None if not determinable.
    """
    if logs is None:
        logs = []

    # Check hostname patterns first (fastest)
    host_lower = host.lower()
    for service, patterns in KNOWN_SERVICE_HOSTS.items():
        if any(pat in host_lower for pat in patterns):
            logger.debug("Service guess from host '%s': %s", host, service)
            return service

    # Check syslog keywords
    log_text = " ".join(logs).lower()
    
    for service, rules in SERVICE_PATTERNS.items():
        for kpi_pattern, syslog_pattern, service_name in rules:
            if re.search(kpi_pattern, kpi_name, re.IGNORECASE):
                if not syslog_pattern or re.search(syslog_pattern, log_text, re.IGNORECASE):
                    logger.debug(
                        "Service detected: %s (KPI='%s', logs matched='%s')",
                        service_name, kpi_name, bool(syslog_pattern and re.search(syslog_pattern, log_text, re.IGNORECASE))
                    )
                    return service_name

    logger.debug("Service not detected for KPI '%s' on host '%s'", kpi_name, host)
    return None


def enrich_kpi_with_service(kpi: Dict, logs: List[str] = None) -> Dict:
    """
    Enhance a KPI record with the detected service field.
    """
    if logs is None:
        logs = []
    
    service = classify_service_from_kpi(
        kpi.get("kpi_name", ""),
        kpi.get("host", ""),
        logs
    )
    
    kpi["service"] = service or "generic"
    return kpi


def get_service_summary(enriched_kpis: List[Dict]) -> Dict[str, List[str]]:
    """Returns { service: [kpi_names] } — useful for logging and UI."""
    summary: Dict[str, List[str]] = {}
    for kpi in enriched_kpis:
        svc = kpi.get("service", "generic")
        summary.setdefault(svc, [])
        name = kpi.get("kpi_name", "")
        if name not in summary[svc]:
            summary[svc].append(name)
    return summary
