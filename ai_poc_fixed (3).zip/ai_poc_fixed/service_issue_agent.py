import logging
from typing import Dict, Any

from syslog_agent import get_related_logs
from rca_agent import analyze_kpi
from fixer_agent import generate_fix_plan
from approval_agent import request_approval
from memory_writer import store_resolution

logger = logging.getLogger("service_issue_agent")


def _get_service_handler(service: str):
    return _generic_service_handler


def _generic_service_handler(kpi: Dict[str, Any]) -> Dict[str, Any]:
    log_dict = get_related_logs([kpi])
    logs = log_dict.get(kpi.get("kpi_name", ""), [])

    rca_result = analyze_kpi(kpi, logs)
    fix_proposal = generate_fix_plan(rca_result, kpi)
    approval_request = request_approval(fix_proposal)

    hosts = kpi.get("hosts", ["unknown"])
    for host in hosts:
        store_resolution(
            kpi_name=kpi.get("kpi_name", "unknown"),
            service=kpi.get("service", "unknown"),
            host=host,
            resolution=rca_result.get("root_cause", ""),
            source=rca_result.get("analysis_source", "unknown"),
            kb_title=rca_result.get("kb_title"),
            initial_confidence=0.5,
        )

    return {
        "kpi_name": kpi.get("kpi_name", "unknown"),
        "service": kpi.get("service", "unknown"),
        "service_confidence": kpi.get("confidence", 0.0),
        "path": "deep",
        "memory_hit": False,
        "root_cause": rca_result.get("root_cause", ""),
        "analysis_source": rca_result.get("analysis_source", "unknown"),
        "fix_plan": fix_proposal.get("fix_plan", {}),
        "approval_id": approval_request.get("approval_id"),
        "approval_status": approval_request.get("status"),
        "rca_report": rca_result.get("report", ""),
    }


def resolve_service_issue(kpi: Dict[str, Any]) -> Dict[str, Any]:
    service = kpi.get("service", "unknown")
    handler = _get_service_handler(service)
    return handler(kpi)
