"""
main.py — Pipeline Entry Point
================================
Thin wrapper that delegates to pipeline_orchestrator.
Also exposes report_fix_outcome for the server feedback endpoint.
"""
import logging
from dotenv import load_dotenv
load_dotenv()

from pipeline_orchestrator import run_pipeline as run_orchestrated_pipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger(__name__)


def run_pipeline() -> dict:
    """Run full pipeline. Called by server /api/analyze."""
    result = run_orchestrated_pipeline()
    if result.get("error"):
        logger.error("Pipeline error: %s", result["error"])
    return result


def report_fix_outcome(kpi_name: str, service: str, host: str, success: bool):
    """
    Update confidence after a fix is validated.
    success=True  → confidence +0.1
    success=False → confidence -0.2
    """
    from memory_writer import update_confidence
    update_confidence(kpi_name, service, host, success)
    if success:
        logger.info("Fix SUCCESS: %s/%s on %s — confidence raised", kpi_name, service, host)
    else:
        logger.warning("Fix FAILURE: %s/%s on %s — confidence lowered", kpi_name, service, host)


if __name__ == "__main__":
    import json
    print(json.dumps(run_pipeline(), indent=2))
