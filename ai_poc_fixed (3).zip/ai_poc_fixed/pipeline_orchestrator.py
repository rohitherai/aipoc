"""
pipeline_orchestrator.py — Full 10-Agent Pipeline
===================================================
Orchestrates all agents in sequence per the leadership summary.

PIPELINE FLOW:
  Agent 1  — Grafana KPI Fetcher (get_kpi_data)
  Agent 2  — KPI Processor (identify_priority_kpis)
  Agent SI — Service Identifier (labels → instance → kpi_name)
  Agent M  — Memory Agent (fast-path vs deep-path decision)
             ↓ FAST PATH: confidence ≥ 0.75 → return cached
             ↓ DEEP PATH:
  Agent L  — Log Agent (syslog correlation)
  Agent R  — Root Cause Agent (KB search → LLM fallback)
  Agent F  — Fixer Agent (service-specific fix plan)
  Agent A  — Approval Agent (create approval item, ID)
  Agent AE — Approval Executor (check status, execute if approved)
  Agent KW — KB Writer Agent (write resolution to KB if executed)
  Agent H  — History Agent (audit trail to kpi_history.json)
  Agent MW — Memory Writer (store result, set confidence=0.3/0.6)
"""

import logging
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from grafana_agent import get_kpi_data
from kpi_agent import identify_priority_kpis
from service_identifier_agent import ServiceIdentifierAgent
from memory_agent import MemoryAgent
from log_agent import LogAgent
from rca_agent import RootCauseAgent
from fixer_agent import FixerAgent
from approval_agent import ApprovalAgent
from approval_executor_agent import ApprovalExecutorAgent
from kb_writer_agent import KBWriterAgent
from history_agent import HistoryAgent
from memory_writer import store_resolution

logger = logging.getLogger("pipeline_orchestrator")

CONFIDENCE_THRESHOLD = 0.75


class PipelineOrchestrator:
    def __init__(self):
        self.service_agent          = ServiceIdentifierAgent()
        self.memory_agent           = MemoryAgent()
        self.log_agent              = LogAgent()
        self.rca_agent              = RootCauseAgent()
        self.fixer_agent            = FixerAgent()
        self.approval_agent         = ApprovalAgent()
        self.approval_executor_agent = ApprovalExecutorAgent()
        self.kb_writer_agent        = KBWriterAgent()
        self.history_agent          = HistoryAgent()

        self.stats = {
            "total_runs": 0, "kpis_processed": 0,
            "fast_path_hits": 0, "deep_path_hits": 0,
            "kb_hits": 0, "llm_calls": 0,
            "fixes_proposed": 0, "avg_processing_time": 0.0
        }

    # ── Main pipeline ─────────────────────────────────────────────────────────
    def run_pipeline(self) -> Dict[str, Any]:
        start = time.time()
        self.stats["total_runs"] += 1
        # Reset per-run counters at start of every run
        # (kb_hits and llm_calls were accumulating across runs — fixed)
        run_kb_hits   = 0
        run_llm_calls = 0

        try:
            # Reload KB at start of every run so auto-written articles
            # from the previous run are picked up immediately
            from analysis_agent import get_kb
            get_kb(reload=True)
            logger.info("KB reloaded: %d articles", len(get_kb().articles))

            # ── Step 1: Fetch KPIs from Grafana (or dummy data) ───────────────
            raw_kpis = get_kpi_data()
            if not raw_kpis:
                return self._result([], start)

            # ── Step 2: Identify priority (breached) KPIs ─────────────────────
            # identify_priority_kpis returns top-N breached KPIs with
            # breach_count, peak_value, threshold, avg_excess_pct, hosts
            critical_kpis = identify_priority_kpis(raw_kpis)
            if not critical_kpis:
                logger.info("No KPI breaches detected")
                return self._result([], start)

            self.stats["kpis_processed"] += len(critical_kpis)

            # ── Step 3: Identify service for each KPI ─────────────────────────
            # ServiceIdentifierAgent checks: labels → instance → kpi_name
            # Also checks the 'service' field directly from the KPI record
            identified = []
            for kpi in critical_kpis:
                # Build full context for service identifier
                # The dummy_kpis.json has 'service' field — pass as labels hint
                # Step A: if KPI has a service field, use it directly (conf 0.99)
                # Step B: otherwise let ServiceIdentifierAgent infer from host/kpi_name
                service_hint = kpi.get("service", "").strip()

                if service_hint:
                    svc_result = {"service": service_hint.lower(), "confidence": 0.99, "source": "data_field"}
                else:
                    # host may be a list (from kpi_agent grouping) or a string
                    host_val = kpi.get("host", "") or kpi.get("hosts", [""])
                    if isinstance(host_val, list):
                        host_val = host_val[0] if host_val else ""
                    svc_result = self.service_agent.run({
                        "kpi_name": kpi.get("kpi_name", ""),
                        "labels":   None,
                        "instance": str(host_val)
                    })
                # Merge service identification result into KPI dict
                identified.append({**kpi, **svc_result})

            # ── Step 4: Memory check — fast path or deep path ─────────────────
            fast_results = []
            deep_kpis    = []

            for kpi in identified:
                mem = self.memory_agent.run({
                    "action":   "lookup",
                    "kpi_name": kpi["kpi_name"],
                    "service":  kpi.get("service", "unknown"),
                    "hosts":    kpi.get("hosts", ["unknown"])
                })

                if float(mem.get("confidence", 0)) >= CONFIDENCE_THRESHOLD:
                    # FAST PATH — high confidence cached resolution
                    logger.info("⚡ FAST PATH: %s/%s (conf=%.2f)",
                                kpi["kpi_name"], kpi.get("service"), mem["confidence"])
                    fast_results.append({
                        **kpi,
                        "path":             "fast",
                        "memory_hit":       True,
                        "confidence":       mem["confidence"],
                        "analysis":         mem.get("resolution", ""),
                        "analysis_source":  mem.get("source", "cache"),
                        "severity":         kpi.get("severity", "WARNING"),
                        "excess_pct":       kpi.get("avg_excess_pct", 0),
                        "fix_plan":         {},
                        "approval_id":      None,
                        "approval_status":  "n/a (fast path)",
                        "execution_status": "n/a (fast path)",
                        "rca_report":       "Resolved from memory cache.",
                    })
                    self.stats["fast_path_hits"] += 1
                else:
                    # DEEP PATH — full analysis needed
                    logger.info("🔍 DEEP PATH: %s/%s (conf=%.2f)",
                                kpi["kpi_name"], kpi.get("service"), mem.get("confidence", 0))
                    deep_kpis.append({**kpi, "path": "deep", "memory_hit": False})
                    self.stats["deep_path_hits"] += 1

            # ── Steps 5–10: Deep path processing ─────────────────────────────
            deep_results = []
            for kpi in deep_kpis:
                result = self._deep_path(kpi)
                deep_results.append(result)

            self.stats["fixes_proposed"] += len(deep_results)

            # Count per-run KB vs LLM hits from results
            for r in deep_results:
                if r.get("analysis_source") == "knowledge_base":
                    run_kb_hits += 1
                else:
                    run_llm_calls += 1

            # Timing
            elapsed = time.time() - start
            self.stats["avg_processing_time"] = (
                (self.stats["avg_processing_time"] * (self.stats["total_runs"] - 1) + elapsed)
                / self.stats["total_runs"]
            )

            return self._result(fast_results + deep_results, start,
                              run_kb_hits=run_kb_hits,
                              run_llm_calls=run_llm_calls)

        except Exception as exc:
            logger.exception("Pipeline failed")
            return self._result([], start, error=str(exc))

    # ── Deep path — runs Agents L → R → F → A → AE → KW → H → MW ────────────
    def _deep_path(self, kpi: Dict[str, Any]) -> Dict[str, Any]:
        kpi_name = kpi.get("kpi_name", "unknown")
        service  = kpi.get("service", "unknown")
        logger.info("Deep path: %s / %s", kpi_name, service)
        t0 = time.time()

        # Step 5 — Log Agent: find syslog lines matching this KPI
        logs_out = self.log_agent.run({"kpis": [kpi]})
        logs     = logs_out.get("logs", {}).get(kpi_name, [])

        # Step 6 — Root Cause Agent: KB search → LLM fallback
        rca = self.rca_agent.run({"kpi": kpi, "logs": logs})
        # Count per-run (tracked in run_pipeline via analysis_source in result)

        # Step 7 — Fixer Agent: build service-specific fix plan
        fix = self.fixer_agent.run({"rca_result": rca, "kpi": kpi})

        # Step 8 — Approval Agent: create approval item with unique ID
        approval = self.approval_agent.run({"fix_proposal": fix})

        # Step 9 — Approval Executor: check status, execute if approved
        executor = self.approval_executor_agent.run({
            "approval_id":     approval.get("approval_id"),
            "approval_status": approval.get("status"),
            "fix_plan":        fix.get("fix_plan", {}),
        })

        # Step 10a — KB Writer: write to KB only if execution succeeded
        kb_write = self.kb_writer_agent.run({
            "kpi_name":         kpi_name,
            "service":          service,
            "root_cause":       rca.get("root_cause", ""),
            "fix_plan":         fix.get("fix_plan", {}),
            "execution_status": executor.get("execution_status", "pending"),
            "execution_output": executor.get("execution_output", ""),
            "approval_id":      approval.get("approval_id"),
            # Pass analysis_source so KB writer knows whether to skip (already from KB) or write (from LLM)
            "analysis_source":  rca.get("analysis_source", "llm_generated"),
        })

        # Step 10b — History Agent: audit trail for every incident
        hosts = kpi.get("hosts", ["unknown"])
        for host in hosts:
            self.history_agent.run({
                "kpi_name":         kpi_name,
                "service":          service,
                "host":             host,
                "root_cause":       rca.get("root_cause", "")[:100],
                "fix_plan":         fix.get("fix_plan", {}),
                "approval_id":      approval.get("approval_id"),
                "approval_status":  approval.get("status"),
                "execution_status": executor.get("execution_status", "pending"),
                "execution_output": executor.get("execution_output", ""),
                "kb_id":            kb_write.get("kb_id"),
                "processing_time":  time.time() - t0,
            })

        # Step 10c — Memory Writer: store resolution for future fast-path
        # confidence=0.6 if executed successfully, 0.3 otherwise
        init_confidence = 0.6 if executor.get("execution_status") == "success" else 0.3
        store_resolution(
            kpi_name=kpi_name,
            service=service,
            host=hosts[0] if hosts else "unknown",
            resolution=rca.get("root_cause", ""),
            source=rca.get("analysis_source", "unknown"),
            kb_title=kb_write.get("kb_id"),
            initial_confidence=init_confidence,
        )

        return {
            "kpi_name":         kpi_name,
            "service":          service,
            "path":             "deep",
            "memory_hit":       False,
            "confidence":       init_confidence,
            "peak_value":       kpi.get("peak_value"),
            "threshold":        kpi.get("threshold"),
            "excess_pct":       kpi.get("avg_excess_pct", 0),
            "severity":         kpi.get("severity", "WARNING"),
            "hosts":            hosts,
            "analysis":         rca.get("root_cause", ""),
            "analysis_source":  rca.get("analysis_source", "unknown"),
            "rca_report":       rca.get("rca_report", ""),
            "fix_plan":         fix.get("fix_plan", {}),
            "approval_id":      approval.get("approval_id"),
            "approval_status":  approval.get("status"),
            "execution_status": executor.get("execution_status", "pending"),
            "execution_output": executor.get("execution_output", ""),
            "kb_id":            kb_write.get("kb_id"),
            "kb_status":        kb_write.get("kb_write_status"),
            "logs":             logs,
        }

    def _result(self, results: List[Dict], start: float,
                error: Optional[str] = None,
                run_kb_hits: int = 0,
                run_llm_calls: int = 0) -> Dict[str, Any]:
        return {
            "timestamp":               datetime.now().isoformat(),
            "processing_time_seconds": round(time.time() - start, 3),
            "kpis_processed":          len(results),
            "fast_path_hits":          sum(1 for r in results if r.get("path") == "fast"),
            "deep_path_hits":          sum(1 for r in results if r.get("path") == "deep"),
            "kb_hits":                 run_kb_hits,
            "llm_calls":              run_llm_calls,
            "fixes_proposed":          self.stats["fixes_proposed"],
            "pipeline_stats":          self.stats.copy(),
            "results":                 results,
            "error":                   error,
        }

    def get_stats(self) -> Dict:
        return self.stats.copy()


# Singleton orchestrator — keeps stats across requests
orchestrator = PipelineOrchestrator()

def run_pipeline() -> Dict[str, Any]:
    return orchestrator.run_pipeline()

def get_pipeline_stats() -> Dict[str, Any]:
    return orchestrator.get_stats()
