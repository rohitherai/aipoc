"""
basic_service_classifier.py — Basic Service Classifier
=======================================================

Provides basic service classification based on KPI names and host patterns.
Fast, lightweight classification without log analysis.
"""

import json
import logging
import os
from typing import Dict, List, Optional

logger = logging.getLogger("basic_service_classifier")
DEFAULT_SERVICES = ["smf", "upf", "amf", "pcf", "nrf", "nssf", "ausf", "oam"]


def load_services() -> List[str]:
    try:
        base = os.path.dirname(__file__)
        path = os.path.join(base, "data", "services.json")
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list) and data:
            return [str(x).lower() for x in data]
        logger.warning("data/services.json empty or invalid, falling back to defaults")
    except Exception:
        logger.debug("Could not load data/services.json; using defaults", exc_info=True)
    return DEFAULT_SERVICES


SERVICES = load_services()
SERVICES_REGEX = "|".join(SERVICES)

# ── Service classification rules ───────────────────────────────────────────────
# Format: (kpi_pattern, host_pattern, service_name)

SERVICE_PATTERNS: Dict[str, List[tuple]] = {
    "5G Core": [
        (rf"{SERVICES_REGEX}", rf"{SERVICES_REGEX}|core|5g", "5g_core"),
        (r"session.*failure|auth.*failure|attach.*failure|registration.*failure", r"", "5g_core"),
        (r"pfcp.*error|gtp.*loss|latency|jitter", r"", "5g_core"),
    ],
    "System": [
        (r"cpu.*usage|memory.*usage|disk.*io|load.*average|swap.*usage", r"host|node|vm|infra", "system"),
    ],
}

KNOWN_SERVICE_HOSTS: Dict[str, List[str]] = {
    "5g_core": SERVICES + ["core", "5g"],
    "system": ["host", "node", "vm", "baremetal", "infra"],
}


def classify_service_basic(kpi_name: str, host: str = "") -> Optional[str]:
    """
    Basic service classification based on KPI name and host patterns.
    Fast classification without log analysis.

    Returns the service name or None if not determinable.
    """
    import re

    # Check hostname patterns first (fastest)
    host_lower = host.lower()
    for service, patterns in KNOWN_SERVICE_HOSTS.items():
        if any(pat in host_lower for pat in patterns):
            logger.debug("Service classified from host '%s': %s", host, service)
            return service

    # Check KPI name patterns
    kpi_lower = kpi_name.lower()
    for service, rules in SERVICE_PATTERNS.items():
        for kpi_pattern, host_pattern, service_name in rules:
            if re.search(kpi_pattern, kpi_lower, re.IGNORECASE):
                if not host_pattern or re.search(host_pattern, host_lower, re.IGNORECASE):
                    logger.debug(
                        "Service classified: %s (KPI='%s', host='%s')",
                        service_name, kpi_name, host
                    )
                    return service_name

    logger.debug("Service not classified for KPI '%s' on host '%s'", kpi_name, host)
    return None


def enrich_kpis_with_basic_service(kpis: List[Dict]) -> List[Dict]:
    """
    Add basic service classification to a list of KPI records.
    """
    for kpi in kpis:
        service = classify_service_basic(
            kpi.get("kpi_name", ""),
            kpi.get("host", "")
        )
        kpi["service"] = service or "generic"
    return kpis


def get_service_summary_basic(enriched_kpis: List[Dict]) -> Dict[str, List[str]]:
    """Returns { service: [kpi_names] } — useful for logging and UI."""
    summary: Dict[str, List[str]] = {}
    for kpi in enriched_kpis:
        svc = kpi.get("service", "generic")
        summary.setdefault(svc, [])
        name = kpi.get("kpi_name", "")
        if name not in summary[svc]:
            summary[svc].append(name)
    return summary