"""
memory_writer.py — Memory Writer Agent
=======================================

Handles memory storage operations for new KPI resolutions.
Stores analysis results and updates confidence scores.
"""

import json
import logging
import os
from datetime import datetime, timezone
from typing import Dict, List, Optional

logger = logging.getLogger("memory_writer")

# ── Config ────────────────────────────────────────────────────────────────────
DYNAMODB_TABLE     = os.getenv("DYNAMODB_TABLE", "kpi_memory")
AWS_REGION         = os.getenv("AWS_REGION", "us-east-1")
LOCAL_FALLBACK_FILE  = os.path.join(os.path.dirname(__file__), "data", "kpi_memory.json")

# ── DynamoDB client (lazy) ────────────────────────────────────────────────────
_dynamo_table = None
_use_local    = False


def _get_table():
    """Get DynamoDB table resource. Falls back to local JSON silently."""
    global _dynamo_table, _use_local
    if _dynamo_table is not None:
        return _dynamo_table
    if _use_local:
        return None

    try:
        import boto3
        from botocore.exceptions import NoCredentialsError, ClientError

        aws_key    = os.getenv("AWS_ACCESS_KEY_ID", "")
        aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY", "")

        if not aws_key or not aws_secret:
            raise ValueError("AWS credentials not set in .env")

        dynamodb = boto3.resource(
            "dynamodb",
            region_name=AWS_REGION,
            aws_access_key_id=aws_key,
            aws_secret_access_key=aws_secret,
        )
        table = dynamodb.Table(DYNAMODB_TABLE)

        # Create table if it doesn't exist
        try:
            table.load()
            logger.info("DynamoDB table '%s' found", DYNAMODB_TABLE)
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                logger.info("Creating DynamoDB table '%s'...", DYNAMODB_TABLE)
                dynamodb.create_table(
                    TableName=DYNAMODB_TABLE,
                    KeySchema=[{"AttributeName": "kpi_key", "KeyType": "HASH"}],
                    AttributeDefinitions=[{"AttributeName": "kpi_key", "KeyType": "HASH"}],
                    BillingMode="PAY_PER_REQUEST",
                )
                table.wait_until_exists()
                logger.info("DynamoDB table created")
            else:
                raise

        _dynamo_table = table
        return _dynamo_table

    except Exception as exc:
        logger.warning(
            "DynamoDB not available (%s) — using local JSON fallback: %s",
            type(exc).__name__, LOCAL_FALLBACK_FILE
        )
        _use_local = True
        return None


# ── Local JSON fallback ───────────────────────────────────────────────────────

def _local_read() -> Dict:
    """Read from local JSON file."""
    os.makedirs(os.path.dirname(LOCAL_FALLBACK_FILE), exist_ok=True)
    if not os.path.exists(LOCAL_FALLBACK_FILE):
        return {}
    try:
        with open(LOCAL_FALLBACK_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _local_write(data: Dict):
    """Write to local JSON file."""
    os.makedirs(os.path.dirname(LOCAL_FALLBACK_FILE), exist_ok=True)
    with open(LOCAL_FALLBACK_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _local_get(kpi_key: str) -> Optional[Dict]:
    return _local_read().get(kpi_key)


def _local_put(kpi_key: str, item: Dict):
    data = _local_read()
    data[kpi_key] = item
    _local_write(data)


# ── Core memory operations ────────────────────────────────────────────────────

def _make_key(kpi_name: str, service: str, host: str) -> str:
    """Unique key per KPI + service + host combination."""
    return f"{kpi_name}::{service}::{host}"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def store_resolution(
    kpi_name:   str,
    service:    str,
    host:       str,
    resolution: str,
    source:     str,
    kb_title:   Optional[str] = None,
    initial_confidence: float = 0.5,
):
    """
    Store a new resolution for a KPI+service+host combination.
    Called after the first time a KPI is analyzed (deep path).
    Confidence starts at 0.5 — needs one success to reach fast-path threshold.
    """
    kpi_key = _make_key(kpi_name, service, host)
    table   = _get_table()

    item = {
        "kpi_key":       kpi_key,
        "kpi_name":      kpi_name,
        "service":       service,
        "host":          host,
        "confidence":    initial_confidence,
        "resolution":    resolution,
        "source":        source,
        "kb_title":      kb_title or "",
        "success_count": 0,
        "fail_count":    0,
        "last_seen":     _now(),
        "last_success":  "",
        "created_at":    _now(),
    }

    try:
        if table is not None:
            # DynamoDB uses Decimal for numbers — keep as string/float for simplicity
            table.put_item(Item=item)
        else:
            _local_put(kpi_key, item)

        logger.info(
            "Memory STORED: %s (source=%s, confidence=%.2f)",
            kpi_key, source, initial_confidence
        )
    except Exception as exc:
        logger.error("Memory store failed for %s: %s", kpi_key, exc)


def update_confidence(kpi_name: str, service: str, host: str, success: bool):
    """
    Update confidence score based on fix outcome feedback.

    success=True:  confidence +0.1 (max 1.0)
    success=False: confidence -0.2 (min 0.0)
    """
    kpi_key = _make_key(kpi_name, service, host)
    table   = _get_table()

    try:
        # Get current item
        if table is not None:
            response = table.get_item(Key={"kpi_key": kpi_key})
            item = response.get("Item")
        else:
            item = _local_get(kpi_key)

        if not item:
            logger.warning("Cannot update confidence for unknown KPI: %s", kpi_key)
            return

        current_confidence = float(item.get("confidence", 0.5))
        success_count = int(item.get("success_count", 0))
        fail_count = int(item.get("fail_count", 0))

        if success:
            new_confidence = min(current_confidence + 0.1, 1.0)
            success_count += 1
            item["last_success"] = _now()
            logger.info("Confidence INCREASED: %s → %.2f (+0.1)", kpi_key, new_confidence)
        else:
            new_confidence = max(current_confidence - 0.2, 0.0)
            fail_count += 1
            logger.info("Confidence DECREASED: %s → %.2f (-0.2)", kpi_key, new_confidence)

        item["confidence"] = new_confidence
        item["success_count"] = success_count
        item["fail_count"] = fail_count
        item["last_seen"] = _now()

        # Store updated item
        if table is not None:
            table.put_item(Item=item)
        else:
            _local_put(kpi_key, item)

    except Exception as exc:
        logger.error("Confidence update failed for %s: %s", kpi_key, exc)