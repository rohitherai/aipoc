"""
dashboard_server.py — AIOps NOC Dashboard Server
=================================================
Serves the hackathon_demo UI wired to the real pipeline.
Uses SSE for real-time step-by-step streaming.
Run: python dashboard_server.py
Open: http://localhost:5000
"""

from flask import Flask, jsonify, request, send_file, Response, stream_with_context
from pipeline_orchestrator import run_pipeline, get_pipeline_stats, PipelineOrchestrator
from vector_db_wrapper import VectorDBWrapper
from datetime import datetime
import json, os, logging, threading, time, uuid

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Execution store for SSE streaming ────────────────────────────────────────
execution_store = {}   # eid → {status, logs, path, confidence, ...}
execution_history = [] # list of completed runs

# ── CORS ──────────────────────────────────────────────────────────────────────
@app.after_request
def cors(r):
    r.headers["Access-Control-Allow-Origin"]  = "*"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type"
    r.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return r

def make_eid():
    eid = uuid.uuid4().hex[:8].upper()
    execution_store[eid] = {
        "status": "running", "logs": [], "path": None,
        "confidence": 0.0, "approved": False, "approval_required": False,
        "decision": None, "proposed_fix": None, "root_cause": None,
        "kpi_name": None, "service": None, "duration": 0.0,
    }
    return eid

def emit(eid, step, status, message, confidence=None, path=None):
    rec = execution_store.get(eid)
    if not rec:
        return
    entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "step": step, "status": status, "message": message,
        "confidence": confidence if confidence is not None else rec.get("confidence"),
        "path": path if path is not None else rec.get("path"),
    }
    rec["logs"].append(entry)
    if confidence is not None:
        rec["confidence"] = confidence
    if path is not None:
        rec["path"] = path

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
@app.route("/approval-cache")
@app.route("/approval-cache/")
@app.route("/approvalcache")
def index():
    # Try multiple locations to find hackathon_demo.html
    candidates = [
        os.path.join(SCRIPT_DIR, "hackathon_demo.html"),
        os.path.join(os.getcwd(), "hackathon_demo.html"),
        "hackathon_demo.html",
    ]
    for p in candidates:
        if os.path.exists(p):
            logger.info("Serving hackathon_demo.html from: %s", p)
            return send_file(os.path.abspath(p), mimetype="text/html", max_age=0)
    # Debug info
    logger.error("hackathon_demo.html NOT FOUND. SCRIPT_DIR=%s CWD=%s", SCRIPT_DIR, os.getcwd())
    logger.error("Files in SCRIPT_DIR: %s", os.listdir(SCRIPT_DIR))
    return f"<h1>hackathon_demo.html not found</h1><p>SCRIPT_DIR: {SCRIPT_DIR}</p><p>CWD: {os.getcwd()}</p><p>Files: {os.listdir(SCRIPT_DIR)}</p>", 404

@app.route("/api/inject-fault", methods=["POST", "OPTIONS"])
def inject_fault():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    data      = request.json or {}
    eid       = make_eid()
    kpi_name  = data.get("fault_type", "SMF_CPU_Usage")
    service   = data.get("service", "smf")
    force_fast = bool(data.get("force_fast", False))
    execution_store[eid]["kpi_name"]   = kpi_name
    execution_store[eid]["service"]    = service
    execution_store[eid]["force_fast"] = force_fast
    t = threading.Thread(target=_run_real_pipeline, args=(eid,), daemon=True)
    t.start()
    return jsonify({"status": "started", "execution_id": eid}), 202

@app.route("/api/stream/<eid>")
def stream_execution(eid):
    if eid not in execution_store:
        return jsonify({"error": "not found"}), 404
    def gen():
        last = 0
        while True:
            rec  = execution_store.get(eid, {})
            logs = rec.get("logs", [])
            while last < len(logs):
                yield f"data: {json.dumps({**logs[last], 'execution_id': eid})}\n\n"
                last += 1
            if rec.get("status") in ("done", "error"):
                break
            time.sleep(0.3)
        final = execution_store.get(eid, {})
        yield f"data: {json.dumps({'step':'__complete__','status':final.get('status','done'),'message':'execution finished','execution_id':eid,'path':final.get('path'),'confidence':final.get('confidence')})}\n\n"
    return Response(stream_with_context(gen()), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

@app.route("/api/approve", methods=["POST", "OPTIONS"])
def approve_execution():
    if request.method == "OPTIONS":
        return jsonify({}), 200
    data     = request.json or {}
    eid      = data.get("execution_id")
    decision = data.get("decision", "approve")
    rec      = execution_store.get(eid)
    if not rec:
        return jsonify({"status": "error", "message": "not found"}), 404
    rec["approved"]          = True
    rec["approval_required"] = False
    rec["decision"]          = decision
    emit(eid, "Approval", "completed",
         "Operator approved" if decision == "approve" else "Operator rejected")
    return jsonify({"status": "ok"})

@app.route("/api/pipeline-stats")
def pipeline_stats():
    try:
        stats = get_pipeline_stats()
        fast  = stats.get("fast_path_hits", 0)
        total = stats.get("total_runs", 0)
        return jsonify({
            "total_runs":      total,
            "hit_ratio":       round((fast / total * 100) if total else 0, 1),
            "fast_path_hits":  fast,
            "deep_path_hits":  stats.get("deep_path_hits", 0),
            "avg_fix_time":    round(stats.get("avg_processing_time", 0), 1),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/cache-status")
def cache_status():
    try:
        db  = VectorDBWrapper()
        val = db.validate_persistence()
        fast = sum(1 for ex in execution_history if ex.get("path") == "fast")
        tot  = len(execution_history)
        return jsonify({
            "status":        "success",
            "total_entries": val["total_records"],
            "hit_ratio":     round((fast / tot * 100) if tot else 0, 1),
            "last_update":   datetime.now().isoformat(),
            "message":       val["status_message"],
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/dashboard")
def dashboard_data():
    try:
        db  = VectorDBWrapper()
        val = db.validate_persistence()
        fast = sum(1 for ex in execution_history if ex.get("path") == "fast")
        tot  = len(execution_history)
        return jsonify({
            "status":           "success",
            "execution_history": execution_history[-10:],
            "db_status":        {"total_entries": val["total_records"],
                                  "path": val["db_path"], "is_valid": val["is_valid"]},
            "cache_metrics":    {"hit_ratio": round((fast/tot*100) if tot else 0, 1),
                                  "avg_cache_time": 0.05, "avg_deep_time": 16.5},
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/analyze", methods=["GET", "POST"])
def analyze():
    try:
        return jsonify(run_pipeline())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/kpis")
def get_kpis():
    """Return KPIs from dummy_kpis.json — the single source of truth."""
    try:
        path = os.path.join(SCRIPT_DIR, "data", "dummy_kpis.json")
        with open(path) as f:
            raw = json.load(f)
        kpis = []
        for k in raw:
            v   = float(k.get("value", 0))
            thr = float(k.get("threshold", 1))
            exc = round((v - thr) / thr * 100, 1) if v > thr else 0
            sev = "CRITICAL" if exc >= 50 else "HIGH" if exc >= 20 else "WARNING" if exc > 0 else "HEALTHY"
            kpis.append({
                "kpi_name":  k.get("kpi_name", ""),
                "value":     v,
                "threshold": thr,
                "host":      k.get("host", "unknown"),
                "service":   k.get("service", ""),
                "timestamp": k.get("timestamp", ""),
                "excess_pct": exc,
                "severity":  sev,
                "breached":  v > thr,
            })
        return jsonify({"kpis": kpis, "total": len(kpis), "ts": datetime.now().isoformat()})
    except Exception as e:
        return jsonify({"error": str(e), "kpis": []}), 500

@app.route("/health")
def health():
    return jsonify({"status": "healthy", "timestamp": datetime.now().isoformat()})

# ── Real pipeline streaming ────────────────────────────────────────────────────
def _run_real_pipeline(eid):
    rec   = execution_store[eid]
    start = time.time()

    try:
        # Step 1 — KPI received
        emit(eid, "KPI", "completed", f"KPI received: {rec['kpi_name']}")
        time.sleep(0.3)

        # Step 2 — Embedding
        emit(eid, "Embedding", "running", "Encoding KPI vector for ChromaDB lookup")
        time.sleep(0.8)
        emit(eid, "Embedding", "completed", "Embedding complete (hash-based fallback)")

        # Step 3 — Cache search (real ChromaDB)
        emit(eid, "Cache", "running", "Searching ChromaDB for cached resolution")
        time.sleep(0.5)

        # Step 4 — Run real pipeline
        emit(eid, "Decision", "running", "Running pipeline analysis...")

        orchestrator = PipelineOrchestrator()
        result       = orchestrator.run()

        results = result.get("results", [])
        if not results:
            emit(eid, "Decision", "completed", "No KPI breaches detected", confidence=1.0, path="fast")
            rec["status"] = "done"
            rec["duration"] = round(time.time() - start, 2)
            return

        first  = results[0]
        path   = first.get("path", "deep")
        conf   = float(first.get("confidence_score", 0.75))
        kpi_n  = first.get("kpi_name", rec["kpi_name"])
        svc    = first.get("service", rec["service"])
        rc     = first.get("root_cause", "")
        fix_pl = first.get("fix_plan", {})
        actions = fix_pl.get("actions", []) if fix_pl else []
        fix_str = " | ".join(actions[:2]) if actions else "Review and apply service-specific fix plan"

        rec["path"]       = path
        rec["confidence"] = conf
        rec["root_cause"] = rc
        rec["proposed_fix"] = fix_str

        # Emit cache result
        if path == "fast":
            emit(eid, "Cache", "completed", "Cache hit — stored resolution found", confidence=conf, path="fast")
            emit(eid, "Decision", "completed", "FAST PATH selected — no AI needed", confidence=conf, path="fast")
            emit(eid, "RCA", "skipped", "Skipped — using cached knowledge")
        else:
            emit(eid, "Cache", "completed", "Cache miss — routing to deep analysis", confidence=conf, path="deep")
            emit(eid, "Decision", "completed", "DEEP PATH selected — running AI analysis", confidence=conf, path="deep")
            emit(eid, "RCA", "running", "Analyzing with Capgemini LLM + Knowledge Base")
            time.sleep(1.0)
            emit(eid, "RCA", "completed", f"Root cause identified: {rc[:120]}")

        # Proposed fix
        emit(eid, "ProposedFix", "ready", fix_str)

        # Approval gate
        rec["approval_required"] = True
        emit(eid, "Approval", "waiting", "Operator approval required")

        # Wait for approval (max 120s)
        deadline = time.time() + 120
        while not rec.get("approved") and time.time() < deadline:
            time.sleep(0.4)

        if rec.get("decision") == "reject":
            emit(eid, "Execution", "completed", "Operator rejected fix — escalating to NOC")
            emit(eid, "Learning", "skipped", "Rejected fix — learning skipped")
            rec["status"]   = "done"
            rec["duration"] = round(time.time() - start, 2)
            execution_history.append({"path": path, "kpi": kpi_n, "service": svc,
                                       "duration": rec["duration"], "ts": datetime.now().isoformat()})
            return

        # Execute + store
        emit(eid, "Execution", "running", "Applying fix...")
        time.sleep(1.0)
        emit(eid, "Execution", "completed", "Fix applied successfully")

        # Post-approval storage (the fix from our previous work)
        emit(eid, "Learning", "running", "Storing resolution in ChromaDB...")
        try:
            first["approval_status"] = "approved"
            first["execution_status"] = "success"
            updated = orchestrator.post_approval_storage(first)
            if updated.get("stored_in_memory"):
                emit(eid, "Learning", "completed", "Resolution stored in ChromaDB — next run: FAST PATH")
            else:
                emit(eid, "Learning", "completed", "Storage attempted (check ChromaDB logs)")
        except Exception as se:
            emit(eid, "Learning", "completed", f"Storage note: {str(se)[:80]}")

        rec["status"]   = "done"
        rec["duration"] = round(time.time() - start, 2)
        execution_history.append({"path": path, "kpi": kpi_n, "service": svc,
                                   "duration": rec["duration"], "ts": datetime.now().isoformat()})

    except Exception as e:
        logger.exception("Pipeline stream error")
        emit(eid, "System", "error", str(e))
        rec["status"] = "error"

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    print(f"\n{'='*60}")
    print(f"  AIOps NOC Dashboard: http://localhost:{port}")
    print(f"  Real pipeline SSE:   POST /api/inject-fault")
    print(f"  Cache status:        GET  /api/cache-status")
    print(f"  Pipeline stats:      GET  /api/pipeline-stats")
    print(f"{'='*60}\n")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
